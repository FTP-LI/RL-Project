# 物理端点筛查 · high-mid

改变 foot_friction=1.3, vin_range=7.7，保持官方控制器和原滚翻、落地、前进门槛。

[冻结方案](protocol.json) · [运行状态](state.json) · [观察页](../../roll-domain-parameter-screen-live.html)
