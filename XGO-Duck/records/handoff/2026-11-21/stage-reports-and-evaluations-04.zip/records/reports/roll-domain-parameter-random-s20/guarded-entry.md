# 有界运行入口的离线验证

训练和仿真继续暂停。新入口将停止判断接入独立的收集循环，保留历史 S20 脚本与原记录。当前只进行了 CPU 回放和假环境测试，没有初始化 CUDA、执行物理步或访问真机。

## 改动与结果

| 检查 | 离线结果 |
| --- | --- |
| 滚翻门槛不可达 | 三个低摩擦原轨迹均在第 500 步停止；保存 501 个状态、500 个控制，不调用第 501 个控制步 |
| 安全与异常状态 | 构造的头部穿透、非有限值和无效四元数均在第 5 步停止，并保留该步状态 |
| 暂停请求 | 假环境在第 7 步记录后停止，不调用第 8 步 |
| 运行或观察器出错 | 测试在第 9 步物理调用后报错时区分 9 个实际调用和 8 条已记录控制；观察器报错后不继续下一步 |
| 臂间检查 | 功能门槛失败、安全结果异常或暂停时不进入下一臂 |
| 入口准入 | 当前暂停状态下，`zero` 和 `sample` 两种真实命令均在导入训练环境前返回 `pause-requested`，退出码均为 2 |

停止判定、循环和收集器分别见 [判定代码](../../../scripts/validation/roll_screen_stop_guard.py)、[循环代码](../../../scripts/validation/guarded_roll_loop.py) 和 [收集器代码](../../../scripts/validation/guarded_roll_collector.py)。测试使用已保存轨迹以及假环境、假策略、假视频与假观察器；因此只证明代码在这些输入下的行为，不证明实际 GPU 运行时已经通过。

## 入口范围

[名义入口](../../../scripts/validation/guarded_nominal_entry.py) 要求显式解除暂停、冻结协议、匹配源码和官方模型哈希，并验证观察入口和输出目录。采样前还要求与协议哈希一致的真实 CUDA 零步及实际 guard 状态检查。当前命令仍会拒绝运行。

该入口只接受脚底摩擦 1.0、供电 7.7 V 的名义配置；其他参数组合会被拒绝。参数因子注入、实际多臂调用和各臂初态匹配还没有实现或验证。零步入口本身也不会自动完成 guard 的 GPU 状态检查，必须另行生成独立证据。入口逐步读取暂停状态，性能开销尚未在实际仿真中测量。

## 复现核验

在 Windows 的 `XGO-Duck` 工程根目录执行以下命令，只读取保存轨迹并使用临时假环境，不会启动仿真。入口准入测试要求当前项目仍处于暂停状态：

```powershell
Set-Location 'C:\Users\atlas-win\Desktop\RL-Project\XGO-Duck'
py scripts/validation/verify_guarded_roll_loop.py
py scripts/validation/verify_guarded_roll_collector.py
py scripts/validation/verify_guarded_nominal_entry.py
```

[循环核验](guarded-loop-offline-verification.json) · [收集器核验](guarded-collector-offline-verification.json) · [入口准入核验](guarded-nominal-entry-offline-verification.json) · [后续对照草案](../../../configs/experiments/roll_parameter_matched_review_draft.json)
