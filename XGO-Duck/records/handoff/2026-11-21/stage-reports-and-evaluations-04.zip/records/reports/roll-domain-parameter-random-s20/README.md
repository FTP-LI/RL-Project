# 参数随机化筛查暂停记录

**离线复核后的解释：** 六组评分已从原始轨迹重新算出，但本组在落地站立阶段保留 25 步目标过渡，S17 已验收路线为 0 步；两批结果不能作为同控制器的参数对照。原协议的安全评分后停止规则也没有接入外层循环。 [离线复核](offline-review.md) · [机器记录](offline-review.json)

本阶段使用官方固定策略，8 个摩擦/供电组合预留 128 个并行环境和 1550 个控制步。每个臂使用一个固定参数组合，不是逐环境随机采样。没有 PPO 更新、没有模型修改、没有硬件 IO。首次运行因旧协议的源码哈希过期在零物理步停止，修复后只刷新当前脚本哈希并继续，原失败记录保留在 [failure-first-run.json](failure-first-run.json)。

## 已完成结果

| 参数臂 | 滚翻完成 | 进入前进 | 连续路线 | 结论 |
| --- | ---: | ---: | ---: | --- |
| 低摩擦 / 低电压 | 110/128 | 110/128 | 73/128 | 未过滚翻门槛 |
| 低摩擦 / 名义电压 | 108/128 | 108/128 | 0/128 | 未过滚翻门槛 |
| 低摩擦 / 高电压 | 112/128 | 112/128 | 0/128 | 未过滚翻门槛 |
| 中摩擦 / 低电压 | 125/128 | 125/128 | 125/128 | 通过 |
| 中摩擦 / 高电压 | 117/128 | 117/128 | 25/128 | 连续路线未通过 |
| 高摩擦 / 低电压 | 124/128 | 124/128 | 124/128 | 通过 |

每个完整臂都保存了 31 秒原片和按 50 控制步采样的关键帧：[低摩擦/低电压视频](../../evaluations/duck_roll-domain-parameter_low-low_s1240_20261114T113333/clip-step-0.mp4) · [低摩擦/名义电压视频](../../evaluations/duck_roll-domain-parameter_low-mid_s1240_20261114T113333/clip-step-0.mp4) · [低摩擦/高电压视频](../../evaluations/duck_roll-domain-parameter_low-high_s1240_20261114T113333/clip-step-0.mp4) · [中摩擦/低电压视频](../../evaluations/duck_roll-domain-parameter_mid-low_s1240_20261114T113334/clip-step-0.mp4) · [中摩擦/高电压视频](../../evaluations/duck_roll-domain-parameter_mid-high_s1240_20261114T113334/clip-step-0.mp4) · [高摩擦/低电压视频](../../evaluations/duck_roll-domain-parameter_high-low_s1240_20261114T113334/clip-step-0.mp4)。暂停的高摩擦/名义电压臂保留了 29 张 `frame-step-0.jpg` 至 `frame-step-1400.jpg`、状态和执行日志；部分 MP4 缺少 `moov` 索引，不能作为可播放原片，见[媒体检查](partial-media-audit.json)和[部分评估目录](../../evaluations/duck_roll-domain-parameter_high-mid_s1240_20261114T113334/)。

低摩擦行在三个电压点均未达到 116/128 的滚翻门槛；中、高摩擦的两个已完成臂通过了滚翻门槛，但中摩擦/高电压的连续路线只有 25/128。由于控制器、种子和单因素对照不完整，这些结果不能单独归因于摩擦或电压，也不能把整个参数区间认定为通过。

## 暂停位置

用户要求暂停时，`high-mid` 臂已完成 1400/1550 个控制步、179,200 条转移和 7,000 个物理子步，原始帧、状态和执行日志均已保存；该臂没有写出完整 `trace.npz` 或可恢复的物理检查点。其余 `high-high` 臂尚未启动。机器停止记录见 [stop-record.json](stop-record.json)，汇总见 [pause-summary.json](pause-summary.json)，六个完整臂的计数及视频哈希已通过[暂停核验](pause-verification.json)，原片仍在 `records/evaluations/` 中。

保持暂停。收到恢复指令后，先冻结与 S17 对齐的控制器、同种子标称对照和明确的停止规则，并完成离线及零步准入，再决定是否重跑 `high-mid` 或运行 `high-high`。中断臂不能从 1400 步恢复；在此之前不把 S20 标记为鲁棒性通过，也不启动新的 PPO。
