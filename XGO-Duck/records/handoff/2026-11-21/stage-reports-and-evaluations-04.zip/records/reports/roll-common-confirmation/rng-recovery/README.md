# 官方滚翻独立确认

本轮已关闭，开发A117/128、开发B116/128、独立留出112/128；留出未达到116次门槛，可靠性确认未通过。384个首次episode、172800个评价转移、零学习、无物理重置。seed2020已消费，不用于后续挑参数；真机未执行。

| 文件 | 用途 |
| --- | --- |
| [独立协议](../../../../configs/experiments/roll_common_rng_recovery.json) | 88份来源、相同判据、开发先行与条件留出 |
| [CPU准入](preflight.json) | 父87份来源不变，修复仅保护导入随机状态 |
| [实际GPU零步](startup/gpu-import-parity.json) | CPU/CUDA状态和物理初态不变，最大动作误差7.15×10⁻⁷ |
| [开发A](development-a-analysis.json) | seed1020，117/128 |
| [开发B](development-b-analysis.json) | seed1021，116/128 |
| [留出](heldout-analysis.json) | seed2020，112/128，不反复用于挑参数 |
| [总结果](analysis.json) | 未通过、实际预算、零学习及关闭结论 |
| [开发失败复盘](development-failure-review.json) | 23个开发失败的接触/旋转分类；后续假设只据开发数据 |
| [支撑损失时点](development-support-timing.json) | 两个开发种子，按原评分重建头顶接触前后离地旋转 |
| [头部支撑中断](development-contact-handoff.json) | 逐段复算最大离地转角、起止姿态和前后支撑部位 |
| [头部支撑几何](development-head-support-geometry.json) | 对齐约 160° 的前翻姿态，复算机身、颈部和头部俯仰对离地速度的贡献 |
| [脚掌触地复盘](development-foot-transfer.json) | 256 条开发轨迹、14 对先恢复头部接触样本、脚底网格距离及首次着地角度 |
| [支撑损失分段](development-head-recontact.json) | 沿用 14 个配对，逐段分解离地和侧倾损失 |
| [驱动余量](development-head-motor-envelope.json) | 重放 4 ms 延迟和内部限速，按供电两端点复算电机侧输出 |
| [颈部介入准入](neck-support-timing-preflight.json) | 计算离地前触发覆盖、局部几何方向和固定状态的电机力矩变化 |
| [图像来源](figure-review.json) | 原相机事件帧、qpos和视频哈希 |
| [实际播放](vscode-complete-playback.jpg) | 原VS Code播放完整9秒，尺寸与布局不变 |

三个预定相机环境0都成功，图片用于解释过程，不代替128次总体结果。原片完整0–9秒、226帧、25fps，无新增物理步。每组采样、录像与轨迹保存约48秒；完整可见任务含初始化和CPU复核约5分7秒，这不是PPO速度比较。

在头部支撑后离地的 15 个失败样本中，离地前的实际颈部及头部俯仰分别至少还有 30.8°、56.6° 的关节余量。两批各 450 个控制点的内部目标与实际缓冲及固件算法一致。在离地前最后一个头部支撑时刻，按场景 7.0–7.7 V 两端点计算，头部俯仰有 12/15 个失败样本、105/184 个成功样本达到 PWM 上限。失败样本的颈部俯仰均有余量。原轨迹未记录逐子步供电与摩擦，电机侧计算保留这一限制。

父协议在GPU随机状态守卫处停止，物理步0；[根因](../rng-root-cause.json)和[失败运行契约](../startup/runtime-contract.json)保持原记录。单独修复只在原导入函数外保护CPU/CUDA随机状态，所有原断言继续执行；固定种子复用是因为父协议没有任何动态episode，不计作新的独立样本。更早的启动脚本换行错误在Python前退出，见[记录](../launcher-repair.json)。

代码：[修复入口](../../../../scripts/validation/recover_roll_import_rng.py)、[批量采集](../../../../scripts/validation/collect_roll_confirmation.py)、[独立复算](../../../../scripts/validation/verify_roll_confirmation.py)。已结束的动态入口不能再次运行。只读复算已保存数据，在原可见VS Code的WSL终端运行：

```bash
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/recover_roll_import_rng.py --verify development-a
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/recover_roll_import_rng.py --verify development-b
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/recover_roll_import_rng.py --verify heldout
```

这只复核既有轨迹，不创建新留出episode。共同噪声/目标过渡、技能切换及扰动仍未通过，九类动作完整目标保持有效。

颈部支撑动态对照已结束。开发种子 1022 在零物理步退出，独立种子 1023 完成 170,240 条转移。候选 111/128，两次官方 116/128、114/128，未达到继续门槛。触发依赖仿真的精确接触传感器。 [动态结果与三段原片](../../roll-neck-support/README.md)

复算两批开发轨迹时，在工程目录执行以下命令。

```bash
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_roll_head_support_geometry.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_roll_head_motor_envelope.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/check_roll_neck_support_timing.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_roll_foot_transfer.py
```

脚掌触地复盘首次执行后保留原核验文件。两批配对的触地延迟中位差均为 0，失败组触地时已经少累计有效支撑旋转。分析范围是开发样本，保留原可靠性成绩及留出结果。
