# 滚翻接触计时评估

两批旧轨迹每 20 毫秒记录一次接触，配对复算把主要转角损失定位在最大离地段。本轮沿用官方固定模型、共同物理场景及原评分，在新的开发种子 1024 中检查 128 个首次 episode。 [旧轨迹分段](../roll-common-confirmation/rng-recovery/development-head-recontact.json) · [冻结方案](../../../configs/experiments/roll_contact_clock.json)

0.20–1.40 秒内，每次现有 4 毫秒物理步保存积分前后四元数、地面接触点数，以及地面、头部、左右脚掌的接触法向力。法向力来自求解器，取原始接触坐标的法向分量。用于诊断的载荷下限是机器人标称重量的 1%。分段脚本核对 4 毫秒姿态与原 20 毫秒边界逐位对齐。原评分继续使用原接触采样。 [CPU 检查](preflight.json)

实际 GPU 零步通过，采样进程与独立启动检查的姿态、速度、观测、接触和随机状态逐位相同。共执行 450 个批量控制步、2,250 个物理子步、57,600 条控制转移。0.20–1.40 秒的 300 个物理时点全部对齐，原评分为 109/128，低于 116/128。未使用留出数据，学习更新为零。 [独立核验](analysis.json) · [运行状态](coordinator.json)

15 个失败场景的最大离地段有完整采样。原信号标为离地的 45 个控制区间，在第 16 毫秒都没有地面法向力，在第 20 毫秒同姿态的下一次求解都有载荷。每段未承载子步比例的中位数为 20%。[边界核对](boundary-review.json) · [法向力图](../../../docs/reports/assets/roll-contact-clock-force.png)

7,552 个场景边界中，地面、头部、脚掌的原接触标记均与末子步积分前的接触点完全一致。地面原信号与积分后的同姿态接触点相差 548 次。CPU 使用实际 `ContactSensor` 复现了缓存。奖励可以先读取接触，随后前向更新虽刷新底层缓冲，原接口仍返回已经缓存的结果。直接读缓冲的辅助入口通过 CPU 验证。下一轮在同一轨迹并排保留两种读法，独立评估可靠性。 [缓存复现](sensor-cache-review.json) · [下一轮条件](../../../configs/experiments/roll_endpoint_readback_draft.json)

[9 秒原片](../../evaluations/duck_roll_contact-clock_development_s1024_20261109T221332/clip-step-0.mp4)为预先指定的环境 0，原判据通过，保留 226 帧。原 VS Code 实际播放至终点。 [运行截图](../../../docs/reports/assets/roll-contact-clock-terminal.jpg) · [播放截图](../../../docs/reports/assets/roll-contact-clock-playback.jpg)

一次性 VS Code 任务 `XGO-Duck · 滚翻接触计时评估` 已归档。下列首条为历史启动命令，冻结任务拒绝重复启动。其余命令只读已保存的轨迹，核验文件首次写入后保留。

```bash
bash scripts/training/training_workflow.sh roll-contact-clock
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_roll_contact_clock_boundaries.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/diagnose_roll_contact_sensor_cache.py
```
