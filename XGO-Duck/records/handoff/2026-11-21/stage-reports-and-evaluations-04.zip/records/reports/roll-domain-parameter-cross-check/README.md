# 滚翻物理端点交叉复验

本轮在单因素端点筛查后换用 seed 1190，使用同一 `ProjectedRollPolicy`、128 个 CUDA 环境、1,550 个控制步和原 116/128 门槛。四组均无学习更新，每组完成 198,400 次控制迁移、7,750 个物理子步和完整 31 秒原片。

| 组合 | 滚翻完成 | 连续前进成功 | 结论 |
| --- | ---: | ---: | --- |
| 标称 1.0 / 7.7 V | 123/128 | 122/128 | 通过 |
| 摩擦 1.3 / 7.7 V | 125/128 | 125/128 | 通过 |
| 摩擦 1.0 / 7.4 V | 124/128 | 124/128 | 通过 |
| 摩擦 1.3 / 7.4 V | 125/128 | 125/128 | 通过 |

四组均通过独立来源哈希、首步接口、接触回读、动作历史、连续门槛和视频完整性核验。结合上一轮单因素结果，可以把脚底摩擦 1.0–1.3、供电 7.4–7.7 V 作为参数随机化训练的候选区间；低摩擦 0.7 和高电压 8.0 V 仍排除在候选区间外。

这只是固定策略的物理鲁棒性证据，尚未证明随机化训练后的策略收益。下一步冻结短预算参数随机化训练：先做一个保持官方权重和奖励的零学习对照，再做受控小预算学习，记录随机化范围、更新数、显存、吞吐、真实短片和七指令、起身、滚翻回归结果。

## 证据

- [总分析](analysis.json) · [运行进度](progress.json) · [冻结结果](freeze.json)
- [交叉复验草案](../../../configs/experiments/roll_domain_parameter_cross_check_draft.json)
- [预检失败归档](preflight-failures/README.md)

完整记录和视频：

- [标称记录](../../evaluations/duck_roll-domain-parameter_nominal_s1190_20261113T221504/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_nominal_s1190_20261113T221504/clip-step-0.mp4)
- [高摩擦记录](../../evaluations/duck_roll-domain-parameter_friction-high_s1190_20261113T221504/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_friction-high_s1190_20261113T221504/clip-step-0.mp4)
- [低电压记录](../../evaluations/duck_roll-domain-parameter_voltage-low_s1190_20261113T221504/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_voltage-low_s1190_20261113T221504/clip-step-0.mp4)
- [交叉组合记录](../../evaluations/duck_roll-domain-parameter_corner-friction-high-voltage-low_s1190_20261113T221504/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_corner-friction-high-voltage-low_s1190_20261113T221504/clip-step-0.mp4)
