# 站立、前滚翻、站立、前进

同一物理环境完整采集。切换不重置，保留模型原始动作历史与实际执行器目标。

[方案](protocol.json) · [执行日志](execution.log) · [状态](state.json)
