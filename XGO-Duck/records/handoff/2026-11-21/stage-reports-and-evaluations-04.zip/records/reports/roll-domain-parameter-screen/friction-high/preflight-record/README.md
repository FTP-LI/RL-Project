# 物理端点筛查 · friction-high

单独改变 foot_friction 到 1.3，保持官方控制器和原滚翻、落地、前进门槛。

[冻结方案](protocol.json) · [运行状态](state.json) · [观察页](../../roll-domain-parameter-screen-live.html)
