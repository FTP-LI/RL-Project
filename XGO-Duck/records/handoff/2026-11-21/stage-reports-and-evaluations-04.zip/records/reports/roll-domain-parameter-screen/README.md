# 滚翻物理端点筛查

本轮使用 `ProjectedRollPolicy`、seed 1176、128 个并行环境和完整 1,550 个控制步。每组只改变一个物理因素，官方滚翻与行走 ONNX、动作历史、投影、20 ms 控制周期、接触读数和原始评分保持不变；没有学习更新，也没有真机输入。

## 结果

| 端点 | 改变量 | 滚翻完成 | 连续前进成功 | 门槛 | 结论 |
| --- | ---: | ---: | ---: | ---: | --- |
| 脚底摩擦低 | 0.7 | 106/128 | 0/128 | 116/128 | 未通过；第 500 步起滚翻门槛理论最多 106 个 |
| 脚底摩擦高 | 1.3 | 120/128 | 120/128 | 116/128 | 通过 |
| 供电低 | 7.4 V | 123/128 | 123/128 | 116/128 | 通过 |
| 供电高 | 8.0 V | 118/128 | 0/128 | 116/128 | 未通过；滚翻通过但连续前进全部未满足偏航条件 |

四组均完成 198,400 次控制迁移和 7,750 个物理子步，独立验证器通过来源哈希、首步接口、接触回读、动作历史和视频完整性检查。低摩擦组的“不可达”是完整采集中的诊断标记，不是提前停止；高电压组没有自动提前停止，连续前进失败来自原始评分。

## 可复查证据

- 总分析：[analysis.json](analysis.json)
- 运行进度：[progress.json](progress.json)
- 冻结协议：[freeze.json](freeze.json)
- 参数范围预检：[domain-parameter-ranges.json](../common-plant-screen/domain-parameter-ranges.json)
- 失败与修复归档：[preflight-failures/README.md](preflight-failures/README.md)

每组均保留完整轨迹、命令、接触数组、运行状态和 31 秒原片：

- 低摩擦：[记录](../../evaluations/duck_roll-domain-parameter_friction-low_s1176_20261113T214032/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_friction-low_s1176_20261113T214032/clip-step-0.mp4) · [关键帧](../../evaluations/duck_roll-domain-parameter_friction-low_s1176_20261113T214032/frame-step-250.jpg)
- 高摩擦：[记录](../../evaluations/duck_roll-domain-parameter_friction-high_s1176_20261113T214032/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_friction-high_s1176_20261113T214032/clip-step-0.mp4) · [关键帧](../../evaluations/duck_roll-domain-parameter_friction-high_s1176_20261113T214032/frame-step-250.jpg)
- 低电压：[记录](../../evaluations/duck_roll-domain-parameter_voltage-low_s1176_20261113T214032/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_voltage-low_s1176_20261113T214032/clip-step-0.mp4) · [关键帧](../../evaluations/duck_roll-domain-parameter_voltage-low_s1176_20261113T214032/frame-step-250.jpg)
- 高电压：[记录](../../evaluations/duck_roll-domain-parameter_voltage-high_s1176_20261113T214032/README.md) · [视频](../../evaluations/duck_roll-domain-parameter_voltage-high_s1176_20261113T214032/clip-step-0.mp4) · [关键帧](../../evaluations/duck_roll-domain-parameter_voltage-high_s1176_20261113T214032/frame-step-250.jpg)

## 解释与下一步

本轮说明固定策略对参数端点并非对称鲁棒：低摩擦破坏滚翻完成率，高电压保留滚翻却破坏滚翻后前进的偏航门槛。高摩擦和低电压端点通过，不能直接把整个矩形范围宣布为安全，也不能据此修改官方权重。

下一阶段采用通过端点的交叉组合（高摩擦/低电压及其与标称值的组合），使用新 seed 做一次独立复验；若组合仍通过，再把通过区间写入训练随机化候选，并以短学习预算和固定七指令、起身、滚翻回归门槛评估。失败组合保留原片和停止位置，当前官方权重继续作为回退。
