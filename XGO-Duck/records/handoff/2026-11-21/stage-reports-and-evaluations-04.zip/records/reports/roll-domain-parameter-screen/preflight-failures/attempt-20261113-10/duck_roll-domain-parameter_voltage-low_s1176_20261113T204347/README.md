# 物理端点筛查 · voltage-low

单独改变 vin_range 到 7.4，保持官方控制器和原滚翻、落地、前进门槛。

[冻结方案](protocol.json) · [运行状态](state.json) · [观察页](../../roll-domain-parameter-screen-live.html)
