import json,hashlib,shutil
from pathlib import Path
from datetime import datetime,timezone
root=Path('/mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck')
record=root/'records/experiments/baseline_continuation_20261101T101809_s42'
path=record/'training-completion-check.json'
check=json.loads(path.read_text())
original=check['input_sha256']
labels=['training-result.json','exit-code.txt','log-tensorboard-check.json','final-checkpoint-check.json','plot-check.json','curriculum-check.json','media-manifest.json','live-media-check.json','export-readiness.json']
assert len(original)==len(labels)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for src,expected in original.items():
    assert sha(root/src)==expected,src
frozen=record/'resume-verification/20261101T060522460407Z/training-completion-inputs'
frozen.mkdir(exist_ok=False)
frozen_hashes={}
mapping={}
for (source,expected),name in zip(original.items(),labels):
    target=frozen/name
    shutil.copy2(root/source,target)
    assert sha(target)==expected
    key=str(target.relative_to(root))
    frozen_hashes[key]=expected
    mapping[source]=key
check['input_original_paths']=mapping
check['input_sha256']=frozen_hashes
check['evidence_frozen_at']=datetime.now(timezone.utc).isoformat()
check['evidence_snapshot_reason']='Task 19 reruns the final checkpoint verifier; preserve the training closure evidence before that mutable verifier output is rewritten.'
path.write_text(json.dumps(check,indent=2)+'\n')
print(json.dumps({'status':'passed','frozen_inputs':len(mapping),'completion_check_sha256':sha(path),'directory':str(frozen)},indent=2))

