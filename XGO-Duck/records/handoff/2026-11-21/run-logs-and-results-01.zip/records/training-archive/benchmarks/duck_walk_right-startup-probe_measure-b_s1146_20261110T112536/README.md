# 原生右转采样

固定权重，测量原生回报、自动重置和净采样吞吐。

[冻结方案](../../../configs/experiments/common_walk_right_startup_probe.json) · [运行观察](../../walk-right-startup-measure-b-live.html)
