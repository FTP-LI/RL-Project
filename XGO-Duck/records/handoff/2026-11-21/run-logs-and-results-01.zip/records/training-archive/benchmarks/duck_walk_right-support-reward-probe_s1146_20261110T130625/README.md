# 右转原生奖励接线

[冻结方案](../../../configs/experiments/common_walk_right_support_reward_probe.json) · [运行观察](../../walk-right-support-reward-probe-live.html)
