# 起身 PPO 零步检查

在本机 RTX 3080 Laptop 上顺序初始化 1,536 和 3,072 个起身环境。两组使用同一自训父检查点、继承的 actor 与 critic Adam 状态、均匀的四姿态及同一场景接口。逐组核验实际 CUDA 张量、初始动作偏差、场景数组和物理随机状态。这里的显存来自环境仍在进程中时的整卡读数。 [冻结方案](../../../configs/experiments/local_getup_ppo_preflight.json) · [离线数值准入](../../reports/getup-success-step-control/adaptive-replay-archives.json)

本检查不推进物理，不运行 PPO 更新。两组完整回合、训练显存峰值及动作质量留给下一次实际对照。

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
flock -n "$HOME/XGO-Duck/training.lock" "$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python" \
  -B scripts/validation/preflight_local_getup_ppo.py
```

## 结果

| 环境数 | 显存读数 | 判定 |
| ---: | ---: | --- |
| 1,536 | 6,747 MiB / 16,384 MiB | 通过 |
| 3,072 | 11,927 MiB / 16,384 MiB | 通过 |

两组核验到相同父权重与 Adam 步数，父模型 SHA-256 一致。初始化检查点与起点数据哈希已复核。实际学习显存仍待验证。 [总结果](summary.json) · [对照日志](control.log) · [高并行日志](throughput.log)
