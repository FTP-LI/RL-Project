# 右转原生接触采样 · measure-b

[冻结方案](../../../configs/experiments/common_walk_right_support_yaw_probe.json) · [运行观察](../../walk-right-support-yaw-probe-measure-b-live.html)
