# 训练记录归档

日常先打开[权重与迭代记录](../../artifacts/delivery/iteration_record.md)。本目录集中保存训练、评估、基准及性能诊断的原始批次。

2026-11-14 的当前文件数量、空间占用、重复内容与保留原因见[训练资料存储盘点](../reports/storage-review-20261114/README.md)。

归档文件的逐项路径、大小和哈希见[训练归档完整清单](../reports/progress-archive-20261114/training-files/README.md)；它只覆盖本 Windows 实体目录，不覆盖 WSL 训练日志。

| 归档目录 | 初次归档文件数 | 内容 |
| --- | ---: | --- |
| `experiments/` | 3,524 | 训练日志、源码快照、轨迹、保存点与录像 |
| `evaluations/` | 6,075 | 动作评估原始数据、评分和录像 |
| `benchmarks/` | 477 | 环境数、渲染和观察开销对照 |
| `profiling/` | 74 | 采样分解和性能时间线 |

四个实体目录在本归档下保存。`records/` 的旧入口通过 Windows 目录联接读取同一批文件，报告和当前冻结协议继续用旧相对路径。VS Code 的项目设置隐藏这些兼容入口及旧权重目录。早期原始 WSL 保存点仍在 `~/XGO-Duck/workspace/xgoduck_rl/logs/rsl_rl/`，归档记录使用原路径定位它们。 [归档清单](manifest.json) · [哈希复核](verification.json)

最新的低摩擦承重转正批次已完成两组训练、权重复核与三组动作对照。按批次索引可查看环境数、曲线、保存点和实际原片。[最新训练和动作证据](../reports/nominal-skill-composition/low-friction-early-transfer-authority/loaded-upright-ppo/README.md) · [当前训练记录](../training-current.md) · [11月16日暂停归档](../reports/pause-archive-20261116/README.md)

## 查阅与恢复

后续训练和评估写入同一归档入口。起身回放覆盖的两组训练、三组评估和后退两批执行器评估已在对应报告中索引。 [起身训练](../reports/getup-side-to-supine-replay/training/README.md) · [起身评估](../reports/getup-side-to-supine-replay/evaluation/README.md) · [后退评估](../reports/common-walk-backward-actuator-support/README.md)

右转支撑奖励的接线、共享价值、两组策略训练和七指令评估按批归档。阶段索引给出原片、训练曲线、保存点的核验记录和退出日志。 [右转阶段索引](../reports/common-walk-right-support-yaw-training/README.md)

直接打开归档内的批次即可查看日志和原片。较早的少数复现脚本要求旧目录为实体目录，运行这些命令前，在 Windows 工程根目录用 PowerShell 恢复。

```powershell
$archiveDigest = (Get-Content -Raw -LiteralPath 'records/training-archive/verification.json' | ConvertFrom-Json).manifest_sha256
& '.\scripts\validation\training_record_archive.ps1' -Action Restore -ManifestSha256 $archiveDigest
```

复盘结束后，用同一命令的 `-Action Archive` 归回。归档状态下可执行 `python -B scripts/validation/training_record_archive.py verify`，核对归档时的文件内容与兼容入口。迁移到原生 Ubuntu 时，将四个实体目录放到目标工程 `records/` 的对应位置，供历史脚本按原路径读取。
