# 起身末层候选评估

从同一释放快照比较两路父策略与候选。

[冻结方案](protocol.json) · [运行观察](../../getup-teacher-head-s1162-live.html) · [执行日志](execution.log)
