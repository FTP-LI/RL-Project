# 仰卧锁存起身评估

同一释放快照的三路固定策略。

[冻结方案](protocol.json) · [运行观察](../../getup-teacher-head-latch-s1163-live.html) · [日志](execution.log)
