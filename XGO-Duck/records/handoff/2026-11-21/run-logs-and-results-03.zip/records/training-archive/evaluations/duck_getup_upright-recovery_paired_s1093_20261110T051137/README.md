# 仰卧转正配对试验

三路从同一物理释放开始，两路原策略作为参照。

[冻结方案](../../../configs/experiments/getup_upright_recovery_pair.json) · [状态](evaluation.json) · [日志](execution.log)
