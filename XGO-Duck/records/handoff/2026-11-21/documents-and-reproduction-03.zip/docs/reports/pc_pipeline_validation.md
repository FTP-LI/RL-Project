# 电脑端流程验证

验收日期：2026-10-31。

电脑端已完成官方短训练、单项奖励修改训练、两组 ONNX 导出、数值一致性和 ONNX 闭环仿真检查，并通过独立 ONNX Runtime 1.22.1 接口检查。两组都只训练 5 次迭代，本轮证明开发流程可运行，不能据此认定稳定行走、性能改善或实机可部署。本次验收时机器人尚未装配；2026-11-01 用户已确认装配完成，后续状态与全流程见 [主报告](development_report.md)。

## 环境

| 项目 | 实测配置 |
| --- | --- |
| 主机 | Windows 11，Ryzen 9 5900HX，约 64 GB 内存 |
| GPU | RTX 3080 Laptop，16 GB 显存 |
| Linux | WSL 3.0.3.0，Ubuntu 24.04.5，用户 atlas |
| 训练栈 | Python 3.12.3，PyTorch 2.9.1，mjlab 1.3.0，Warp 1.12.0，MuJoCo 3.10.0 |
| 数值检查 | Linux ONNX Runtime 1.24.4；Windows 独立环境 1.22.1 |
| 官方训练提交 | `fa621fc77ad9a05d69da13270e86118bdd3603fe` |

Ubuntu 24.04 是本机选型，官方没有指定该发行版。安装期间修复了 WSL NAT 无法访问本机代理的问题，改为镜像网络；用户确认优先镜像后，使用清华下载地址，并保留官方依赖版本与哈希。安装后恢复原锁文件，离线同步通过。所有操作集中在可见终端，详细日志见 [部署记录](../../records/deployment/2026-10-31/README.md)。

## 结果

两组均使用 `Mjlab-Velocity-Flat-XgoDuck`、256 个环境、seed 42、5 次迭代；最终 checkpoint 为迭代编号 4。唯一源码变化是 XGO-Duck 的线速度跟踪奖励权重 `3.0 → 3.3`。

| 检查项 | 官方基线 | 修改组 |
| --- | --- | --- |
| 运行标识 | `baseline_smoke_20261031T230120` | `candidate_smoke_20261031T230835` |
| 保存配置中的奖励权重 | 3.0 | 3.3 |
| 训练退出码 | 0 | 0 |
| checkpoint 张量检查 | 76 个，全部有限 | 76 个，全部有限 |
| ONNX 闭环仿真 | 1000 帧 | 1000 帧 |
| 超过数值容差的帧数 | 0 | 0 |
| 最大动作绝对误差 | 1.7881 × 10⁻⁷ | 1.4901 × 10⁻⁷ |
| 回放重置次数，含超时 | 1 | 6 |
| Runtime 1.22.1 图与合成输入检查 | 通过 | 通过 |
| 接口 | float32，61 维输入、14 维输出 | float32，61 维输入、14 维输出 |
| ONNX 格式 | IR 8，opset 18 | IR 8，opset 18 |

数值检查让 ONNX 输出驱动实际仿真，同时在相同原始观测上运行 checkpoint actor，容差为 `atol=1e-5, rtol=1e-4`。输出有限且误差通过，并不等于步态质量通过。修改组本次重置更多，不能宣称修改改善了控制效果；重置包含 episode 超时，也不能直接当作跌倒率。

证据分别保存在 [基线训练检查](../../records/experiments/baseline_smoke_20261031T230120/training-summary.json)、[基线导出检查](../../records/experiments/baseline_smoke_20261031T230120/export-validation.json)、[修改组训练检查](../../records/experiments/candidate_smoke_20261031T230835/training-summary.json) 和 [修改组导出检查](../../records/experiments/candidate_smoke_20261031T230835/export-validation.json)。相同目录下保留实际参数、完整日志与 Runtime 兼容报告。

## 仿真画面

以下是本机 Viser 回放的实际截图，暂停后调整了观察视角。单帧画面仅用于记录模型加载与可视化，不作为行走能力的证明。

![官方基线回放](../../records/experiments/baseline_smoke_20261031T230120/screenshots/01_simulation.jpg)

![修改组回放](../../records/experiments/candidate_smoke_20261031T230835/screenshots/01_simulation.jpg)

## 产物与目录

可审查模型分别位于 [基线模型包](../../artifacts/baseline_smoke_20261031T230120/README.md) 和 [修改组模型包](../../artifacts/candidate_smoke_20261031T230835/README.md)。每个包包含 `policy.onnx`、来源清单和实际导出接口；均标明尚未通过实机验收。

Linux 开发副本仍位于 `/home/atlas/XGO-Duck/workspace/xgoduck_rl`，当前保留修改组的 3.3 权重。checkpoint、TensorBoard 事件和 1000 帧观测/动作轨迹保存在该副本的 `logs/rsl_rl/xgoduck_velocity/` 中，Windows 实验清单记录了完整路径和 SHA-256。原始归档的 390 个文件全部复核通过，开发副本仅有计划中的一个源码文件不同，详见 [完整性记录](../../records/experiments/workspace-integrity.json)。

文档、脚本、实验定义、执行证据和模型分别归入 `docs/`、`scripts/`、`configs/`、`records/`、`artifacts/`。缓存、虚拟环境和模型不混入官方归档，大文件不纳入普通 Git 提交。

## 继续执行

在已有可见 Ubuntu 终端加载环境并回放修改组：

```bash
source /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/setup/project_environment.sh
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
uv run --locked --offline play Mjlab-Velocity-Flat-XgoDuck \
  --checkpoint-file logs/rsl_rl/xgoduck_velocity/2026-10-31_23-08-52_candidate_smoke_20261031T230835/model_4.pt \
  --num-envs 1 --viewer viser
```

当前开发副本已修改，不要直接重跑要求基线一致的首次部署脚本。若要恢复官方配置，在开发副本中先执行 `git apply -R --check`，检查通过后再执行 `git apply -R`，两条命令均指向项目的 `configs/experiments/velocity_tracking.patch`。现有模型和实验记录保留。

下一阶段先做充分训练与固定条件评估，基线和修改组采用相同预算、至少 3 个 seed，比较速度误差、存活时间、跌倒、动作变化和脚底滑移。装配完成后先跑官方预训练实机基线，再对齐关节映射、零位、默认姿态、时序与反馈延迟；通过纯推理和托举检查后再做低速试走。完整步骤与验收条件见 [开发路线](../development_roadmap.md) 和 [操作说明](../runbooks/pc_training.md)。

