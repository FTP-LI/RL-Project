# 原生奖励读回检查

固定策略采样一个完整起身回合，核对实际奖励与重置。

[冻结方案](../../../configs/experiments/getup_early_support_native_reward.json) · [状态](state.json) · [协调日志](../../reports/getup-early-support-native-reward/candidate.log)
