# 起身早期支撑 · control

[冻结方案](../../../configs/experiments/getup_early_support_ppo_recovery.json) · [运行观察](../../getup-early-support-ppo-recovery-live.html) · [逐次更新](observation.json) · [执行日志](../../reports/getup-early-support-ppo-recovery/control-execution.log)
