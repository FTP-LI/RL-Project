# 低摩擦仰卧起身｜原奖励对照

[冻结配置](../../../configs/experiments/nominal_low_friction_support_ppo.json) · [完整指标](observation.json) · [起身原片索引](clips.json)
