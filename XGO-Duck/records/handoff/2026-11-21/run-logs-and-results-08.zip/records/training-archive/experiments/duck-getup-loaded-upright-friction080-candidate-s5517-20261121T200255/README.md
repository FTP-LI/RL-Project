# 低摩擦起身｜承重后转正候选

[训练配置](../../../configs/experiments/nominal_low_friction_loaded_upright_ppo.json) · [逐次指标](observation.json) · [原片索引](clips.json)
