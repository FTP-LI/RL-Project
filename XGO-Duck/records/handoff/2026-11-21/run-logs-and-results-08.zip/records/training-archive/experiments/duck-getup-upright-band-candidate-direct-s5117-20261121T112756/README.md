# 仰卧起身配对训练 · 新增转正奖励

[实际冻结方案](../../../configs/experiments/nominal_supine_upright_band_candidate_authorization.json) · [逐次指标](observation.json) · [原片索引](clips.json)
