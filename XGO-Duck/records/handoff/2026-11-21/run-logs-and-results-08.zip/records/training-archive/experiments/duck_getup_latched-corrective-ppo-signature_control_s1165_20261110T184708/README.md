# 起身纠正回放 · control

[冻结方案](../../../configs/experiments/getup_latched_head_corrective_ppo_signature.json) · [运行观察](../../getup-latched-head-corrective-ppo-signature-live.html) · [逐次更新](observation.json) · [执行日志](../../reports/signature-recovery/control-execution.log)
