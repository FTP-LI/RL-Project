# 起身训练记录

运行：`duck_getup_auth-canonical_e3072_s3265_20261116T021829`。相同起身训练的固定路径解析开销对照

[冻结方案](../../../configs/experiments/observed_getup_path_pair_20261116.json) · [本机状态](../../reports/getup-canonical-path-20261116/training/throughput/native-view/native-status.txt) · [最终记录](../../reports/getup-canonical-path-20261116/training/throughput/final-view/native-status.txt) · [指标](observation.json) · [执行日志](../../reports/getup-canonical-path-20261116/training/throughput/execution.log)

画面来自本次实际采样；动作效果和保存点完整性需要单独核验。
