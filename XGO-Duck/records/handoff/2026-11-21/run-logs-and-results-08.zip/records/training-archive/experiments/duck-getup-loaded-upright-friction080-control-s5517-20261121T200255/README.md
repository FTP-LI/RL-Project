# 低摩擦起身｜原奖励对照

[训练配置](../../../configs/experiments/nominal_low_friction_loaded_upright_ppo.json) · [逐次指标](observation.json) · [原片索引](clips.json)
