# 起身训练记录

运行：`duck_getup_auth-sync_e3072_s3266_20261116T095241`。同预算训练检查调度对照；记录原始指标、完整动作和分段耗时

[冻结方案](../../../configs/experiments/observed_getup_monitor_pair_20261116.json) · [本机状态](../../reports/getup-monitored-authorization-20261116/training/control/native-view/native-status.txt) · [最终记录](../../reports/getup-monitored-authorization-20261116/training/control/final-view/native-status.txt) · [指标](observation.json) · [执行日志](../../reports/getup-monitored-authorization-20261116/training/control/execution.log)

画面来自本次实际采样；动作效果和保存点完整性需要单独核验。
