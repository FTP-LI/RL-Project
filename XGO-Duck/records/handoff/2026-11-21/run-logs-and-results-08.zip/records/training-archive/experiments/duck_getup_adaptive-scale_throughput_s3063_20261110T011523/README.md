# 起身 PPO · 3,072 环境

同父点、同动作阈值、同样本预算的本机对照。曲线来自实际逐次更新，录像来自环境 0。

[冻结方案](../../../configs/experiments/local_getup_ppo.json) · [运行观察](../../training-live.html) · [数值记录](observation.json) · [执行日志](execution.log)
