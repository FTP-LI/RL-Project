# 仰卧起身配对训练 · 原奖励

[实际冻结方案](../../../configs/experiments/nominal_supine_upright_band_training_observation_recovery.json) · [逐次指标](observation.json) · [原片索引](clips.json)
