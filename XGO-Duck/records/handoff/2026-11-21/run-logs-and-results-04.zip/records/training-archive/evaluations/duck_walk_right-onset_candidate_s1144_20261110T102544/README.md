# 右转启动对照 1144-candidate

[冻结方案](../../../configs/experiments/common_walk_routed_right_onset.json) · [运行观察](../../walk-right-onset-1144-candidate-live.html)
