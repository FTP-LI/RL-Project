# 前进反馈对照 · 1152 · 父策略 · 0.12

[冻结方案](../../../configs/experiments/common_walk_right_support_forward_margin.json) · [运行观察](../../walk-forward-margin-parent012-s1152-live.html)
