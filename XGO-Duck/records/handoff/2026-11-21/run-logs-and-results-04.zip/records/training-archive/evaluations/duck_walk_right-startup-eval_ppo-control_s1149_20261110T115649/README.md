# 七指令评估 · 1149 · 原奖励训练

[冻结方案](../../../configs/experiments/common_walk_right_startup_seven_command.json) · [运行观察](../../walk-right-startup-eval-1149-ppo-control-live.html)
