# 连续方向反馈短试验

[冻结方案](../../../configs/experiments/common_walk_forward_yaw_direction_pilot.json) · [运行观察](../../walk-forward-yaw-direction-pilot-live.html)

三组共 96,768 条转移，四秒门槛通过。实际运行命令、退出码、首回合轨迹和观察日志与本目录的运行编号一致。原片拍摄固定的后退场景，前进并排图由保存姿态重放。 [独立评分](../../reports/common-walk-right-support-yaw-training/yaw-direction-pilot/analysis.json) · [前进关键帧](../../reports/common-walk-right-support-yaw-training/yaw-direction-pilot/forward-direction-keyframes.jpg) · [分支记录](fork-readback.json)
