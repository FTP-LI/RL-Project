# 七指令评估 · 1149 · 父策略

[冻结方案](../../../configs/experiments/common_walk_right_startup_seven_command.json) · [运行观察](../../walk-right-startup-eval-1149-routed-parent-live.html)
