# 七指令评估 · 1141 · 欠速训练

[冻结方案](../../../configs/experiments/common_walk_right_startup_seven_command.json) · [运行观察](../../walk-right-startup-eval-1141-ppo-candidate-live.html)
