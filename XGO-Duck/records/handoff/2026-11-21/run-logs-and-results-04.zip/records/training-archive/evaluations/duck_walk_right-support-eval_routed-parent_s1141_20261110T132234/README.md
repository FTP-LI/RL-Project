# 右转支撑七指令 · 1141 · 父策略

[冻结方案](../../../configs/experiments/common_walk_right_support_seven_command.json) · [运行观察](../../walk-right-support-eval-1141-routed-parent-live.html)
