# 后退 PPO 显存核验

实际采样、回报和梯度计算，官方权重固定。

[冻结方案](../../../configs/experiments/common_walk_backward_ppo_headroom.json) · [运行观察](../../walk-backward-ppo-headroom-live.html)

## 计算结果

3,072 环境完成 216 个控制步，共 663,552 条实际转移。热身后执行 5 批真实采样，每批 4 个 PPO 小批量。采样使用固定官方权重和 0.05 标准差。两组共享原生奖励、价值损失及六指令保留样本，候选只在策略损失中对停滞样本加权。本轮记录到 2,668 条加权样本。 [梯度与损失](gradient-metrics.json) · [执行日志](execution.log) · [命令](command.txt)

实际前向和反向的显存峰值为 12,476 / 16,384 MiB。两份 Adam 状态按参数尺寸预留，距 85% 上限仍有 1,450 MiB，高于预设的 256 MiB 余量。每批梯度计算用时约 0.05–0.12 秒。 [显存采样](gpu-telemetry.json) · [结果](analysis.json)

价值目标的独立复算最大误差为 1.49×10⁻⁶，实际结束回合的回报边界通过核验。策略和价值网络的前后哈希均一致，优化器步数为零。Windows 端读到 10 次带真实帧的运行中状态，原片覆盖 0–4 秒，共 101 帧。 [独立核验](verification.json) · [完整原片](clip-step-0.mp4) · [观察核验](windows-view-verification.json)

下一阶段使用完整原生首回合拟合两路共用的价值起点。 [价值拟合方案](../../../configs/experiments/common_walk_backward_shared_value_draft.json)
