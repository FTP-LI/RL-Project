# 连续方向反馈独立开发复验

[冻结方案](../../../configs/experiments/common_walk_forward_yaw_direction_fresh.json) · [进度、曲线和四秒原片](../../walk-forward-yaw-direction-fresh-live.html)

两条参照与方向反馈均完成七项各 32 个首回合。方向反馈较两次参照的前进平均绝对偏航各下降 0.00720、0.00618 rad/s。首次读回摘要错误与修复日志按原顺序保存。 [独立评分](../../reports/common-walk-right-support-yaw-training/yaw-direction-fresh/analysis.json) · [Windows 观察](windows-view-verification.json)
