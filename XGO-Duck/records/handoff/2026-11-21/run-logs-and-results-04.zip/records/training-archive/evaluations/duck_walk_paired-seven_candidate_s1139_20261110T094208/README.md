# 七指令评估 1139-candidate

[冻结方案](../../../configs/experiments/common_walk_backward_paired_eval.json) · [运行观察](../../walk-backward-paired-eval-1139-candidate-live.html)
