# 右转早期切换 · 实际切换

[冻结方案](../../../configs/experiments/common_walk_early_official_right_recovery.json) · [运行观察](../../walk-early-official-right-recovery-early-official-live.html)
