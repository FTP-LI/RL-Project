# 前进偏航重复对照

各路前两秒为诊断录像。

[冻结方案](../../../configs/experiments/common_walk_right_support_forward_retention.json) · [运行观察](../../walk-right-support-forward-repeatability-live.html)
