# 连续方向反馈最终留出

[冻结方案](../../../configs/experiments/common_walk_forward_yaw_direction_holdout.json) · [进度、曲线和四秒原片](../../walk-forward-yaw-direction-holdout-live.html)

三路共 634,368 条转移，方向反馈七项各 32/32，完整动作与配对偏航均通过。 [独立评分](../../reports/common-walk-right-support-yaw-training/yaw-direction-holdout/analysis.json) · [Windows 观察](windows-view-verification.json) · [仿真组件](../../../artifacts/delivery/walking-simulation.json)
