# 原生后退采样

固定官方权重，首次检查实际 CUDA 原生重置和回报边界，用同一轮记录包含录像和写盘开销的净吞吐。

[冻结方案](../../../configs/experiments/common_walk_backward_native_probe.json) · [运行观察](../../walk-backward-native-probe-live.html)

384 步共 393,216 条环境转移。热身后的 320 步净吞吐为 13,279 转移/秒，显存峰值 5,084 MiB。实际自动重置后，回报独立复算通过，67 个场景的 13,400 条加权样本与记录一致。 [结果](analysis.json) · [独立核验](verification.json) · [完整原片](clip-step-0.mp4) · [命令](command.txt) · [日志](execution.log)
