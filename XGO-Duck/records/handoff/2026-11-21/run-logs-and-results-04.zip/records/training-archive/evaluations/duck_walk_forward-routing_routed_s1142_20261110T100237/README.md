# 七指令模型选择 1142-routed

[冻结方案](../../../configs/experiments/common_walk_forward_model_routing.json) · [运行观察](../../walk-forward-routing-1142-routed-live.html)
