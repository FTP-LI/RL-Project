# 同进程参考重复

[冻结方案](../../../configs/experiments/common_walk_shared_prefix_repeat.json) · [运行观察](../../walk-shared-prefix-repeat-live.html)
