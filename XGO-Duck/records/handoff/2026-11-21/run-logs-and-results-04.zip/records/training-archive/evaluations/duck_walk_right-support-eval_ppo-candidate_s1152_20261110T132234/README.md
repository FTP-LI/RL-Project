# 右转支撑七指令 · 1152 · 支撑奖励训练

[冻结方案](../../../configs/experiments/common_walk_right_support_seven_command.json) · [运行观察](../../walk-right-support-eval-1152-ppo-candidate-live.html)
