# 右转早期切换 · 实际切换

[冻结方案](../../../configs/experiments/common_walk_early_official_right.json) · [运行观察](../../walk-early-official-right-early-official-live.html)
