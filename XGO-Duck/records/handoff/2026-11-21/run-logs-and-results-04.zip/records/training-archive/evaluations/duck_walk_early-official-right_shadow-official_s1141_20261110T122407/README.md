# 右转早期切换 · 影子计算

[冻结方案](../../../configs/experiments/common_walk_early_official_right.json) · [运行观察](../../walk-early-official-right-shadow-official-live.html)
