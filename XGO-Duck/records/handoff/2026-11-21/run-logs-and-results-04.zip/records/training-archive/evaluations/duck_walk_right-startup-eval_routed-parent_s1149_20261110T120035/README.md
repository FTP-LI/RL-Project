# 七指令评估 · 1149 · 父策略

[冻结方案](../../../configs/experiments/common_walk_right_startup_seven_command_recovery.json) · [运行观察](../../walk-right-startup-eval-recovery-1149-routed-parent-live.html)
