# 电脑环境部署记录

日期：2026-10-31，Asia/Shanghai。目标是本机官方仿真与训练环境；用户已确认机器人尚未装配。

## 当前结果

已完成 WSL、Ubuntu、镜像下载与官方锁定依赖安装，CUDA 运算和任务入口通过。官方组及权重修改组均完成 256 环境、5 次迭代、checkpoint 检查、ONNX 导出、1000 帧数值对比与闭环、Runtime 1.22.1 兼容检查和实际回放截图。官方训练归档 390 个文件复核通过，开发副本仅保留计划中的权重修改。结果与边界见 [验证报告](../../../docs/reports/pc_pipeline_validation.md)；实机尚未装配、未部署。下面的时间线保留各步骤当时的状态。

| 记录 | 内容 |
| --- | --- |
| `host-inspection.txt` | 初次可见主机检查，WSL 检测处未正常结束；不能作为环境完整通过证据 |
| `host-environment.json` | 当前主机结构化核查：虚拟化已开启，hypervisor 正在运行；不代表 Linux CUDA 已通过 |
| `wsl-install-transcript.txt` | 可见 WSL 安装终端记录 |
| `wsl-install-output.txt` | WSL 安装原始输出，生成后据此判断重启或失败 |
| `wsl-install-result.json` | 安装命令与退出码，生成后读取 |
| `wsl-msi-result.json` | 官方 MSI 的下载、签名、安装及系统组件状态 |
| `wsl-download-verified.json` | 完整安装包的发布哈希、实际哈希、微软签名与下载完成时间 |
| `wsl-version-utf8.txt` | 重新按 UTF-16 解码取得的可读 WSL 信息；原始日志保留 |
| `restart-checkpoint.json` | 重启前系统启动时间、3010 依据与恢复入口 |
| `ubuntu-install-220357-result.json` | 镜像大小、SHA-256 校验与 Ubuntu 安装退出码 0 |
| `ubuntu-install-210646-result.json`、`ubuntu-install-212920-result.json` | 在线安装失败与本地包下载重试用尽的保留记录 |
| `wsl-download-output.txt`、`wsl-msi.log` | 可见下载进度与 Windows Installer 日志 |
| `preparation-check.json` | 文件链接、脚本准备和官方训练源码核验摘要 |
| `onnx-check-result.json`、`official-onnx-cpu.json` | CPU 检查实际结果，生成后读取；不代表实机验证 |
| `official-walk-home-comparison.json` | 14 关节默认姿态逐项比较，未修改运行配置 |
| `screenshots/01_wsl_installation.png` | 18:23 实际 Windows Installer 界面；安装结果另外依据退出码判断 |

原始日志和截图保留本地，Git 跟踪摘要与结构化结果。日志中含本机账户、路径等环境信息，分享时只取相关部分。

## 主机核查

当前主机 GPU 为 NVIDIA GeForce RTX 3080 Laptop GPU，显存 16384 MiB，驱动 592.54。CPU 为 AMD Ryzen 9 5900HX，8 核 16 线程；内存约 64 GB，Windows 11 专业工作站版 10.0.26200。与项目旧记录 RTX 5070 不同，后续使用本次实测。

初检未找到 WSL 服务、Ubuntu App 包及发行版注册项。`wsl --list --verbose` 长时间未完成，因此停止本次检查启动的进程；没有停止其他项目的训练或 Linux 会话。

## 已执行操作

1. 读取已有文档、固定来源、训练和运行代码；保留工作区已有用户改动。
2. 新建 `scripts/setup/inspect_host.ps1`，以可见 PowerShell 窗口运行；保存检查记录。
3. 普通沙箱启动未留下持久窗口与记录，改用受支持的提权执行入口启动可见窗口；成功取得日志。
4. 用只读系统查询核实本机 GPU、WSL 服务与发行版注册信息。
5. 新建并在可见管理员终端运行 `scripts/setup/install_wsl.ps1`，实际命令为 `wsl.exe --install --no-distribution --web-download`；脚本不会自动重启。
6. 创建路线文档、目录约定和首轮单因素实验定义。训练环境尚未就绪时，不提前记录训练成功。
7. 17:56 终止仍无进度输出的一键安装进程；原命令记录退出码 -1。微软官方入口可访问，改用 `install_wsl_msi.ps1` 显示下载进度、核验哈希和签名并安装；不会并行保留两个 WSL 安装器。
8. 官方 MSI 固定为 WSL 3.0.3，来源 `https://github.com/microsoft/WSL/releases/download/3.0.3/wsl.3.0.3.0.x64.msi`，发布资产大小 367575040 字节，预期 SHA-256 为 `ae977286974255bd26bf925f00f40f5692c6b2084155cbc0563c09aea091f211`。实际下载完成后还需核验微软签名。
9. 在独立项目虚拟环境 `workspace/onnx-runtime` 安装 `onnxruntime==1.22.1`、`onnx==1.20.1`、`numpy==2.2.6`，用于 PC CPU 兼容性检查。安装日志与最终检查结果分别保存，不污染系统 Python。
10. 18:00 CPU 检查完成，退出码 0。5 个模型各测试 128 组固定 seed 合成输入，均输出有限的 `[1,14]` 动作；全部模型为 IR 8 / opset 18，文件哈希与归档静态报告一致。单线程 PC CPU 的 200 次热身后计时中位数约 0.030 ms，p99 为 0.037–0.051 ms；这些数值不代表 UNO Q 性能。
11. 从实际模型元数据与归档 `rl_core.py` 重新计算普通行走默认姿态，最大差异约 2.007°。逐关节结果已保存；这是待对齐事项，尚未据此修改官方运行程序或判断实机效果。
12. 18:03 首次 MSI 下载因 `curl` 退出码 56（服务端关闭连接）结束，保留 98518976 字节部分文件。原始失败结果另存 `wsl-msi-attempt1-result.json`；改为断点续传及网络错误重试，重新启动可见安装窗口。
13. 续传启动时 Windows 弹出管理员授权，已提示用户在本机确认。没有通过后台服务绕过弹窗。
14. 根据锁定的 mjlab 1.3.0 / rsl-rl-lib 5.0.1 接口准备 `validate_export.py`：在 CPU 上做同观测 PyTorch/ONNX 对比，由 ONNX 驱动 CUDA 仿真并保存轨迹。当前仅通过语法检查，须在训练环境与 checkpoint 就绪后实际运行。
15. Windows 返回“操作已被用户取消”，管理员续传窗口未成功启动，原启动会话退出。改用 `install_wsl_msi.ps1 -DownloadOnly` 在普通可见终端续传与校验；该模式不运行 MSI、不启用系统组件，安装等待之后的系统授权。
16. 已生成单因素奖励补丁，保留归档源码的 CRLF 换行。用临时副本验证 `git apply --check` 和实际应用，修改后 SHA-256 与实验定义一致；核验后删除临时副本。正式训练副本尚未创建，未执行修改训练。
17. 用户回复已确认系统授权；当前实际运行的是普通终端的下载/校验模式，安装尚未开始。文件完整并通过校验后，再启动可见管理员安装；不同时运行两个下载器或安装器。
18. 18:21:51 续传完成，文件大小 367575040 字节，实际 SHA-256 与预期完全一致，Authenticode 状态 `Valid`，签名主体为 Microsoft Corporation。下载校验结果单独保存，随后启动可见管理员安装。Windows 再次要求管理员授权，已请用户在系统弹窗确认。
19. 用户确认管理员授权，18:23:35 MSI 返回 0；VirtualMachinePlatform 从 Disabled 改为 Enabled，DISM 返回 3010。18:23:48 安装脚本结束，明确标记需要重启；未自动重启。WSL 信息查询退出码为 0，已另存可读输出。
20. 后续只读核查显示启动时间仍为 2026-10-30 09:54:18，尚未完成所需重启。补齐 `scripts/setup/install_ubuntu.ps1`，用于重启后在可见终端检查 WSL 并记录 Ubuntu 安装；脚本尚未执行，不代表 Ubuntu 已安装。
21. 21:04 用户报告重启后重新核验：系统启动事件与运行时长均仍指向 10 月 30 日 09:54，系统仍有 `RebootPending`，`HiberbootEnabled=1`。`wsl --status` 虽返回 0，正文仍明确提示 WSL2 无法启动；发行版列表为空。诊断保存至 `wsl-readiness-check.json`，未据退出码 0 判断环境就绪。用户随后确认之前是关机后开机或重启应用，现准备从 Windows 电源菜单选择“重启”。
22. 21:06 核验到系统启动时间已更新为 21:05:04.5，`RebootPending` 消失。启动可见 PowerShell 运行 `install_ubuntu.ps1`，日志为 `ubuntu-install-210646-transcript.txt`。WSL 状态中已不再出现 WSL2 无法启动的提示；Ubuntu 安装命令正在执行，尚无完成结果。
23. 用户询问官方是否使用 Ubuntu 24.04。重新核对归档和官方网页：XGO-Duck README 只指定 CUDA GPU、Python 3.12、uv；mjlab 1.3.0 要求 Linux 与 NVIDIA GPU，未指定 Ubuntu 发行版。24.04 / WSL2 是本机实施选择，已在路线及操作文档中明确；BAM 的 Read the Docs 构建配置不能作为官方训练系统的证据。
24. 用户确认窗口正在显示下载进度；持续监测同一安装进程的活动，未因日志没有新增文字重启安装。21:28:40 下载以 `WININET_E_INVALID_SERVER_RESPONSE` 失败，退出码 -1，未注册 Ubuntu。结果见 `ubuntu-install-210646-result.json`。
25. 21:29 启动可见 `install_ubuntu.ps1 -UseLocalPackage`：从 Ubuntu 官方地址下载微软发行清单列出的 `ubuntu-24.04.5-wsl-amd64.wsl`，预期大小 388975696 字节，SHA-256 为 `bb415d824822c4b878125729af451a5d18fb13d1cf5cbed9a7393ad64ac6039e`。先断点续传及核验，再从本地包安装；原失败日志保留。此刻尚无本地包安装成功证据。
26. 本地包下载在约 106.7 MiB 时出现 curl 56（服务端关闭连接）。实际日志显示自动重试后待传输总量变为约 264.1 MiB，本地文件继续增长，确认本机 curl 8.21.0 配合 `--continue-at -` 已从保留数据续传；未重启下载器。完整性仍须以最终 SHA-256 为准。
27. 22:03:15 本轮 curl 的自动重试次数用尽，以退出码 56 结束；保留 375783889 字节，约占完整文件的 96.6%。确认旧下载进程已结束后，于 22:03:56 启动同一可见脚本续传剩余部分；未删除部分文件，未并行重复下载。失败结果保留在 `ubuntu-install-212920-result.json`。
28. 续传完成后镜像大小为 388975696 字节，实际 SHA-256 与预期完全一致。22:04:35 本地安装完成，安装及发行版查询退出码均为 0；注册表确认 `Ubuntu-24.04` 使用 WSL2。22:05:09 打开可见首次初始化窗口，由用户设置 Linux 用户名和密码；该窗口没有启用终端录制，尚未记录初始化完成。
29. 22:07:47 首次启动进程仍存活，注册的默认 UID 为 0；独立的只读用户、系统及 GPU 探针在 20 秒后超时，探针进程已结束，原初始化窗口保留。尚不能证明进入了可用 Linux 会话，等待用户完成初始化或反馈窗口提示。状态见 `ubuntu-first-start-state.json`；未据超时判断安装失败或重启安装器。
30. 用户确认创建 atlas 后，只读核验默认用户为 atlas、UID 1000、Ubuntu 24.04.5、Python 3.12.3；Linux 中 `nvidia-smi` 识别 RTX 3080 Laptop 16384 MiB，驱动 592.54。官方 uv 安装脚本入口经重定向返回 HTTP 200；WSL 仍提示 localhost 代理未映射，但本次访问成功，未据提示修改网络配置。结果见 `linux-preflight.json`。
31. 首次启动环境脚本在 Windows 路径转换阶段失败，原因是 WSL shell 解析了路径反斜杠，尚未执行 Linux 安装。改用 `--exec wslpath` 和 `--exec bash` 直接传参，补充 Windows 启动日志及结果文件；只读路径探针、PowerShell 与 Bash 语法检查通过后重新打开可见窗口。
32. 22:11 训练源码 390 个文件验证通过，创建并核验 `/home/atlas/XGO-Duck/workspace/xgoduck_rl`。日志为 `linux-bootstrap-221121.log`；当前正在安装 uv 0.13.6，随后才执行 `uv sync --locked` 与 CUDA/任务检查。
33. uv 安装完成后进入锁定依赖下载。为诊断速度，分别从 Windows 与 WSL 只读获取官方锁文件中同一 PyTorch wheel 的前 1 MiB 并丢弃内容；两次均返回 HTTP 206，Windows 用时约 2.54 秒，WSL 约 1.83 秒。这次小样本未支持“WSL 网络比 Windows 慢”的判断，未更改代理或网络模式；完整包速度仍以实际下载为准。
34. 准备项目缓存环境脚本与缓存迁移脚本，待本次 uv 进程结束后再整理默认缓存；当前尚未移动。另准备基线/候选短训练记录脚本，检查源码哈希并保存唯一运行名称、配置和退出码。脚本通过 PowerShell/Bash 语法检查，尚未执行训练。

35. 22:18 首次 Linux 同步失败，`better-actuator-models` 构建所需的 `setuptools>=77.0` 索引连接 PyPI 超时；Linux 退出码 2，见 `linux-bootstrap-221121.log` 与 `linux-launch-221121-result.json`。Linux IPv4 后续只读请求该索引返回 HTTP 200，Windows 代理请求仍发生 TLS 握手失败；未修改系统代理、镜像或证书验证。
36. 22:32 确认 uv 已结束后，在可见窗口将 84 MiB 缓存从 `~/.cache/uv` 移入 `~/XGO-Duck/cache/uv`，迁移退出码 0。恢复脚本加载项目缓存配置，使用 `UV_HTTP_CONNECT_TIMEOUT=60` 和 `UV_HTTP_TIMEOUT=600` 再次执行 `uv sync --locked`；官方副本 390 文件复核通过。安装结果仍须以后续退出码与 CUDA 检查为准。

37. 恢复同步期间 PyPI 完整请求仍发生连接超时；IPv4 与 HTTP/1.1 对照也失败。只读查询发现 `FlClash / Meta Tunnel` 启用、DNS 为 `198.18.0.2`，`FlClashCore` 在监听 7890；WSL 将 PyPI 解析为 `198.18.0.22`。用户说明没有主动使用代理，已请用户检查已有 FlClash 连接。详见 `network-diagnosis.json`；未修改整机网络配置。

38. 用户切换 FlClash 节点后，Windows 经 `127.0.0.1:7890` 下载完整 PyPI 索引成功（538021 字节），WSL NAT 仍超时。22:42 在可见窗口中断本项目 uv（退出 130），创建此前不存在的 `.wslconfig`，启用 mirrored、autoProxy、dnsTunneling，仅重启 WSL。实际网络模式返回 mirrored；代理请求 HTTP 200、538021 字节、约 5.25 秒，恢复结果为 passed，见 `network-recovery-224217-result.json`。随后默认连接请求也返回 HTTP 200、538021 字节、约 7.27 秒；22:43 再次启动可见依赖安装。回退说明见电脑环境操作文档。

39. 用户说明代理会自动切换节点，并要求终端集中、优先使用镜像源。已核验并关闭结束后的旧安装 PowerShell，后续任务集中在 `visible_console.ps1` 的单个可见窗口。当前命令与退出结果分别保存为 `console-request-*.json`、`console-result-*.json`。
40. 相同 PyTorch wheel 抽测：原通路 25 秒收到 1342356 字节；Windows 清华镜像在约 0.65 秒返回 8 MiB，Linux 经本机代理约 1.07 秒完成。镜像 SHA-256 与官方锁文件一致。22:53 启动镜像同步，仅替换 641 个归档下载 URL（跨平台总数，不是本机下载包数），包版本、哈希、registry 和 marker 保持一致；派生锁保存为 `mirror-transport-225341.lock`，结束后恢复官方锁再离线核验。22:56 缓存达到约 3.4 GiB，NCCL 下载完成；尚未完成环境验收。

41. 22:58 镜像安装完成，142 个包已安装；`mirror-sync-225341.json` 记录同步和恢复原锁后的离线同步均退出 0，官方锁哈希保持不变。CUDA 12.8 张量运算通过，GPU 为 RTX 3080 Laptop；已加载 XGO-Duck 任务。随后 `list-envs` 返回 58 导致检查脚本停止；检查已安装源码发现其返回任务数量，再由 console-script 的 `sys.exit(main())` 转成退出码。辅助脚本改为直接调用列表函数并断言目标任务存在，不修改官方库；继续完成 CLI 验证。

42. 23:00 完整环境检查退出 0，证据为 `linux-launch-225954-result.json`。随后在同一可见控制台完成基线 `baseline_smoke_20261031T230120` 与修改组 `candidate_smoke_20261031T230835`，均运行 5 次迭代并退出 0，保存配置权重分别为 3.0 与 3.3；两组 checkpoint 各 76 个张量全部有限。
43. 两组 ONNX 闭环各运行 1000 帧，数值超差帧数均为 0，最大动作绝对误差分别约 1.79e-7 和 1.49e-7。独立 Runtime 1.22.1 图、接口及合成输入检查均通过，产物包保存在 `artifacts/<run-id>/`；详细报告、实际参数与截图保存在对应实验目录。Viser 回放截图后正常停止，未遗留训练或回放任务。修改组重置次数更多，本轮不支持性能改善结论。

## 过程问题

### 历史环境与本机不一致

旧文档描述的是另一台电脑的配置。解决方式是重新查询当前主机，保留历史信息，并在状态文件中单独登记当前主机。

### WSL 检测停留

初次 `wsl --list --verbose` 没有正常返回；系统查询未发现已安装的服务与发行版。当前按首次安装处理，后续必须用 `wsl --version`、`wsl -l -v`、Linux 内 CUDA 查询重新验证。

### 终端截图能力

界面工具的窗口清单未返回部署终端，暂不能通过该工具取得真实终端截图。保留原始命令日志；后续仿真浏览器、安装界面可见时再截图，不制作伪运行截图。

实际 Windows Installer 窗口可被识别，已保存以下截图。图中进度条只证明安装正在执行，最终结果见 `wsl-msi-result.json` 和 MSI 日志。

![WSL 安装](screenshots/01_wsl_installation.png)

## 下一步

当前电脑端流程已完成。下一阶段按 [开发路线](../../../docs/development_roadmap.md) 开展充分训练与固定条件评估；装配完成后再执行官方实机基线和 sim2real 对齐。复现命令见 [操作说明](../../../docs/runbooks/pc_training.md)。

应选择 Windows 电源菜单的“重启”。本机开启快速启动，关机后开机可能保留内核状态；[微软电源状态说明](https://learn.microsoft.com/en-us/windows/win32/power/system-power-states)区分了快速启动与完整重启流程。
