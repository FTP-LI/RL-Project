# 离线真机准备审计

本阶段只检查文件、模型和软件映射，没有访问串口、板端地址、Arduino App Lab 或电机总线。实体设备仍处于待现场核验状态。

## 已核验

- 后续硬件准备使用的官方行走参照为 `artifacts/delivery/official/walk-simulation-reference.onnx`，SHA-256 为 `5eaae52c92df20139a779b4656e49ab824bb501fdd219e1241bcda91386fd75a`。
- CPU ONNX Runtime 可以加载该模型，接口为 `[1,61]` 输入、`[1,14]` 输出；模型元数据包含 14 个策略关节的顺序、默认姿态、观测布局和动作尺度。
- 离线关节映射记录为 `passed-offline-only`，包含 14 个策略输出和 15 个舵机的 ID、总线位置、符号及量化规则。它只证明软件变换往返一致，不证明实物接线或方向正确。
- `configs/hardware/commissioning_record_template.csv` 有 15 行，均保持 `pending`，可逐舵机记录扫描 ID、机械中心、重启读回、方向观察和证据路径。
- 部署手册已经固定首次只读顺序：状态采集、`Inference only`、`Servos online 15/15`、`IMU online`，以及 `Torque off`、`Reset Mid`、`Set center & hold` 和回退步骤。
- 官方模型、教师约束研究权重、迭代记录和标定模板均存在，后续可在现场异常时恢复官方参照。

机器判定见 [s19-readiness.json](s19-readiness.json)，执行协议见 [hardware_readiness_audit_s19.json](../../../configs/experiments/hardware_readiness_audit_s19.json)，审计脚本见 [audit_hardware_readiness_s19.py](../../../scripts/validation/audit_hardware_readiness_s19.py)。

## 尚未完成

这些项目必须在具备现场条件后逐项填写，不能由仿真结果代替：

1. 在可见终端连接 UNO Q 运行工程，保存 `/api/status` 原始日志，确认 `Servos online 15/15` 和 `IMU online`。
2. 一次只核对一个舵机的实物标签、扫描 ID、机械中心和方向，完成记录表和照片；未核对前不使能整机。
3. 记录 IMU 静止、俯仰和侧倾读数，确认归档的 `[z,-x,-y]` 变换与实际安装方向一致。
4. 现场读数全部通过后，托举状态先运行官方模型的默认姿态和低速短程；出现异常立即卸载并按手册回退。

当前 `physical_calibration_verified=false`、`physical_deployment_started=false` 是有意保留的待办状态。审计结果为 **软件准备通过，硬件准备延期**，没有产生新的训练或模型晋级。
