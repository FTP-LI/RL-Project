# 后退启动诊断

使用种子 1071、1072，各采集 128 个场景、6 秒。外部指令固定为 −0.10 m/s，策略输入为 −0.14 m/s。使用原官方模型、共同物理场景、目标投影和动作历史。每个场景的启动时点按第一个达到 0.06 m/s 后退方向均速的 1 秒分块统计。6 秒都存活且各分块纵向速度绝对值均不超过 0.02 m/s，记为近静止。20 秒七指令原门槛继续用于后续验收。

[冻结方案](../../../configs/experiments/common_walk_backward_onset.json) · [CPU 零步](preflight.json) · [首检日志](../common-walk-actuator-yaw-feedback/backward-onset-freeze.log) · [通过日志](../common-walk-actuator-yaw-feedback/backward-onset-freeze-verified.log)

第一次 CPU 预检把与并行规模联动的地形场景数当作意外差异，物理步为零。核对唯一差异后，按同一并行数归一化地形容量，逐项比较其余设置并完成场景快照检查。

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
set -o pipefail
for seed in 1071 1072; do
  flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
    "$PY -B scripts/validation/collect_walk_backward_onset.py --sample $seed" /dev/null || break
  "$PY" -B scripts/validation/verify_walk_backward_onset.py "$seed" || break
done
```

## 核验结果

| 开发种子 | 2 秒内启动 | 3–6 秒启动 | 6 秒未启动 | 采样转移 |
| --- | ---: | ---: | ---: | ---: |
| 1071 | 122 | 5 | 1 | 38,400 |
| 1072 | 112 | 12 | 4 | 38,400 |

五个未启动场景均存活到 6 秒，符合近静止判据。从第 2 秒分块起，五个场景均未出现单脚支撑。两批保存并核验了各 101 帧、覆盖 4 秒的后退原片，录像为预选场景 0。每批复核 896 条 ONNX 输入，确认模型权重、名义动作历史及关节目标投影。Windows 两批均读到 3 个运行中状态和完整原片。 [1071 评分](seed1071-analysis.json) · [1072 评分](seed1072-analysis.json) · [1071 观察](../../walk-backward-onset-s1071-live.html) · [1072 观察](../../walk-backward-onset-s1072-live.html) · [1071 资源](gpu-s1071.csv) · [1072 资源](gpu-s1072.csv)

## 停滞回放与下一步

从两个批次各选一个近静止场景，按保存的真实关节与机身状态回放 0–6 秒，每段 151 帧。原始相机文件仍单独保留。 [1071 场景 11](replay-s1071-world11.mp4) · [1072 场景 4](replay-s1072-world4.mp4) · [关键帧](backward-stall-keyframes.jpg) · [回放核验](replay-verification.json)

1–2 秒髋膝平均绝对速度与迟启动重叠。以保护 2 秒内已启动的场景为约束，只用 1071 定出 0.87735 rad/s 阈值。该阈值在 1072 覆盖 4 个停滞及 8 个迟启动，且 112 个早启动均未触发。用相同观测重新运行原模型，将内部后退输入改为 −0.18 m/s 时，5 个停滞场景的目标最大变化为 0.02445–0.03751 rad。实际助推将该变化进一步限制在 0.03 rad，并单独做同初态动态对照。 [观测及 CPU 目标复算](stall-observable-review.json) · [助推冻结检查](../common-walk-backward-start-pulse/preflight.json)
