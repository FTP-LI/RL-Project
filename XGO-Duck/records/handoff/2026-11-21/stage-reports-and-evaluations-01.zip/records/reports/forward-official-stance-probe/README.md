# 官方站立接自训前进

种子1247、脚底摩擦0.8的同一批128个场景，第1秒使用官方行走权重执行站立，之后使用已归档的偏航奖励候选权重执行20秒前进。候选接收实际站立动作历史。对照为站立与前进均使用同一候选权重。原0.20 rad/s偏航上限、前进速度、关节和接触检查及116/128通过数均纳入评分。[冻结方案](../../../configs/experiments/forward_official_stance_probe/master.json) · [VS Code评价入口](current-evaluation.md) · [对照记录](../forward-low-friction-yaw-reward/README.md)

## 同场景评分

两组均有128个场景完成前进区间，完整动作均为0/128，唯一失分项为偏航。候选站立与官方站立的20秒平均绝对偏航速度组内中位数为0.29516和0.29477 rad/s。同编号场景的偏航差中位数为−0.00098 rad/s。使用官方站立后，仍可复现这批自训前进的偏航超限。[独立比较](independent-comparison.json) · [21.04秒原片](../../evaluations/duck_forward_official_stance_e128_s1247_20261120T234314/clip-step-0.mp4)

原评分器按同一行走权重复算两段动作，首次回放在站立输出比对处停止。按实际指令及保存的阶段映射选择相应权重后，复算继续沿用原观测、动作历史、反馈、关节目标、接触与20秒评分检查。另用区域采样核对1,024条官方站立输出，录像以526帧独立解码确认完整。[首次回放日志](s1247-friction-low/score-command.log) · [分阶段复算依据](s1247-friction-low/phase-scoring-adapter.json)
