# 官方站立接自训前进

已复核。学习站立组0/128，官方站立组0/128。

[配对数据及录像](independent-comparison.json)
