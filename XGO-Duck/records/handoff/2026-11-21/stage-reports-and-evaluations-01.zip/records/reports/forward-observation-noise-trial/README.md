# 前进闭环观测噪声对照

种子1247，脚底滑动摩擦系数0.8，128个初态。前50步使用官方站立权重及原观测。之后使用同一前进候选权重的确定性动作均值，向它和偏航反馈共用的观测加入训练幅值的均匀噪声。原评分要求至少116/128通过，前进20秒平均绝对偏航速度不高于0.20rad/s，速度、姿态、接触和安全条件同时成立。对照沿用之前独立评分的确定性轨迹。这一项仅新增一组物理采样，学习更新为0次。[冻结方案](../../../configs/experiments/forward_observation_noise_trial/master.json) · [固定状态复算](../forward-action-sampling/observation-noise-readback.json)

## 结果

| 前进观测 | 原门槛通过数 | 20秒平均绝对偏航速度的场景中位数（rad/s） | 完整原片 |
| --- | ---: | ---: | --- |
| 确定性参照 | 0/128 | 0.29468 | [21.04秒原片](../../evaluations/duck_forward_action_deterministic_e128_s1247_20261120T235632/clip-step-0.mp4) |
| 训练幅值观测噪声 | 0/128 | 0.28219 | [21.04秒原片](../../evaluations/duck_forward_training_noise_e128_s1247_20261121T001102/clip-step-0.mp4) |

两组各记录1,050步，128/128进入前进，偏航是唯一失分项。固定场景逐对比较，加噪组的偏航差中位数为−0.01189rad/s，重抽样95%区间为[−0.01363, −0.01068]rad/s。同一零步的位置和速度完全一致，独立CUDA进程在共同站立阶段存在小幅数值差。独立评分核验128,000组实际加噪观测、真实动作历史与执行器目标，两段录像各526帧。[对照复算](comparison.json) · [新增组独立评分](training-noise/independent.json)

在VS Code可查看[运行状态](training-noise/native-view/native-status.txt)、[采样曲线](training-noise/native-view/native-curve.png)与[最新仿真帧](training-noise/native-view/native-latest.jpg)。[采样日志](training-noise/collect-command.log) · [独立评分日志](training-noise/score-command.log) · [配对汇总日志](review-command.log)

## 早期筛查校准

复用11批各128场景，共1,408个完整前进区间。从切换前进后的第一个物理采样起，比较前8秒和完整20秒的同口径偏航。将前8秒偏航达标场景少于116个的批次标记为待复核，批次判定与原20秒完整动作评分一致。两批标称官方参照均通过，另九批均被标记。种子1248的标称官方组有1个场景被早期标记后通过完整评价，另1个场景相反。后续训练可用早期窗口发现退化，模型验收沿用20秒完整动作评分。[逐组结果与来源哈希](early-screen-calibration.json) · [复算命令日志](early-screen-calibration-command.log)

从WSL中的工程根目录执行下列命令，可复算归档评分窗口。

```bash
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/audit_forward_early_screen.py
```
