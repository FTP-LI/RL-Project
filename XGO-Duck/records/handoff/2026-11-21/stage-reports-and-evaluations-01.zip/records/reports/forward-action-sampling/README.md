# 前进探索与确定性推理

两组使用种子1247的128个低摩擦场景，脚底滑动摩擦系数为0.8。官方权重站立1秒后，自训候选权重执行20秒前进。高斯探索组的14个关节使用最终checkpoint中的标准差。关节目标按原规则投影，下一步观测接收实际采样动作。冻结的配对使用原通过数、偏航、速度、姿态和接触判定。[冻结方案](../../../configs/experiments/forward_action_sampling/master.json) · [VS Code运行入口](current-evaluation.md)

第8次更新保存点的actor与共同父点逐张量相同。在官方低摩擦轨迹的1,024条输入上，保存点actor和官方ONNX通过原误差容差。其确定性成绩沿用同一官方权重已独立核验的20秒轨迹。前进组另对最终checkpoint与候选ONNX执行同输入核验。[早期与最终checkpoint读回](checkpoint-readback.json)

| 前进推理方式 | 原门槛通过数 | 20秒平均绝对偏航速度的场景中位数（rad/s） | 完整原片 |
| --- | ---: | ---: | --- |
| 确定性推理 | 0/128 | 0.29468 | [21.04秒原片](../../evaluations/duck_forward_action_deterministic_e128_s1247_20261120T235632/clip-step-0.mp4) |
| 高斯探索 | 0/128 | 0.28916 | [21.04秒原片](../../evaluations/duck_forward_action_gaussian_e128_s1247_20261120T235632/clip-step-0.mp4) |

两组各完成1,050个控制步，全部场景进入前进，偏航是唯一失分项。场景逐对比较时，高斯组相对确定性组的偏航差中位数为−0.00458rad/s，固定场景重抽样的95%区间为[−0.00720, −0.00095]rad/s。复算确认两组零步位置和速度完全一致，两个CUDA进程各自推进的前50步存在小幅数值差。原门槛为至少116/128、平均绝对偏航速度不超过0.20rad/s。[逐组评分与配对复算](comparison.json)

归档训练启用了陀螺仪、投影重力、关节位置和关节速度四项观测噪声，动作评估关闭了输入噪声。训练为8秒可自动重置的行走环境，评估先执行1秒官方站立，再进入20秒前进。归档训练零步和评估前进首帧的原始动作历史RMS场景中位数分别为0和0.03733rad。按这两个原始时点记录的分布核对配置，具体影响通过单变量对照测量。[环境字段、实际起点和来源](environment-contract.json)

在VS Code打开[确定性组采样曲线](deterministic/native-view/native-curve.png)、[高斯组采样曲线](gaussian/native-view/native-curve.png)及[运行状态](gaussian/native-view/native-status.txt)，可按运行编号查看原始日志。[确定性组日志](deterministic/collect-command.log) · [高斯组日志](gaussian/collect-command.log)

## 固定状态的观测噪声复算

从完整确定性轨迹取32个时点、每个时点128场景，固定已记录的偏航反馈。只向61维输入中的四项传感器数据加入训练幅值的独立均匀噪声，动作历史及指令使用原值。先用干净输入回读已保存候选动作和电机目标，最大误差均为5.96×10⁻⁷rad。[取样方案](../../../configs/experiments/forward_observation_noise_readback.json) · [复算与逐关节统计](observation-noise-readback.json) · [命令输出](observation-noise-recovery-command.log)

| 关节目标变化 | 样本中位数（rad） | 第95百分位（rad） |
| --- | ---: | ---: |
| 官方权重加噪前后 | 0.01318 | 0.02788 |
| 候选权重加噪前后 | 0.01307 | 0.02741 |
| 干净输入下候选与官方权重 | 0.01353 | 0.01769 |

每个样本先对14个关节的目标差求RMS，再跨4,096个样本汇总。噪声引起的目标变化与两套权重之间的差值量级相近。闭环对照将噪声传给策略与偏航反馈，20秒平均绝对偏航速度的场景中位数为0.28219rad/s，原门槛通过0/128。[闭环复算和原片](../forward-observation-noise-trial/README.md)
