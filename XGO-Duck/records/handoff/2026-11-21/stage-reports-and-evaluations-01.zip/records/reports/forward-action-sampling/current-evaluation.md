# 前进探索与确定性推理

| 方式 | 记录控制步 | 原门槛通过数 | 20秒偏航组内中位数（rad/s） |
| --- | ---: | ---: | ---: |
| 确定性推理 | 1050 | 0/128 | 0.29468 |
| 高斯探索 | 1050 | 0/128 | 0.28916 |

[独立复算及录像清单](comparison.json) · [checkpoint核验](checkpoint-readback.json)

| 运行记录 | 状态 | 采样曲线 | 采样日志 |
| --- | --- | --- | --- |
| 确定性推理 | [终态](deterministic/native-view/native-status.txt) | [曲线](deterministic/native-view/native-curve.png) | [日志](deterministic/collect-command.log) |
| 高斯探索 | [终态](gaussian/native-view/native-status.txt) | [曲线](gaussian/native-view/native-curve.png) | [日志](gaussian/collect-command.log) |
