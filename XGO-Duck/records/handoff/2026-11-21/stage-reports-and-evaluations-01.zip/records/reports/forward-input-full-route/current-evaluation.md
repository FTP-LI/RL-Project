# 前进模型输入20秒同快照对照

前进指令保持0.15m/s。每场景求完整20秒平均绝对偏航，再取场景中位数。

| 种子／脚底摩擦 | 参照通过数 | 候选通过数 | 参照偏航（rad/s） | 候选偏航（rad/s） |
| --- | ---: | ---: | ---: | ---: |
| 1247／0.8 | 0/128 | 128/128 | 0.229228 | 0.136721 |
| 1248／0.8 | 0/128 | 128/128 | 0.229180 | 0.136766 |
| 1247／1.0 | 128/128 | 128/128 | 0.188299 | 0.131434 |
| 1248／1.0 | 128/128 | 128/128 | 0.187641 | 0.131778 |

[逐场景评分](s1247-friction-low/independent.json) · [首段脉冲参照一原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1247-friction-low_20261121T031951/clips/reference-a/clip-step-0.mp4) · [前进模型输入0.115m/s原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1247-friction-low_20261121T031951/clips/forward-input-0115/clip-step-0.mp4)

[逐场景评分](s1248-friction-low/independent.json) · [首段脉冲参照一原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1248-friction-low_20261121T031951/clips/reference-a/clip-step-0.mp4) · [前进模型输入0.115m/s原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1248-friction-low_20261121T031951/clips/forward-input-0115/clip-step-0.mp4)

[逐场景评分](s1247-nominal/independent.json) · [首段脉冲参照一原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1247-nominal_20261121T031951/clips/reference-a/clip-step-0.mp4) · [前进模型输入0.115m/s原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1247-nominal_20261121T031951/clips/forward-input-0115/clip-step-0.mp4)

[逐场景评分](s1248-nominal/independent.json) · [首段脉冲参照一原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1248-nominal_20261121T031951/clips/reference-a/clip-step-0.mp4) · [前进模型输入0.115m/s原片](../../../records/evaluations/duck_forward_input_full_forward-input-0115_s1248-nominal_20261121T031951/clips/forward-input-0115/clip-step-0.mp4)

[完整配对结果](full-route-comparison.json)
