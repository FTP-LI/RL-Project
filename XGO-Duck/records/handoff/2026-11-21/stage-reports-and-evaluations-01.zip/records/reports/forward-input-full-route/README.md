# 前进模型输入20秒同快照对照

[VS Code逐组状态](current-evaluation.md) · [冻结方案](../../../configs/experiments/forward_input_full_route/master.json) · [冻结日志](../forward-stride-yaw-response/full-route-freeze-command.log) · [批次日志](../forward-stride-yaw-response/full-route-batch-command.log)

两组低摩擦的完整步态周期对照选出0.115m/s模型输入。完整对照先共同站立1秒、前进4秒，再从第250个CUDA控制边界恢复两次。基准沿用0.15m/s输入，候选用15个控制步将内部输入过渡到0.115m/s。外部0.15m/s目标、原官方ONNX、原偏航反馈与步态判据贯穿完整20秒。配对始终保留同一次物理重置和第一步电机目标核验。[开发筛选](../forward-stride-yaw-response/README.md) · [原轨迹评分流程复核](saved-pair-preflight.json)

两档速度值均指送入原命令映射前的数值。乘以已有的1.4倍前进增益后，ONNX前进输入槽从0.210过渡到0.161。复核以实际61维模型输入、14维动作和物理电机目标逐步重建。[输入映射源码](../../../scripts/validation/command_input_mapping.py)

种子1247和1248各在脚底摩擦0.8与1.0下运行128个场景。完整验收要求每组至少116/128个场景同时满足平均绝对偏航速度不超过0.20rad/s、前进速度不低于0.10m/s、原姿态和接触条件。每组1,850个批量控制步，四组总预算947,200条仿真环境转移。21秒原片包含1秒站立和全部20秒前进。

## 独立评分

四组均完成21秒路线和原20秒前进评分，共947,200条环境转移。候选512/512通过。完整评估按各场景20秒时间均值取场景中位数，前进速度仍以外部0.15m/s指令评价。完整样本的整卡显存最高为2,987MiB。[逐组评分和八段21秒原片](current-evaluation.md)

| 种子／脚底摩擦系数 | 参照通过数 | 候选通过数 | 参照偏航（rad/s） | 候选偏航（rad/s） | 候选速度（m/s） |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1247／0.8 | 0/128 | 128/128 | 0.229228 | 0.136721 | 0.133786 |
| 1248／0.8 | 0/128 | 128/128 | 0.229180 | 0.136766 | 0.133764 |
| 1247／1.0 | 128/128 | 128/128 | 0.188299 | 0.131434 | 0.133960 |
| 1248／1.0 | 128/128 | 128/128 | 0.187641 | 0.131778 | 0.133896 |

![完整前进累计偏航](full-forward-yaw.png)

[低摩擦关键帧标注](full-forward-keyframes.jpg) · [图像来源及哈希](full-forward-media.json) · [逐场景对照结果](full-route-comparison.json)

首组评分读取了错误的配对重抽样种子字段。恢复时按冻结文件里的正确字段复算已采集首组，随后完成其余三组。首组复算新增物理步为0。[评分字段核验](score-readback.json) · [批次恢复日志](score-readback-command.log)

| 种子／脚底摩擦系数 | VS Code状态 | 采样曲线 | 采集日志 |
| --- | --- | --- | --- |
| 1247／0.8 | [状态](s1247-friction-low/native-view/native-status.txt) | [曲线](s1247-friction-low/native-view/native-curve.png) | [日志](s1247-friction-low/collect-command.log) |
| 1248／0.8 | [状态](s1248-friction-low/native-view/native-status.txt) | [曲线](s1248-friction-low/native-view/native-curve.png) | [日志](s1248-friction-low/collect-command.log) |
| 1247／1.0 | [状态](s1247-nominal/native-view/native-status.txt) | [曲线](s1247-nominal/native-view/native-curve.png) | [日志](s1247-nominal/collect-command.log) |
| 1248／1.0 | [状态](s1248-nominal/native-view/native-status.txt) | [曲线](s1248-nominal/native-view/native-curve.png) | [日志](s1248-nominal/collect-command.log) |

## 连续路线准备

另复核了低摩擦加权自训滚翻模型的四份保存路线。以每个场景进入前进的时刻为起点，4秒后的输入过渡在归档上的首个改变出现在绝对第460至476步。新的逐场景计时与四组20秒候选的实际模型输入逐项一致，七条指令中只有标准前进输入发生变化。该证据用于冻结连续路线时序，滚翻接前进仍需实测。[归档时序核验](archived-roll-entry-timing.json) · [逐场景计时源码](../../../scripts/validation/forward_input_timing.py) · [连续路线草案](../../../configs/experiments/roll_forward_input_integration_draft.json)
