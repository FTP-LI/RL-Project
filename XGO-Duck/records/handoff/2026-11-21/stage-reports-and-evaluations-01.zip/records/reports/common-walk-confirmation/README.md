# 共同接口七指令

两个新开发种子逐项通过，留出前进30/32未达到31/32门槛，本轮关闭，不追加。原环境672/672的证据保持原记录；共同环境的连续技能切换仍未完成。

| 记录 | 结果 | 实际转移 |
| --- | --- | --- |
| 原开发1040 | 223/224，七项通过 | 224000 |
| 原开发1041 | 第79步停止，后退环境98需要局部重置 | 17696 |
| 新开发1042 | 221/224，七项通过 | 224000 |
| 新开发1043 | 221/224，七项通过 | 224000 |
| 留出2040 | 221/224，前进30/32未通过 | 224000 |

合计913696评价转移、零学习。2040已消费，不再用于挑参数。新种子全部完成20秒，没有提前结束，局部重置分支只做了CPU检查，尚未在GPU实际触发。

## 证据

- [全部成绩与失败分量](closure-review.json)：直接从保存轨迹复算；原中断视频状态哈希也在此核验。
- [开发偏航复算](development-yaw-review.json)：三个开发种子中站立、前进和后退的偏航均值与波动，未读取留出轨迹。
- [编码器相位复算](development-phase-review.json)和[输入预检](forward-phase-action-preflight.json)：用两个开发种子复核所选信号，比较 4,608 组保存观测上的候选目标。
- [接口审计](interface-audit.json)、[目标决定](target-decision.json)：共同噪声、合法目标和输入历史。
- [原冻结协议](../../../configs/experiments/common_walk_confirmation.json)：46份来源，原中断不重跑。
- [独立修复协议](../../../configs/experiments/common_walk_reset_recovery.json)：50份来源，新种子独立冻结。
- [CPU局部重置检查](reset-recovery/cpu-reset-check.json)、[原故障核对](reset-recovery/parent-failure-audit.json)、[顺序执行结果](reset-recovery/suite-progress.json)。
- [开发1042](reset-recovery/s1042/analysis.json)、[开发1043](reset-recovery/s1043/analysis.json)、[留出2040](reset-recovery/s2040/analysis.json)：逐指令成绩和95%区间、GPU零步/来源/模型/原片核验。
- [全部录像图册](../../../docs/reports/stage-video-gallery.html)：N256–N290，共35段；7段0–1.56秒的中断原片明确标注，28段完整4秒观察窗口。
- [全流程报告](../../../docs/reports/development_report.md)：第7.15节说明改动、结果、原因和复现入口。

## 保存数据复算

在已有WSL环境运行以下CPU命令，重新读取原始轨迹；不会启动动力学、训练或重新使用留出场景。

```bash
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/review_common_walk_closure.py
.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/review_common_walk_yaw.py
.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/review_common_walk_phase.py
.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/probe_walk_forward_phase.py
```

关闭的采样入口已移入历史任务清单，不在日常菜单中重复启动。独立练习使用有名称的新开发协议，不能覆盖上述运行或消耗已使用的留出。
