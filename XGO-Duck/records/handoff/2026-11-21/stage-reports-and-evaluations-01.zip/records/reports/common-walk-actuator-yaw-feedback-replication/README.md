# 前进闭环复验

[冻结方案](../../../configs/experiments/common_walk_actuator_yaw_feedback_replication.json) · [零步检查](preflight.json) · [运行观察](../../walk-actuator-feedback-replication-live.html)

种子 1048 使用首批通过的同一套执行器反馈、官方模型和七指令门槛。重新分配 224 个场景，保留两路参照和共同第一秒，重新检查 CUDA 零步及分支状态。 [首批开发结果](../common-walk-actuator-yaw-feedback/README.md) · [CPU 冻结日志](../common-walk-actuator-yaw-feedback/replication-freeze.log)

在现有 WSL 环境加载 `scripts/setup/project_environment.sh`，用专属虚拟环境的 Python 调用 `scripts/validation/repeat_walk_actuator_yaw_feedback.py`。`--freeze` 检查首批准入并冻结新批次，`--sample` 采样，`--verify` 复算保存轨迹。三个入口和数值门槛都在冻结方案中留档，已完成批次可直接查看评分和证据。 [采样日志](sampling-console.log) · [GPU 指标](gpu.csv)

## 实测结果

反馈组七项 224/224。两路参照的前进为 31/32、30/32，反馈组为 32/32。两路参照的前进偏航误差为 0.16257、0.16207 rad/s，反馈组为 0.14561 rad/s。配对改善 0.01696、0.01646 rad/s，95% 区间分别为 [0.01451, 0.01938]、[0.01416, 0.01882]，前进速度差小于 0.00028 m/s。原七项和配对门槛均通过。

实际采集 649,600 条转移，30,400 条反馈输入经 CPU ONNX 独立重放，39 条触发目标限幅。三段 4 秒原片各 101 帧并核对物理帧哈希。Windows 端读取 29 个运行中状态，均包含本轮原始帧，完成时可播放本轮原片。 [完整评分](analysis.json) · [观察核验](../../evaluations/duck_walk_actuator-feedback_paired_s1048_20261110T022551/windows-view-verification.json) · [参照一](../../evaluations/duck_walk_actuator-feedback_paired_s1048_20261110T022551/evaluation-reference-a/clip-step-0.mp4) · [参照二](../../evaluations/duck_walk_actuator-feedback_paired_s1048_20261110T022551/evaluation-reference-b/clip-step-0.mp4) · [反馈原片](../../evaluations/duck_walk_actuator-feedback_paired_s1048_20261110T022551/evaluation-actuator-feedback/clip-step-0.mp4)
