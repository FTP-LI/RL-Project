# 同目标偏航脉冲

从种子 1046 的共同第 50 步状态运行原策略、内部偏航脉冲和执行器目标脉冲。两支脉冲的第 51 步使用同一投影后目标，执行器脉冲保留原策略的原始动作及动作历史。三个分支其余控制沿用原映射。32 个前进场景各半施加正负扰动，其余六组保持原控制。全程 112,000 条转移、2,500 个批量物理子步、零学习。

先核验两支脉冲实际目标及首个延迟执行器命令，再比较 20 毫秒和 40 毫秒偏航。要求 20 毫秒的配对平均绝对差不超过 0.001 rad/s。40 毫秒的反向响应至少减少一半，配对差异区间下界高于零，才通过这条机制验证。原 20 秒动作门槛单独保留。

[冻结方案](../../../configs/experiments/common_walk_yaw_history_probe.json) · [CPU 零步](preflight.json) · [动作投影组件](../common-walk-yaw-pulse/history-probe-component-preflight.json) · [实时观察](../../walk-yaw-history-live.html)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
  "$PY -B scripts/validation/common_walk_yaw_history_probe.py --sample" /dev/null
"$PY" -B scripts/validation/verify_walk_yaw_history_probe.py
```

## 实测结果

1046 实际采集 112,000 条转移、2,500 个批量物理子步。三支均通过 309 项分支状态核验，三段 4 秒原片各 101 帧。两支脉冲的投影后目标逐值相同，首个延迟执行器命令一致。执行器脉冲保留原策略的动作和请求，最大目标变化 0.01904 rad。20 毫秒命令侧与执行器侧均约 +0.00773 rad/s，配对平均绝对差 0.00000959 rad/s。40 毫秒命令侧为 −0.00195、执行器侧为 +0.00037 rad/s，配对差 +0.00231 rad/s，95% 区间为 [0.00091, 0.00339]。该短脉冲通过预定机制门槛，完整 20 秒跟踪仍需独立验证。 [评分、回读与原片](analysis.json) · [Windows 运行观察核验](../../evaluations/duck_walk_yaw-history_paired_s1046_20261110T020753/windows-view-verification.json)

用执行器侧的六个脉冲响应重新筛查短时控制。±0.12 rad/s 在两个开发批次中估算收益约 0.01381 和 0.01392 rad/s。对 60,480 条实际观测重新运行策略并限制每步目标改变量为 0.03 rad，85 条需要缩放。计入缩放后估算收益仍为 0.01380 和 0.01392 rad/s，超过 0.01 的原继续门槛。通过离线组件准入，待新种子的 20 秒闭环试验。 [反馈回放](saved-actuator-feedback-screen.json) · [目标限幅核验](actuator-feedback-target-preflight.json) · [下一轮草案](../../../configs/experiments/common_walk_actuator_yaw_feedback_draft.json)
