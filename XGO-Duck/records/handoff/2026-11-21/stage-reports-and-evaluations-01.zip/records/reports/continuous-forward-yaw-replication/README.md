# 连续前进偏航独立复验

新开发种子 1096 使用入选的 0.15 rad/s 偏航反馈乘数。站立、滚翻、落地和前进均在同一物理环境中完成，只有一次初始重置。关节目标修正上限为 0.03 rad。前进评分继续覆盖完整 20 秒，平均绝对偏航速度上限为 0.20 rad/s，整段通过数至少 116/128。

125/128 个场景完成滚翻和站立并走完 20 秒，**124/128** 通过全部判据。三个滚翻未达到有支撑的正向旋转和及时持稳；一个前进场景的偏航为 0.20412 rad/s。整轮采集 198,400 条转移、7,750 个批量物理子步，零学习。Windows 读取 63 次运行中原始画面，31 秒原片的 776 帧已逐帧解码核验。 [独立评分](analysis.json) · [运行观察](../../continuous-forward-yaw-replication-live.html) · [完整原片](../../evaluations/duck_switch_forward-yaw-replication_development_s1096_20261110T053630/clip-step-0.mp4) · [Windows 观察核验](../../evaluations/duck_switch_forward-yaw-replication_development_s1096_20261110T053630/windows-view-verification.json)

[冻结方案](../../../configs/experiments/continuous_forward_yaw_replication.json) · [零步核验](zero/startup.json) · [运行日志](sample-execution.log) · [评分日志](verify-execution.log) · [同初态对照](../continuous-forward-yaw-pair/README.md)

后续在同一场景单独验证前进阶段的左右横向扰动。第 550 步加一次 0.08 m/s 的速度增量，沿用原序列评分并核对两秒内恢复。使用本轮保存状态进行 CPU 写入时，125 个符合条件场景仅改变水平根速度，294 项快照字段精确回退。原名义轨迹有 124 个场景同时通过完整序列和新增恢复窗口。CUDA 零步与三组实际响应随后均已核验。 [CPU 写入与回退](../continuous-forward-yaw-pair/lateral-push-writer-cpu.json) · [扰动结果与原片](../continuous-forward-lateral-push/README.md)
