# 后退困难初态

从十批开发档案复算 2,048 个原策略场景，索引出 63 个不同的困难初态。配对试验要求两路原策略均判为近静止，按机身位置、姿态、关节角和速度核对初态，并忽略绝对地面 XY 做精确去重。所有来源与共同物理环境、官方权重的校验值一致。初态保留在原批次，索引记录运行编号、场景号和来源哈希。 [初态索引](initial-cases.json) · [筛选脚本](../../../scripts/validation/audit_walk_backward_initial_cases.py)

侧倾试验的种子 1103 有 6 个场景在两路原策略中共同停滞，其中 5 个进入当时的干预触发评估。本次使用原策略的 6 个初态，原侧倾试验判定仍按原门槛归档。 [侧倾评估](../common-walk-backward-roll-pair/README.md)

数据覆盖超过 48 个初态、6 批的准入门槛。计划中的两组训练共用父模型、原奖励、预算和保留样本，仅候选加入有界的困难后退初态。独立评估仍使用常规初始化和原七指令标准。 [课程草案](../../../configs/experiments/common_walk_backward_start_curriculum_draft.json)

## 重置读回

CPU 和 CUDA 均在 128 个真实仿真环境中读回全部 63 个困难初态，并核对部分重置的 8 个环境，其中 4 个使用困难初态。未选环境的位置、速度和动作历史逐位保留。随机化和两组随机流一致。每个设备核对 512 个首帧模型输入，最大官方 ONNX 输出误差分别为 2.38×10⁻⁷ 和 2.03×10⁻⁷。全部零物理步、零学习更新。 [门槛](../../../configs/experiments/common_walk_backward_start_reset_readback.json) · [CPU 结果](reset-readback/cpu.json) · [CUDA 结果](reset-readback/cuda.json)

早期检查把原生 ±0.50 米的重置范围误设为 ±0.25 米，随后以原配置为准重新核对。部分重置还会重新计算原生 BAM 摩擦量。CUDA 两组在该动态字段上的最大差异为 1.86×10⁻⁹，按 10⁻⁷ 容差验收，位置、速度和原始动作历史仍逐位核对。 [坐标中止](reset-cpu-initial-stop.json) · [CPU 摩擦中止](reset-cpu-bam-stop.json) · [CUDA 数值中止](reset-cuda-bam-stop.json)

## 保留样本

使用两个开发种子的原策略轨迹，保留站立、前进、左右转、左右平移各 512 条观测，共 3,072 条。逐条用官方 ONNX 重算参考动作，和记录动作的最大差为 4.77×10⁻⁷。两组学习共享同一份样本；实际动作仍通过独立的七指令回归验收。 [数据核验](retention/analysis.json) · [样本方案](../../../configs/experiments/common_walk_backward_start_retention.json)

## 难度复验

63 个初态共用同一关节姿态和高度，广义速度全部为零，差别集中在平面位置与偏航。CUDA 两组在困难槽位的首帧动作最大差仅为 1.14×10⁻⁷。下一步用新随机流和原策略对照常规重置与困难初态重置，检验移植后的初态是否仍更容易停滞。首批至少多出 4 个近静止场景，且没有候选独有的提前结束，才进入新种子复验。 [初态差异](reset-readback/release-variation.json) · [复验草案](../../../configs/experiments/common_walk_backward_start_enrichment_draft.json)

执行命令与日志可直接复查。 [命令](commands.txt) · [CPU 日志](reset-cpu-final.log) · [CUDA 日志](reset-cuda-final.log) · [样本日志](retention.log)
