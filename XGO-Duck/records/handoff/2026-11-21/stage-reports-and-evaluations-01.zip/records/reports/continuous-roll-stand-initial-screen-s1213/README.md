# 起始站立准备度筛查

本轮复用官方滚翻场景和已验收行走 actor，执行 50 个控制步；没有学习更新、权重修改、留出数据或硬件通信。第 50 步 128/128 个环境满足高度、倾角、角速度、双脚接触和关节限位条件，并达到 25 步连续稳定门槛。

| 证据 | 路径 |
| --- | --- |
| 冻结协议 | [router_initial_stand_screen_s1213.json](../../../configs/experiments/router_initial_stand_screen_s1213.json) |
| CPU 前置核验 | [preflight.json](preflight.json) |
| GPU 零步 | [zero/runtime-contract.json](zero/runtime-contract.json) |
| 数值分析 | [analysis.json](analysis.json) |
| 实际轨迹 | [readiness.npz](../../../records/evaluations/duck_router-initial-stand-screen_development_s1213_20261114T015020/readiness.npz) |
| 完整短片 | [clip-step-0.mp4](../../../records/evaluations/duck_router-initial-stand-screen_development_s1213_20261114T015020/clip-step-0.mp4) |

结论：seed-1212 router 的失败不是起始站立门槛，下一步转查真正的 `ROLL` 阶段和落地 latch。
