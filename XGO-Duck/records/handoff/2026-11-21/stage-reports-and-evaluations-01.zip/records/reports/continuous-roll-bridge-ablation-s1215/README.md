# bridge 配对消融

本轮用同一 seed 1215、同一官方滚翻与行走组件，唯一变化是跨模型 bridge：保留 25 个控制步，或关闭 bridge。每个 arm 运行 50 个站立控制步和 100 个滚翻控制步，零学习、无硬件。

| 证据 | 路径 |
| --- | --- |
| 冻结协议 | [router_bridge_ablation_s1215.json](../../../configs/experiments/router_bridge_ablation_s1215.json) |
| CPU 前置核验 | [preflight.json](preflight.json) |
| GPU 零步 | [zero-step.json](zero-step.json) |
| 配对分析 | [analysis.json](analysis.json) |
| bridge 保留原片 | [clip-step-0.mp4](../../../records/evaluations/duck_router-bridge-ablation_bridge-on-25_s1215_20261114T020837/clip-step-0.mp4) |
| bridge 关闭原片 | [clip-step-0.mp4](../../../records/evaluations/duck_router-bridge-ablation_bridge-off-0_s1215_20261114T020901/clip-step-0.mp4) |

bridge 保留时头部穿透 127/128、末尾完整状态 1/128；关闭时头部穿透 0/128、末尾完整状态 128/128。该配对结果把 bridge 判为当前路由的主要故障源，但不代表模型已经完成连续路由验收。
