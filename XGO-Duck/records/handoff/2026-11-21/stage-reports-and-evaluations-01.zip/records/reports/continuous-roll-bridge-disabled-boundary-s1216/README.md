# bridge 关闭后的完整滚翻边界

本轮用 seed 1216 在官方组件下运行 50 个站立控制步和 450 个滚翻控制步，关闭跨模型 bridge；没有学习、留出数据、硬件通信或前进阶段。

| 证据 | 路径 |
| --- | --- |
| 冻结协议 | [router_bridge_disabled_boundary_s1216.json](../../../configs/experiments/router_bridge_disabled_boundary_s1216.json) |
| CPU 前置核验 | [preflight.json](preflight.json) |
| GPU 零步 | [runtime-contract.json](../../../records/reports/continuous-roll-bridge-disabled-boundary-s1216/zero/runtime-contract.json) |
| 独立分析 | [analysis.json](analysis.json) |
| 7 个失败复盘 | [failure-review.json](failure-review.json) |
| phase/latch 轨迹 | [trace.npz](../../../records/evaluations/duck_switch_roll-stand-walk_development_s1216_20261114T021238/trace.npz) |
| raw score | [raw-score.json](../../../records/evaluations/duck_switch_roll-stand-walk_development_s1216_20261114T021238/raw-score.json) |
| 完整序列原片 | [clip-step-0.mp4](../../../records/evaluations/duck_switch_roll-stand-walk_development_s1216_20261114T021238/clip-step-0.mp4) |

121/128 环境达到滚翻→落地 latch，超过 116/128 开发门槛；头部穿透最大 3.25 mm、超限 0 个，关节限位超限 0 个。7 个未完成环境全部有脚接触和头接触，但 supported rotation 只有 316.7°–325.9°，没有形成支持的一圈；它们不是头部穿透、关节限位或起始站立失败。下一步先针对这一支持旋转缺口复盘，再决定站立接力。
