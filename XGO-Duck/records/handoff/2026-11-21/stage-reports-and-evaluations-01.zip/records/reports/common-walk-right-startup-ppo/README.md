# 右转启动训练

共同起点和动作保留样本已通过 CPU 读回。检查点与 ONNX 在 1,024 条真实观测上的最大动作差为 2.98×10⁻⁷，录像对应的原始动作与 ONNX 最大差为 3.58×10⁻⁷。 [读回结果](parent-readback.json) · [冻结的保留样本](right-turn-retention.npz)

两个开发种子各取 512 条。样本来自通过全程原门槛的右转场景，取第 5 秒之后满足一秒偏航门槛的区间。样本含来源种子、场景、控制步、模型观测和原始动作，将用于限制两组在稳定转向段的行为漂移。 [上一步动态结果](../common-walk-right-leg-recovery/README.md) · [训练草案](../../../configs/experiments/common_walk_right_startup_ppo_draft.json)

拟比较的唯一奖励差异在右转的前 4 秒，持续跟踪和七条指令的动作门槛保持原判据。

CPU 零步检查已通过。两批归档输入的映射最大差为 5.96×10⁻⁸ rad/s，原生零步推理与 ONNX 最大差为 1.49×10⁻⁷。第 0、1、200、201 步的静止欠速项分别为 0、−1、−1、0。局部重置只清空指定环境的动作历史并重新初始化该环境的滤波器。原生奖励使用重置前的机身偏航，派生量按原环境滞后一个 4 ms 物理子步。 [CPU 读回](native-cpu.json)

## CUDA 短测

两遍使用同一开发种子、固定策略和 3,072 个环境，各完成 240 控制步，共 1,474,560 条转移。每遍前 96 步单列为预热，净吞吐包含后 144 步内的真实录像、状态发布和诊断开销。 [冻结方案](../../../configs/experiments/common_walk_right_startup_probe.json) · [独立评分](probe-analysis.json) · [退出记录](probe-execution.json)

| 批次 | 净转移/秒 | 峰值显存 MiB | 实测区间录像秒数 | Windows 运行快照 |
| --- | ---: | ---: | ---: | ---: |
| 第一遍 | 22,694 | 12,162 | 3.15 | 10 |
| 第二遍 | 22,723 | 12,167 | 3.15 | 11 |

两遍净吞吐相差约 0.13%，状态发布每遍在计时区间用时约 0.09 秒，原始轨迹压缩各约 0.98 秒，单列在计时区间之外。最高显存低于 85% 上限约 1,759 MiB。保留 3,072 环境用于下一阶段，后续有实际梯度时再核对显存。 [第一遍过程和原片](../../walk-right-startup-measure-a-live.html) · [第二遍过程和原片](../../walk-right-startup-measure-b-live.html)

超时场景在第 1,000 回合步重置。提前终止的场景在第 132 回合步重置，重置前偏航为 −0.585、−0.649 rad/s，均已快于目标，欠速项为零。重置后的角速度是零。两类终止步均只使用本步奖励，不继承新回合价值。逐批独立回报复算的最大误差为 1.46×10⁻⁶。两段 4 秒、25 fps 原片各 101 帧，逐帧状态哈希均通过检查。

图册 N519 和 N520 标注两段原片的第 1 秒与第 4 秒。 [录像图册](../../../docs/reports/stage-video-gallery.html) · [媒体核验](probe-media-review.json)

## 共享价值方案

迟启动定义为第 51–100 步和第 101–150 步的有向平均偏航绝对值均不超过 0.05 rad/s，并持续到第 200 步。排除两例有意重置后，第一遍有 68/3,070，第二遍有 67/3,070，重合 51 例。两遍使用同一种子，用于核对采样和规模。 [奖励复算](probe-reward-signal.json)

按迟启动段原偏航奖励中位数的 20% 向下取 0.05 档，得到欠速系数 0.25。计入 20 ms 控制周期后，迟启动段每步典型新增代价约 0.005，原每步奖励中位数约 0.169。

共享价值从 3,072 个完整首回合拟合。在 768 个验证环境中，解释方差 0.836，归一化均方误差 0.00728。 [共享价值核验与原片](../../experiments/duck_walk_right-startup-shared-value_reference_s1147_20261110T113806/README.md)

## 等样本策略对照

两组各完成 14 次更新，累计采样 2,064,384 条转移，最高显存 12,480 MiB。初始物理状态、策略和共享价值一致，实际首批梯度通过显存准入。训练覆盖回合前 6.72 秒，全回合终止回报由前置采样与独立读回核验。两组原片和 Windows 运行记录均已核验。 [训练核验](paired-ppo-analysis.json) · [原奖励组](../../experiments/duck_walk_right-startup-ppo_control_s1148_20261110T114313/README.md) · [欠速组](../../experiments/duck_walk_right-startup-ppo_candidate_s1148_20261110T114313/README.md)

两组导出各在 960 条非右转输入上保留原输出，160 条右转输入与独立 ONNX 推理对齐。下一步执行原七指令动态评估。 [训练导出路由](trained-right-route-components.json) · [评估草案](../../../configs/experiments/common_walk_right_startup_seven_command_draft.json)

图册 N521 至 N523 分别保留欠速组、原奖励组和共享价值的原片标注帧。 [录像图册](../../../docs/reports/stage-video-gallery.html) · [三段媒体核验](shared-value-and-ppo-media.json)

以下是本轮核验命令。零步核验在尚无对应输出的工程副本运行，CUDA 读回可直接读取现有归档。

```bash
CUDA_VISIBLE_DEVICES=-1 python -B -u scripts/validation/check_walk_right_startup_parent.py
CUDA_VISIBLE_DEVICES=-1 python -B -u scripts/validation/check_walk_right_startup_native.py
CUDA_VISIBLE_DEVICES=-1 python -B -u scripts/validation/verify_walk_right_startup_probe.py
```
