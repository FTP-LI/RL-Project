# 连续滚翻与前进

使用独立开发场景。站立转滚翻保留目标投影，去掉入口限速，滚翻后转站立保持原过渡和 20 秒前进判据。

[冻结方案](../../../configs/experiments/continuous_roll_projected_entry.json) · [运行观察](../../roll-projected-entry-live.html) · [三路依据](../continuous-roll-entry-isolation/README.md)

## 独立结果

128 个场景使用一个连续物理回合。126 个通过滚翻并完成后续站立与 20 秒前进，111 个通过全部判据，低于 116 个的继续门槛。15 个完成前进的失败场景仅超出偏航上限 0.20 rad/s，实际偏航误差为 0.20002–0.20515 rad/s。其余 2 个未进入前进。

运行完成 1,550 个批量控制步、198,400 条转移和 7,750 个物理子步，只有一次初始重置。Windows 读取 63 次运行中画面，31 秒原片的 776 帧均已解码核验。 [独立评分](analysis.json) · [完整原片](../../evaluations/duck_switch_roll-projected-entry_development_s1092_20261110T050708/clip-step-0.mp4) · [Windows 观察核验](windows-view-closure.json)

15 个偏航失败在第 2–20 秒仍全部超限，13 个在最后 10 秒仍超限。失败组的偏航速率中位变化符号 87 次，平均有符号偏航速率中位数约 0.020 rad/s，远小于绝对误差中位数约 0.202 rad/s。后续应针对持续波动。 [按秒复算](forward-yaw-localization.json)

在 12,600 个保存的前进输入上复算 0.12、0.15、0.18 rad/s 三档反馈上限。0.15 和 0.18 分别有约 25% 和 47% 的采样触发原 0.03 rad 关节修正上限。下一项先用 0.12 与 0.15 做同初态闭环对照，原前进判据继续生效。 [静态范围检查](forward-yaw-feedback-range.json) · [配对草案](../../../configs/experiments/continuous_forward_yaw_pair_draft.json)

从保存轨迹逐步重建到第 260 步首次前进决策，共 5 个场景同时进入。15 项阶段状态可还原，并逐项复现下一步的状态变化。配对试验还需核对实际 GPU 环境快照。 [分支控制器预检](forward-yaw-fork-controller-preflight.json)
[脚底接触与偏航周期复算](forward-yaw-gait-phase.json)用每个场景前半段的左脚触地周期拟合偏航曲线，再预测后半段。111 个通过场景和 15 个仅偏航失败场景的周期中位数均为约 0.46 秒，预测决定系数中位数为 0.91 和 0.90。两组在前进 20 秒内的绝对净航向变化中位数为 20.18° 和 21.85°。原判据仍按每步机身偏航速度的绝对值评分。
