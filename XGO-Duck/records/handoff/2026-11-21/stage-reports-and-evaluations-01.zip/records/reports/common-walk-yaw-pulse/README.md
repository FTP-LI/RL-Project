# 前进偏航单步脉冲

共同物理场景的 224 个环境共用前 50 步。随后从同一快照运行两次原策略及一次脉冲分支，各至第 200 步。第 51 步只改变 32 个前进场景的内部偏航输入，16 个为 +0.06 rad/s，16 个为 −0.06 rad/s。分支其余时刻和其他六条指令保持原映射。总预算 112,000 条转移、2,500 个批量物理子步、零学习。

将脉冲分支分别减去两次同状态原策略，用施加方向统一符号，比较 20 至 120 毫秒的偏航响应。原策略之间的差作为重复对照。预先要求 20 和 60 毫秒均通过方向一致性、效应和区间门槛，60 毫秒幅度至少保留首步的一半，才测试 60 毫秒预测反馈。七指令完整动作和至少 0.01 rad/s 的前进偏航收益仍在独立的 20 秒物理试验判断。

[冻结方案](../../../configs/experiments/common_walk_yaw_pulse.json) · [CPU 检查](preflight.json) · [执行进度](../../walk-yaw-pulse-live.html)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
  "$PY -B scripts/validation/common_walk_yaw_pulse.py --sample" /dev/null
"$PY" -B scripts/validation/verify_common_walk_yaw_pulse.py
```

## 实测响应

GPU 分支恢复逐项核验 309 个字段。候选只在第 51 步改变前进组偏航输入；其他六组的首个输入、动作和目标完全相同。每支复算 1,568 条 ONNX 输入，三段原片各 101 帧。

| 时点 | 对原策略一的响应（rad/s） | 对原策略二的响应（rad/s） |
| ---: | ---: | ---: |
| 20 毫秒 | +0.00806 | +0.00805 |
| 40 毫秒 | -0.00416 | -0.00397 |
| 60 毫秒 | +0.00108 | +0.00098 |
| 80 毫秒 | -0.00263 | -0.00277 |
| 100 毫秒 | +0.00184 | +0.00172 |
| 120 毫秒 | -0.00007 | -0.00052 |

20 毫秒两次配对各 31/32 同向，区间下界均约 0.00433 rad/s。40 毫秒出现反向响应。60 毫秒各 23/32 同向，区间跨零，响应只剩首步的 12%–13%。60 毫秒反馈候选关闭。 [独立核验、区间与原片](analysis.json) · [Windows 观察核验](../../evaluations/duck_walk_yaw-pulse_paired_s1045_20261110T015803/windows-view-verification.json)

用前六个平均响应建立短时线性模型。±0.06 rad/s 下，即使控制器知道未来偏航，开发轨迹的误差收益上限也只有 0.00566–0.00579 rad/s。冻结输入的 20 毫秒陀螺仪反馈回放约为 0.00086–0.00092 rad/s。上限仅适用于该线性模型，完整跟踪以独立物理试验为准。 [上限复算](saved-feedback-capacity.json)

另用开发 1040 拟合只读取当前与上一帧的响应方向预测，将前六个实际脉冲系数计入指令。在 1042、1043 两批保存轨迹回放中，±0.12 与 ±0.18 rad/s 估算最高收益分别约 0.0036、0.0053 rad/s，均低于原 0.01 门槛。两档未进入完整物理动作试验。 [反向响应回放](rebound-feedback-screen.json)

冻结 ONNX 的输入替换复算把第 52 步输出分为动作历史和其余观测两项。两次对照中，历史项在全部 32 个前进场景与首步动作改变反向，动作 RMS 中位数约 0.00190 rad，其余观测项约 0.00049 rad。首步的实际目标变化以左髋偏航和头部偏航为主，投影未削弱这次脉冲。该复算解释策略输出差异，物理反弹还需同目标试验。 [次步输出复算](action-response-review.json)

新组件在 224 个保存场景复现了命令脉冲的实际目标，保持原动作和请求不变，最大目标改变量约 0.01798 rad。越限候选在改写目标前停止。 [CPU 组件](history-probe-component-preflight.json) · [同目标对照草案](../../../configs/experiments/common_walk_yaw_history_probe_draft.json)
