# 连续前进偏航对照

原连续轨迹有 126 个场景完成滚翻、站立和 20 秒前进，111 个通过全部判据。15 个完成全程的失败场景仅偏航超过 0.20 rad/s。保存观测的推理对照支持先测试 0.12 与 0.15 rad/s 两档输入上限。

两组使用同一批 128 个开发场景，共用站立、滚翻和落地轨迹。首个场景进入前进后，在计算其第一个前进动作前保存物理状态、执行器延迟缓冲、随机数、状态机和策略历史。两组的归一化反馈乘数分别为 0.12 和 0.15 rad/s。同一观测下送入行走策略的反馈增量放大 25%。关节目标修正仍限于 0.03 rad，滚翻、落地和 20 秒前进的原评分保持一致。

候选须达到至少 116/128 个完整序列，配对净增至少 1 个，并保持原通过场景的前进存活与关节范围。达到冻结停止条件时保留原始轨迹和已完成录像。场景、权重及物理均为仿真用途，本轮零学习更新。

[上轮轨迹与偏航定位](../continuous-roll-projected-entry/README.md) · [冻结方案](../../../configs/experiments/continuous_forward_yaw_pair.json) · [零步前置核验](preflight.json) · [Windows 观察入口](windows-entry.json)

## 实测结果

| 偏航反馈乘数 | 滚翻并进入前进 | 完成 20 秒前进 | 通过全部判据 |
| --- | ---: | ---: | ---: |
| 0.12 rad/s | 122/128 | 122/128 | 110/128 |
| 0.15 rad/s | 122/128 | 122/128 | 122/128 |

0.15 rad/s 组达到 116/128 的开发门槛。配对新增 12 个通过场景，无原通过场景退步。122 个可比场景的平均绝对偏航速度变化为 −0.00602 rad/s，按场景配对自助抽样的 95% 区间为 [−0.00674, −0.00530] rad/s。两组均有 6 个场景未进入前进。

共享前段 259 个控制步，核对 300 项物理状态与 15 项阶段状态。首个观测、基础模型输入、原始动作及延迟后的首个电机命令逐位一致。两组共计 363,648 条转移、14,205 个批量物理子步、一次初始重置。Windows 读取 115 次运行中原始画面和 54 次带完整原片的状态。两段原片各 31 秒、776 帧。整机显存峰值 2,232 MiB，本轮评估固定 128 个场景，训练并行规模见原短测。 [独立评分](analysis.json) · [资源采样](gpu-samples.csv) · [Windows 观察核验](../../evaluations/duck_switch_forward-yaw-pair_development_s1095_20261110T052525/windows-view-verification.json)

从发布第 0 步到最后一个采样状态约 369 秒，含录像和中途归档，平均约 985 条转移/秒。共享前段少执行 259 个批量控制步，约占两次完整独立轨迹的 8.4%。这次固定评价的计时与 PPO 训练的吞吐分开记录。

[原反馈原片](../../evaluations/duck_switch_forward-yaw-pair_development_s1095_20261110T052525/clips/reference/clip-step-0.mp4) · [扩大反馈原片](../../evaluations/duck_switch_forward-yaw-pair_development_s1095_20261110T052525/clips/wider-input/clip-step-0.mp4)

入选项进入新开发种子复验。原 20 秒评分、滚翻判据和最低通过数保持一致。 [独立复验方案](../../../configs/experiments/continuous_forward_yaw_replication_draft.json)

Windows 可直接打开[运行观察页](../../continuous-forward-yaw-live.html)。以下命令重新核验已保存轨迹和原片，使用项目已有环境。已结束的采样批次保留原编号。

```powershell
wsl -d Ubuntu-24.04 -u atlas --exec /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/verify_continuous_forward_yaw_pair.py
```
