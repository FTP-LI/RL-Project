# 起身接七指令独立留出

同站立状态对照通过后，预留种子 2175 和 3,072 个场景。每个场景经过 2 秒姿态准备、9 秒起身与 1 秒站立，再执行 20 秒指令。完整回合及每条指令的成功率均须达到 95%。

## 初态复核

首次入口在物理零步时停止。复核从两次 CUDA 重置读取 `warp.cdof_dot` 的原生数组，368,640 个数值完全相同，其中一个零值的符号位不同。其他初态检查沿用原规则。场景分组、控制器、模型和评分门槛保持原定，首个物理步前记录独立消耗凭据。

[首轮停止](../continuous-routed-turn-feedback-holdout/README.md) · [冻结协议](../../../configs/experiments/continuous_routed_turn_feedback_holdout_zero_recovery.json) · [初态证据](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/zero-qualification.json) · [消耗凭据](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/holdout-consumption.json)

## 运行与观察

在 XGO-Duck 工作区用 VS Code 打开观察页或日志。页面保存阶段、控制步、每秒转移数和周期性原始画面。

[运行观察](../../continuous-routed-turn-feedback-holdout-zero-recovery-live.html) · [执行日志](sample.log) · [执行入口](../../../scripts/validation/recover_routed_turn_holdout_zero.py) · [运行记录](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/README.md)

RTX 3080 Laptop GPU 以 3,072 个环境并行完成 1,600 个控制步，共 4,915,200 条转移。采样耗时 290.9 秒，平均每秒 16,897 条，50 步观察窗口的吞吐中位数为每秒 19,256 条。显存峰值 13,122 MiB，占 16 GiB 的 80.1%。Windows 观察核验含 32 次带原始画面的进度更新。

[采样状态与计数](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/evaluation.json) · [显存时序](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/gpu-telemetry.json) · [观察核验](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/windows-view-verification.json)

## 独立评分

完整通过 2,992/3,072（97.40%），原总体门槛为 2,919。共有 2,993 个场景进入指令段，其中一例左转在步态评分失败。

| 指令 | 完整通过 | 门槛 |
| --- | ---: | ---: |
| 站立 | 431/439 | 418 |
| 前进 | 427/439 | 418 |
| 后退 | 427/439 | 418 |
| 左转 | 422/439 | 418 |
| 右转 | 430/439 | 418 |
| 左平移 | 428/439 | 418 |
| 右平移 | 427/438 | 417 |

场景 0 的左转原片完整记录姿态准备、起身、站立与接入左转，共 801 帧。仿真交付索引核对了六个实际推理模型和五个自训保存点。

[独立评分](analysis.json) · [32 秒原片](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/restored-gyro/clip-step-0.mp4) · [标注关键帧](../stage-media/cards/N628.jpg) · [权重和控制清单](../../../artifacts/delivery/routed-seven-command-simulation.json)
