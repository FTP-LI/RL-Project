# 后退停滞在线加权

两组都从原生环境重置开始，使用相同的初始策略、奖励、价值损失、训练预算和六指令保留样本。候选仅将已观察到的停滞样本在 PPO 策略损失中的权重设为 3。权重按有效样本的权重和归一化，保留原 PPO 裁剪。每个环境独立计时，结束或重置后重新计数。 [方案](../../../configs/experiments/common_walk_backward_online_focus_draft.json) · [实现](../../../scripts/training/walk_backward_online_focus.py)

在种子 1131 的原始轨迹上，CPU 和 CUDA 识别出相同的 71 个场景。加权覆盖控制步 101–300 的 14,200 条有效样本，对照始终为 1。核验覆盖提前结束、部分重置、缺失速度、全无效批次以及对照损失与梯度一致性。六指令保留样本每类 512 条，来源文件哈希已核对。本轮学习更新和仿真步数均为零。 [复算输出](readback.json)

在仓库根目录使用已安装 CUDA 依赖的 Python 运行复算。

```bash
python scripts/validation/check_walk_backward_online_focus.py
```

## 原生采样核验

在共同物理环境中使用 −0.10 m/s 后退指令，策略仍接收 −0.14 m/s 的映射值。原 76 项价值观测增加一项剩余时间，策略的 61 项观测保持原接口。CPU 实际环境验证了局部重置和 17 项原生奖励，CUDA 实际环境验证了原生自动重置后的动作历史和回报边界。验证用价值网络固定，训练前需要另行建立价值起点。 [CPU 核验](native-cpu.json) · [采样实现](../../../scripts/training/walk_backward_native_rollout.py)

本机 1,024 个 CUDA 环境实际采样 393,216 条转移，67 个场景被标记，13,400 条样本被加权。为验证超时，预先指定环境 1 在第 24 步只把回合年龄设为 999，随后由原生环境执行第 1,000 步和自动重置。终止回报与原生奖励一致。独立复算两类结束边界和全部价值目标，最大误差 2.53×10⁻⁶。 [数值与计时](../../evaluations/duck_walk_native-rollout-probe_reference_s1133_20261110T084940/analysis.json) · [独立核验](../../evaluations/duck_walk_native-rollout-probe_reference_s1133_20261110T084940/verification.json)

热身后 320 步净吞吐约 13,279 条转移/秒。计时窗口中录像约 4.04 秒、运行页和日志更新约 0.12 秒，显存峰值为 5,084 / 16,384 MiB。Windows 读到了 12 次带真实帧的运行中状态，完整原片覆盖 0–4 秒、101 帧。该轮未更新权重。 [运行观察](../../walk-backward-native-probe-live.html) · [完整原片](../../evaluations/duck_walk_native-rollout-probe_reference_s1133_20261110T084940/clip-step-0.mp4)

细测选定 3,072 环境，两遍净吞吐约为 2.64–2.67 万条转移/秒。实际 PPO 采样和梯度计算通过显存准入，价值目标已独立复算。两路配对学习使用同一价值起点和训练预算，独立评价保留原七指令和安全门槛。 [细测结果](../../benchmarks/duck_walk_native-scale_reference_s1135_20261110T090325/README.md) · [PPO 核验](../../evaluations/duck_walk_ppo-headroom_reference_s1136_20261110T091415/README.md)
