# 后退停滞状态采集

使用普通重置与原官方策略，共享前 100 步，在第 2 秒根据两段速度与存活状态筛选候选。随后从同一点各续跑 200 步。 [前缀筛选](../common-walk-backward-stall-prefix/README.md)

首次入口在环境创建前因上下文管理器写法错误退出。修复后，种子 1130 的 1,024 环境完成一次重置，所需快照为 291,106,848 字节，超过 268,435,456 字节上限，在零物理步停止。容量调整保留上限并按 5% 余量选择 896 个环境，使用新开发种子 1131。最多 448,000 条转移、2,500 个批量物理子步。 [入口中止](zero-step-stop.json) · [容量中止](recovery/capacity-stop.json) · [调整后的冻结方案](../../../configs/experiments/common_walk_backward_stall_capture_capacity.json)

归档保存求解器与执行器缓冲、传感器、观测、动作历史、命令和随机状态。第二条分支读取磁盘归档，按原样写回环境，并核对状态哈希和首步输出。实际 CUDA 采集受 85% 显存上限约束。 [CPU 检查](capacity/preflight.json) · [运行观察](../../walk-backward-stall-capture-s1131-capacity-live.html) · [Windows 入口核验](capacity/windows-entry.json)

```bash
bash scripts/validation/run_walk_backward_stall_capture.sh
```

## 采集结果

种子 1131 完成 448,000 条实际环境转移，GPU 显存峰值为 4,874 / 16,384 MiB。896 个环境中筛入 71 个，其中 19 个在两路中都保持近静止至第 6 秒。压缩归档为 13,316,645 字节，从磁盘恢复的 309 项运行状态哈希全部一致。 [采集和归档核验](capacity/analysis.json)

第 101 个控制步的输入观测、策略输出和电机目标相同，但步后关节位置的最大误差为 2.14×10⁻⁴ rad，超过预定的 2×10⁻⁵ rad。4 个仍有效的环境超差，其中 1 个属于筛入的停滞场景。差异出现在左右踝和左膝，首步记录的脚底接触标记一致。观测和动作从第 102 步开始出现差异。物理恢复未通过，关闭这条训练路线。 [逐步差异](capacity/continuation-audit.json)

Windows 端读到 6 次运行中状态，其中 5 次含原始画面。结束页已按累计控制步改为 500/500，原始状态文件仍可按哈希核对。两条原片各覆盖 0–4 秒、101 帧，固定记录环境 0。 [运行观察](../../walk-backward-stall-capture-s1131-capacity-live.html) · [原续跑](../../evaluations/duck_walk_backward-stall-capture_capacity_s1131_20261110T083432/evaluation-backward/clip-step-0.mp4) · [磁盘恢复](../../evaluations/duck_walk_backward-stall-capture_capacity_s1131_20261110T083432/evaluation-reference-repeat/clip-step-0.mp4)

后续改用原生重置，在正常采样中识别已发生的停滞。 [在线加权验证](../common-walk-backward-online-focus/README.md)
