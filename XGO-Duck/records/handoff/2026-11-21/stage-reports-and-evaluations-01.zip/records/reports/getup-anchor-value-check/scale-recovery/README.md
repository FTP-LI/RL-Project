# 新种子固定价值检查

已完成，价值准入通过，起身功能另行评估。新种子43、400控制步×1024，409600转移，actor/critic均零更新且逐位不变。独立CPU复算25600验证输入：EV0.8078015、归一化MSE0.029093，四姿态EV均为正。

[协议](../../../../configs/experiments/getup_anchor_scale_recovery.json)固定83份来源；[CPU预检](preflight.json)、[独立复算](analysis.json)和[原片](../../../experiments/duck_getup_anchor-scale_reference_s43_20261103T131707/clip-step-0.mp4)保留完整8秒201帧、25fps及逐帧状态哈希。原VS Code共享终端完成采集，无隐藏任务。

父协议在物理0步因报告独立复算标量与检查点相差一个双精度单位停止。[失败分析](../failure-analysis.json)保留差值和原记录；独立修复只直接读取检查点标量15.416328204600083，严格相等断言及其余门槛保持不变，不重拟合、不续跑父轮。
