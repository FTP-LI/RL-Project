# 后退摆动脚净空

使用开发种子 1077、1078 在两秒分支点保存的 13 个共同停滞姿态。分别试算左右摆动腿，固定机身和另一条腿。每关节保持 0.03 rad 上限，鞋底最低点须抬升至少 2 毫米并高出地面至少 0.5 毫米，同时检查脚的水平位移、旋转和支撑脚位置。 [冻结协议](../../../configs/experiments/common_walk_backward_swing_clearance_jacobian_readback.json) · [有效复算](jacobian-readback/analysis.json)

26 个试算均未达到门槛。最高鞋底抬升为 0.323 毫米，最高最终净空为 0.035 毫米。关节雅可比和中央有限差分最大相差 1.75×10⁻⁹ m/rad。关闭固定机身的这项单腿目标方案，保留共同接口后退启动的原验收。

首次读取因来源哈希手录错误停住，随后确认归档缺少速度字段，改为用原位置做纯运动学。首次位置雅可比缺少缓存更新，产生的全零结果作废，保留在原位置。修正后逐关节用中央有限差分独立检查。全程物理步和学习更新均为零。 [来源修复](../../../configs/experiments/common_walk_backward_swing_clearance_hash_readback.json) · [作废结果](analysis.json)

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- env PYTHONPATH=scripts/validation:scripts/training /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/run_walk_backward_swing_clearance_readback.py --jacobian
```
