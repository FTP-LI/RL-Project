# 起身同一释放对照

开发种子 1056 在同一物理释放状态比较两次官方策略和已有的成功动作保持模型。候选总体达到 95% 门槛，实际仰卧与指定仰卧仍未通过。三组均未通过完整功能验收。 [独立结果](analysis.json)

## 持稳成绩

第 8 秒前开始连续持稳 3 秒，并在第 8–11 秒全程持稳。本轮两个条件的通过名单相同。实际释放每类至少 32 次，无未知类别。表中按指定姿态与实际释放分别计数。

| 分组 | 官方一 | 官方二 | 已训练模型 | 至少通过 |
| --- | ---: | ---: | ---: | ---: |
| 总体 | 301/320 | 294/320 | 305/320 | 304 |
| 指定俯卧 | 32/32 | 32/32 | 32/32 | 31 |
| 指定仰卧 | 29/32 | 28/32 | 27/32 | 31 |
| 指定左侧 | 122/128 | 116/128 | 122/128 | 122 |
| 指定右侧 | 118/128 | 118/128 | 124/128 | 122 |
| 实际俯卧 | 32/32 | 32/32 | 32/32 | 31 |
| 实际仰卧 | 153/171 | 148/171 | 157/171 | 163 |
| 实际左侧 | 61/61 | 60/61 | 60/61 | 58 |
| 实际右侧 | 55/56 | 54/56 | 56/56 | 54 |

候选的实际仰卧比分别高 4 次和 9 次，指定仰卧比分别少 2 次和 1 次。两次官方在实际仰卧有 13 个逐场景分歧。对同一批实际仰卧，候选在 11 个双官方失败场景中恢复，在 10 个双官方成功场景中退化。结果来自一个开发种子。 [逐场景对照](mechanism-review.json)

候选 15 次失败均在末段出现头腿接触和倾角超限，其中 13 次在第 3 秒时或之前已出现头腿接触。末段没有其他评分项越线。接下来单独试验仰卧释放首秒的训练权重。 [失败轨迹](mechanism-review.json) · [训练草案](../../../configs/experiments/getup_supine_weighted_learning_draft.json)

## 运行与复查

固定同一 2 秒跌落前缀。三组释放时 345 项状态、首个策略输入和首个延迟执行器值逐位一致。物理场景、噪声、关节投影和后段限速相同。三路共完成 1,450 个批量控制步、7,250 个物理子步、464,000 条转移，只有一次初始重置。模型权重固定，留出集未使用。 [协议](../../../configs/experiments/getup_anchor_same_release.json) · [CPU 检查](preflight.json) · [运行状态](coordinator.json) · [可见终端日志](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/execution.log)

![起身对照终端](../../../docs/reports/assets/getup-anchor-same-release-terminal.jpg)

实际从原 VS Code 的 `Terminal → Run Task…` 运行 `XGO-Duck · 起身同一释放三组对照`，窗口边界与布局核验一致。该任务已归档。终端对应命令为 `bash scripts/training/training_workflow.sh getup-anchor-same-release`。该轮已经关闭，同一运行名有防重复守卫。 [窗口核验](terminal-layout.json) · [任务历史](../../../configs/environments/vscode_tasks_history.json)

可见任务在采集结束时自动调用 `getup_anchor_same_release.py --verify`，复算评分、控制历史和媒体来源。该入口要求采集完毕、等待核验的状态。现在可从 WSL 工程根目录复算逐场景差异，物理步数为零。

```bash
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_getup_anchor_same_release.py
```

## 原片与关键帧

每段均为 25 fps、276 帧，物理时间覆盖 0–11 秒。三段仰卧选用同一预设环境 0，候选四个相机环境的指定姿态和实际释放姿态相符。图册标出第 2 秒释放和第 11 秒末段判定。 [逐段图册](../../../docs/reports/stage-video-gallery.html)

| 分支 | 环境 | 完整录像 | 标注帧 |
| --- | ---: | --- | --- |
| 官方一 · 仰卧 | 0 | [原片](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/evaluation-reference-a-supine/clip-step-0.mp4) | [N322](../stage-media/cards/N322.jpg) |
| 官方二 · 仰卧 | 0 | [原片](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/evaluation-reference-b-supine/clip-step-0.mp4) | [N323](../stage-media/cards/N323.jpg) |
| 已训练模型 · 俯卧 | 2 | [原片](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/evaluation-success-anchor-prone/clip-step-0.mp4) | [N324](../stage-media/cards/N324.jpg) |
| 已训练模型 · 仰卧 | 0 | [原片](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/evaluation-success-anchor-supine/clip-step-0.mp4) | [N325](../stage-media/cards/N325.jpg) |
| 已训练模型 · 左侧 | 1 | [原片](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/evaluation-success-anchor-left-side/clip-step-0.mp4) | [N326](../stage-media/cards/N326.jpg) |
| 已训练模型 · 右侧 | 3 | [原片](../../evaluations/duck_getup_anchor-same-release_paired_s1056_20261109T204411/evaluation-success-anchor-right-side/clip-step-0.mp4) | [N327](../stage-media/cards/N327.jpg) |
