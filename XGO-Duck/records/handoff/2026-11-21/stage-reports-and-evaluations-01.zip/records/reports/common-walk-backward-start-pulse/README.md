# 后退启动助推

开发种子 1073、1074 各 224 个新场景。两路参照和候选共享第 2 秒前的物理状态及控制器记忆。用前 1 秒的双侧髋、膝俯仰速度判断低活动。候选在第 101–120 步采用 −0.18 m/s 的替代输入，投影后每步修正限于 0.03 rad，保留原策略动作、历史和外部指令。每批均要求至少挽回一个两路参照共同停滞的场景，并保持触发场景的既有启动与安全判据。

[冻结方案](../../../configs/experiments/common_walk_backward_start_pulse.json) · [CPU 零步](preflight.json) · [冻结日志](../common-walk-backward-onset/start-pulse-freeze.log) · [上轮回放与阈值](../common-walk-backward-onset/README.md)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
for seed in 1073 1074; do
  flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
    "$PY -B scripts/validation/collect_walk_backward_start_pulse.py --sample $seed" /dev/null || break
  "$PY" -B scripts/validation/verify_walk_backward_start_pulse.py "$seed" || break
done
```

## 实测结果

| 种子 | 触发 | 共同停滞 | 挽回 | 已启动损失 | 触发安全越线 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1073 | 25 | 6 | 0 | 0 | 0 |
| 1074 | 25 | 7 | 1 | 0 | 0 |

两批实际采集 313,600 条转移、7,000 个批量物理子步。三路分支各核对 309 项物理和控制器状态，首个延迟电机命令完全一致。每批独立重放 500 条替代 ONNX 输入，目标修正均在 0.03 rad 和浮点容差内。两批各有三段 4 秒相机原片，Windows 各读到 8 个运行中状态。固定评估的显存峰值为 3,731、3,726 MiB。 [1073 评分与原片](seed1073-analysis.json) · [1074 评分与原片](seed1074-analysis.json) · [1073 观察](../../walk-backward-pulse-s1073-live.html) · [1074 观察](../../walk-backward-pulse-s1074-live.html) · [1073 资源](gpu-s1073.csv) · [1074 资源](gpu-s1074.csv)

13 个共同停滞场景在助推期间均未出现单脚支撑。1074 场景 180 到第 4–5 秒分块才达到 0.09492 m/s 后退均速。两批挽回结果未达到共同晋级门槛。下一步用开发轨迹对齐首次单脚支撑与此前的髋、膝、踝动作，区分自然迟启动和持续停滞。 [响应复算](response-review.json) · [下一步方案](../../../configs/experiments/common_walk_backward_support_transfer_draft.json)

## 单脚支撑前侧移

四批保存轨迹的 59 个迟启动场景中，50 个在 140 毫秒内向随后承重的脚侧移。窗口开始与结束时偏向该脚的比例分别为 28/59、54/59。八个批次与左右侧组合的侧移中位数均高于同批、同侧、同时间窗口的停滞样本。位置只能反映侧向位移，承重力与因果方向仍需独立检查。 [原始几何复算](lateral-loading-review.json)
