# 七指令独立留出

同站立状态开发对照通过后，单独预留种子 2175。沿用恢复的陀螺仪转向反馈和原七项输入、起身、站立及步态门槛。全体 3,072 个场景各运行一次 32 秒，逐指令和总体完整成功率均须达到 95%。 [开发对照](../continuous-routed-turn-feedback-pair/README.md) · [冻结协议](../../../configs/experiments/continuous_routed_turn_feedback_holdout.json) · [CPU 冻结核验](freeze.json) · [运行观察](../../continuous-routed-turn-feedback-holdout-live.html)

留出使用同一套已通过配对的控制器，保持首个实际物理步之前的独立消耗凭据。保存真实进度、原片、独立评分所需轨迹和首个切换控制的完整输入输出。

## 首轮启动记录

正式入口在 CUDA 初态复核时发现 `warp.cdof_dot` 哈希差异。已尝试及完成的控制步和物理步均为零，留出尚未使用。复核单独保存两次原生重置的完整派生量，要求有限数值逐元素一致，逐位记录零值符号差异。

[首轮退出](sample-exit.json) · [首轮评估记录](../../evaluations/duck_switch_routed-turn-gyro_holdout_s2175_20261110T225946/evaluation.json) · [初态复核方案](../../../configs/experiments/continuous_routed_turn_feedback_holdout_zero_recovery.json) · [复核运行观察](../../continuous-routed-turn-feedback-holdout-zero-recovery-live.html)
