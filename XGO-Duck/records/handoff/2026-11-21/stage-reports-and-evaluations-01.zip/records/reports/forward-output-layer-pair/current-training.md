# 前进输出层配对

两组各12次更新，保存点和ONNX已独立复核。

[权重与原片清单](training-check.json) · [全策略层曲线](control/native-view/native-curve.png) · [末端输出层曲线](candidate/native-view/native-curve.png) · [导出核验日志](export-readback-command.log)
