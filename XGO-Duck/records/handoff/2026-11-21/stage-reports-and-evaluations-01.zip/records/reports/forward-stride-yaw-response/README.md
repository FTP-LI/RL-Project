# 前进完整步态周期偏航对照

[VS Code逐组进度](current-evaluation.md) · [冻结方案](../../../configs/experiments/forward_stride_yaw_response/master.json) · [冻结日志](freeze-command.log) · [批次日志](batch-command.log)

两个低摩擦种子各128个场景的归档轨迹均覆盖两个完整左脚起始周期和两个完整右脚起始周期。从前进第4秒起，两个起始方向的两周期均在68个控制步内完成。首段脉冲参照在随后3秒的场景平均绝对偏航中位数分别为0.231686和0.231042rad/s。若末段持续在这一水平，则按各场景实测前4秒推算，达到20秒0.20rad/s门槛所需的后段平均偏航降幅中位数分别为0.036000和0.034848rad/s。[归档逐组复算](archived-stride-coverage.json)

下一次对照从站立起点后的5秒保存CUDA快照。每组运行两次仅首段脉冲参照、同侧反向右髋俯仰、0.13m/s前进模型输入和0.115m/s前进模型输入。模型输入用0.30秒过渡，原外部0.15m/s指令用于全部评分。两套接触起点都在过渡结束后取两个完整周期。前进输入和相位修正分别对照，以区分步幅变化和单关节作用。[对照草案](../../../configs/experiments/forward_stride_response_draft.json)

每组128个场景，计划250个共同控制步和五条各150步的分支，共1,000个批量控制步。候选进入下一次完整20秒对照的条件为两个种子的3秒配对降幅均超过两次参考差的第95百分位、两种接触起点均观察到周期偏航下降，并且至少116/128个场景的后段偏航投影和已观察到的速度、姿态与接触条件达到原动作门槛。投影用于筛选需实测的候选。

独立CPU使用两个种子各512条保存观测复算官方ONNX。把前进模型输入从0.15m/s改为0.130或0.115m/s时，各种子内单场景最大关节动作差的第95百分位分别约为0.062和0.109rad。CUDA对照按15个控制步逐渐改变模型输入，之后用实际速度和接触检验折减是否合适。[ONNX输入复算](actor-input-preflight.json)

## 完整周期结果

两组共256,000条实际环境转移。种子1247、1248的双参照3秒绝对偏航差第95百分位分别为0.016122和0.014928rad/s。0.130m/s模型输入的场景配对偏航降幅中位数分别为0.088751和0.088664rad/s，0.115m/s的降幅分别为0.111922和0.112260rad/s。两档在两个接触起点的完整周期间均降低偏航，分别有128/128个场景通过20秒偏航投影和已测动作条件。反向右髋俯仰的降幅低于双参照波动。按原筛选排名选0.115m/s进入完整20秒测量。[逐组评分和十段8秒原片](current-evaluation.md) · [独立重复与选型记录](stride-comparison.json)

![前进输入与偏航](stride-response-tradeoff.png)

两个低摩擦种子的0.115m/s组，两种接触起点的周期中位时长均为0.46秒，双参照均为0.47秒。候选每周期水平净位移的场景中位数约0.058m，双参照约0.074m。过渡后绝对偏航的汇总降幅集中于左脚单独支撑前3步和右脚单独支撑前8步，两个种子占85%至86%。[实际支撑时序和净位移](input-gait-phase-analysis.json)

首次独立评分发现多余运算符，复算时又发现反向分支的启用时刻须绑定真实CUDA分支边界。后续按归档控制步逐项复核首组，保留原采样和两次评分日志。第二组在校验通过后完成原定采样。首组复算新增物理步为0。[评分恢复](score-recovery.json) · [实际分支边界复核](replay-boundary-recovery.json) · [执行记录](replay-boundary-command.log)

| 低摩擦种子 | VS Code状态 | 采样曲线 | 采集日志 |
| --- | --- | --- | --- |
| 1247 | [状态](s1247-friction-low/native-view/native-status.txt) | [曲线](s1247-friction-low/native-view/native-curve.png) | [日志](s1247-friction-low/collect-command.log) |
| 1248 | [状态](s1248-friction-low/native-view/native-status.txt) | [曲线](s1248-friction-low/native-view/native-curve.png) | [日志](s1248-friction-low/collect-command.log) |
