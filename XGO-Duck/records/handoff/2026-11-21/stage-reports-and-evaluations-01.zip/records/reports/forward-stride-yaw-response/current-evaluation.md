# 前进完整步态周期偏航对照

后段偏航为各场景分支3秒平均绝对偏航速度的中位数。投影视作后续完整20秒评估的筛选依据。

| 低摩擦种子 | 组别 | 3秒偏航（rad/s） | 后段速度（m/s） | 投影与观察通过数 |
| --- | --- | ---: | ---: | ---: |
| 1247 | 首段脉冲参照一 | 0.231584 | 0.15965 | 0/128 |
| 1247 | 反向右髋俯仰 | 0.230332 | 0.16023 | 0/128 |
| 1247 | 前进模型输入0.130m/s | 0.142197 | 0.14306 | 128/128 |
| 1247 | 前进模型输入0.115m/s | 0.119657 | 0.12771 | 128/128 |
| 1247 | 首段脉冲参照二 | 0.231677 | 0.15971 | 0/128 |
| 1248 | 首段脉冲参照一 | 0.232634 | 0.15973 | 0/128 |
| 1248 | 反向右髋俯仰 | 0.232184 | 0.16025 | 0/128 |
| 1248 | 前进模型输入0.130m/s | 0.144190 | 0.14308 | 128/128 |
| 1248 | 前进模型输入0.115m/s | 0.120378 | 0.12767 | 128/128 |
| 1248 | 首段脉冲参照二 | 0.233579 | 0.15964 | 0/128 |

[种子1247逐组评分](s1247-friction-low/independent.json) · [首段脉冲参照一原片](../../../records/evaluations/duck_forward_stride_response_s1247-friction-low_20261121T030805/clips/reference-a/clip-step-0.mp4) · [反向右髋俯仰原片](../../../records/evaluations/duck_forward_stride_response_s1247-friction-low_20261121T030805/clips/right-hip-reverse/clip-step-0.mp4) · [前进模型输入0.130m/s原片](../../../records/evaluations/duck_forward_stride_response_s1247-friction-low_20261121T030805/clips/forward-input-0130/clip-step-0.mp4) · [前进模型输入0.115m/s原片](../../../records/evaluations/duck_forward_stride_response_s1247-friction-low_20261121T030805/clips/forward-input-0115/clip-step-0.mp4) · [首段脉冲参照二原片](../../../records/evaluations/duck_forward_stride_response_s1247-friction-low_20261121T030805/clips/reference-b/clip-step-0.mp4)
[种子1248逐组评分](s1248-friction-low/independent.json) · [首段脉冲参照一原片](../../../records/evaluations/duck_forward_stride_response_s1248-friction-low_20261121T030805/clips/reference-a/clip-step-0.mp4) · [反向右髋俯仰原片](../../../records/evaluations/duck_forward_stride_response_s1248-friction-low_20261121T030805/clips/right-hip-reverse/clip-step-0.mp4) · [前进模型输入0.130m/s原片](../../../records/evaluations/duck_forward_stride_response_s1248-friction-low_20261121T030805/clips/forward-input-0130/clip-step-0.mp4) · [前进模型输入0.115m/s原片](../../../records/evaluations/duck_forward_stride_response_s1248-friction-low_20261121T030805/clips/forward-input-0115/clip-step-0.mp4) · [首段脉冲参照二原片](../../../records/evaluations/duck_forward_stride_response_s1248-friction-low_20261121T030805/clips/reference-b/clip-step-0.mp4)

[配对差与完整周期结果](stride-comparison.json)
