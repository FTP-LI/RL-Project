# 起身、站立与渐升前进

本轮用新的开发种子复验完整 32 秒。同一个物理回合依次运行跌倒、起身、站立和前进。第 12 秒接入前进时，用 25 个控制步把指令逐渐升到 0.15 m/s。全程用同一条 0.15 m/s 外部指令评分，所有 3,072 个场景都计入完整序列分母，验收门槛为 95%。

模型、原始动作历史、各阶段切换时钟、限速与偏航反馈沿用原连续序列。采样上限为 1,600 个控制步、8,000 个批量物理子步和 4,915,200 条转移。 [原连续序列](../continuous-routed-getup-stand-walk/README.md) · [起步对照](../continuous-routed-forward-entry-ramp/README.md) · [冻结方案](../../../configs/experiments/continuous_routed_getup_ramped_forward.json) · [CPU 核验](freeze.json) · [运行观察](../../continuous-routed-getup-ramped-forward-live.html)

CUDA 零步核验通过 335 项状态，渐升时钟检查覆盖前 26 步。同步读回交付目录中的 4 份官方 ONNX、5 份自训 ONNX 和 5 份对应保存点。14 份文件均与各自来源字节一致，ONNX 输入输出及关节顺序通过核对，保存点压缩记录通过完整性检查。首次 CPU 入口在导入时退出，调整导入顺序后完成冻结，失败时物理步为零。 [CUDA 核验](independent-zero/proof.json) · [交付文件读回](component-readback.json) · [首次入口日志](freeze-entrypoint-first.log)

## 独立评分

| 项目 | 结果 |
| --- | ---: |
| 起身及时并末段持稳 | 2,983/3,072，指定与实际四姿态均通过 |
| 站立持稳并接入前进 | 2,983/3,072 |
| 完整 20 秒前进 | 2,976/2,983 |
| 完整 32 秒序列 | 2,976/3,072（96.88%） |

达到原 95% 开发门槛。进入前进的场景起步两秒仍为 0 例持续严重姿态异常，平均绝对偏航为 0.129 rad/s。完整前进段平均绝对偏航为 0.136 rad/s，平均前向速度为 0.158 m/s。89 个场景未进入前进，7 个已进入场景仅偏航超限。独立重建 25 个渐升输入，复核 636 条 ONNX 输入、两次切换和实际关节目标。后续独立留出通过 2,990/3,072。 [完整评分](analysis.json) · [起步与失败分组](startup-throughput-review.json) · [独立留出](holdout/README.md)

## 运行与录像

采样完成 4,915,200 条转移和 8,000 个批量物理子步，全程只有初始重置。含录像和写盘用时 421.62 秒，净吞吐为每秒 11,658 条。显存峰值 13,036 MiB，平均 GPU 利用率 35.1%。常规 50 步窗口的速率中位数为每秒 18,613 条，包含上一批压缩写盘的窗口为 5,323 条。Windows 核验 33 次运行刷新，其中 32 次含真实画面。原片共 32 秒、801 帧。 [采样退出记录](sample-exit.json) · [评分日志](verify.log) · [观察核验](../../evaluations/duck_switch_routed-getup-ramped-forward_development_s1172_20261110T211424/windows-view-verification.json) · [32 秒原片](../../evaluations/duck_switch_routed-getup-ramped-forward_development_s1172_20261110T211424/clip-step-0.mp4)

从 3,072 个场景取 25 步的全部遥测，比较两个无损压缩级别。两轮逐数组哈希均一致。低压缩级别把写入中位耗时从 2.20 秒缩短到 1.85 秒，文件增大 0.31%，写入速率提高约 19%，低于预设的 20% 门槛。留出沿用已有写盘设置。 [压缩短测](trace-compression-benchmark.json)

下图来自固定镜头的完整原片，场景 0 实际仰卧释放。 [原片与关键帧核验](media-review.json)

![起身、站立与渐升前进](sequence-keyframes.jpg)
