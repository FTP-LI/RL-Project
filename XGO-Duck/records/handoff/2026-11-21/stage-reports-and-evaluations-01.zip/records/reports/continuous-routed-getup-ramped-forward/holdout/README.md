# 起身、站立与渐升前进留出

本轮从 3,072 个新场景开始，完整记录 32 秒。使用原四姿态起身、站立接入、20 秒前进和整段 95% 判据。相较开发轮，物理与控制配置保持相同，种子和指定姿态排列独立。

CPU 与实际 CUDA 零步核验通过，后者核对了 335 项状态。Windows 观察页通过启动检查。一次性使用记录在初始重置之后、第一个物理步之前写入。 [冻结方案](../../../../configs/experiments/continuous_routed_getup_ramped_forward_holdout.json) · [CPU 核验](freeze.json) · [CUDA 零步](independent-zero/proof.json) · [一次性使用记录](consumption.json) · [运行观察](../../../continuous-routed-getup-ramped-forward-holdout-live.html)

## 独立评分

| 项目 | 通过数 |
| --- | ---: |
| 起身及时并末段持稳 | 2,992/3,072 |
| 站立持稳并接入前进 | 2,992/3,072 |
| 完整 20 秒前进 | 2,990/2,992 |
| 完整 32 秒序列 | 2,990/3,072（97.33%） |

实际释放的俯卧、仰卧、左侧和右侧分别为 286/288、2,362/2,438、190/190、154/156，指定姿态和实际姿态的各项门槛均通过。整段未通过的场景中，80 个未接入前进，2 个仅偏航超限。完整前进段平均前向速度为 0.158 m/s，平均绝对偏航为 0.136 rad/s。独立复算核对了 25 个渐升输入和 636 条 ONNX 输入。 [独立评分](analysis.json) · [评分日志](verify.log) · [模型与保存点](../../../../artifacts/delivery/ramped-getup-standing-forward-simulation.json)

本轮共 4,915,200 条转移、8,000 个批量物理子步，只有一次初始重置。含录像和写盘耗时 422.82 秒，净吞吐约每秒 11,625 条转移。显存峰值 13,021 MiB。Windows 核验 33 次运行刷新，32 次带真实画面。原片共 32 秒、801 帧。 [采样退出](sample-exit.json) · [Windows 核验](../../../evaluations/duck_switch_routed-getup-ramped-forward_holdout_s2172_20261110T213200/windows-view-verification.json) · [完整原片](../../../evaluations/duck_switch_routed-getup-ramped-forward_holdout_s2172_20261110T213200/clip-step-0.mp4)

下图选自固定场景的完整原片。实际释放为仰卧，按回合时钟标注各阶段。 [原片和帧核验](media-review.json)

![留出关键帧](sequence-keyframes.jpg)
