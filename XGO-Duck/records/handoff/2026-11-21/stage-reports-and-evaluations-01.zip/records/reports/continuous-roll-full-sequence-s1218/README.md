# 完整连续路由复盘

seed-1218 使用冻结的官方滚翻和已验收行走组件，在同一物理回合中执行 50 步站立、450 步前滚翻、50 步落地站立和 1,000 步前进。跨模型 bridge 关闭，未进行学习、留出评估或硬件 IO。

滚翻入口为 128/128，落地并进入前进接力为 123/128，超过 116/128 的阶段门槛。原有 20 秒前进判据为 111/128，低于 116/128，因此完整路线不晋级。5 个世界没有进入前进，12 个世界只因偏航误差超过 0.2 rad/s 失败；速度、线性误差、接触滑移、头部穿透和关节范围没有造成主要失分。

关键证据：

- [离线分析](analysis.json)
- [冻结协议](../../configs/experiments/router_full_sequence_s1218.json)
- [原始评分](../../records/training-archive/evaluations/duck_switch_roll-stand-walk_development_s1218_20261114T025305/raw-score.json)
- [完整状态轨迹](../../records/training-archive/evaluations/duck_switch_roll-stand-walk_development_s1218_20261114T025305/trace.npz)
- [实际动作目标](../../records/training-archive/evaluations/duck_switch_roll-stand-walk_development_s1218_20261114T025305/commands.npz)
- [完整 31 秒录像](../../records/training-archive/evaluations/duck_switch_roll-stand-walk_development_s1218_20261114T025305/clip-step-0.mp4)
- [阶段关键帧](../../docs/reports/assets/router-full-sequence-s1218-keyframes.jpg) · [关键帧清单](../../docs/reports/assets/router-full-sequence-s1218-keyframes.json)

复现离线评分：

```powershell
python scripts/validation/analyze_router_full_sequence.py records/evaluations/duck_switch_roll-stand-walk_development_s1218_20261114T025305
```

该结果只允许进入接力失败和偏航失败的单因素诊断；不把当前组件组合标记为最终多技能模型，也不启动无目标的长训练。

## S15 切换时序审计

对同一份状态轨迹做保存数据审计。123/128 个世界在控制步 210–229 进入落地站立，123/128 个世界在控制步 260–279 进入前进，已进入前进的切换延迟固定为 50 步。未进入前进的 5 个世界可以由“控制步 500 前未进入站立”这一因果事件完整识别，但这只是失败分类信号，不能挽回滚翻完成度。

对 123 个已进入前进的世界，使用前 50 步的角速度、速度、脚速、高度、头部接触和穿透摘要筛查偏航失败。留一环境重拟合没有形成同时覆盖至少 75% 偏航失败、成功误触发不超过 5% 的规则；因此不改变原 0.2 rad/s 判据，也不启动新的 PPO 或动力学对照。 [S15 机器可读审计](route-transition-causal-s15.json) · [审计脚本](../../scripts/validation/audit_route_transition_causal_s15.py)
