# 右转早期切换

三组右转均为 30/32，未挽回已知两例，关闭本次切换。独立复算了三组各 224,000 条转移、全部实际名义动作和原七指令。种子 1141 的原生初态与首步观测、动作、关节目标逐位一致。 [独立评分](zero-physics-recovery/analysis.json) · [三组退出记录](zero-physics-recovery/execution.json)

固定种子 1141、224 个环境、20 秒首回合，比较父策略、只计算官方动作的影子组和实际切换组。第 26 至 75 步读取陀螺仪，在第 76 步判断是否停滞。触发后只有符合原关节限幅和正常目标变化范围的场景才改用官方右转。其他指令、采样器和原评分规则沿用七指令评估。 [冻结方案](../../../configs/experiments/common_walk_early_official_right.json) · [运行观察](../../walk-early-official-right-live.html)

首次 CPU 检查将反馈后的模型偏航输入直接与原指令比较，断言提前退出，物理零步。修正后使用保存的完整前缀重放反馈，核对 76 步实际模型输入、影子组输出、非右转与终止后的屏蔽。 [CPU 核验](preflight.json) · [保存前缀](archived-input-fixture.npz)

首次 CUDA 启动通过模型和投影检查，随后在第一次动作写入时退出。尝试 1 个控制步，完成 0 个控制步和 0 个物理子步。零步检查还原了带推理标记的张量，常规动作处理器无法继续原位写入。恢复入口在关闭梯度、保留常规张量语义的上下文里执行零步检查，并检查还原后各缓冲区的内容和实际可写性。 [首次退出记录](execution.json)

恢复对照使用相同种子、模型、世界分组、规则和预算。 [恢复冻结方案](../../../configs/experiments/common_walk_early_official_right_recovery.json) · [恢复检查](zero-physics-recovery/preflight.json) · [三组观察](../../walk-early-official-right-recovery-live.html)

## 动作成绩

| 策略 | 触发场景 | 实际切换 | 右转通过 | 其余六项 |
| --- | --- | --- | ---: | --- |
| 父策略 | 13、198 | 无 | 30/32 | 各 32/32 |
| 影子计算 | 13、198 | 无 | 30/32 | 各 32/32 |
| 实际切换 | 13、198 | 13、198 | 30/32 | 各 32/32 |

两条参考和切换组的共同失败均为 13、198。切换组相对两条参考的前进平均速度最大变化为 0.000036 m/s，后退通过数保持 32/32。三组共采集 672,000 条 CUDA 转移，未使用独立留出。 [逐组复算](zero-physics-recovery/readback.log)

## 支撑与转速

场景 13 的首段持续单脚支撑从约 7.50 秒提前至 7.10 秒，全程偏航误差从 0.2276 降至 0.2067 rad/s，仍高于 0.20 门槛。场景 198 切换后未形成持续单脚支撑，平均右转速度为 0.0105 rad/s，父策略为 0.2807 rad/s。历史上全程使用官方策略的场景 13 通过，场景 198 失败。历史试验对所有指令均使用官方模型，单列参考。 [逐场景时序](zero-physics-recovery/support-review.json)

三批父策略的 94 个成功场景均在 1.5 秒内形成至少 0.10 秒的同脚支撑，81 个右脚先支撑，13 个左脚先支撑。两例失败在 0.5–1.5 秒均保持双脚接触，机身相对两脚中点横向移动仅 3.35、3.58 mm。三批成功场景的下四分位数均至少 9.86 mm。该关联用于设计短时负重转移试验，实际响应仍需同初态评估。 [逐场景移重](zero-physics-recovery/support-transfer-screen.json) · [短对照草案](../../../configs/experiments/common_walk_right_support_transfer_draft.json)

三组均保留 11 次含原始画面的 Windows 运行快照和 4 秒后退原片。场景 13 从保存姿态生成 20 秒并排回放。 [原片图册](../../../docs/reports/stage-video-gallery.html) · [右转回放](zero-physics-recovery/right-startup-s1141-w13.mp4) · [媒体核验](zero-physics-recovery/visual-review.json)

![右转关键帧](zero-physics-recovery/right-startup-s1141-w13-keyframes.jpg)

## 复查命令

在 WSL 中进入工程根目录并激活项目环境。下列命令读取已保存的轨迹，重新评分及生成回放。

```bash
export PYTHONPATH=scripts/training
python -B -u scripts/validation/run_walk_early_official_right_recovery.py --verify
MUJOCO_GL=egl python -B -u scripts/validation/run_walk_early_official_right_recovery.py --replay
python -B -u scripts/validation/review_walk_early_official_right_outcome.py
python -B -u scripts/validation/review_walk_right_support_transfer.py
```
