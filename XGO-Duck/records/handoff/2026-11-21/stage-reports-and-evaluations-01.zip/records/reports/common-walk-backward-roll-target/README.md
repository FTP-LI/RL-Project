# 后退双腿侧倾目标

以较小的 1° 侧倾为目标，联合求解两腿关节偏移。每关节保持 0.03 rad 上限。CPU 复算核对了从四分之一幅度到完整幅度的四个姿态。 [冻结协议](../../../configs/experiments/common_walk_backward_roll_target.json) · [几何结果](analysis.json)

种子 1077 的 7 个停滞姿态和 1078 的 6 个停滞姿态在左右支撑方向均通过。摆动脚最终净空为 0.69–0.88 毫米，鞋底抬升为 1.13–1.19 毫米，支撑脚位置最大偏移 0.021 毫米。求解中的机身姿态只用于构造关节目标。实际侧倾和后退启动须由新场景的动态对照验证。

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- env PYTHONPATH=scripts/validation:scripts/training /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/check_walk_backward_roll_target.py
```
