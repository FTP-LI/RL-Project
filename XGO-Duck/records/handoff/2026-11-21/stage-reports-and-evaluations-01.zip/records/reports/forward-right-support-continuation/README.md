# 右脚支撑持续修正同快照对照

[当前逐组评分和运行入口](current-evaluation.md) · [冻结方案](../../../configs/experiments/forward_right_support_continuation/master.json) · [冻结日志](freeze-command.log) · [批次执行日志](batch-command.log)

## 20秒动作结果

本机CUDA的四组同快照对照共完成998,400条环境转移。两个低摩擦种子下，两条路线均为0/128通过，唯一失分项为偏航。两个标称种子的仅首段脉冲／持续修正通过数分别为128/128／128/128和127/128／126/128。候选共实际追加98,791个控制步，均对应真实右脚单独接触。原动作验收要求各场景20秒平均绝对偏航不超过0.20rad/s，并满足原速度、姿态及接触条件，每组至少116/128通过。[逐组评分、八段原片和配对结果](current-evaluation.md)

![20秒前进累计偏航](cumulative-forward-yaw.png)

[分时段和分支撑相位复算](paired-yaw-windows.json) · [24张标注实景](paired-forward-keyframes.jpg) · [每帧来源及接触记录](paired-forward-keyframes.json)

四组使用固定的128场景配对。完整采样过程的整卡显存峰值为2,984MiB，四组GPU利用率中位数为31%至36%。正式前进PPO采用3,072环境，前一批候选实测净吞吐为20,583条训练转移/秒。配对评分中同时读取全部接触与关节目标并逐步留存原始状态，两项计时各按各自过程记录。[正式前进PPO容量与结果](../forward-output-layer-pair/README.md)

| 种子／脚底摩擦系数 | VS Code状态 | 采样曲线 | 采集日志 |
| --- | --- | --- | --- |
| 1247／0.8 | [状态](s1247-friction-low/native-view/native-status.txt) | [曲线](s1247-friction-low/native-view/native-curve.png) | [日志](s1247-friction-low/collect-command.log) |
| 1248／0.8 | [状态](s1248-friction-low/native-view/native-status.txt) | [曲线](s1248-friction-low/native-view/native-curve.png) | [日志](s1248-friction-low/collect-command.log) |
| 1247／1.0 | [状态](nominal-verification/s1247-nominal/native-view/native-status.txt) | [曲线](nominal-verification/s1247-nominal/native-view/native-curve.png) | [日志](nominal-verification/s1247-nominal/collect-command.log) |
| 1248／1.0 | [状态](nominal-verification/s1248-nominal/native-view/native-status.txt) | [曲线](nominal-verification/s1248-nominal/native-view/native-curve.png) | [日志](nominal-verification/s1248-nominal/collect-command.log) |

## 保存数据预检

控制器沿用已经通过同快照对照的+0.01rad右髋俯仰目标。确认右脚支撑并完成首段脉冲后，从识别器第4至8步中的首个合格控制步开始追加。失去支撑识别、正陀螺仪信号或关节余量时结束该次修正，识别到左侧支撑后重新允许下一次触发。[控制器源码](../../../scripts/validation/forward_right_support_continuation.py) · [整段方案](../../../configs/experiments/forward_right_support_continuation_draft.json)

| 种子与脚底摩擦系数 | 追加控制步 | 与真实右脚单独支撑相符 | 真实右脚支撑第4至8步 | 最长连续追加步数 |
| --- | ---: | ---: | ---: | ---: |
| 1247／0.8 | 24,586 | 24,586 | 22,832 | 5 |
| 1248／0.8 | 24,580 | 24,580 | 22,863 | 5 |
| 1247／1.0 | 24,952 | 24,952 | 23,584 | 5 |
| 1248／1.0 | 24,946 | 24,946 | 23,693 | 5 |

四组均覆盖128个场景，原始首段目标逐步复算一致，追加只作用于指定右髋俯仰轴，目标均在原关节区间和0.03rad整体修正上限内。真实支撑用于复核触发，控制器读取原编码器与IMU观测。同一个实际支撑区间内未出现重复启动。预检读取保存数据，闭环改变后的接触和动作效果由整段仿真实测确认。[完整复算及源哈希](archived-controller-replay.json) · [运行日志](preflight-command.log)

整段仿真先运行1秒站立和2秒前进，在第150个控制边界保存快照。每个分支从同一状态再运行900个控制步，合并共用前进段后按原20秒偏航、速度、姿态和接触条件评分。低摩擦先做两组，标称结果用于确认同一规则在原摩擦范围内的行为。[同快照局部响应](../right-support-hip-pitch-duration/README.md)

## 运行记录和复现入口

每组独立复核两次快照读回、首个模型输入与电机目标、实际物理接触、原动作门槛和完整录像。打开VS Code中的逐组评分，在采样时查看当前组状态、曲线与实景。四组各运行1,950个物理控制步，共用段只计算一次。相机每两个控制步保存一帧，输出25fps原片。[执行入口](../../../scripts/validation/run_forward_right_support_continuation.py) · [证据复核入口](../../../scripts/validation/verify_forward_right_support_continuation.py)

本次采样使用与交付件逐字节一致的官方行走仿真权重。前一批等样本输出层对照的两份自训ONNX和保存点也已重算SHA-256。前一批改变PPO允许更新的策略层数，本批只改变有条件的关节目标。[权重来源核验](weight-source-check.json) · [前进输出层训练方案与结果](../forward-output-layer-pair/README.md)

复算图表时，在WSL中的项目根目录执行以下命令。脚本读取已保存的轨迹和原片，生成分时段偏航统计与标注关键帧。

```bash
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/plot_forward_support_continuation.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/build_forward_support_continuation_keyframes.py
```

## 标称摩擦观察中断

种子1247的首次标称对照在1,353/1,950个物理控制步时停止，产生173,184条部分环境转移。候选录像记录至站立起点后的9.04秒。观察关闭后的状态只保留通用守卫错误，当时的细分原因未保存。显存峰值为2,992MiB，运行时长低于360秒，物理接触槽检查通过，项目状态显示暂停未触发。[原采集日志](s1247-nominal/collect-command.log) · [运行收据](s1247-nominal/collection-result.json) · [原片时长与解码核验](interrupted-media-check.json) · [候选部分原片](../../evaluations/duck_forward_support_continuation_s1247-nominal_20261121T021532/clips/right-support-continuation/clip-step-0.mp4)

新观察协议在健康文件暂时不可读时最多等待0.45秒，等待期间仿真停在原控制边界。持续不可读、内容错误、心跳过期、进程退出或身份不匹配仍触发停止，终止时另存观察决策和健康记录。CPU故障测试通过后，两个标称组按原动作配置分别采样，前两组低摩擦结果直接进入汇总。每个标称组各用新运行编号，便于查阅本次采样与中断原片。[观察故障测试](nominal-verification/observer-preflight.json) · [新冻结方案](../../../configs/experiments/forward_right_support_nominal_verification/master.json) · [执行日志](nominal-batch-command.log)
