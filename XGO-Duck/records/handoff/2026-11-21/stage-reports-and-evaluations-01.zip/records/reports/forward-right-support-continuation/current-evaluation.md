# 右脚支撑持续修正同快照对照

每组128个场景。两条路线共用1秒站立和最初2秒前进，随后从同一快照运行18秒。偏航先按场景求完整20秒前进的平均绝对偏航速度，再取场景中位数。

| 种子／脚底摩擦系数 | 仅首段脉冲通过数 | 持续修正通过数 | 仅首段脉冲偏航（rad/s） | 持续修正偏航（rad/s） |
| --- | ---: | ---: | ---: | ---: |
| 1247／0.8 | 0/128 | 0/128 | 0.228815 | 0.230367 |
| 1248／0.8 | 0/128 | 0/128 | 0.229229 | 0.229883 |
| 1247／1.0 | 128/128 | 128/128 | 0.188018 | 0.188942 |
| 1248／1.0 | 127/128 | 126/128 | 0.188354 | 0.189717 |

s1247-friction-low · [仅首段脉冲原片](../../../records/evaluations/duck_forward_support_continuation_s1247-friction-low_20261121T021532/clips/onset-only/clip-step-0.mp4) · [持续修正原片](../../../records/evaluations/duck_forward_support_continuation_s1247-friction-low_20261121T021532/clips/right-support-continuation/clip-step-0.mp4) · [逐场景复核](s1247-friction-low/independent.json)

s1248-friction-low · [仅首段脉冲原片](../../../records/evaluations/duck_forward_support_continuation_s1248-friction-low_20261121T021532/clips/onset-only/clip-step-0.mp4) · [持续修正原片](../../../records/evaluations/duck_forward_support_continuation_s1248-friction-low_20261121T021532/clips/right-support-continuation/clip-step-0.mp4) · [逐场景复核](s1248-friction-low/independent.json)

s1247-nominal · [仅首段脉冲原片](../../../records/evaluations/duck_forward_support_nominal_verification_s1247-nominal_20261121T023001/clips/onset-only/clip-step-0.mp4) · [持续修正原片](../../../records/evaluations/duck_forward_support_nominal_verification_s1247-nominal_20261121T023001/clips/right-support-continuation/clip-step-0.mp4) · [逐场景复核](nominal-verification/s1247-nominal/independent.json)

s1248-nominal · [仅首段脉冲原片](../../../records/evaluations/duck_forward_support_nominal_verification_s1248-nominal_20261121T023001/clips/onset-only/clip-step-0.mp4) · [持续修正原片](../../../records/evaluations/duck_forward_support_nominal_verification_s1248-nominal_20261121T023001/clips/right-support-continuation/clip-step-0.mp4) · [逐场景复核](nominal-verification/s1248-nominal/independent.json)

[配对差、物理触发和验收结果](closed-loop-comparison.json)
