# 右转腿部对照

两批共完成 1,164,800 条 CUDA 转移。旧批的两例共同失败均实际触发修正，均未挽回。新批右转全部通过，修正未触发。该方案关闭。 [逐场景成绩](analysis.json) · [退出记录](execution.json)

上一轮一例右转失败的保存输入通过腿部组件筛查。本轮沿用混合策略和原七指令，验证这项限幅修改能否挽回实际失败。旧种子 1141 用于复查已知场景，新种子 1145 用于开发对照。 [组件筛查](../common-walk-shared-prefix-repeat/right-leg-cross-actor-cpu.json) · [冻结方案](../../../configs/experiments/common_walk_right_leg_recovery.json)

每个种子使用一个 CUDA 仿真环境。前 200 步只采一次，恢复同一边界后各跑完整后缀。两条参考分支与候选分支都在第 201–250 步按相同的 32 行批次计算官方模型候选输出，只有候选分支会在低角速度条件下将限幅修正用于十个腿部关节。头颈和动作历史使用名义输出。

每个完整分支包含 224 个场景，七条指令各 32 个。两个种子的预算共 1,164,800 条转移。右转挽回要求两条参考都失败、修正实际触发且候选通过。参考分支不一致的场景另列。候选须通过原七指令，且新种子有可归因的挽回，才进入独立确认。 [触发窗口复算](preflight.json)

## 动作成绩

| 种子 | 参考一 | 参考二 | 腿部修正 | 实际修正的场景 | 挽回 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1141 | 30/32 | 30/32 | 30/32 | 2 | 0 |
| 1145 | 32/32 | 32/32 | 32/32 | 0 | 0 |

表中为右转原门槛成绩，单批至少 31/32。旧批的其余六条指令均为 32/32。新批三组左转均为 31/32，其他六条均为 32/32。两批七指令均未出现两条参考一过一不过的场景。候选相对两条参考均无后退成功数损失，前进速度差绝对值均小于 0.0001 m/s。

旧批场景 13 和 198 在第 4–5 秒均保持双脚接触。候选与第一参考首次达到一秒偏航窗口的结束时刻分别为第 9 秒和第 10 秒。第二参考的场景 13 全程没有达到该窗口。两批第一参考的成功场景中，61/62 在第 4 秒前或当时已结束首个达标窗口。旧批候选两例的前 4 秒欠速分别贡献 0.074 和 0.076 rad/s 全程误差。该分解用于选择学习目标，实际轨迹改善须另行验证。 [逐段复算](right-leg-outcome-review.json) · [右转训练草案](../../../configs/experiments/common_walk_right_startup_ppo_draft.json)

## 运行留档

Windows 独立核对两批从零开始的页面，每批保留 26 个带完整原片的运行快照，覆盖共享前缀和三条分支。两批分别在 224 个场景采样，最高显存 2,563 MiB。每批保存三段 4 秒原始录像。三条分支的原片均覆盖同一共享前缀，图册各批索引一段。 [运行观察](../../walk-right-leg-recovery-live.html) · [录像图册](../../../docs/reports/stage-video-gallery.html) · [媒体核验](visual-review.json)

场景 13 的三分支保存姿态回放覆盖 0–20 秒，25 fps，共 501 帧。标注图记录修正窗口、启动阶段和终态。新批未触发修正，可在运行页查看原片。 [完整回放](right-leg-s1141-w13.mp4) · [逐帧来源](right-leg-replays.json)

![右转关键帧](right-leg-s1141-w13-keyframes.jpg)

在 WSL 工程根目录激活项目环境后，以下命令从已归档的轨迹复算成绩、接触时序与回放。

```bash
CUDA_VISIBLE_DEVICES=-1 python -B -u scripts/validation/verify_walk_right_leg_recovery.py
CUDA_VISIBLE_DEVICES=-1 python -B -u scripts/validation/review_walk_right_leg_recovery_outcome.py
MUJOCO_GL=egl CUDA_VISIBLE_DEVICES=-1 python -B -u scripts/validation/render_walk_right_leg_recovery.py
```
