# 前进关节修正上限

两组低摩擦直接前进的关节修正请求，按场景计算第95百分位并取中位数，均约0.0333 rad。本轮用种子1247、摩擦0.8的同一批128个场景，将最大单步关节修正从0.03提高到0.035 rad。前进策略、0.15 m/s前进命令、0.15 rad/s偏航反馈输入上限和原20秒评分一致。[冻结方案](../../../configs/experiments/forward_correction_limit_probe/master.json) · [原命令读回](../roll-friction-stand-forward/feedback-limit-readback.json)

复用站立接前进入口、原关节范围和重置状态校验。每组执行1,050个控制步，独立读回数值和完整21秒原片。以原0.20 rad/s偏航上限及116/128通过数评价这次单变量改动。[VS Code运行索引](current-evaluation.md) · [运行截图](running-in-vscode.jpg) · [评分截图](results-in-vscode.jpg) · [本轮命令日志](s1247-friction-low/collect-command.log)

## 对照结果

两组各128个场景进入前进。0.03与0.035 rad两组的完整动作通过数均为0/128，唯一失分项均为偏航。各场景20秒平均绝对偏航速度的组内中位数为0.23030和0.22916 rad/s，128个同编号场景的偏航差中位数为−0.00077 rad/s。四项资料保留在配对评分、命令读回、独立核验和全长录像中。[配对评分](independent-comparison.json) · [独立核验](s1247-friction-low/independent.json) · [21秒原片](../../evaluations/duck_forward_joint_limit_e128_s1247_20261120T224621/clip-step-0.mp4)

逐步重算控制目标，关节修正发生缩放的场景内步数比例中位数由26.15%降至0.20%，偏航输入触顶占比中位数均为14.1%。本项单变量试验已完成，后续以低摩擦前进策略为对象。[试验组实际控制目标读回](applied-correction-readback.json)
