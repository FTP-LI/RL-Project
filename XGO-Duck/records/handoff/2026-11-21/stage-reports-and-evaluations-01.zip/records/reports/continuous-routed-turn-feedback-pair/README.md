# 同站立状态转向对照

上轮七指令连续评估左转和右转低于原门槛。核对后发现连续入口漏接了固定七指令验收使用的陀螺仪转向反馈。恢复入口沿用原控制器，反馈只作用于已接入的左右转。 [上轮评分与原片](../continuous-routed-seven-command/README.md) · [200 步输入核验](../continuous-routed-seven-command/turn-feedback-cpu.json)

新开发批次含 3,072 个场景。先执行共用的 12 秒跌倒、起身和站立，再从同一个已校验的状态分别运行固定映射和恢复反馈两个分支。两组都执行完整的 20 秒指令段，保持原总体、逐指令及步态门槛。入选要求恢复组通过全部原门槛，左右转平均偏航误差分别下降，且对照未通过的转向组完整通过数必须增加。 [冻结方案](../../../configs/experiments/continuous_routed_turn_feedback_pair.json) · [CPU 冻结核验](freeze.json) · [运行观察](../../continuous-routed-turn-feedback-pair-live.html)

两支使用相同的场景分组、策略权重和动作过渡。0 号场景预先分到左转，两段原片均从初态记录到终态。采样使用压缩等级 1，并只保存独立评分和转向输入核验需要的逐步字段，完整控制输入在分支首步另存。 [无损写入基准](../continuous-routed-seven-command/trace-compression-benchmark.json)

实际 CUDA 零步复核通过，核对到 335 个初态字段，并对 878 个转向分配和 2,194 个其他分配核验边界输入。首次启动在创建场景前因旧入口的显存配置键名退出。兼容入口使用冻结协议中同一个 85% 上限，复用原 Windows 观察入口，首次退出前的物理步为零。 [独立 CUDA 复核](independent-zero/proof.json) · [原退出](sample-exit.json) · [兼容入口记录](launch-recovery.json)

两组均以同一个 345 字段快照为起点，七项接入人数逐项相同。只执行了一次初始重置，共完成 2,600 个控制步、13,000 个批量物理子步和 7,987,200 条实际转移。Windows 观察器核验了 52 次带真实帧的运行状态，0 号场景在两组均接入左转。 [采样退出](recovered-sample-exit.json) · [原片和进度](../../continuous-routed-turn-feedback-pair-live.html)

采样耗时 481.55 秒，整体 16,587 条转移/秒，显存峰值 13,157 MiB。常规窗口的中位吞吐为 19,143 条/秒，跨分块写入的窗口为 12,198 条/秒。13 个分块合计约 1.65 GB。上轮跨写盘窗口为 5,480 条/秒，本轮同时减少了逐步归档字段并采用压缩等级 1。 [性能记录](sampling-performance.json)

| 指令 | 固定映射 | 恢复反馈 | 原门槛 |
| --- | ---: | ---: | ---: |
| 站立 | 426/439 | 426/439 | 418 |
| 前进 | 427/439 | 427/439 | 418 |
| 后退 | 425/439 | 425/439 | 418 |
| 左转 | 391/439 | 426/439 | 418 |
| 右转 | 404/439 | 423/439 | 418 |
| 左平移 | 425/439 | 425/439 | 418 |
| 右平移 | 425/438 | 425/438 | 417 |

固定映射完整通过 2,923/3,072（95.15%），两项转向低于逐项门槛。恢复反馈完整通过 2,977/3,072（96.91%），七项均达标。左、右转平均偏航误差从 0.1649、0.1860 降到 0.1195、0.1359 rad/s，分别净增 35、19 例。两个分支首个执行器子步相同，其他五路的首步观测、输出和目标逐项一致。转向反馈的全部 1,000 步输入已复算。 [独立评分](analysis.json) · [固定映射原片](../../evaluations/duck_switch_routed-turn-gyro_pair_s1175_20261110T223736/static-turn/clip-step-0.mp4) · [恢复反馈原片](../../evaluations/duck_switch_routed-turn-gyro_pair_s1175_20261110T223736/restored-gyro/clip-step-0.mp4)

恢复反馈准入新的单次独立留出。预留种子 2175，采用原七项动作、总体和安全门槛。 [留出草案](../../../configs/experiments/continuous_routed_turn_feedback_holdout_draft.json)
