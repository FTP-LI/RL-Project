# 标称参数零步检查

这次检查使用 128 个仿真环境、种子 1241、脚底摩擦 1.0 和标称电压 7.7 V。它只初始化模型并检查接口，没有执行控制步、物理子步、训练更新或真机操作。原失败和原方案保留。 [冻结记录](freeze.json) · [运行结果](native-zero-run/result.json) · [原失败与诊断](../native-observer-preflight/zero-attempt-20261115.md)

## 修改与结果

原检查器要求限力标志为整数，而此次真实 XGO 模型的 14 个标志实际为 `bool`。独立候选只在检查时复制并转换这一字段，保留原始数组，并继续检查关节传动映射、限力是否启用及力范围；真实模型数组不被修改。原失败运行没有保存该字段，因此其报错原因仍是有证据支持的推断。 [候选代码](../../../scripts/validation/model_force_limit_guard_bool.py) · [原始字段](zero/actuator-observed-before-check.json)

独立复核重新读取了本次原始数组：14 个限力开关全部启用，编译限力为 ±0.97816 N·m，两个脚底的摩擦系数为 1.0；32 个保存的接口样本中，PyTorch 与 ONNX 输出最大差为 5.96×10⁻⁷。零步接触传感器与约束记录没有差异，但该运行没有完成与另一初态的配对。 [独立复核](independent-verification.json) · [限力记录](zero/actuator-force-limits.json) · [接口记录](zero/reset-0-interface.json) · [运行契约](zero/runtime-contract.json)

## 过程与查看

VS Code 中实际打开了本次状态文件，并观察到来源时间自动刷新。运行已结束，文件显示结束状态。标准输出和错误输出合并保存，进程正常退出，日志长度与 SHA-256 已复核。 [状态文件](native-zero-run/view/native-status.txt) · [完整日志](native-zero-execution.log) · [退出记录](native-zero-execution.json) · [截图](native-zero-run/ui-check.jpg)

![零步检查状态](native-zero-run/ui-check.jpg)

日志中 ONNX Runtime 报告了 Linux DRM 设备发现警告；Warp 同一日志显示 CUDA 设备并加载了 CUDA 模块。本次 ONNX 对照使用 CPU 执行，不能把此警告解释为 GPU 推理已通过。完整日志还包含模型初始化警告，均保留供后续排查。

下一步需要另行核验不同参数组的配对初态、动态采样停止和训练观察；本次结果不证明滚翻抗扰、行走效果或真机可用。
