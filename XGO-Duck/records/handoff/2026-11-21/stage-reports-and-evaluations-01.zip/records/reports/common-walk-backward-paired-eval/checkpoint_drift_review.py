"""Measure checkpoint drift on the same official observations without stepping physics."""

from pathlib import Path

import numpy as np
import torch

from common_walk_startup import make_actor
from record_io import write
from run_walk_backward_paired_eval import OUT, PLAN
from s1_reference_inputs import ROOT, read, sha
from walk_backward_ppo import actor_mean


@torch.inference_mode()
def main():
    spec = read(PLAN)
    training_path = ROOT / "configs/experiments/common_walk_backward_paired_ppo.json"
    training = read(training_path)
    arms = {}
    for name in ("control", "candidate"):
        folder = ROOT / training["arms"][name]["record"]
        for update in training["checkpoints"]:
            path = folder / f"checkpoint-{update}.pt"
            state = torch.load(path, map_location="cpu", weights_only=True)
            assert state["arm"] == name and state["completed_updates"] == update
            assert state["protocol_sha256"] == sha(training_path)
            arm = make_actor(spec["cases"]["1139-official"]["environment"], "cpu")
            arm.load_state_dict(state["actor_state_dict"], strict=True)
            arms[(name, update)] = (arm, path)
    rows, traces = [], {}
    for seed in spec["development_seeds"]:
        case = spec["cases"][f"{seed}-official"]
        folder = ROOT / case["record"]
        proof = read(folder / "verification.json")
        paths = [folder / "trace-shared-prefix.npz", folder / "trace-actuator-feedback.npz"]
        assert [sha(path) for path in paths] == proof["trace_hashes"]
        traces[str(seed)] = proof["trace_hashes"]
        names = ("observations", "actions", "active")
        segments = []
        for path in paths:
            with np.load(path, allow_pickle=False) as data:
                segments.append({name: data[name] for name in names})
        trace = {name: np.concatenate([segment[name] for segment in segments])[::10] for name in names}
        teacher = make_actor(case["environment"], "cpu")
        for command, worlds in case["environment"]["groups"].items():
            mask = trace["active"][:, worlds]
            obs, expected = (trace[name][:, worlds][mask] for name in ("observations", "actions"))
            source = torch.from_numpy(obs)
            answer = actor_mean(teacher, source).numpy()
            np.testing.assert_allclose(answer, expected, atol=2e-5, rtol=2e-5)
            home = np.asarray(case["environment"]["model_home"])
            low, high = np.asarray(case["environment"]["joint_limits"]).T
            reference = np.clip(answer + home, low, high)
            for (name, update), (actor, path) in arms.items():
                estimate = actor_mean(actor, source).numpy()
                error = np.clip(estimate + home, low, high) - reference
                assert np.isfinite(error).all()
                rows.append(dict(seed=seed, command=command, arm=name, update=update, observations=len(obs),
                                 target_rms_rad=float(np.sqrt(np.mean(error**2))),
                                 target_abs_p95_rad=float(np.quantile(abs(error), .95)),
                                 checkpoint_sha256=sha(path)))
    assert not torch.cuda.is_initialized() and len(rows) == 84
    write(OUT / "checkpoint-drift.json", dict(
        status="readback-of-checkpoint-target-drift", source_sha256=sha(Path(__file__)),
        protocol_sha256=sha(PLAN), trace_sha256=traces, row_stride=10, comparisons=rows,
        scope="Nominal bounded target differences on fixed official observations. No behavior or feedback estimate.",
        physical_substeps=0, learning_updates=0, heldout_used=False))
    print("CHECKPOINT_TARGET_DRIFT_ROWS", len(rows), flush=True)


if __name__ == "__main__":
    torch.set_num_threads(3)
    main()
