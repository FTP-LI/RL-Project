# 后退七指令对照

两种子共六组固定策略评估。两组自训策略都在种子 1140 挽回两个后退失败场景。两批前进速度损失均超过 0.01 m/s 容差，因此两组均未晋级。加权组相对等权组在两批后退均无新增成功。

## 动作成绩

各项分母为 32，成绩同时检查速度跟踪、偏航、接触滑移、姿态、脚间距和物理关节限位。表中速度为前进指令的平均有向速度。

| 种子 | 策略 | 站立 | 前进 | 后退 | 左转 | 右转 | 左平移 | 右平移 | 前进 m/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1139 | 官方 | 32 | 32 | 32 | 32 | 30 | 32 | 32 | 0.16160 |
| 1139 | 等权 | 32 | 32 | 32 | 32 | 32 | 32 | 32 | 0.14734 |
| 1139 | 停滞加权 | 32 | 32 | 32 | 31 | 32 | 32 | 32 | 0.14630 |
| 1140 | 官方 | 32 | 31 | 30 | 32 | 31 | 32 | 32 | 0.16120 |
| 1140 | 等权 | 32 | 32 | 32 | 32 | 32 | 32 | 32 | 0.14676 |
| 1140 | 停滞加权 | 32 | 32 | 32 | 32 | 31 | 32 | 32 | 0.14562 |

种子 1140 的官方后退 30/32，Wilson 95% 区间为 79.9%–98.3%。两组自训均为 32/32，区间为 89.3%–100%。场景 144 的官方后退方向速度为 −0.00013 m/s，场景 148 为 0.08558 m/s，但后者仍超过速度跟踪误差门槛。两组自训均挽回这两个场景，未丢失其他后退场景。种子 1139 的三组后退均为 32/32。 [逐场景评分](analysis.json)

对照图取两例在 0、2、6、20 秒的保存状态。场景 144 在第 20 秒的离起点距离，官方为 0.02 m，等权为 2.51 m，停滞加权为 2.54 m。相机跟随机器人，距离直接取自保存的平面位置。 [图像来源](backward-comparison.json)

![后退场景对照](backward-comparison.jpg)

## 运行与核验

每组从同种子匹配的原生重置开始，记录 224 个场景的首回合，每个指令 32 个场景。六组共采集 1,344,000 条转移，零学习更新，均记录进程退出码 0。CUDA 采样期间，CPU 独立复算已关闭的轨迹。六组实际显存峰值最高 2,556 MiB。每组保存同一后退机位的 4 秒、25 fps 原片，全部 101 帧均与逐帧物理状态哈希相符。录像的英文页眉来自通用录制器，图册标为固定评估。 [冻结方案](../../../configs/experiments/common_walk_backward_paired_eval.json) · [六组观察与原片](../../walk-backward-paired-eval-live.html) · [进程退出记录](execution.json)

首组只保存了两次 Windows 运行快照，少于原要求的三次。其余五组各有 11 次。原核验器停在观察次数检查，原代码和采样档案继续保留。另存的核验入口继续复算动作、物理、接口和原片，首组的观察缺口单列。以后在 CUDA 启动前先确认 Windows 观察器已就绪。 [原核验器](../../../scripts/validation/verify_walk_backward_paired_eval.py) · [独立读回入口](observer-review/verify_readback.py) · [读回日志](observer-review/execution.log)

在两个官方轨迹的同一批观察输入上，两组前进目标相对官方的均方根偏差，第 28 次更新为 0.0205–0.0215 rad，第 42 次更新为 0.0310–0.0333 rad。这里比较的是固定输入下的目标变化，实际速度以首回合评分为准。 [保存点目标读回](checkpoint-drift.json)

## 复算

在 WSL 打开工程根目录并激活项目 Python 环境。下列命令读取现有轨迹、保存点和 ONNX，重新生成评分与目标读回，无需开启仿真窗口。运行进度页可直接从 VS Code 打开。

```bash
export PYTHONPATH=scripts/validation:scripts/training
export CUDA_VISIBLE_DEVICES=-1
python -B -u records/reports/common-walk-backward-paired-eval/observer-review/verify_readback.py
python -B -u records/reports/common-walk-backward-paired-eval/checkpoint_drift_review.py
```

## 下一步

等权组两批共 448 个场景全部通过逐场景判据，并挽回 1140 的两例后退失败。以其作为后退和其余五条非前进指令的候选。下一轮比较固定官方、固定等权和按外部指令选择模型三组。CPU 已核对两路模型选择、前进反馈输入和上一条原始动作的离线传递。新种子的动态动作及同场景切换待验证。两组权重继续保留为研究档案。 [下一阶段草案](../../../configs/experiments/common_walk_forward_model_routing_draft.json) · [CPU 核验](../common-walk-forward-routing/cpu-components.json)
