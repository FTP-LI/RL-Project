"""Render paired backward failures from recorded poses without integrating physics."""

from hashlib import sha256
from pathlib import Path

import mujoco
import numpy as np
from mjlab.scene import Scene
from PIL import Image, ImageDraw, ImageFont

from common_scene_contract import compare_arrays, model_arrays
from common_walk_forward_phase_screen import make_config
from record_io import write
from run_walk_backward_paired_eval import OUT, PLAN
from s1_reference_inputs import ROOT, read, sha


def main():
    spec = read(PLAN)
    analysis = read(OUT / "analysis.json")
    seed = 1140
    official = spec["cases"][f"{seed}-official"]
    worlds = [row["world"] for row in analysis["cohorts"][str(seed)]["results"]["official"]["backward"]["episode_scores"]
              if not row["success"]]
    assert len(worlds) == 2 and analysis["protocol_sha256"] == sha(PLAN)
    cfg, _ = make_config(official["environment"])
    model = Scene(cfg.scene, device="cpu").compile()
    with np.load(OUT / "startup" / "official" / "cpu-scene-fields.npz", allow_pickle=False) as source:
        compare_arrays(model_arrays(model), {name: source[name] for name in source.files})
    root, = [i for i in range(model.nbody)
             if (mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, i) or "").endswith("trunk_base")]
    width, height = 400, 240
    model.vis.global_.offwidth = max(model.vis.global_.offwidth, width)
    model.vis.global_.offheight = max(model.vis.global_.offheight, height)
    font = ImageFont.truetype("/mnt/c/Windows/Fonts/msyh.ttc", 18)
    title = ImageFont.truetype("/mnt/c/Windows/Fonts/msyh.ttc", 28)
    times = (0, 100, 300, 1000)
    plate = Image.new("RGB", (4*width, 52+len(worlds)*3*height), "#132431")
    ImageDraw.Draw(plate).text((12, 8), "后退场景对照", font=title, fill="white")
    data = mujoco.MjData(model)
    camera = mujoco.MjvCamera()
    camera.distance, camera.azimuth, camera.elevation = 0.98, 90, -18
    frames = []
    with mujoco.Renderer(model, height=height, width=width) as renderer:
        for arm_index, arm in enumerate(("official", "control", "candidate")):
            key = f"{seed}-{arm}"
            folder = ROOT / spec["cases"][key]["record"]
            receipt = folder / "verification.json"
            assert sha(receipt) == analysis["records"][key]["verification_sha256"]
            paths = (folder / "trace-shared-prefix.npz", folder / "trace-actuator-feedback.npz")
            assert [sha(path) for path in paths] == read(receipt)["trace_hashes"]
            initial_path = folder / "physical-initial.npz"
            assert sha(initial_path) == read(folder / "evaluation.json")["initial_state_sha256"]
            with (
                np.load(initial_path, allow_pickle=False) as initial,
                np.load(paths[0], allow_pickle=False) as first,
                np.load(paths[1], allow_pickle=False) as second,
            ):
                start = initial["qpos"][worlds]
                poses = np.concatenate((start[None], first["qpos"][:, worlds], second["qpos"][:, worlds]))
                active = np.concatenate((first["active"][:, worlds], second["active"][:, worlds]))
            scored = {row["world"]: row for row in read(receipt)["scores"]["backward"]["episode_scores"]}
            name = {"official": "官方", "control": "等权", "candidate": "停滞加权"}[arm]
            for world_index, world in enumerate(worlds):
                last = int(active[:, world_index].sum())
                for col, requested in enumerate(times):
                    step = min(requested, last)
                    pose = poses[step, world_index]
                    data.qpos[:] = pose
                    mujoco.mj_forward(model, data)
                    np.testing.assert_array_equal(data.qpos, pose)
                    camera.lookat[:] = data.xpos[root]
                    renderer.update_scene(data, camera=camera)
                    frame = Image.fromarray(renderer.render().copy())
                    draw = ImageDraw.Draw(frame)
                    draw.rectangle((0, 0, width, 52), fill="#132431")
                    result = "达标" if scored[world]["success"] else "未达标"
                    draw.text((8, 3), f"{seed}/{world}  {name}  {step*.02:g} s  {result}", font=font, fill="white")
                    shift = np.linalg.norm(pose[:2] - start[world_index, :2])
                    draw.text((8, 27), f"离起点 {shift:.2f} m · 保存状态回放", font=font, fill="white")
                    row = world_index*3 + arm_index
                    plate.paste(frame, (col*width, 52+row*height))
                    frames.append(dict(arm=arm, world=world, step=step, requested_step=requested,
                                       xy_distance_m=float(shift), success=scored[world]["success"],
                                       qpos_sha256=sha256(pose.tobytes()).hexdigest()))
    output = OUT / "backward-comparison.jpg"
    plate.save(output, quality=93)
    with Image.open(output) as saved:
        saved.verify()
    write(OUT / "backward-comparison.json", dict(path=output.relative_to(ROOT).as_posix(), sha256=sha(output),
        source_sha256=sha(Path(__file__)), analysis_sha256=sha(OUT / "analysis.json"), frames=frames,
        physics_substeps=0, learning_updates=0))
    print("BACKWARD_COMPARISON_FRAMES", len(frames), flush=True)


if __name__ == "__main__":
    main()
