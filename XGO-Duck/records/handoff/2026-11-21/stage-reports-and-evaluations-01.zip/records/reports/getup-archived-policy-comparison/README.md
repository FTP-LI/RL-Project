# 归档起身策略对照

用固定父模型的两路重复和两份归档自训策略比较实际起身。1,024 个场景共用 2 秒跌落，随后从同一释放点分叉。每路沿用原 8 秒前进入连续 3 秒持稳和回合末端持稳，按请求与实际释放姿态分别评分。候选须达到总体和各姿态 95%，且实际仰卧相对两路参照分别净增至少 2 例，才进入第二批开发场景。

[候选来源与历史成绩](../getup-archived-policy-shortlist/analysis.json) · [冻结方案](../../../configs/experiments/getup_archived_policy_comparison_qualified_s1160.json) · [运行观察](../../getup-archived-policy-qualified-s1160-live.html)

## 启动核对

首次启动因跨进程整场哈希不同在零步停止。两次复查定位 25 个求解和传感器派生字段，14 项关键控制输入签名一致。新入口先逐项核对差异范围，再在同一进程保存并恢复第 100 步的全部状态。首个动作输入、延迟生效前的电机控制及两路重复参照另行检查。首次停止的方案、日志和数值均保留。

[首次停止](../../getup-archived-policy-s1160-live.html) · [字段复查](s1160/reset-field-diagnosis/analysis.json) · [同进程冻结](s1160-qualified/freeze.json)

## 首批结果

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 四姿态门槛 | 原片 |
| --- | ---: | ---: | ---: | --- | --- |
| 固定参照 A | 971/1,024 | 624/672 | 762/815 | 未通过 | [参照 A](../../evaluations/duck_getup_archived-policies_qualified_s1160_20261110T171358/evaluation-reference-a-supine/clip-step-0.mp4) |
| 固定参照 B | 974/1,024 | 624/672 | 765/815 | 未通过 | [参照 B](../../evaluations/duck_getup_archived-policies_qualified_s1160_20261110T171358/evaluation-reference-b-supine/clip-step-0.mp4) |
| 原奖励续训 | 993/1,024 | 644/672 | 785/815 | 通过 | [原奖励续训](../../evaluations/duck_getup_archived-policies_qualified_s1160_20261110T171358/evaluation-prior-reward-continuation-supine/clip-step-0.mp4) |
| 侧卧到仰卧回放 | 994/1,024 | 647/672 | 786/815 | 通过 | [侧卧到仰卧回放](../../evaluations/duck_getup_archived-policies_qualified_s1160_20261110T171358/evaluation-side-to-supine-replay-supine/clip-step-0.mp4) |

两路参照在 33 个场景的成败不同，净差 3 例。首个控制周期的输入、动作、目标与第一个物理子步电机量逐字节一致。随后四个子步出现差异，第五子步的电机量最大差 0.00553 N·m。原评分因要求五个子步逐字节一致而停止。使用保存轨迹复算时分别报告了该差异和最终持稳，原评分停止日志保留。四路释放快照的 345 个字段完全一致。 [电机量差异](s1160-qualified/reference-motor-drift.json) · [独立评分](s1160-qualified/analysis.json)

原奖励续训在实际仰卧相对两路参照净增 23、20 例，侧卧到仰卧回放净增 24、21 例。两份候选的实际右侧均为 51/52，参照两路各 52/52。候选均满足开发晋级条件，下一批用独立种子复验。 [复验草案](../../../configs/experiments/getup_archived_policy_replication_draft.json)

两路参照均失败而两份候选均通过的实际仰卧共有 13 例。图中取编号最小的场景 98，从保存状态渲染。第 3.20 秒四路均双脚触地，两路参照仍约 33° 倾斜并有头腿接触，两份候选分别为 1.1° 和 1.4°，已解除头腿接触。 [逐帧来源](s1160-qualified/paired-recovery-keyframes.json)

![同场景仰卧起身](s1160-qualified/paired-recovery-keyframes.jpg)

共执行 1,945,600 条转移。运行中由 Windows 核对 39 次刷新，38 次包含真实仿真帧。最后一个物理步前用时约 334 秒，最后一步至写盘完成约 57 秒，端到端约 4,976 条转移/秒。整卡显存峰值为 5,494 MiB，利用率采样均值为 23.6%。 [观察核验](../../evaluations/duck_getup_archived-policies_qualified_s1160_20261110T171358/windows-view-verification.json) · [GPU 记录](../../evaluations/duck_getup_archived-policies_qualified_s1160_20261110T171358/gpu-telemetry.json) · [标注帧核验](s1160-qualified/media-review.json)

## 复现入口

在 WSL 项目根目录设置 `PYTHONPATH=scripts/training` 和 `MUJOCO_GL=egl`。采样使用 [执行脚本](../../../scripts/validation/run_getup_archived_policy_qualified.py) 的 `freeze`、`sample`，并在采样前用 [Windows 观察脚本](../../../scripts/validation/observe_getup_archived_policy_qualified.py) 核验起始页。现有轨迹可直接用 [独立评分脚本](../../../scripts/validation/verify_getup_archived_policy_reference_drift.py) 复算。已有记录及种子保持冻结，新的仿真实验另建名称和协议。

## 独立复验

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 原片 |
| --- | ---: | ---: | ---: | --- |
| 固定参照 A | 966/1,024 | 625/672 | 763/815 | [参照 A](../../evaluations/duck_getup_archived-policies_replication_s1161_20261110T172917/evaluation-reference-a-supine/clip-step-0.mp4) |
| 固定参照 B | 969/1,024 | 623/672 | 763/815 | [参照 B](../../evaluations/duck_getup_archived-policies_replication_s1161_20261110T172917/evaluation-reference-b-supine/clip-step-0.mp4) |
| 原奖励续训 | 980/1,024 | 632/672 | 772/815 | [原奖励续训](../../evaluations/duck_getup_archived-policies_replication_s1161_20261110T172917/evaluation-prior-reward-continuation-supine/clip-step-0.mp4) |
| 侧卧到仰卧回放 | 983/1,024 | 634/672 | 775/815 | [侧卧到仰卧回放](../../evaluations/duck_getup_archived-policies_replication_s1161_20261110T172917/evaluation-side-to-supine-replay-supine/clip-step-0.mp4) |

实际仰卧相对两路参照的净增分别为 9、12 例。指定仰卧须至少 639/672，两份候选分别少 7、5 例。两路重复参照的成败分歧为 35 个场景。两份候选均结束本轮晋级，最终留出保持封存。 [独立评分](s1161/analysis.json) · [晋级记录](s1161/selection.json)

复验完成 1,945,600 条转移，采样到写盘结束约 321 秒，端到端约 6,063 条转移/秒。最后一个物理步后约 49 秒完成压缩和写盘。整卡显存峰值 5,503 MiB，利用率采样均值 26.8%。Windows 核对了 39 次刷新，其中 38 次包含真实画面。 [运行观察](../../getup-archived-policy-s1161-live.html) · [标注帧核验](s1161/media-review.json)

第二批的 672 个指定仰卧中，620 个两份候选均通过，26 个仅一份通过，26 个均失败。按事后已知的结果为每个场景选策略，最多可得 646/672。这个上界比门槛多 7 例。两批共同失败共 37 例，回合末双脚均触地且头腿仍接触，候选倾角中位数约 32.7°–33.5°。 [两批离线复盘](residual-review.json)

用首个起身动作前的 34 项真实观测，在一批拟合和定阈值，另一批完整复算。指定仰卧两个方向分别由 634 降至 630、647 降至 644，分流关闭。下一阶段对齐成功和失败的实际动作与接触时序，判断是否有重复出现的动作可用于续训。 [分流复算](release-routing.json) · [动作分析草案](../../../configs/experiments/getup_archived_policy_teacher_recovery_draft.json)

## 释放后动作时序

固定比较释放后前四个控制周期，记录时点为 2.02–2.08 秒。剔除期间已有头腿接触或双足读数分歧的场景，仅教师策略成功的合格样本两批为 16、13 例。按首批筛出的右髋俯仰方向，实际下发目标的有符号差值中位数为 −0.000062 和 +0.000044 rad。要求至少 +0.012 rad。同一实际观测下两份 ONNX 的动作差也低于 0.008 rad 门槛。此项只覆盖首四步，未找到可用于单关节续训的动作差异。 [冻结方案](../../../configs/experiments/getup_archived_policy_teacher_timing.json) · [独立复算](teacher-timing.json)

双策略平滑混合使用当前重力方向，教师占比最高为 50%。两批均覆盖全部 815 个实际仰卧释放，其他姿态释放和保存的直立双足支撑输入均退回父策略。在仅教师成功的两批 17、13 个场景中，均未达到 0.008 rad 的早段动作变化门槛。相对父策略的最大新增越界量为 0.00640 rad，高于 0.005 rad 上限，关闭。 [混合预检](blend-preflight.json)

在 2.20–3.10 秒重新提取教师的实际成功动作。两批共 1,380 条教师输入和 1,024 条四姿态父策略成功输入，全部 30 个教师独有成功场景均含足够的有界腿部变化。相同输入与父策略标签组成对照。拟合后仅保留原残差的 62.6%，两批重新导出均通过动作保留与限位。 [回放数据核验](teacher-replay/analysis.json) · [拟合、限位和运行记录](../../experiments/duck_getup_teacher_head_offline_s1160_20261110T175320/README.md)
