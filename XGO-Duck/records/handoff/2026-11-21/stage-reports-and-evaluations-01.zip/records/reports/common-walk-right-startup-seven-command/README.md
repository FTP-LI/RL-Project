# 右转训练的七指令评估

欠速训练未挽回已知两例右转失败，停止追加训练。三组右转在种子 1141 均为 30/32，在种子 1149 均为 32/32。全组无晋级，保留父策略用于诊断。 [逐场景评分](zero-step-recovery/analysis.json) · [运行观察与原片](../../walk-right-startup-seven-command-recovery-live.html)

比较父策略、原奖励训练和欠速训练。每个种子 224 个环境，七条指令各 32 个，三组各采完整首回合并保留提前结束。种子 1141 沿用原分组，1149 的新分组在启动前固定。 [原冻结方案](../../../configs/experiments/common_walk_right_startup_seven_command.json) · [恢复后的运行观察](../../walk-right-startup-seven-command-recovery-live.html)

首次入口的上下文管理语句在调用原生采样前出错，实际零物理步。恢复入口只修正启动语句并实测该调用路径，保留原模型、场景、评分和预算。 [原失败退出记录](execution.json) · [恢复冻结方案](../../../configs/experiments/common_walk_right_startup_seven_command_recovery.json) · [恢复核验](zero-step-recovery/preflight.json)

所有组的前进仍用官方策略与原执行器反馈，其他五条非右转指令仍用原等权策略。两组训练导出只替换右转。基础模型和右转模型均使用同一 192 行布局，避免非右转模型因批量形状变化产生首步差异。独立核验逐组比对初态、首步、路由、回报评分所需轨迹与原片。 [训练导出核验](../common-walk-right-startup-ppo/paired-ppo-analysis.json) · [右转路由读回](../common-walk-right-startup-ppo/trained-right-route-components.json)

原逐指令、姿态、脚距、接触滑移和关节门槛继续使用。另核对前进速度与父策略的差异是否在 0.01 m/s 以内，以及后退是否保留通过数。开发计数用于选择独立确认的候选。

## 七指令成绩

每项分母为 32。两批同种子的原生初态哈希相同，非右转的首步观测、动作及关节目标逐位一致。各组前进均保持在 0.01 m/s 容差内，最大变化约 0.000082 m/s。原奖励组在 1149 前进少通过一个场景，欠速组在 1141 左转少通过一个场景。 [独立复算日志](zero-step-recovery/readback.log)

| 种子 | 策略 | 站立 | 前进 | 后退 | 左转 | 右转 | 左平移 | 右平移 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1141 | 父策略 | 32 | 32 | 32 | 32 | 30 | 32 | 32 |
| 1141 | 原奖励 | 32 | 32 | 32 | 32 | 30 | 32 | 32 |
| 1141 | 欠速奖励 | 32 | 32 | 32 | 31 | 30 | 32 | 32 |
| 1149 | 父策略 | 32 | 32 | 32 | 32 | 32 | 32 | 32 |
| 1149 | 原奖励 | 32 | 31 | 32 | 32 | 32 | 32 | 32 |
| 1149 | 欠速奖励 | 32 | 32 | 32 | 32 | 32 | 32 | 32 |

六组均正常退出，共 1,344,000 条 CUDA 评估转移，评估显存峰值均为 2,563 MiB。每组保留真实运行观察和环境 0 的 4 秒后退原片。动作评分使用全部场景；两段右转回放从保存的物理状态生成。 [退出记录](zero-step-recovery/execution.json) · [逐段图册](../../../docs/reports/stage-video-gallery.html)

## 右转启动

种子 1141 的共同失败为场景 13、198。三组在两个场景的前 4 秒均处于双脚支撑。父策略在两场景的首个达标一秒窗分别结束于第 9、10 秒，欠速组时间相同。欠速组全程偏航误差从 0.2233、0.2491 降到 0.2181、0.2392 rad/s，仍超过 0.20 rad/s 门槛。原奖励组在场景 13 的平均右转速度为 0.0058 rad/s。 [逐秒数据](zero-step-recovery/right-startup-s1141-replay.json)

两段并排回放各 20 秒。从已知的场景 13 看迟启动，从新种子预先指定的最小编号右转场景看正常启动。 [迟启动视频](zero-step-recovery/right-startup-s1141-w13.mp4) · [正常启动视频](zero-step-recovery/right-startup-s1149-w1.mp4) · [正常启动关键帧](zero-step-recovery/right-startup-s1149-w1-keyframes.jpg)

![迟启动关键帧](zero-step-recovery/right-startup-s1141-w13-keyframes.jpg)

三批父策略保存轨迹中，0.5–1.5 秒的陀螺仪平均角速度绝对值不超过 0.05 rad/s，覆盖已知 2/2 个失败，触发 0/94 个成功场景。用两例同一输入计算官方右转策略的首步关节目标，最大单关节跳变 0.0757 rad，各关节均在 6,956 条成功场景步间变化的观测上限内，没有新增限幅。闭环效果仍待通过双参照仿真验证。 [早期观测复算](zero-step-recovery/early-gyro-review.json) · [首步目标复算](zero-step-recovery/early-official-right-target-screen.json) · [下一步方案](../../../configs/experiments/common_walk_early_official_right_draft.json)

## 复查

在项目根目录的 WSL 终端激活训练环境后执行以下命令。各入口读回既有记录，不新增物理步。

```bash
export PYTHONPATH=scripts/training
python -B scripts/validation/review_walk_right_startup_early_gyro.py
python -B scripts/validation/screen_walk_early_official_right.py
```

六段原片和两段回放的来源、校验值、帧数及抽查图卡另行保存。 [媒体核验](zero-step-recovery/visual-review.json)
