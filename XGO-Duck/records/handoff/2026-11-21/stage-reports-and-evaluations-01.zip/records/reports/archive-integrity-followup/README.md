# 归档完整性检查

训练和仿真继续暂停。本次检查原有进度快照，不执行学习、物理仿真或真机操作。

## 检查结果

原快照内 56 份文本与代码通过 ZIP 完整性和成员哈希检查；清单中仍保留在工程里的 83 个模型、轨迹、视频及图片均与记录一致。原快照、清单和首次核验记录保持不变。 [检查记录](verification.json) · [首次核验](../progress-archive-20261114/verification.json)

快照保存的是归档当时的内容，项目后续更新后，一些当前文件与快照不同是正常现象。检查记录会分别列出这些文件及新旧哈希，不能仅凭不一致判断更新内容是否正确。若未打入快照的模型、轨迹或视频缺失、变化，检查会失败并列出具体文件。

原创建入口现在会拒绝覆盖已有快照、清单和核验记录，创建文件时也使用独占方式。使用临时文件模拟源文件变化、缺失、压缩包损坏、清单变化、重复成员和越界路径，并实际确认已有归档的创建请求被拒绝；共 11 项检查通过。 [检查用例](fixture-verification.json)

## 重新检查

在 Windows 工程根目录执行：

```powershell
Set-Location 'C:\Users\atlas-win\Desktop\RL-Project\XGO-Duck'
py -X utf8 -B scripts/validation/archive_paused_progress.py verify
```

输出 `passed` 表示快照、当前源文件和保留文件均一致；`passed-with-live-source-changes` 表示快照及保留文件完整，但当前源文件有更新或缺失，详情见[检查记录](verification.json)。输出 `failed` 时先检查记录中的原因。该命令只更新本目录的检查结果，不覆盖原归档。

校验依据是原清单及首次核验记录，并非外部签名。快照未包含大体积模型、轨迹和录像，仍需保留原工程目录；它不能代替独立备份。 [暂停进度与文件位置](../progress-archive-20261114/README.md)
