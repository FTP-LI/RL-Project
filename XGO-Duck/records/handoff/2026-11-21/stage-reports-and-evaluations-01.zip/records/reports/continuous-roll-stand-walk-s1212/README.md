# seed-1212 连续路由开发

本轮使用官方滚翻、已验收行走组件，在同一物理环境测试 `stand → roll → stand → forward`。协议先通过 CPU 场景编译和 GPU reset-only 零步，再执行一次 dynamics；没有学习更新、留出集或硬件 IO。

## 结果

GPU 零步通过：128 环境、0 物理步、0 学习更新、接口检查 1 次。连续 dynamics 在 746 个控制步后按门槛提前停止；滚翻完整窗口结束时 0/128 世界进入 `roll → stand`，前进阶段 0/128。剩余站立和前进预算没有继续消耗。

| 证据 | 路径 |
| --- | --- |
| 冻结协议 | [continuous_roll_stand_walk_s1212.json](../../../configs/experiments/continuous_roll_stand_walk_s1212.json) |
| CPU 预检 | [preflight.json](preflight.json) |
| GPU 零步 | [zero/runtime-contract.json](zero/runtime-contract.json) |
| 停止复盘 | [stop-review.json](stop-review.json) |
| 状态与曲线 | [运行状态](../../../records/evaluations/duck_switch_roll-stand-walk_development_s1212_20261114T012627/state.json) · [执行日志](../../../records/evaluations/duck_switch_roll-stand-walk_development_s1212_20261114T012627/execution.log) |
| 部分原片 | [clip-step-0.mp4](../../../records/evaluations/duck_switch_roll-stand-walk_development_s1212_20261114T012627/clip-step-0.mp4) |

运行观察页在运行中写入 [roll-stand-walk-s1212-live.html](../../../records/roll-stand-walk-s1212-live.html)。本轮 0/128 的滚翻切换结果不支持继续同协议或同 seed 重试；下一步先复盘 roll-to-stand 边界和首个完成条件，再决定是否冻结新的 router 协议。

![seed-1212 router 停止过程](../../../docs/reports/assets/router-s1212-stop-overview.jpg)
