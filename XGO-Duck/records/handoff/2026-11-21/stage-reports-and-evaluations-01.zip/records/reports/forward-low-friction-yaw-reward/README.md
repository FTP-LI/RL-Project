# 低摩擦前进偏航奖励

## 修改与方案

两组共用官方行走策略、价值网络初态、优化器、训练种子和摩擦0.8场景。候选增加物理机身Z轴角速度绝对值代价，单步信号在0.8 rad/s封顶。线速度跟踪的权重为3.0。以原评分上限0.20 rad/s计算，新增代价取线速度跟踪峰值的8%，得到代价系数1.20。控制保留0.15 m/s外部前进命令、0.15 rad/s偏航输入上限、0.030 rad关节修正上限及原始动作历史。CUDA使用设备侧反馈，以减少逐步复制观测的开销。[训练方案](../../../configs/experiments/forward_low_friction_yaw_reward_draft.json) · [奖励与反馈源码](../../../scripts/training/forward_low_friction_yaw_reward.py)

## 保存轨迹复算

四个开发组的512个完整前进区间共512,000条控制样本，按原评分口径计算20秒平均绝对偏航。应用新增代价后，两个标称组的每世界每秒代价组内中位数为0.22445和0.22505，两个低摩擦组为0.27133和0.27083。设备侧实现另外逐项复算8,192条保存的反馈和关节目标。首次检查把默认的切向摩擦分量误判为配置缺失。复核仿真器定义后显式指定切向分量，再通过检查。[复算](cpu-preflight.json) · [命令日志](cpu-preflight-command.log)

## CUDA初始化与规模

训练接口原先执行了两次启动重置。128环境复算确认，直接前进和训练场景的第一次重置均与归档摩擦字段逐项一致，第二次重置分别产生0.08758和0.08464的关节摩擦损失系数最大差。共用首次真实重置后，4,096环境构建达到15,760 MiB，在优化前触发85%显存上限。两个3,072环境独立进程的峰值均为12,178 MiB。两组零步状态、策略输入、反馈关节目标和随机状态逐项一致，ONNX最大动作误差为2.09×10⁻⁷。[首次重置复算](zero-field-compare.json) · [4,096环境记录](cuda-zero-20261120T231415/failure.json) · [3,072环境零步对照](cuda-zero-memory-20261120T231802/pair-check.json)

## 实测净吞吐

四轮在独立进程各完成10次更新，其中6次价值网络更新、4次完整PPO更新。净吞吐按固定控制步数与从首批采样至最终观测发布的壁钟时间计算。

| 并行环境数 | 两轮净转移/秒 | 整卡显存峰值（MiB） | 两轮GPU利用率中位数 |
| ---: | ---: | ---: | ---: |
| 2,560 | 16,205／16,233 | 11,347／11,324 | 57%／56.5% |
| 3,072 | 18,785／18,568 | 13,174／13,176 | 63%／60% |

取3,072环境的慢轮与2,560环境的快轮，净吞吐提高14.39%。3,072环境峰值距85%上限最少有750 MiB，选为正式规模。正式两组各24次更新及1,769,472条转移，每组前8次只更新价值网络。[选择复算](capacity/selection.json) · [VS Code运行记录](capacity/current-training.md) · [第6次更新截图](capacity/p1-e2560/running-in-vscode.jpg)

## 在VS Code复盘

从`records/training-current.md`进入正式配对页。使用`Ctrl+Shift+V`打开Markdown预览。当前组的`native-status.txt`显示控制步、已完成更新和最新视频，`native-curve.png`显示真实训练曲线，`native-latest.jpg`显示选定场景的仿真画面。每组`execution.log`保留实际WSL命令和逐轮指标。[当前配对](pair/current-training.md) · [对照运行截图](pair/control/running-in-vscode.jpg) · [对照曲线](pair/control/native-view/native-curve.png) · [本次配对冻结方案](../../../configs/experiments/forward_low_friction_yaw_reward_pair.json)

## 正式训练与导出

原奖励对照组与偏航奖励候选组各完成24次更新和1,769,472条转移。按从采样启动到最终观测发布的计时，净吞吐分别为18,376和18,202条转移/秒。两组整卡峰值均为13,205 MiB，GPU利用率中位数分别为63%与62%。保存点保留策略、价值网络和优化器，导出使用相同的61维输入及14维动作定义。四段训练录像各81帧，独立解码已核验。[权重、保存点与完整证据清单](pair/training-check.json) · [对照第17次更新截图](pair/control/running-in-vscode.jpg) · [候选第17次更新截图](pair/candidate/running-in-vscode.jpg)

复核保存点确认两组前8次均保持父点策略权重。第21至24次更新的批内采样均值再取四次均值，原奖励对照与偏航奖励候选的平均绝对偏航分别为0.21804和0.21023 rad/s，平均前进速度为0.16388和0.16340 m/s。该口径含训练探索，动作验收使用独立的20秒前进区间。[训练过程与优化器读回](pair/training-process-readback.json) · [独立动作评价](pair/development/current-evaluation.md)

| 组别 | 训练曲线 | 起始原片 | 更新后原片 |
| --- | --- | --- | --- |
| 原行走奖励对照组 | [真实训练曲线](pair/control/native-view/native-curve.png) | [原片](../../experiments/duck_forward_yaw_reward_control_e3072_s1250_20261120T232536/clip-step-0.mp4) | [原片](../../experiments/duck_forward_yaw_reward_control_e3072_s1250_20261120T232536/clip-step-400.mp4) |
| 低摩擦前进偏航奖励候选组 | [真实训练曲线](pair/candidate/native-view/native-curve.png) | [原片](../../experiments/duck_forward_yaw_reward_candidate_e3072_s1250_20261120T232536/clip-step-0.mp4) | [原片](../../experiments/duck_forward_yaw_reward_candidate_e3072_s1250_20261120T232536/clip-step-400.mp4) |

## 动作评价

种子1247的四组训练权重评估均有128个场景进入前进，完整动作均为0/128，唯一失分项为偏航。每组按20秒平均绝对偏航速度至多0.20 rad/s、至少116/128通过全部检查验收。表中偏航取各场景20秒平均绝对值的组内中位数。

| 脚底摩擦 | 官方通过数／偏航（rad/s） | 原行走奖励对照通过数／偏航（rad/s） | 偏航奖励候选通过数／偏航（rad/s） |
| --- | ---: | ---: | ---: |
| 0.8 | 0/128／0.23030 | 0/128／0.31858 | 0/128／0.29516 |
| 1.0 | 127/128／0.18934 | 0/128／0.30311 | 0/128／0.27953 |

相较同样本原奖励组，新增偏航代价使两种摩擦下的偏航中位数分别少0.02342和0.02358 rad/s。候选在两种摩擦下仍超过原偏航门槛。两份自训权重用于复盘，官方权重作为后续仿真参照。[独立评分及原片清单](pair/development/paired-action-analysis.json) · [VS Code结果表](pair/development/current-evaluation.md)

低摩擦下，官方、原奖励对照和候选的20秒平均前进速度组内中位数分别为0.15929、0.15832和0.15850 m/s。三组最后10秒的平均绝对偏航组内中位数分别为0.23380、0.32499和0.30054 rad/s，超限持续到后段。相同保存观测下，候选对官方投影后关节目标的平均绝对差在低摩擦组为站立0.00593 rad、前进0.00985 rad。[物理轨迹复算](pair/development/physical-metrics-readback.json) · [控制输出复算](pair/development/archived-policy-drift.json) · [VS Code评分截图](pair/development/results-in-vscode.jpg) · [官方站立接自训前进](../forward-official-stance-probe/README.md)

| 脚底摩擦 | 官方行走权重 | 原行走奖励对照 | 偏航奖励候选 |
| --- | --- | --- | --- |
| 0.8 | [完整原片](../../evaluations/duck_direct_forward_s1247-friction-low_20261120T223327/clip-step-0.mp4) | [完整原片](../../evaluations/duck_forward_yaw_s1247-friction-low-control_20261120T233112/clip-step-0.mp4) | [完整原片](../../evaluations/duck_forward_yaw_s1247-friction-low-candidate_20261120T233112/clip-step-0.mp4) |
| 1.0 | [完整原片](../../evaluations/duck_direct_forward_s1247-nominal_20261120T223327/clip-step-0.mp4) | [完整原片](../../evaluations/duck_forward_yaw_s1247-nominal-control_20261120T233112/clip-step-0.mp4) | [完整原片](../../evaluations/duck_forward_yaw_s1247-nominal-candidate_20261120T233112/clip-step-0.mp4) |
