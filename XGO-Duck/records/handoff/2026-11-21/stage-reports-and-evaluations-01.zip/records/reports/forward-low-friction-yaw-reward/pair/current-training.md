# 低摩擦前进偏航奖励配对

两组训练及导出均已核验，进入独立动作评价。

[权重与录像清单](training-check.json) · [对照运行](control/execution.log) · [候选运行](candidate/execution.log)
