# 后退离地分解

复算四个开发种子的 59 次自然迟启动和 325 个时间对齐的停滞窗口。将原始姿态的机身平移、机身转动和关节角分别换成该段末端值，计算各组合的鞋底净空，再对各更新顺序的边际变化取平均。所有分量之和与真实姿态的净空变化吻合，最大闭合误差为 3.6×10⁻¹⁵ 毫米。 [冻结协议](../../../configs/experiments/common_walk_backward_clearance_decomposition.json) · [逐场景结果](analysis.json)

离地前的机身转动贡献在四批中位数为 0.58–1.11 毫米，关节运动贡献为 0.35–1.09 毫米。机身平移贡献为 −0.94 至 +0.07 毫米。单脚支撑开始后的 60 毫秒中，摆动膝贡献中位数为 2.61–3.91 毫米。离地前各批摆动膝的贡献方向有差异，后续分别分析准备段和抬腿段。数字描述已发生的运动，物理步和学习更新均为零。

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- env PYTHONPATH=scripts/validation:scripts/training /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_walk_backward_clearance_decomposition.py
```
