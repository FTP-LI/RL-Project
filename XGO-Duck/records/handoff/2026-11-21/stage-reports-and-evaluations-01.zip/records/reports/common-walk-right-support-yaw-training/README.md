# 右转支撑奖励训练

在原生 CUDA 奖励管理器中加入启动奖励。每个右转回合最多获得一次 0.07，条件沿用已核验的低角速度、连续单脚支撑及随后转速。保留策略、动作历史和原奖励，先用固定策略检查真实奖励和终止重置，再拟合两组共用的价值起点。 [训练草案](../../../configs/experiments/common_walk_right_support_yaw_training_draft.json) · [CPU 重放](../common-walk-right-support-yaw-probe/reward-cpu.json)

接线检查在 3,072 环境中运行 240 步，保留第 120 步的超时和第 132 步的提前终止。记录原奖励、实际增量、最终总奖励、脚底接触和回合步数，独立核对原观测及终止回报。 [冻结方案](../../../configs/experiments/common_walk_right_support_reward_probe.json) · [运行观察](../../walk-right-support-reward-probe-live.html)

真实接线完成 737,280 条 CUDA 转移。第 3 秒前有 26 个有效事件，终止步奖励增量为零。原奖励加实际增量与最终总奖励的最大误差为 6.24×10⁻⁸，终止回报在独立复算后通过。策略权重保持一致。 [接线评分](reward-probe-analysis.json)

共同价值阶段使用新种子 1150。固定策略采集 3,072 个完整首回合，原奖励和候选奖励取均值。世界按是否触发及是否收到奖励分层划分，独立验证世界不进入拟合。价值梯度前先核对完整回报和奖励覆盖。 [价值冻结方案](../../../configs/experiments/common_walk_right_support_shared_value.json) · [价值曲线与原片](../../walk-right-support-shared-value-live.html)

首次价值入口在启动语句处退出，完成 0 个物理步和 0 次梯度更新。保留原方案、起始页面和退出日志，恢复入口沿用同一采样和拟合预算。 [零步核验](value-zero-step-recovery/launch-stop.json) · [恢复冻结方案](../../../configs/experiments/common_walk_right_support_shared_value_recovery.json) · [恢复观察页](../../walk-right-support-shared-value-recovery-live.html)

恢复批完成 3,072,000 条转移和 100 次价值更新，策略权重逐位一致。35 个回合实际获得奖励，独立验证集含 9 个。768 个独立环境的解释方差为 0.828，归一化均方误差为 0.00765。采样耗时 112.89 秒，显存峰值 12,414 MiB。 [独立价值核验](value-zero-step-recovery/shared-value-analysis.json)

两组策略训练采用种子 1151、共同策略和价值起点，每组 3,072 个环境、14 次更新、1,032,192 条转移。候选组加入 0.07 支撑启动奖励，原奖励组的该项权重为零。独立读回训练产物后，使用七指令评估检查实际效果。 [冻结方案](../../../configs/experiments/common_walk_right_support_paired_ppo.json) · [两组运行观察](../../walk-right-support-paired-ppo-live.html)

两组均完成预算，分别采样 44.19、44.61 秒，显存峰值 12,562、12,568 MiB。候选组全程实际获得 4 次启动奖励，均在第 3 秒前。两个保存点、终点 ONNX、原始奖励及逐步价值回报均通过独立复算。 [训练读回](paired-ppo-analysis.json)

两批固定策略满足低转速条件的场景为 102、100 个，随后满足持续单脚支撑和偏航条件的为 26、35 个。两组 PPO 满足低转速条件的仅 4、6 个，其中 3、4 个满足后续条件。原奖励组的 3 个为离线复算事件，实际增量为零。这个差异出现在低转速触发阶段。各批种子、动作采样和更新状态有差异，归因需另设对照。 [覆盖复算](credit-coverage.json)

完整回合的评估使用开发种子 1141 和 1152。每个种子含七指令各 32 个场景，依次运行父策略、原奖励训练和支撑奖励训练。只替换右转路由，前进和其余指令保留父路由的批次形状。先在保存输入上核对每组 960 条非右转输出逐位一致，再运行物理采样。 [评估冻结方案](../../../configs/experiments/common_walk_right_support_seven_command.json) · [路由读回](seven-command/trained-right-route-components.json) · [六组观察](../../walk-right-support-seven-command-live.html)

## 七指令结果

| 开发种子 | 父策略右转 | 原奖励组右转 | 支撑奖励组右转 | 前进 |
| --- | ---: | ---: | ---: | --- |
| 1141 | 30/32 | 31/32 | 32/32 | 三组均 32/32 |
| 1152 | 31/32 | 32/32 | 32/32 | 父策略 32/32，两组训练均 31/32 |

其余五项在两批均为 32/32。场景 198 在种子 1141 的两组训练中都通过，场景 13 仅支撑奖励组通过。种子 1152 的场景 152 在两组训练中均通过。三组均未进入独立确认，两个训练权重保留在原批次。 [独立评分](seven-command/analysis.json) · [执行结果](seven-command/execution.json)

原奖励组前进失败的场景为 63，支撑奖励组为 36。两例仅平均绝对偏航误差超限，分别为 0.20468、0.20197 rad/s，门槛为 0.20 rad/s。第 1 步的观测、名义动作和关节目标一致，积分后的物理状态已出现数值差异。第 2 步才出现动作差异。下一轮先用两组原策略重复、只计算右转动作、实际使用右转动作四路短对照，沿用原门槛。 [前进轨迹复算](seven-command/forward-retention-diagnosis.json) · [短对照草案](../../../configs/experiments/common_walk_right_support_forward_retention_draft.json)

## 前进偏航重复

种子 1152 的四路各用 224 个环境、100 步，共 89,600 条转移、2,000 个批量物理子步。一次真实重置后，每路恢复相同的 302 项物理状态与控制历史。前进首个动作和关节目标一致。仅重复父策略时，首个控制步的第 2 个物理子步出现状态差异，随后 31/32 个前进环境在第 1 步结束时已有姿态差异。 [冻结方案](../../../configs/experiments/common_walk_right_support_forward_retention.json) · [独立复算](forward-repeatability/analysis.json) · [运行观察](../../walk-right-support-forward-repeatability-live.html)

| 两秒配对比较 | 前进各场景平均绝对偏航误差的最大差值 |
| --- | ---: |
| 两次父策略 | 0.02654 rad/s |
| 第一次父策略与仅计算候选 | 0.01507 rad/s |
| 仅计算与实际使用候选 | 0.02684 rad/s |

只计算与实际使用候选之间，第 1 个物理子步已出现约 2.04×10⁻¹⁰ 的姿态数值差。短测证实同一父策略也会出现变化，无法凭这两秒确定全程偏航失败的原因。四段 2 秒原片记录预选后退环境，场景 36 和 63 的前进关键帧取自实际保存姿态。 [诊断原片与图册](../../../docs/reports/stage-video-gallery.html) · [前进关键帧](forward-repeatability/forward-keyframes.jpg)

## 前进反馈对照

沿用连续动作中已验证的候选，将内部前进偏航反馈上限从 0.12 提至 0.15 rad/s，关节修正仍限 0.03 rad。CPU 在两批保存轨迹的 121,600 条前进反馈输入上复算。原目标读回一致，候选投影均在关节范围内。 [连续动作证据](../continuous-forward-yaw-pair/README.md) · [CPU 复算](forward-feedback-margin-cpu.json)

完整七指令比较父策略、右转候选配 0.12 反馈、右转候选配 0.15 反馈。两组候选共用右转权重。已知种子 1152 的候选须保持两组参照的前进成功数、原速度容差、后退和右转净成功数，并较同权重原反馈降低至少 0.002 rad/s 的平均绝对偏航误差。符合全部原门槛后才运行开发种子 1153。 [冻结方案](../../../configs/experiments/common_walk_right_support_forward_margin.json) · [运行观察](../../walk-right-support-forward-margin-live.html)

父策略重复完整评估时，模型、指令、反馈、重置初态以及首步观测与关节目标均一致。旧批前进为 32/32，复测为 30/32。场景 36 的绝对偏航均值由 0.19178 升至 0.20169 rad/s，场景 63 由 0.19799 升至 0.20622 rad/s。 [完整回合复算](forward-margin/known/parent-repeat-readback.json)

| 种子 1152 | 前进 | 右转 | 前进平均绝对偏航误差 |
| --- | ---: | ---: | ---: |
| 父策略配 0.12 | 30/32 | 31/32 | 0.14272 rad/s |
| 右转候选配 0.12 | 31/32 | 32/32 | 0.14274 rad/s |
| 右转候选配 0.15 | 31/32 | 32/32 | 0.14123 rad/s |

三组完成 672,000 条实际转移和独立评分。扩大反馈通过原七指令功能门槛，前进成功数和速度保持。平均偏航误差较同权重对照下降 0.00151 rad/s，未达到 0.002 rad/s 继续门槛。场景 63 的偏航误差由 0.20226 升至 0.20399 rad/s，仍超限。新种子 1153 的三组未启动，最终留出未使用。 [全部七项成绩](forward-margin/known/analysis.json) · [运行观察](../../walk-right-support-forward-margin-live.html)

三组各保留一段 4 秒原片。四路诊断的四段 2 秒原片和两例前进关键帧已单独核验。 [完整评估媒体](forward-margin/known/visual-review.json) · [短对照媒体](forward-repeatability/visual-review.json)

## 单脚支撑与偏航

在种子 1152 的六组保存轨迹中，场景 36 和 63 的单脚支撑占前进时长 95.7%–96.9%，贡献 94.2%–97.3% 的绝对偏航误差。左脚单支撑的平均偏航速度为 −0.164 至 −0.102 rad/s，右脚为 0.232 至 0.254 rad/s。全程有方向的平均偏航幅值为平均绝对偏航的 20.3%–41.5%，需要分别看支撑侧的摆动和全程漂移。 [六组时序复算](forward-yaw-phase-readback.json)

支撑侧识别用种子 1141 的 31,968 条观测拟合，只输入已有腿部关节位置、速度、重力方向和横滚、俯仰陀螺仪读数。验证种子 1142、1152 的四批共 127,872 条观测。左右识别精确率至少 99.99%，召回为 82.0%–86.3%。置信不足保留原控制，实际反馈效果需另行验证。 [识别方案](../../../configs/experiments/common_walk_forward_stance_observation.json) · [识别核验](forward-stance-observation-cpu.json) · [反馈草案](../../../configs/experiments/common_walk_forward_stance_feedback_draft.json)

历史执行器脉冲的高置信左支撑包含正、负各 15 个场景，首个 20 ms 的响应方向通过核验。右支撑只有 1 个正向样本，需补双向证据。两批 60,800 条保存反馈输入已核对双向目标投影。单次输入增量不超过 0.02 rad/s，输入绝对上限保持 0.12 rad/s，关节修正上限保持 0.03 rad。置信不足的输入保持原值。两批保存轨迹在第 85 步均有至少 8 个经核对的左支撑和 8 个右支撑。 [历史脉冲复算](forward-stance-pulse-readback.json) · [目标投影与分支选择](forward-stance-feedback-targets-cpu.json)

## 支撑脉冲

种子 1152 在第 84 步后恢复同一份 309 项状态，运行两次原反馈及一正一负脉冲。四路共 33,152 条转移、740 个批量物理子步。10 个左支撑和 9 个右支撑的识别与脚底接触一致。两侧首个 20 ms 的正负响应斜率分别为 0.619 和 0.473，配对区间下界均高于零。关节目标、非前进首步目标和原动作历史已独立读回。 [冻结方案](../../../configs/experiments/common_walk_forward_stance_response.json) · [四路评分](stance-response/analysis.json) · [运行观察](../../walk-forward-stance-response-live.html)

在分支时点，原反馈的左支撑组平均偏航已是正值。固定正脉冲使其平均绝对偏航增加 0.00179 rad/s，右支撑负脉冲使其下降 0.00370 rad/s。按支撑侧固定选择极性未通过继续门槛。四段诊断原片拍摄预选后退环境，前进图来自每侧编号最小的合格场景。 [前进关键帧](stance-response/stance-response-keyframes.jpg) · [原片核验](stance-response/visual-review.json)

用旧预测器与当前陀螺仪的一致性作为方向门槛，四批开发轨迹的方向准确率为 86.6%–92.0%，覆盖率为 28.0%–33.5%。低于预设的 95% 准确率和 50% 覆盖率。离线重选只覆盖四个右支撑场景，左侧没有合格样本，关闭此规则。 [旧方向规则复算](forward-yaw-sign-screen-cpu.json)

四帧预测器先拟合下一步偏航幅度，使用种子 1141 的 45,600 条拟合输入和 15,200 条隔离校准输入。逐一复核 12,475 个公共阈值均未通过。左右分别校准时，左侧达到门槛，右侧在覆盖率达到 50% 的范围内最高准确率为 96.99%，低于 97% 校准门槛。该批未进入开发验证。 [幅度预测](forward-yaw-predictor-cpu.json) · [公共阈值复算](forward-yaw-predictor-exact-calibration.json) · [分别校准](forward-yaw-predictor-stance-calibration.json)

在同一四帧输入、网络大小和整场景划分上，将训练目标改为加权二分类。四批开发样本的方向准确率为 96.2%–97.4%，覆盖率为 73.4%–77.6%。按离线预测逐场景重选已保存的物理脉冲，左侧 9 例平均降低绝对偏航 0.01230 rad/s，右侧 5 例降低 0.00433 rad/s。通过筛查后，连续反馈从第 84 步同一状态恢复，比较两次原反馈及一次方向反馈。每次额外输入上限 0.02 rad/s，总输入上限 0.12 rad/s，关节修正上限 0.03 rad。 [分类方案](../../../configs/experiments/common_walk_forward_yaw_direction_fit.json) · [离线复算](forward-yaw-direction-fit-cpu.json) · [四秒对照](../../../configs/experiments/common_walk_forward_yaw_direction_pilot.json) · [进度与原片](../../walk-forward-yaw-direction-pilot-live.html)

四秒对照按预算完成 96,768 条转移、2,160 次批量物理子步，Windows 观察到 19 次运行状态，显存峰值 2,610 MiB。首步两侧都通过，分支后的 2.32 秒相对两组偏航各改善 0.00696、0.00706 rad/s，前进速度最多下降 0.00020 m/s。三段原片各 4 秒，拍摄的是预先固定的后退场景，前进得分由 32 个前进场景的真实轨迹独立计算。 [独立复算](yaw-direction-pilot/analysis.json) · [运行记录](../../evaluations/duck_walk_yaw-direction-pilot_s1152_20261110T142852/README.md)

用前进场景 9 和 48 的已保存姿态生成 24 张标注帧，选取标准是分支时左右支撑各自编号最小的有效场景。对齐分支时点、首步、2.20 秒和 4.00 秒。 [并排关键帧](yaw-direction-pilot/forward-direction-keyframes.jpg) · [姿态与画面校验](yaw-direction-pilot/forward-direction-visual.json)

20 秒评估以同一批 224 个场景运行三路，共 634,368 条转移，显存峰值 2,621 MiB。Windows 观察到 115 个运行状态。两路参照的前进分别为 32/32、31/32，方向反馈为 32/32。三路左转都为 31/32，其余五项都为 32/32。前进平均绝对偏航较两条参照各减少 0.00577、0.00555 rad/s，32 个场景中分别有 30、31 个改善。原七指令及配对门槛通过，预留种子 1153 待复验。 [分项评分](yaw-direction-development/analysis.json) · [完整过程](../../walk-forward-yaw-direction-development-live.html)

前进场景 63 的三路保存姿态重放覆盖 0–20 秒，输出 501 帧。保存的第 85 步额外列入标注图。两次参照和候选在该场景的平均绝对偏航依次为 0.19071、0.20287、0.19760 rad/s。 [前进并排回放](yaw-direction-development/forward-world-63.mp4) · [关键帧](yaw-direction-development/forward-world-63-keyframes.jpg) · [画面校验](yaw-direction-development/forward-world-63-visual.json)

预留开发种子 1153 完成三路 634,368 条转移。三路七项均为 32/32，方向反馈的配对偏航降幅为 0.00720、0.00618 rad/s。独立观察捕获 115 个运行状态，显存峰值 2,610 MiB。首次评分在生成摘要时缺少诊断状态，读回修复直接使用原轨迹复算，物理步、反馈和动作门槛保持原值。 [初态检查](yaw-direction-fresh/native-zero.json) · [独立评分](yaw-direction-fresh/analysis.json) · [观察和原片](../../walk-forward-yaw-direction-fresh-live.html) · [首次评分日志](yaw-direction-fresh/readback.log)

最终留出 2153 按同一预算完成，三路七项各 32/32。方向反馈的配对偏航降幅为 0.00603、0.00524 rad/s，前进速度最多下降 0.00029 m/s。Windows 核验 115 个运行状态，显存峰值 2,616 MiB。启动前的首次读取错误保留，修复后通过 CUDA 零步，正式留出执行一次。 [留出评分](yaw-direction-holdout/analysis.json) · [观察和原片](../../walk-forward-yaw-direction-holdout-live.html) · [仿真交付清单](../../../artifacts/delivery/walking-simulation.json)

## 查看记录

从两组观察页进入训练曲线、更新次数和原始 4 秒视频。完整右转评分使用每个场景的首回合，时限为 20 秒。每组运行目录都保留冻结参数、命令、日志、指标、保存点和独立核验，最终模型入口集中在[权重与迭代记录](../../../artifacts/delivery/iteration_record.md)。

训练和评估共十段仿真原片已经解码，关键帧来自记录的实际环境和控制步。评估原片拍摄的是统一预选的后退场景。右转的完整过程另从保存姿态生成并排回放。 [训练媒体核验](training-visual-review.json) · [评估媒体核验](seven-command/visual-review.json) · [阶段图册](../../../docs/reports/stage-video-gallery.html)

两段右转回放各覆盖 0–20 秒，按 0、1、4、8、12、20 秒标注。种子 1141 的场景 13 用于对比起转失败和恢复，种子 1152 的场景 1 是预先按编号选定的正常右转。首次回放渲染的进程等待失败，随后直接从已保存的姿态重新生成。 [场景 13 回放](seven-command/right-startup-s1141-w13.mp4) · [场景 13 关键帧](seven-command/right-startup-s1141-w13-keyframes.jpg) · [场景 1 回放](seven-command/right-startup-s1152-w1.mp4) · [场景 1 关键帧](seven-command/right-startup-s1152-w1-keyframes.jpg) · [渲染记录](seven-command/replay-launch-stop.json) · [回放核验](seven-command/replay-verification.json)

复算已完成的训练时，在 [WSL 环境](../../../docs/runbooks/pc_training.md) 中进入项目目录，以项目虚拟环境执行以下命令。

```bash
PYTHONPATH=scripts/training python -B scripts/validation/review_walk_right_support_credit_coverage.py
PYTHONPATH=scripts/training python -B scripts/validation/review_walk_right_support_forward_retention.py
PYTHONPATH=scripts/training python -B scripts/validation/review_walk_forward_margin_parent_repeat.py
PYTHONPATH=scripts/training python -B scripts/validation/review_walk_forward_yaw_phase.py
PYTHONPATH=scripts/training python -B scripts/validation/check_walk_forward_stance_observation.py
PYTHONPATH=scripts/training python -B scripts/validation/review_walk_forward_stance_pulse.py
PYTHONPATH=scripts/training python -B scripts/validation/check_walk_forward_stance_feedback_targets.py
PYTHONPATH=scripts/training python -B scripts/validation/verify_walk_forward_stance_response.py
PYTHONPATH=scripts/training python -B scripts/validation/check_walk_forward_yaw_sign_screen.py
PYTHONPATH=scripts/training python -B scripts/validation/calibrate_walk_forward_yaw_prediction.py
PYTHONPATH=scripts/training python -B scripts/validation/calibrate_walk_forward_yaw_prediction_by_stance.py
PYTHONPATH=scripts/training python -B scripts/validation/fit_walk_forward_yaw_direction.py
PYTHONPATH=scripts/training python -B scripts/validation/verify_walk_forward_yaw_direction_pilot.py
PYTHONPATH=scripts/training python -B scripts/validation/verify_walk_forward_yaw_direction_development.py
PYTHONPATH=scripts/training python -B scripts/validation/recover_walk_forward_yaw_direction_fresh_readback.py
PYTHONPATH=scripts/training python -B scripts/validation/verify_walk_forward_yaw_direction_holdout.py
```
