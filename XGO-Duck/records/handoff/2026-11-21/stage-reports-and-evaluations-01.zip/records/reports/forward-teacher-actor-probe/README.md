# 行走教师约束权重低摩擦对照

种子1247、脚底摩擦0.8的128个直接前进场景，分别使用官方行走权重与归档的教师约束行走权重。归档权重来自此前完成两次更新的行走试验。此次只替换站立及前进的权重，沿用同一批初态、0.030 rad单步关节修正上限、0.15 rad/s偏航反馈输入上限与0.15 m/s前进命令。每组执行50个站立控制步及1,000个前进控制步，原评分要求20秒平均绝对偏航速度至多0.20 rad/s且至少116/128通过全部条件。[冻结方案](../../../configs/experiments/forward_teacher_actor_probe/master.json) · [VS Code评分表](current-evaluation.md) · [运行命令和日志](s1247-friction-low/collect-command.log)

运行前，以4组已有路线的6,144条策略输入复算控制量。候选与官方的61维输入、14维动作、关节顺序、默认关节位置及动作缩放一致。投影后的关节目标平均绝对差为0.00125–0.00129 rad，各组最大差中的最大值为0.00482 rad。[离线读回](../forward-correction-limit-probe/offline-teacher-actor-readback.json) · [教师约束ONNX](../../../artifacts/duck_walk_route-aware-teacher-anchor_candidate_s1230_20261114T071414/policy.onnx)

## 对照结果

两组各128个场景进入前进。官方和教师约束权重均为0/128，唯一失分项为偏航。各场景20秒平均绝对偏航速度的组内中位数为0.23030和0.22656 rad/s，同编号场景的偏航差中位数为−0.00369 rad/s。教师约束组的1,050个控制步、越界检查和完整526帧原片均已独立核验。[配对评分](independent-comparison.json) · [独立核验](s1247-friction-low/independent.json) · [21.04秒原片](../../evaluations/duck_forward_teacher_actor_e128_s1247_20261120T225535/clip-step-0.mp4)
