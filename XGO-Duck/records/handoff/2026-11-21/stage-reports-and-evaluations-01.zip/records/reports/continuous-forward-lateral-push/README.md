# 前进横向扰动

本轮使用通过开发复验的滚翻接前进控制器，偏航反馈乘数为 0.15 rad/s，关节目标修正上限为 0.03 rad。三组共享前 550 步的站立、滚翻、落地和前进轨迹。第 550 步按当时的机身航向给已进入前进的场景施加一次左或右 0.08 m/s 的水平速度增量。无扰动组沿用同一物理状态。

扰动只作用于根关节的水平速度，保留姿态、关节、竖直和角速度。首个基础策略输入、反馈、目标和延迟电机命令需要逐位一致。独立评分从冻结轨迹核对首个物理子步的实际速度。三组均沿用原 20 秒前进、滚翻和安全判据，并要求扰动后两秒保持存活及关节合法，第 2 秒的速度满足原一秒统计阈值。每组至少 116/128 个场景同时通过完整动作和恢复窗口。

[冻结方案](../../../configs/experiments/continuous_forward_lateral_push.json) · [CUDA 零步](cuda-zero.json) · [CPU 写入](../continuous-forward-yaw-pair/lateral-push-writer-cpu.json) · [运行观察](../../continuous-forward-lateral-push-live.html) · [资源采样](gpu-samples.csv)

## 实测结果

| 组别 | 完成前进 20 秒 | 通过两秒恢复 | 通过原全程与恢复 |
| --- | ---: | ---: | ---: |
| 无扰动 | 125/128 | 125/128 | 125/128 |
| 左推 | 125/128 | 125/128 | 124/128 |
| 右推 | 125/128 | 125/128 | 125/128 |

三组均达到开发门槛。同样 3 个场景未通过滚翻，因而未进入前进。左推场景 40 在两秒内恢复，但整段平均绝对偏航速度为 0.20010 rad/s，略高于 0.20 上限。相对无扰动组，前 0.2 秒的平均机身侧向速度变化为左推 +0.04360 m/s、右推 −0.03724 m/s，按场景配对抽样的 95% 区间分别为 [0.04062, 0.04666]、[−0.03898, −0.03555] m/s。 [逐场景评分](analysis.json)

第 550 步精确恢复 300 项物理字段和 15 项阶段字段。三个首个策略输入、动作目标和延迟电机命令一致，首个物理子步的实际速度与注入值一致。共完成 454,400 条转移和 17,750 个物理子步，零学习。Windows 读到 143 次运行中原始画面。三段原片各 31 秒、776 帧。 [Windows 观察核验](../../evaluations/duck_switch_forward-lateral-push_development_s1097_20261110T055237/windows-view-verification.json)

共享前段减少了 1,100 个批量控制步，即 140,800 条场景转移。相对三组各从头运行，物理采样量少 23.7%。128 场景评价期间整机显存峰值为 2,195 MiB。本轮评价开销与 PPO 并行规模短测分别留档。 [资源采样](gpu-samples.csv)

[无扰动原片](../../evaluations/duck_switch_forward-lateral-push_development_s1097_20261110T055237/clips/reference/clip-step-0.mp4) · [左推原片](../../evaluations/duck_switch_forward-lateral-push_development_s1097_20261110T055237/clips/left-push/clip-step-0.mp4) · [右推原片](../../evaluations/duck_switch_forward-lateral-push_development_s1097_20261110T055237/clips/right-push/clip-step-0.mp4)

三段原片均使用预设相机环境 0。场景 40 的偏航结果与完整物理轨迹随同一批归档。 [左推全场景轨迹](../../evaluations/duck_switch_forward-lateral-push_development_s1097_20261110T055237/clips/left-push/trace.npz)

本结果覆盖前进阶段的一次左右速度扰动。滚翻期间的扰动、参数随机化、七指令连续切换、起身接力及最终留出保留各自门槛。
