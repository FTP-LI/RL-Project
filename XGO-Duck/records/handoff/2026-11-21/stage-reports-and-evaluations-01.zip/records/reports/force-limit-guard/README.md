# 电机力限值检查

训练和仿真保持暂停。本次针对[初态审计](../matched-start-source-audit/README.md)中发现的字段缺口，补充了零步入口的编译模型检查；没有创建真实场景、执行物理步、更新权重或连接设备。 [检查方案](../../../configs/experiments/force_limit_guard_cpu_preflight.json)

## 修改内容

[零步入口](../../../scripts/validation/guarded_factor_zero_entry.py)在未来创建环境后、重置之前调用[力限值检查](../../../scripts/validation/model_force_limit_guard.py)：核对 14 个受控关节对应的传动类型和目标、力限值是否启用，以及上下限是否与声明电压和冻结电机参数计算值一致。实际运行时会保存模型读数、关节映射和哈希；发现字段缺失、映射不符、非有限值或限值不符时停止。现阶段这些输出只在假数据检查中产生，真实模型读数仍不存在。

例如，使用该参数文件中的常数，7.7 V 和 8.0 V 对应的理论上限分别约为 0.9782 和 1.0163 N·m。它们是检查的预期值，不是历史设备或真实仿真的实测值；电压变化会连带改变这个编译上限。

未来计划还须固定本机 BAM、执行器、延迟缓冲和随机数相关的七份源码。新入口在准入时要求这些哈希，原路线的 `checked()` 函数在创建环境前读取并核对实际文件。该要求补充了原路线的来源清单，不改写原来的协议或结果。

## 验证结果

| 检查 | 结果 |
| --- | --- |
| 入口假数据 | 43 项通过，包含三个参数组、暂停和采样拒绝、源码缺失、错误限值、未启用限值、关节映射错误和非有限值。 [记录](entry-fixtures.json) |
| 原守卫假环境 | 8 项通过；错误限值或未启用限值均在重置前停止。 [记录](original-guard-entry.json) |
| 原运行入口来源核对 | 3 项通过：正常核对，以及 BAM 或延迟缓冲哈希不符时拒绝。 [记录](source-check.json) |
| 新旧证据 | 99 项来源哈希读回通过，旧入口和检查源码保留在快照中。 [读回](evidence-readback.json) · [此前源码](previous-sources/) |

假环境中的模型、策略接口和 CUDA 状态均为替身。来源核对测试禁止创建真实场景和初始化 PyTorch CUDA；导入 ONNX Runtime 时出现 GPU 设备发现警告，检查退出码为 0，这不代表 GPU 已通过验证。以上检查不能证明真实模型、完整随机状态、实际执行器电压、配对初态或步态效果，动态采样仍被拒绝。

## 重新检查

在 Windows 工程根目录执行；检查使用临时假数据，不会覆盖既有记录：

```powershell
Set-Location 'C:\Users\atlas-win\Desktop\RL-Project\XGO-Duck'
py -X utf8 -B scripts/validation/verify_guarded_factor_zero_entry.py
wsl.exe -d Ubuntu-24.04 --cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck -- /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/verify_factor_zero_original_guard.py
wsl.exe -d Ubuntu-24.04 --cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck -- /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/verify_force_limit_frozen_sources.py
py -X utf8 -B scripts/validation/verify_force_limit_evidence.py
```

收到明确恢复指令后，仍需冻结真实运行方案、验证观察入口与真实 CUDA 零步，保存并对照随机数及执行器状态，再接通多臂停止规则。当前不能据此开始训练或动态采样。
