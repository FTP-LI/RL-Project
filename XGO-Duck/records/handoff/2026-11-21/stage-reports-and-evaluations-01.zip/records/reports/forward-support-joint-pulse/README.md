# 前进共同支撑关节对照

官方策略先站立1秒，再前进4秒。进入前进2秒后，选取足底真实单脚接触与编码器和IMU识别结果一致、且支撑侧髋侧摆和髋俯仰都能容纳±0.01rad的第一个控制时刻。每个种子和摩擦组合各检查128个场景，左右脚分别至少匹配64个。

| 种子与脚底摩擦系数 | 左脚共同场景 | 右脚共同场景 |
| --- | ---: | ---: |
| 1247／0.8 | 89 | 120 |
| 1248／0.8 | 89 | 115 |
| 1247／1.0 | 66 | 95 |
| 1248／1.0 | 68 | 93 |

表中为归档预检。实际仿真重新从观测、接触和关节目标选取同一批场景。每侧恢复同一状态六次，分别执行两条零脉冲、髋侧摆正负脉冲和髋俯仰正负脉冲。每个非零脉冲改一个关节的一个控制步，原关节区间和0.03rad整体修正上限照常检查。

每组包含250个共同控制步和96个分支控制步，总预算346步。复算初态、执行器延迟、实际目标及前60、160毫秒的平均绝对偏航变化。候选在两个低摩擦种子中，同一支撑侧的160毫秒降幅须分别超过各自双零差第95百分位，才进入20秒评分设计。[共同场景索引](common-mask.json) · [预检日志](preflight-command.log) · [运行状态与记录](current-evaluation.md)

## 同态关节响应

本机CUDA完成4组、1,384个批量控制步，共177,152条物理转移。每组每侧的六条分支恢复相同物理状态、策略历史和执行器延迟。独立核验确认每次非零脉冲只改变指定关节的首步目标，所有分支通过原关节范围、头部接触和数值检查。[冻结方案](../../../configs/experiments/forward_support_joint_pulse/master.json) · [完整60毫秒与160毫秒评分](paired-response.json) · [原始分支复算日志](raw-readback-command.log)

| 低摩擦种子 | 支撑侧与髋俯仰脉冲 | 匹配场景 | 前160毫秒绝对偏航降幅（rad/s） | 双零差第95百分位（rad/s） |
| --- | --- | ---: | ---: | ---: |
| 1247 | 左脚负脉冲 | 85 | 0.0014790 | 0.0002009 |
| 1248 | 左脚负脉冲 | 84 | 0.0015491 | 0.0001176 |
| 1247 | 右脚正脉冲 | 117 | 0.0005989 | 0.0005369 |
| 1248 | 右脚正脉冲 | 116 | 0.0006769 | 0.0005868 |

降幅为每场景前160毫秒平均绝对偏航的减少量，再取场景中位数。双零差为各场景两次零脉冲的平均绝对偏航之差的绝对值，再取场景第95百分位。髋俯仰两个方向均达到各自支撑侧的筛选门槛。髋侧摆在两个低摩擦种子的同一批场景中，最大降幅不足0.000020rad/s。实际分支全部位于识别到该侧支撑后的前3步。[逐组评分](current-evaluation.md) · [传感器与实际接触的时序](pulse-support-timing.json)

四段共同路线原片各126帧、5.04秒。每段包含站立和前进，脉冲响应保存在对应分支轨迹中。

| 种子与脚底摩擦系数 | 采样曲线 | 共同路线原片 |
| --- | --- | --- |
| 1247／0.8 | [种子1247低摩擦采样曲线](s1247-friction-low/native-view/native-curve.png) | [种子1247低摩擦原片](../../evaluations/duck_forward_support_joints_s1247-friction-low_20261121T012024/clip-step-0.mp4) |
| 1248／0.8 | [种子1248低摩擦采样曲线](s1248-friction-low/native-view/native-curve.png) | [种子1248低摩擦原片](../../evaluations/duck_forward_support_joints_s1248-friction-low_20261121T012024/clip-step-0.mp4) |
| 1247／1.0 | [种子1247标称摩擦采样曲线](s1247-nominal/native-view/native-curve.png) | [种子1247标称摩擦原片](../../evaluations/duck_forward_support_joints_s1247-nominal_20261121T012024/clip-step-0.mp4) |
| 1248／1.0 | [种子1248标称摩擦采样曲线](s1248-nominal/native-view/native-curve.png) | [种子1248标称摩擦原片](../../evaluations/duck_forward_support_joints_s1248-nominal_20261121T012024/clip-step-0.mp4) |

## 20秒前进的偏航分布

按实际接触模式及连续支撑的步数，将官方20秒前进归档的512,000个物理样本分组。对每个种子和摩擦组，先用各分组的绝对偏航总和除以全组样本数，再计算低摩擦组减标称组。各分组的差值相加得到两组汇总均值的差。

种子1247、1248的20秒汇总均值分别增加0.04038和0.03971rad/s。左脚单独支撑第1至3步、右脚单独支撑第1至8步合计贡献各自低摩擦增量的93.3%和94.5%。这些比例用于定位要比较的控制时段。[完整分组复算](archived-yaw-by-support-age.json) · [运行日志](support-age-command.log)

![支撑时序与偏航增量](yaw-gap-by-support-age.png)

## 复现步骤

在XGO-Duck目录的WSL环境依次执行。仿真批次目录保存每组实际采集、独立评分、运行曲线及原片，复算时可沿同一配置和归档索引定位来源。

```bash
source "$PWD/scripts/setup/project_environment.sh"
xgo_python="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
"$xgo_python" -B -u scripts/validation/forward_support_joint_pulse.py
"$xgo_python" -B -u scripts/validation/run_forward_support_joint_pulse.py freeze
"$xgo_python" -B -u scripts/validation/run_forward_support_joint_pulse.py batch
"$xgo_python" -B -u scripts/validation/readback_forward_support_pulse_context.py
"$xgo_python" -B -u scripts/validation/audit_forward_yaw_by_support_age.py
```

归档目录收录本次实际执行的[冻结日志](freeze-command.log)和[批次日志](batch-command.log)。整段步态效果按下一阶段20秒前进评分确认。[髋俯仰触发方案](../../../configs/experiments/forward_phase_hip_pitch_draft.json)
