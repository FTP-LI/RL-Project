# 后退侧倾动态对照

首批用开发种子 1103 的 224 个场景。两路原策略、向左支撑和向右支撑共享前两秒和同一物理快照。每路共六秒，最多 201,600 条实际转移。两侧候选的机身倾斜目标只用于求双腿偏移，仿真中仅下发关节目标。原策略、动作历史、指令及 0.03 rad 执行器偏移上限沿用既有协议。 [冻结方案](../../../configs/experiments/common_walk_backward_roll_pair.json) · [CPU 零步](preflight.json) · [首批运行观察](../../walk-backward-roll-s1103-live.html) · [Windows 入口](windows-entry.json)

首批必须在同一共同停滞场景产生预期方向的实际侧倾、新增连续单脚支撑和后退启动，且无原启动损失或安全越线。通过后才使用新开发种子 1104 复验同一方向，两个种子都使用原动作判据。 [目标几何](../common-walk-backward-roll-target/README.md)

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- bash scripts/validation/run_walk_backward_roll_pair.sh 1103
```

## 结果

实际执行 201,600 条转移，零学习更新。匹配快照和实际下发动作均已独立核验。筛出的 12 个场景中有 11 个触发修正，左右最大执行偏移均在 0.03 rad 以内。 [物理核验](seed1103-analysis.json) · [晋级判定](seed1103-decision.json)

| 方案 | 挽回共同停滞 | 原启动变停滞 | 侧倾中位增量 | 鞋底净空中位值 |
| --- | ---: | ---: | ---: | ---: |
| 向左支撑 | 0/5 | 0 | 0.070° | −0.406 毫米 |
| 向右支撑 | 0/5 | 1 | 0.040° | −0.379 毫米 |

表中的轨迹指标使用 2.30 秒的五个共同停滞场景。净空以地面平面为零，负值表示鞋底最低点仍处于接触区。2.14、2.30、2.44、2.60 秒均未出现预期的单脚支撑。场景 174 的存活判据在四路均失败。首批没有达到复验门槛，1104 未使用。 [实际侧倾和净空](seed1103-response.json)

## 录像与关键帧

运行期间，Windows 观察端读到 10 次进行中状态，其中 9 次带原始画面。四路各保存一段 4 秒、101 帧原片，录制场景均为 0。另从保存状态渲染共同停滞场景中编号最小的场景 5，图中标注每一帧的触地脚数和后退速度。 [Windows 观察核验](../../evaluations/duck_walk_backward-roll_paired_s1103_20261110T072734/windows-view-verification.json) · [关键帧数据](seed1103-keyframes.json)

- [原策略](../../evaluations/duck_walk_backward-roll_paired_s1103_20261110T072734/evaluation-backward/clip-step-0.mp4) · [原策略复测](../../evaluations/duck_walk_backward-roll_paired_s1103_20261110T072734/evaluation-reference-repeat/clip-step-0.mp4)
- [向左支撑](../../evaluations/duck_walk_backward-roll_paired_s1103_20261110T072734/evaluation-body-left/clip-step-0.mp4) · [向右支撑](../../evaluations/duck_walk_backward-roll_paired_s1103_20261110T072734/evaluation-body-right/clip-step-0.mp4)

![后退侧倾关键帧](seed1103-keyframes.jpg)
