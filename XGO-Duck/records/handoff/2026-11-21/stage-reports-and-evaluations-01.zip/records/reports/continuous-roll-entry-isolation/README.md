# 滚翻入口同初态对照

三组共用同一个站立结束快照，分别采用原始请求、绝对目标投影以及投影加入口限速。保留原动作判据。达到不可能通过的条件时，结束该组并保存原片与日志。

[冻结方案](../../../configs/experiments/continuous_roll_entry_isolation.json) · [运行观察](../../roll-entry-isolation-live.html) · [CPU 预检](preflight.json)

## 实测结果

三组逐项恢复站立结束时的 300 个字段，128 个场景均进入滚翻。首个策略输入、原始动作与首个延迟电机命令逐位相同。独立核验按原始滚翻判据复算全部场景。

| 目标处理 | 原门槛通过 | 最大头部穿透 | 原片 |
| --- | ---: | ---: | --- |
| 原始目标 | 119/128 | 3.22 mm | [10 秒](../../evaluations/duck_switch_roll-entry-isolation_development_s1091_20261110T050106/clips/original-roll-target/clip-step-0.mp4) |
| 仅目标投影 | 124/128 | 3.28 mm | [10 秒](../../evaluations/duck_switch_roll-entry-isolation_development_s1091_20261110T050106/clips/projection-only/clip-step-0.mp4) |
| 投影加入口限速 | 0/128 | 9.51 mm | [1.44 秒](../../evaluations/duck_switch_roll-entry-isolation_development_s1091_20261110T050106/clips/projection-and-slew/clip-step-0.mp4) |

原始目标和仅投影均完整运行 9 秒滚翻。逐场景比较，仅投影使 9 个原失败场景通过，也有 4 个原通过场景退步，净增 5 个。投影加入口限速在第 22 个滚翻步时已无场景可能达标，自动停止。三路共 972 个批量控制步、124,416 条转移和 4,860 个物理子步。Windows 端读取 46 次运行中画面。下一轮连续试验保留投影，去掉进入滚翻时的限速。滚翻后切回站立时仍按原过渡处理。 [独立评分](analysis.json) · [Windows 观察核验](windows-view-closure.json)
