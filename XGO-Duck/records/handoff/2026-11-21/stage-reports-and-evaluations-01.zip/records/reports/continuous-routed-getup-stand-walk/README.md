# 起身、站立与前进

同一个物理回合连续运行 32 秒。前 2 秒为跌倒，随后按已验收的策略分流起身，到第 11 秒检查站立接入。第 12 秒检查前进接入，保留完整 20 秒前进评分。未进入下一阶段的场景保留在完整序列的分母中。 [冻结方案](../../../configs/experiments/continuous_routed_getup_stand_walk.json) · [起身交付](../../../artifacts/delivery/getup-simulation.json) · [行走交付](../../../artifacts/delivery/walking-simulation.json)

两次切换转换新策略的关节零位和独立动作历史。限速从上一实际目标开始，采样逐步记录原始动作、目标和真实关节状态。CPU 场景与首步测试已通过，优先使用 3,072 个环境。 [CPU 冻结](freeze.json) · [运行观察](../../continuous-routed-getup-stand-walk-live.html)

独立 CUDA 零步核对 335 项状态字段。站立和前进的首步目标变化均限制在 0.040 rad。实际释放为俯卧 288、仰卧 2,427、左侧 179、右侧 178，全部达到样本门槛。 [CUDA 零步](independent-zero/proof.json) · [实际释放](../../evaluations/duck_switch_routed-getup-stand-walk_development_s1170_20261110T203929/release-coverage.json)

采样完成 4,915,200 条转移、8,000 个批量物理子步，只有一次初始重置。含录像和分批写盘用时 424.65 秒，约 11,575 条转移/秒。整卡显存峰值 13,086 MiB，约占 79.9%。Windows 端核验 33 次刷新，其中 32 次含真实帧。轨迹分 8 批保存，学习更新为零。 [采样日志](sample.log) · [观察核验](../../evaluations/duck_switch_routed-getup-stand-walk_development_s1170_20261110T203929/windows-view-verification.json)

## 独立评分

| 项目 | 结果 |
| --- | ---: |
| 原起身及时及末段持稳门槛 | 2,994/3,072，四个实际姿态与四个指定姿态均通过 |
| 站立段连续持稳 | 2,995/3,072 |
| 进入前进 | 2,995/3,072 |
| 通过原前进判据 | 2,718/2,995 |
| 完整序列 | 2,717/3,072（88.4%） |

完整序列低于 95% 门槛。进入前进的场景中，277 例偏航误差超限，平均绝对偏航为 0.248 rad/s，门槛为 0.200 rad/s。平均前向速度为 0.150 m/s，单秒分块误差均值为 0.023 m/s。另有 77 例未进入前进，保留在完整序列分母中。 [独立评分](analysis.json) · [核验日志](verify.log)

独立核验共查询 594 条 ONNX 输入。两个切换点均核对新策略原始动作历史、关节零位、逐步目标及应用限速。第 551 步和第 601 步的最大目标变化均为 0.040 rad。 [执行器目标与切换证据](analysis.json)

## 前进失稳复盘

277 例前进失败中，77 例仅偏航超限，200 例还出现其他失分。后者中 198 例连续 25 个控制步达到严重姿态异常判据。发生时间中位数为开始前进后 0.66 秒，早于偏航反馈的首个控制步。200 例的偏航与姿态异常都在首个一秒窗口出现，当前窗口分辨率无法区分先后。站立末段的机身倾角中位数为通过组 1.55°、多项失败组 1.50°。下一步将从同一站立终态比较原指令与 0.5 秒渐升指令，先验收起步两秒，再决定是否做完整 32 秒对照。 [逐秒复盘](forward-failure-review.json) · [起步对照草案](../../../configs/experiments/continuous_routed_forward_entry_ramp_draft.json)

## 录像

完整原片共 32 秒、801 帧，场景 0 实际仰卧释放。下图标出两次切换边界及前进段。 [32 秒原片](../../evaluations/duck_switch_routed-getup-stand-walk_development_s1170_20261110T203929/clip-step-0.mp4) · [媒体核验](media-review.json)

![起身、站立与前进](sequence-keyframes.jpg)
