# 前进执行器反馈

[冻结方案](../../../configs/experiments/common_walk_actuator_yaw_feedback.json) · [零步检查](preflight.json) · [运行观察](../../walk-actuator-feedback-live.html)

每支覆盖站立、前进、后退、两侧转向和两侧平移，各 32 个场景。三支共享第一秒，在同一快照分支。候选从当步及上一帧陀螺仪偏航、双髋俯仰速度读取反馈。前进内部偏航输入限于 ±0.12 rad/s，单步关节目标修正限于 0.03 rad。名义观测、动作及历史沿用同一官方模型。CPU 预检先测试逐场景重置、分支恢复和命令映射，再检查共同场景。独立评分按原七项门槛，并要求对两路参照均实现至少 0.01 rad/s 的前进偏航改善，配对区间下界为正，前进速度损失最多 0.01 m/s，且成功数不得减少。

本轮冻结前的首次 CPU 检查误把脉冲分析和保存输入索引当作同一来源，哈希保护在场景初始化前停止。分开校验来源后 CPU 检查通过。 [首次日志](../common-walk-yaw-history-probe/actuator-feedback-freeze.log) · [通过日志](../common-walk-yaw-history-probe/actuator-feedback-freeze-verified.log)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
set -o pipefail
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
  "$PY -B scripts/validation/common_walk_actuator_yaw_feedback.py --sample" /dev/null
"$PY" -B scripts/validation/verify_walk_actuator_yaw_feedback.py
```

按上述入口执行时，先登记新运行并冻结场景。已有记录可从原始轨迹复核。运行控制和采样资源分别见 [采样日志](sampling-console.log) · [GPU 指标](gpu.csv)。

## 实测结果

三支七项均 224/224。前进平均绝对偏航误差在两路参照为 0.16418、0.16409 rad/s，反馈组为 0.14960 rad/s。配对改善分别为 0.01457、0.01449 rad/s，95% 区间分别为 [0.01160, 0.01752]、[0.01128, 0.01761]。前进速度差为 −0.00030、−0.00035 m/s，成功数均为 32/32，开发门槛通过。

独立核验了 649,600 条转移、14,500 个批量物理子步及三段各 101 帧的 4 秒原片。30,400 条反馈输入经 CPU ONNX 独立重放，26 条触发目标限幅。其他目标、名义动作历史与首个延迟电机命令的完整性检查通过。Windows 读取了 29 个运行中状态，采样完成和独立核验完成的状态均可打开本轮完整原片。 [完整评分](analysis.json) · [观察核验](../../evaluations/duck_walk_actuator-feedback_paired_s1047_20261110T021935/windows-view-verification.json) · [参照一](../../evaluations/duck_walk_actuator-feedback_paired_s1047_20261110T021935/evaluation-reference-a/clip-step-0.mp4) · [参照二](../../evaluations/duck_walk_actuator-feedback_paired_s1047_20261110T021935/evaluation-reference-b/clip-step-0.mp4) · [反馈原片](../../evaluations/duck_walk_actuator-feedback_paired_s1047_20261110T021935/evaluation-actuator-feedback/clip-step-0.mp4)

分支后的四个连续时段均测得改善，两路参照的分段差值为 0.01308–0.01740 rad/s。112 个本机 GPU 观测的利用率中位数 38%、最高 48%，显存峰值 3,755 MiB。此固定评估每支 224 个场景。正式学习的并行规模以吞吐短测单独选择。 [分段复算与资源](closed-loop-review.json)
