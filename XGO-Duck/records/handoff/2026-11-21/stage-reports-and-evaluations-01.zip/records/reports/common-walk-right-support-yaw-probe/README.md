# 右转原生接触采样

复用已核验的固定策略、物理接口、录像和自动重置。两遍各 3,072 个环境、240 步，在奖励计算后、自动重置前保存双脚接触和回合步数。第 26–75 步的观测角速度绝对均值低于或等于 0.05 rad/s 后，按持续单脚支撑 0.10 秒及随后 0.30 秒的真实和观测右转速度复算。两遍各至少 16 个首回合须在 3 秒内符合条件，才进入奖励函数预检。 [冻结方案](../../../configs/experiments/common_walk_right_support_yaw_probe.json) · [CPU 检查](preflight.json) · [运行观察](../../walk-right-support-yaw-probe-live.html)

## 采样结果

两遍共完成 1,474,560 条 CUDA 转移。每遍触发 101 个首回合，在第 3 秒前分别确认 29 和 30 个事件。接触与原生奖励记录的回合步数逐项相同，超时及提前终止的两例均排除在事件统计外。 [独立复算](analysis.json) · [原始采样核验](probe-analysis.json) · [退出记录](probe-execution.json)

| 批次 | 第 3 秒前事件 | 第 4.8 秒前事件 | 净转移/秒 | 峰值显存 MiB |
| --- | ---: | ---: | ---: | ---: |
| 第一遍 | 29 | 64 | 24,006 | 12,230 |
| 第二遍 | 30 | 65 | 22,593 | 12,235 |

净吞吐按预热后的 144 步计，包含录像和进度发布。每遍保留环境 0 的 4 秒右转原片，事件统计使用全部环境。 [图册](../../../docs/reports/stage-video-gallery.html) · [媒体核验](visual-review.json)

## 奖励预检

两遍事件对应的 0.30 秒原偏航奖励中位数为 0.398 和 0.409。取较小值的 20% 后向下取整，一次性奖励为 0.07。CPU 在线计算重放每遍前 150 步，逐条匹配 29 和 30 个事件的场景与时刻。独立边界样本检查终止后清零、重置后的新回合和每回合最多一次。下一步在 CUDA 原生奖励调用中核验后，拟合两组共用价值起点。 [奖励尺度](reward-scale.json) · [在线 CPU 核验](reward-cpu.json) · [训练草案](../../../configs/experiments/common_walk_right_support_yaw_training_draft.json)

## 复查命令

在工程根目录的 WSL 环境执行。

```bash
export PYTHONPATH=scripts/training
python -B scripts/validation/verify_walk_right_support_yaw_probe.py
python -B scripts/validation/review_walk_right_support_yaw_reward_scale.py
python -B scripts/validation/check_walk_right_support_credit.py
```
