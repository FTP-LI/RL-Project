# 阶段记录

| 工作 | 实际状态 | 证据 |
| --- | --- | --- |
| 环境部署 | 已完成，保留官方依赖和镜像下载记录 | [环境日志](../../records/deployment/2026-10-31/README.md) |
| 全部录像单张总览 | 合并 293 段录像、586 张真实帧；95 段训练、198 段评估，含 2 段注明时长的部分片段 | [单张总览](assets/all-video-overview.jpg)、[来源清单](../../records/reports/stage-media/all-video-overview.json) |
| 历史训练复盘 | 12 次主要训练、14 次性能短测已审计 | [审计记录](../../records/reports/training-review/history-audit.json) |
| 历史视频 | 64 段训练、67 段评估已解码，选取 262 张真实帧 | [标注图册](training-gait-gallery.html) |
| 后续阶段视频 | 31 段训练、131 段评估已解码，选取 324 张真实帧；2 段部分录像也已标明并收录 | [总览](assets/stage-video-overview.jpg)、[逐段图册](stage-video-gallery.html) |
| S1a 来源与导出 | 两组导出及接口核对通过，官方参照固定 | [执行结果](../../records/reports/s1-inputs/progress.json)、[接口核对](../../records/reports/s1-inputs/interface-contracts.json) |
| S1b 七指令评估 | 21 个模型/指令组合、672 个 episode 已核验；三组仅通过站立数值筛查 | [逐项结果](../../records/reports/s1-evaluation/analysis.json) |
| S1c 观察、停止与恢复 | 8 次停止、5 次恢复、两组各 50 次开销对比通过；本轮开销 4.18% | [最终核验](../../records/reports/s1-integration/verification.json) |
| S2a 髋姿态诊断 | 两组各 50 次、起点匹配、导出和 448 个 episode 核验通过；姿态改善为零，未满足继续条件 | [执行记录](../../records/reports/s2-hip-repair/progress.json)、[停止结论](../../records/reports/s2-hip-repair/decision.json) |
| 官方策略初始化 | 50 次更新及 96 个场景已核验；姿态保持，运动跟踪尚未达标 | [训练核验](../../records/reports/official-actor-bootstrap/training-verification.json)、[三指令分析](../../records/reports/official-actor-bootstrap/screen-analysis.json) |
| 官方起点适应训练 | 150 次计算预算及 96 个场景评估已完成；速度退化，停止直接续训 | [独立判定](../../records/reports/official-adaptation/screen-analysis.json)、[最终模型核验](../../records/reports/official-adaptation/training-verification.json) |
| 速度奖励宽度对照 | 两组各 50 次、共 192 个场景；起点匹配，候选未达到进步条件，停止本轮 | [冻结协议](../../configs/experiments/tracking_precision_pair.json)、[结果](../../records/reports/tracking-precision/analysis.json) |
| 速度时间统计对照 | 两组各 50 次及 192 个场景完成；候选未通过进步条件，已关闭 | [协议](../../configs/experiments/planar_filter_pair.json)、[独立结果](../../records/reports/planar-filter/analysis.json) |
| 官方指令响应 | 19 档、304 个场景全部存活；低速输入未必产生足够运动 | [响应结果](../../records/reports/command-response/probe-analysis.json) |
| 输入映射诊断 | 完成 80 个场景后中止；跨进程逐点站立检查失败，部分前后走结果只作诊断 | [原失败](../../records/reports/command-mapping/probe-progress.json)、[部分分析](../../records/reports/command-mapping/partial-behavior-summary.json) |
| 前后走独立确认 | 三项各 32/32 通过功能开发筛查；原瞬时误差未通过，完整行走待验收 | [冻结协议](../../configs/experiments/straight_parallel_confirmation.json)、[独立分析](../../records/reports/straight-parallel/analysis.json) |
| 完整七指令确认 | 两个开发种子及一次留出，每项各 32/32，共 672/672；参数全程固定 | [汇总与范围](../../records/reports/seven-command/confirmation-summary.json)、[仿真包](../../artifacts/simulation/duck_walk_command-gyro_reference_20261103/README.md) |
| 奖励分项诊断 | 64 个固定场景；原分析失败保留，实际奖励分项及总和已独立复算 | [复算结果](../../records/reports/reward-incentives/reanalysis.json) |
| 官方起身参照 | 四姿态 128 次、侧卧补充 256 次、随机跌落 256 次已核验；主要随机倾倒组 249/249，连续切换待验收 | [首轮核验](../../records/reports/standup-reference/analysis.json)、[侧卧覆盖](../../records/reports/lateral-recovery/coverage-analysis.json)、[随机跌落](../../records/reports/random-recovery/random-analysis.json) |
| 官方前滚翻参照 | 32 次独立核验，28 次通过，未达到 90% 门槛；保留四次失败并诊断 | [核验结果](../../records/reports/roll-reference/analysis.json)、[失败阶段](../../records/reports/roll-reference/failure-diagnostic.json) |
| 滚翻初始姿态对照 | 两组各 32 次，原姿态 31/32、候选 27/32；候选不采用 | [冻结协议](../../configs/experiments/roll_reset_pair.json)、[成对分析](../../records/reports/roll-reset-pair/analysis.json) |
| 共同场景固定回归 | 384 次、308800 个控制转移；行走 223/224、滚翻 30/32，起身四姿态未通过 | [完整结果](../../records/reports/common-plant-screen/analysis.json) |
| 技能切换准备 | 模型、运行程序和三任务物理配置已审计；共同环境起身与连续动作待验收 | [接口审计](../../records/reports/skill-interfaces/analysis.json)、[切换说明](../runbooks/skill_switching.md) |
| 部署准备 | 关节映射表、标定步骤、时序与回退说明已整理，映射离线检查通过 | [操作说明](../runbooks/hardware_commissioning.md)、[映射核验](../../records/hardware/deployment-preparation/mapping-check.json) |
| 真机标定与部署 | 未执行；机器人已装配，App Lab 已安装 | 第 9 节 |
