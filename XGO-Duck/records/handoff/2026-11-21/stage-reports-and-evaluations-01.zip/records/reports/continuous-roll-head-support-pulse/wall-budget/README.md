# 滚翻对照暂停记录

采样于 2026-11-10 23:28 退出。128 个并行环境累计执行 2,225 个批量控制步，共 284,800 条转移。暂停守卫在最后一拍物理计算后、采集器写入该拍前退出，因此原始轨迹记录 2,224 步。模型权重保持原样。

| 分支 | 保存进度 | 核验结果 |
| --- | --- | --- |
| 无扰动原控制 | 31 秒，776 帧 | 滚翻 120/128，完整滚翻、落地和前进 119/128 |
| 左推原控制 | 第 732 步，14.64 秒，367 帧 | 部分轨迹，等待完整对照 |
| 右推原控制与三组脉冲 | 各 1.16 秒，30 帧 | 共同起始段 |

CPU 核对了录像帧数、接触轨迹和无扰动组评分。Windows 观察在暂停前记录了 89 次带原始画面的更新。完整物理快照只存在于运行进程中。后续用新运行编号重建共同初态，并保留本次片段供对照。

[暂停核验](pause.json) · [无扰动原片](../../../evaluations/duck_switch_roll-head-support-pulse_wall-budget_s1176_20261110T232238/clips/reference/clip-step-0.mp4) · [左推部分原片](../../../evaluations/duck_switch_roll-head-support-pulse_wall-budget_s1176_20261110T232238/clips/left-push/clip-step-0.mp4) · [最后运行状态](../../../evaluations/duck_switch_roll-head-support-pulse_wall-budget_s1176_20261110T232238/state.json) · [原方案](../../../../configs/experiments/continuous_roll_head_support_pulse_wall_budget.json)
