# 前进闭环留出

[冻结方案](../../../configs/experiments/common_walk_actuator_yaw_feedback_heldout.json) · [零步检查](preflight.json) · [运行观察](../../walk-actuator-feedback-heldout-live.html)

种子 2047 在复验完成前预留。两批开发均过门槛后冻结，仅执行一个留出批次。沿用相同模型、反馈幅度、关节限幅、外部命令和原七项判据。每支 224 个场景、各 20 秒，第一秒共享。执行入口接受 `--freeze`、`--sample` 和 `--verify`，源码、父方案和两批开发评分的 SHA-256 随协议保存。 [首批](../common-walk-actuator-yaw-feedback/README.md) · [复验](../common-walk-actuator-yaw-feedback-replication/README.md) · [CPU 冻结日志](../common-walk-actuator-yaw-feedback-replication/heldout-freeze.log)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
set -o pipefail
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
  "$PY -B scripts/validation/confirm_walk_actuator_yaw_feedback_heldout.py --sample" /dev/null
"$PY" -B scripts/validation/confirm_walk_actuator_yaw_feedback_heldout.py --verify
```

运行中观察页只挂出录像器确认已写完的原片，同时更新控制步和吞吐。Windows 可用 `scripts/validation/verify_walk_live_page.py` 记录观察状态和原片哈希。 [采样日志](sampling-console.log) · [GPU 指标](gpu.csv)

## 留出结果

三支均为 222/224。站立、前进、左右转、左右平移各 32/32，后退各 30/32，低于原门槛 31/32。三支均在环境 200 和 218 失分。这两处后退方向速度接近零，均低于 0.06 m/s，1 秒分块误差约 0.1006–0.1008 m/s，超过 0.05 m/s。修正只作用于前进，其他目标的原投影检查通过。

两路参照前进平均偏航误差分别为 0.15655、0.15550 rad/s，反馈组为 0.13801 rad/s。配对改善为 0.01854、0.01749 rad/s，95% 区间分别为 [0.01514, 0.02184]、[0.01446, 0.02046]。前进速度差约为 −0.00028 m/s，原前进门槛通过。七指令整组未晋级，2047 已消费。后退诊断转用开发数据。 [独立评分](analysis.json)

实际采集 649,600 条转移和 14,500 个批量物理子步，零学习。CPU ONNX 独立重放 30,400 条反馈输入，34 条触发目标限幅。三段前进原片各 101 帧、4 秒。后退两例通过逐场景原轨迹核对，本批相机固定在前进场景。Windows 读取 31 个运行中状态，其中 29 个同时挂出已完成原片。GPU 采样 111 次，利用率中位数 39%，显存峰值 3,710 MiB。 [观察核验](../../evaluations/duck_walk_actuator-feedback_heldout_s2047_20261110T023131/windows-view-verification.json) · [参照一](../../evaluations/duck_walk_actuator-feedback_heldout_s2047_20261110T023131/evaluation-reference-a/clip-step-0.mp4) · [参照二](../../evaluations/duck_walk_actuator-feedback_heldout_s2047_20261110T023131/evaluation-reference-b/clip-step-0.mp4) · [反馈原片](../../evaluations/duck_walk_actuator-feedback_heldout_s2047_20261110T023131/evaluation-actuator-feedback/clip-step-0.mp4)
