# 起始站立到滚翻边界筛查

本轮用 seed 1214 执行 50 个站立控制步和 450 个滚翻控制步，逐步保存 `Sequence.phase`、动作历史清零、`RollLandingLatch` 状态和接触条件；没有学习更新、留出数据或硬件通信。

| 证据 | 路径 |
| --- | --- |
| 冻结协议 | [router_roll_boundary_screen_s1214.json](../../../configs/experiments/router_roll_boundary_screen_s1214.json) |
| CPU 前置核验 | [preflight.json](preflight.json) |
| GPU 零步 | [zero/runtime-contract.json](zero/runtime-contract.json) |
| phase/latch 分析 | [analysis.json](analysis.json) |
| 失败机制分类 | [mechanism-analysis.json](mechanism-analysis.json) |
| 轨迹 | [boundary.npz](../../../records/evaluations/duck_router-roll-boundary_development_s1214_20261114T015736/boundary.npz) |
| 完整序列原片 | [clip-step-0.mp4](../../../records/evaluations/duck_router-roll-boundary_development_s1214_20261114T015736/clip-step-0.mp4) |

128/128 环境进入 `ROLL`；25 步 bridge 期间首次头部穿透出现在滚翻局部第 22 步，最终只有 1 个 latch 就绪。该记录支持继续验证 bridge 影响，不支持直接训练或晋级。
