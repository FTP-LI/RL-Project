# 右转支撑短对照

右脚支撑修正未挽回共同停滞。三条分支触发相同的两个场景，最大实际关节目标变化为 0.02991 rad，原有安全指标没有新增未通过场景。 [独立复算](analysis.json) · [运行退出记录](execution.json)

用成功起步轨迹中的髋、膝和踝关节变化拟合双向目标。右脚方案通过保存姿态和限幅检查，两个已知停滞场景的几何预测均约向右移重 2.0 mm，左脚相对抬高 1.6 mm。第三批符合左脚支撑拟合条件的样本只有一个，其关节变化方向与左脚方案不一致，该侧停在 CPU 核验。 [目标核验](target-preflight.json) · [轨迹依据](../common-walk-early-official-right/zero-physics-recovery/support-transfer-screen.json)

三条分支共享前 75 步。两条参考计算同一候选目标，试验组在相同陀螺仪条件触发后，于最多 0.6 秒内下发修正。头颈和偏航关节目标保持原样，修正不写入策略动作历史。每条分支回放对应 5 秒，真实采样预算 134,400 条转移。先看两例停滞能否在第 3 秒前形成 0.10 秒持续右脚支撑，再按原关节、姿态、滑移和存活判据筛查。 [冻结方案](../../../configs/experiments/common_walk_right_support_pulse.json) · [冻结凭证](preflight.json) · [运行观察](../../walk-right-support-pulse-live.html)

## 支撑结果

表中位置为第 1.5 秒后至第 3 秒内相对分支起点的最大向右移重。

| 场景 | 参考一 | 参考二 | 右脚修正 |
| --- | --- | --- | --- |
| 13 | 无持续支撑，2.13 mm | 无持续支撑，2.13 mm | 无持续支撑，2.40 mm |
| 198 | 2.58 秒，4.64 mm | 无持续支撑，3.42 mm | 2.60 秒，5.19 mm |

场景 198 在未修正的参考一也自然恢复，试验组没有比参考一更早支撑。两条参考的差异保留在逐帧记录，固定修正停止于短对照。完整七指令原门槛继续有效。 [逐组轨迹和评分](analysis.json)

Windows 观察保留 11 次带原始画面的运行快照。三段环境 0 的 4 秒后退原片已归档，两处右转停滞各有 5 秒保存姿态回放。 [图册](../../../docs/reports/stage-video-gallery.html) · [场景 13](right-support-s1141-w13.mp4) · [场景 198](right-support-s1141-w198.mp4) · [媒体核验](visual-review.json)

![场景 198 关键帧](right-support-s1141-w198-keyframes.jpg)

## 启动信号

三个父策略批次中，94/94 个成功场景在持续单脚支撑确认后的 0.30 秒内，真实与观测平均右转速度均达到原门槛 0.28 rad/s。两个失败在第 3 秒前均未达到这个组合条件。短对照的场景 198 中，自然恢复与修正后的随后实际转速分别为 0.562 和 0.561 rad/s。旧的 3,072 环境原生采样仅保存转速，两遍在 3 秒内的候选反馈数上限分别为 43 和 39。 [支撑和转速复算](support-yaw-signal.json) · [覆盖上限](support-yaw-coverage.json) · [接触补采](../common-walk-right-support-yaw-probe/README.md)

## 复查

在独立工程副本的 WSL 环境执行。命令重读已保存的数据并重新生成核验结果，原工程以冻结记录为准。

```bash
export PYTHONPATH=scripts/training
python -B scripts/validation/check_walk_right_support_targets.py
python -B scripts/validation/verify_walk_right_support_transfer.py
MUJOCO_GL=egl python -B scripts/validation/render_walk_right_support_transfer.py
python -B scripts/validation/review_walk_right_support_yaw_signal.py
python -B scripts/validation/review_walk_right_support_yaw_coverage.py
```
