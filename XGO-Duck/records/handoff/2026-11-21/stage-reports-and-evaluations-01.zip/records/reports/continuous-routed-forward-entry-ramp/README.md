# 前进起步对照

首次 32 秒连续评估中，许多失败在刚进入前进时已出现明显倾斜或掉高。本轮只调整前进速度指令进入策略的方式。原指令为 0.15 m/s，候选在 25 个控制步内由低到高达到相同幅度。策略权重、上一动作历史、目标限速和偏航反馈时钟沿用原连续评估。

3,072 个场景只运行一次共同的 12 秒跌倒、起身与站立过程。到达分支点后核对物理状态和控制器历史，再各运行 2 秒。两组均以原 0.15 m/s 指令为比较基准，分别记录持续严重姿态异常、平均偏航和第二秒前进速度。只有达到全部预定门槛才进入完整 32 秒复验。

[来源与失败定位](../continuous-routed-getup-stand-walk/README.md) · [冻结方案](../../../configs/experiments/continuous_routed_forward_entry_ramp.json) · [CPU 核验](freeze.json) · [CUDA 零步核验](independent-zero/proof.json) · [运行观察](../../continuous-routed-forward-entry-ramp-live.html) · [采样记录](../../evaluations/duck_switch_forward-entry-ramp_development_s1171_20261110T210139/README.md)

## 结果

两组各有 3,009 个场景进入前进。分支点 345 项物理状态逐位一致，站立和起身的控制器历史、随机数状态也已核对。未进入前进的 63 例保留在完整序列的分母中。

| 指标 | 立即指令 | 半秒渐升 |
| --- | ---: | ---: |
| 严重姿态异常持续至少 0.5 秒 | 185 / 3,009 | 0 / 3,009 |
| 起步两秒平均绝对偏航 | 0.409 rad/s | 0.129 rad/s |
| 第二秒平均前向速度 | 0.151 m/s | 0.162 m/s |
| 第一步最大实际关节目标变化 | 0.040 rad | 0.040 rad |

原指令组的 185 例异常来自俯卧 16、仰卧 147、左侧 14、右侧 8。渐升组挽回这 185 例，未出现新的同类异常。全部短测门槛通过，下一轮采用新开发种子，保持原起身、站立、20 秒前进和完整序列 95% 门槛。 [独立复算](analysis.json) · [完整复验草案](../../../configs/experiments/continuous_routed_getup_ramped_forward_draft.json)

本轮共 2,457,600 条转移和 4,000 个批量物理子步，只有初始重置。含录像及分支写盘用时 149.43 秒，约 16,446 条转移/秒。整卡显存峰值 13,239 MiB，平均 GPU 利用率 42.5%。Windows 核验 21 次运行刷新，其中 20 次有真实帧。评分入口首次因缺少训练脚本路径退出，补充 `PYTHONPATH` 后复算通过，采样没有重跑。 [采样退出](sample-exit.json) · [首次评分日志](verify-entrypoint-first.log) · [复算日志](verify.log) · [观察核验](../../evaluations/duck_switch_forward-entry-ramp_development_s1171_20261110T210139/windows-view-verification.json)

## 录像

两段原片均为 14 秒、351 帧，共享前 12 秒的真实状态。固定镜头为仰卧释放的场景 0。 [立即指令原片](../../evaluations/duck_switch_forward-entry-ramp_development_s1171_20261110T210139/step-command/clip-step-0.mp4) · [半秒渐升原片](../../evaluations/duck_switch_forward-entry-ramp_development_s1171_20261110T210139/ramped-command/clip-step-0.mp4)

![同一站立状态的起步对照](entry-keyframes.jpg)

以下从保存状态重建一个实际失稳场景，按仰卧挽回组的异常时点中位数选择。场景 116 在起步后 0.68 秒的倾角分别为 52.2° 和 1.5°。图中每列使用相同时间点，保留实际高度和倾角。 [状态与帧哈希](saved-failure-media.json)

![起步失稳对照](saved-failure-keyframes.jpg)
