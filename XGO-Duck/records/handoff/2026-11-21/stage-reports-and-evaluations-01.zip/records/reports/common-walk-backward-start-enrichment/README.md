# 后退初态复验

用固定官方策略和同一新随机种子比较常规重置与困难初态重置。两组各 128 个场景、300 个控制步，候选仅替换预先指定的 63 个后退槽位。至少多出 4 个近静止场景且无候选独有的提前结束，才可使用新开发种子复验。两组用相同后退指令、动作处理和原评分。 [方案草案](../../../configs/experiments/common_walk_backward_start_enrichment_draft.json)

首次入口在构造环境前中止，未发生初始重置、物理步或学习。原因是环境包装以函数替换了原生类，仿真库的录像类无法继承。恢复入口保留对照的原生类，仅在候选构造后绑定困难初态，并继续使用原种子和预算。 [零步中止](zero-step-stop.json) · [中止日志](control/sampling.log) · [恢复方案](../../../configs/experiments/common_walk_backward_start_enrichment_recovery.json)

两组分别记录运行进度、吞吐和原始画面。 [普通重置观察](../../walk-backward-enrichment-s1129-control-recovery-live.html) · [困难初态观察](../../walk-backward-enrichment-s1129-candidate-recovery-live.html)

在 WSL 工程根目录执行的入口如下。原运行编号和结果目录由方案锁定，复现时需使用单独的运行目录。

```bash
bash scripts/validation/run_walk_backward_start_enrichment.sh
```

## 结果

两组完成 76,800 条实际转移，共 3,000 个批量物理子步，零学习更新。在指定的 63 个槽位中，普通重置 0 个停滞，困难初态重置 3 个停滞，低于 4 个的继续门槛。两组均无提前结束。其余 65 个槽位的初始状态、首帧观测和历史逐位一致；状态从第 1 个控制步出现差异，观测与动作从第 2 步出现差异。两组后续均无选择性重置，最终随机流一致。该差异需要保留在比较限制中。 [配对判定](recovery/decision.json) · [普通重置评分](recovery/control/seed1129-analysis.json) · [困难初态评分](recovery/candidate/seed1129-analysis.json)

两段原片各覆盖 4 秒、101 帧，Windows 两组各核验 3 次运行中状态，其中 2 次带原始画面。原始录像镜头为环境 0。场景 7 是困难初态组新增的停滞场景，下图从保存状态重放两组的 8 张关键帧。 [普通重置原片](../../evaluations/duck_walk_backward-enrichment_control-recovery_s1129_20261110T081721/evaluation-backward/clip-step-0.mp4) · [困难初态原片](../../evaluations/duck_walk_backward-enrichment_candidate-recovery_s1129_20261110T081721/evaluation-backward/clip-step-0.mp4) · [关键帧数据](recovery/keyframes.json)

![后退初态对照](recovery/keyframes.jpg)

第 2 秒保存的物理位置、速度、动作历史和观测已核对。后续改为从实际轨迹中捕获停滞状态。 [前两秒筛选](../common-walk-backward-stall-prefix/README.md)

全部录像总览在新增两段后触及 JPEG 高度限制。总览入口改为按录像数量自动选列，写完新图后再替换旧图。623 段原片与 1,246 张真实选帧已重新核对。 [单张总览](../../../docs/reports/assets/all-video-overview.jpg) · [逐段图册](../../../docs/reports/stage-video-gallery.html)
