# 后退脚底受力

共同场景的 CPU 零步检查使用 8 个保存姿态，以零速度求解接触，按地面和脚底的几何配对独立复算左右脚力。脚底几何编号为 12 和 30，名义机体重量为 7.826 N。8 个姿态的通道读数均在 1 nN 容差内一致。 [CPU 核验](preflight.json)

开发种子 1111 的 224 个场景使用原策略完成 67,200 条转移，零学习更新。实际 CUDA 零步核对通过。220 个控制时点的力来自控制步最后一个 4 毫秒物理子步，按积分前状态计时。积分后的关节角和机身位姿与控制轨迹逐位一致，六个原始接触时点的力与接触数独立复算一致。 [冻结方案](../../../configs/experiments/common_walk_backward_load_clock.json) · [启动评分](seed1111-analysis.json) · [受力核验](seed1111-load-analysis.json)

| 指标 | 自然迟启动 | 对齐停滞 |
| --- | ---: | ---: |
| 提前达到持续承重 | 5/15 场景 | 10/165 窗口 |
| 膝目标达标后实际膝动作达标 | 15/15 场景 | 5/78 窗口 |
| 膝目标达标且摆动脚仍承重 | 13/15 场景 | 75/78 窗口 |

承重门槛为同一脚连续三个控制读数占双脚合力至少 65%，且双脚合力至少为名义重量的 25%。15 个自然迟启动场景只覆盖 33%，低于 50% 门槛。165 个停滞窗口来自 11 个场景，按自然启动时刻重复对齐。膝目标达标时仍承重的 13 个自然启动场景均在 60 毫秒窗口内出现实测膝动作。负荷转移可以描述两类轨迹的差异，但单独作为启动标记未通过复验准入。 [逐场景数据](seed1111-load-analysis.json)

![后退脚底法向力](../../../docs/reports/assets/backward-sole-load.png)

实线和虚线表示中位数，色带为四分位范围。停滞窗口的支撑侧取对应自然启动场景的同一侧。 [图表数据](load-figure.json)

Windows 观察端核验了 4 次运行中状态，其中 3 次带原始画面。原片覆盖预定的 4 秒观察窗口、共 101 帧，动作评分与力读数使用 6 秒仿真数据。 [运行观察](../../walk-backward-load-clock-s1111-live.html) · [原始录像](../../evaluations/duck_walk_backward-load-clock_development_s1111_20261110T074946/evaluation-backward/clip-step-0.mp4) · [Windows 核验](../../evaluations/duck_walk_backward-load-clock_development_s1111_20261110T074946/windows-view-verification.json)

本轮命令、退出码、控制步记录与核验日志保留在同一目录。 [执行命令](command.txt) · [采集日志](sampling.log) · [核验日志](verification.log)
