# 前进偏航相位对照

开发种子 1044 共完成 649,600 条实际转移、14,500 个物理子步，学习更新为 0。三路各 224 个场景、每条指令 32 个首次 episode。前 1 秒共用物理轨迹，分支恢复核对 309 项状态和独立控制器历史。候选只在前进时使用双髋俯仰速度之和生成相反方向的内部偏航输入，绝对值最多 0.06 rad/s。关节限位和外部指令沿用原设置。 [冻结协议](../../../configs/experiments/common_walk_forward_phase_screen.json) · [独立结果](analysis.json)

| 分支 | 七指令总通过数 | 前进通过数 | 前进偏航误差（rad/s） | 前进速度（m/s） |
| --- | ---: | ---: | ---: | ---: |
| 官方一 | 223/224 | 31/32 | 0.1601 | 0.16163 |
| 官方二 | 222/224 | 32/32 | 0.1587 | 0.16169 |
| 相位候选 | 223/224 | 32/32 | 0.1540 | 0.16174 |

候选的七指令均通过原功能门槛。前进偏航对两次官方的配对平均收益为 0.0061、0.0047 rad/s，95% 区间分别为 0.0036–0.0085、0.0022–0.0070 rad/s，均低于事前规定的 0.01 rad/s 收益。该方案关闭，最终留出尚未使用。 [配对图](../../../docs/reports/assets/walk-forward-phase-yaw.png)

分支后首个 20 ms，32 个前进环境的偏航变化全部与首个修正同向，中位幅度为 0.00247 rad/s。两次官方重复在同一控制步的差值中位数约为 0.0000021 rad/s。到 60 ms，绝对偏航误差收益的中位数变为 −0.00048 rad/s，部分环境的内部修正已经换向。 [逐步复算](early-response.json) · [图像检查](figure-review.json)

## 录像与复现

三段原片使用预设前进环境 0，覆盖 0–4 秒，每段 101 帧、25 fps，帧的保存状态已逐一校验。整段评分使用 20 秒轨迹。 [运行终端](../../../docs/reports/assets/walk-forward-phase-terminal.jpg)

- [官方一](../../evaluations/duck_walk_forward-phase_paired_s1044_20261109T194459/evaluation-reference-a/clip-step-0.mp4)
- [官方二](../../evaluations/duck_walk_forward-phase_paired_s1044_20261109T194459/evaluation-reference-b/clip-step-0.mp4)
- [相位候选](../../evaluations/duck_walk_forward-phase_paired_s1044_20261109T194459/evaluation-phase-yaw/clip-step-0.mp4)

首次 CPU 检查在快照的类奖励守卫处停下，积分为零。确认固定步行场景的类奖励 `upright` 不累积状态后，保留并恢复实际奖励管理器的累积缓冲，并核验类奖励配置指纹。补齐的 CPU 和 GPU 零步检查通过。运行从原 VS Code 的 Terminal 菜单启动，窗口和面板保持原位置及尺寸。 [首次检查记录](../common-walk-confirmation/forward-phase-cpu-snapshot-first-stop.json) · [CPU 准入](preflight.json) · [运行记录](coordinator.json)

```bash
cd ~/XGO-Duck/workspace/xgoduck_rl
XGO_PROJECT=/mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source "$XGO_PROJECT/scripts/setup/project_environment.sh"
# 原可见运行记录。已关闭的采样协议不能重复执行。
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/common_walk_forward_phase_screen.py" --freeze
bash "$XGO_PROJECT/scripts/training/training_workflow.sh" walk-forward-phase
# 下列命令只读取保存轨迹。
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/review_walk_forward_phase_response.py"
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/render_common_walk_forward_phase.py"
```
