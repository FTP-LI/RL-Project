# 后退自然抬脚

复查四个开发种子共 59 个自然迟启动场景。在首次连续四帧单脚支撑的起点前 160 毫秒、前 20 毫秒、起点和确认时，计算摆动脚碰撞网格最低点相对地面的距离。同批停滞场景按相同时间和摆动侧对齐。 [冻结方案](../../../configs/experiments/common_walk_backward_natural_clearance.json) · [逐场景净空](analysis.json)

| 开发种子 | 自然迟启动 | 起点净空中位数 | 60 毫秒后净空中位数 | 同时点停滞净空中位数 |
| --- | ---: | ---: | ---: | ---: |
| 1071 | 5 | 2.14 mm | 7.52 mm | −0.48 mm |
| 1072 | 12 | 1.19 mm | 6.53 mm | −0.40 mm |
| 1073 | 22 | 0.73 mm | 4.66 mm | −0.42 mm |
| 1074 | 20 | 1.08 mm | 5.65 mm | −0.41 mm |

单脚接触前的 140 毫秒，摆动脚最低点抬升中位数仅为 0.18–0.55 毫米。较大的净空在首次单脚接触后出现。机身高度从参考点到确认时的中位变化为 −0.66 至 +1.53 毫米，各批方向不一致。下一步用保存状态分解机身和腿部关节对鞋底轨迹的贡献。事件由原仿真接触标记对齐，支撑侧由事后轨迹确定。物理步与学习更新均为零。 [固定机身单腿试算](../common-walk-backward-swing-clearance/README.md) · [原支撑时序和录像](../common-walk-backward-start-pulse/README.md)

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- env PYTHONPATH=scripts/validation:scripts/training /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_walk_backward_natural_clearance.py
```
