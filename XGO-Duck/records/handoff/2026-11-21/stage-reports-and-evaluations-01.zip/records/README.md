# 证据入口

当前目标已恢复，最近两组训练已结束并完成核验。[本地观察入口](training-current.md)可在 VS Code 直接打开状态、曲线和完整视频，无需本机网页。[恢复前进度归档](reports/pause-archive-20261116-monitored/README.md)保留当时的状态与未完成事项。

原始安装在 `deployment/`，学习在 `experiments/`，固定推理评估在 `evaluations/`，性能诊断在 `profiling/` 与 `benchmarks/`，硬件准备在 `hardware/deployment-preparation/`，复算与文档核验在 `reports/`。

当前离线真机准备入口是 [`hardware/deployment-preparation/s19-readiness.md`](hardware/deployment-preparation/s19-readiness.md)。它只记录模型、接口、软件映射、标定模板和回退材料的核验；任何实体 ID、机械中心、方向、IMU 或使能状态都必须在现场记录后才可改为通过。

S1 证据分别位于 `reports/s1-inputs/`（来源与导出）、`reports/s1-evaluation/`（七指令评估）、`reports/s1-integration/`（观察与停止恢复）。后续证据按问题分组：

| 目录 | 用途 |
| --- | --- |
| `reports/s2-hip-repair/` | 已结束的髋姿态对照与目标越界诊断 |
| `reports/official-actor-bootstrap/`、`reports/official-adaptation/` | 官方网络初始化、有界适应及停止依据 |
| `reports/tracking-precision/`、`reports/reward-incentives/` | 速度奖励宽度对照及奖励分项复算 |
| `reports/standup-reference/`、`reports/lateral-recovery/` | 官方起身四姿态参照及实际侧卧覆盖 |
| `reports/random-recovery/` | 固定随机跌落的协议、进度与判定 |
| `reports/roll-reference/` | 滚翻判据与独立边界检查；实际参照评估待执行 |
| `reports/skill-interfaces/` | 模型/运行程序接口、纯状态机与任务物理配置审计；不表示切换通过 |
| [前进执行器反馈](reports/common-walk-actuator-yaw-feedback/README.md) · [复验](reports/common-walk-actuator-yaw-feedback-replication/README.md) · [留出](reports/common-walk-actuator-yaw-feedback-heldout/README.md) | 七指令共同接口，含冻结方案、逐场景评分和完整原片 |
| [右转支撑训练与前进偏航反馈](reports/common-walk-right-support-yaw-training/README.md) | 两组 PPO、分支评估、方向模型拟合、前进关键帧和七指令门槛 |
| [起身姿态分流](reports/getup-pose-routing/README.md) | 四姿态起身的开发、留出及仰卧缺口复算 |
| [后退启动诊断](reports/common-walk-backward-onset/README.md) | 两批固定模型开发场景、后退原片和未启动统计 |
| [起身奖励时钟](reports/getup-early-support-clock/README.md) | 仰卧锁存、接触传感器与重置核对，含完整原片 |
| [起身价值起点](reports/getup-early-support-value/README.md) | 共享价值网络、双目标复算、原始录像与运行页 |
| [起身 PPO 初态](reports/getup-early-support-ppo-zero/README.md) | 两组 CUDA 零步、显存、同初态与优化器核验 |
| [仰卧早期支撑训练](reports/getup-early-support-ppo-recovery/README.md) | 同起点 PPO 的改动、训练曲线、动作原片和停止依据 |
| [原生奖励读回](reports/getup-early-support-native-reward/README.md) | 新种子 CUDA 奖励边界、重置、完整原片和观察记录 |
| [起身独立评分](reports/getup-early-support-ppo-functional/README.md) | 三组同次释放、四姿态门槛、配对退化与 11 秒原片 |
| [后退双向侧移](reports/common-walk-backward-lateral-probe/README.md) | 双种子、四路同初态、位移衰减和原片 |
| [侧倒转仰卧回放](reports/getup-side-to-supine-replay/README.md) · [独立评分](reports/getup-side-to-supine-replay/evaluation/README.md) | 等量成功回放、训练、逐姿态评分和 11 秒原片 |
| [后退支撑转移](reports/common-walk-backward-actuator-support/README.md) | 同初态关节目标修正、逐场景启动评分和运行观察 |
| [滚翻连续切换](reports/continuous-roll-stand-walk/README.md) | 同场景站立、滚翻、站立和前进的冻结方案与观察 |
| [滚翻入口同初态对照](reports/continuous-roll-entry-isolation/README.md) | 三种目标处理的原评分、早停、完整与部分原片 |
| [投影入口连续试验](reports/continuous-roll-projected-entry/README.md) | 独立场景的站立、滚翻、站立和 20 秒前进 |
| [连续前进偏航对照](reports/continuous-forward-yaw-pair/README.md) | 共用首次前进状态、两档反馈、两段完整原片与资源采样 |
| [连续前进偏航复验](reports/continuous-forward-yaw-replication/README.md) | 新开发场景评分、31 秒完整原片及有界扰动准备 |
| [连续前进抗扰](reports/continuous-forward-lateral-push/README.md) | 三组同场景前进、两秒恢复与完整原片 |
| [右侧起身奖励时钟](reports/getup-right-upright-clock/README.md) | 原生接触、触发与重置、奖励量级、8 秒原片 |
| [右侧起身首批价值覆盖](reports/getup-right-upright-value/README.md) | 首批触发分组、拟合前停止与完整原片 |
| [右侧起身扩展价值覆盖](reports/getup-right-upright-value-coverage/README.md) | 3,072 场景、共享价值检查点与独立复算 |
| [仰卧转正配对试验](reports/getup-upright-recovery-pair/README.md) | 同释放双参照、腿部目标修正与原四姿态评分 |
| [仰卧左髋双向对照](reports/getup-supine-left-hip-pulse-trial/README.md) | 原生接触读回、同初态四路、运行观察和完整持稳 |
| [二次起身控制链](reports/getup-second-attempt-native/README.md) | 保存观测复演、CUDA 电机写入、延迟、供电和状态恢复 |
| [短程回撤同初态对照](reports/getup-second-attempt-trial/README.md) | 三路 11 秒评估、触发场景回放与接触复算 |
| [仰卧困难初态库](reports/getup-hard-start-bank/README.md) | 五个开发种子的原始跌落坐标、配对来源和复现规则 |
| [仰卧困难初态筛查](reports/getup-hard-start-screen/README.md) | 3,072 个环境、三组独立评分、算力记录和原片 |
| [归档起身权重核对](reports/getup-archived-policy-shortlist/analysis.json) | 两份导出策略、恢复点、共同接口和历史配对 |
| [归档起身策略对照](reports/getup-archived-policy-comparison/README.md) | 新场景四路同释放、零步诊断和运行观察 |
| [起身末层拟合](experiments/duck_getup_teacher_head_offline_s1160_20261110T175320/README.md) | 同输入动作标签、等预算求解、导出限位及可恢复检查点 |
| [末层候选评估](reports/getup-teacher-head-evaluation/s1162/README.md) | 新场景三路对照、逐姿态门槛与完整原片 |
| [仰卧锁存评估](reports/getup-teacher-head-evaluation/s1163-latch/README.md) | 三路评分、完整原片、失效复盘、纠正回放与原生梯度核验 |
| [起身纠正回放对照](reports/getup-latched-head-corrective-ppo/README.md) | 四姿态动作保持回放、匹配 CUDA 初态、训练过程与核验 |
| [右侧起身跨种子复盘](reports/getup-right-fallback-cross-seed/README.md) | 同权分支共同失败、时序差异和右侧专用策略来源 |
| [双姿态起身分流](reports/getup-dual-pose-route/README.md) | 同释放参照、原门槛评分、右侧原片及独立复验 |
| `reports/stage-media/` | 后续录像的来源、真实帧和标注 |

历史训练复盘在 `reports/training-review/`；工程整理在 `reports/project-organization/`。

核验时先读状态和输入哈希，再看指标、轨迹及媒体。`passed` 可能表示文件或计算核验正确，不表示步态通过。不要直接修改原始轨迹或删除恢复父模型；清理必须先列明用途、路径、哈希和引用。

