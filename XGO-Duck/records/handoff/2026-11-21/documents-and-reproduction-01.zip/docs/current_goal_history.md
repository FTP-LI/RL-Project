# 目标历史记录

本页保留整理前的完整原文，部分状态和下一步可能已过期；当前安排请看[当前目标](current_goal.md)。原文中的相对链接仍以 `docs/` 为起点。

---

# 当前目标与验收条件

更新日期 2026-11-14。当前优先完成九类动作的仿真验证、可审查的轻量训练和全流程留档，最终交付官方参照、自训模型、日志、视频、配置和哈希。真机操作后置。全流程见[开发与部署报告](reports/development_report.md)。

## 当前执行

训练和仿真继续暂停。当前整理目标入口，将阶段状态、模型、录像、恢复条件与剩余工作集中呈现，并保留已有详细记录。

训练和仿真继续暂停。零步入口已补充编译模型电机力限值读取及相关源码冻结；43 项入口假数据、8 项原守卫假环境和 3 项原入口源码检查通过，真实模型、观察器及 CUDA 零步仍未验证。 [电机力限值检查](../records/reports/force-limit-guard/README.md)

训练和仿真继续暂停。七组历史筛查的构造种子为 1176、重置种子为 1240；现有记录缺少完整随机数与执行器状态，33 项静态字段不含电机力限值。当前源码显示电压可能连带改变该限值，历史实际值未保存。 [初态与源码审计](../records/reports/matched-start-source-audit/README.md)

训练和仿真继续暂停。单因素参数守卫已接入独立零步入口；此前 34 项入口假数据检查和 6 项原守卫假环境检查及其源码保留，动态采样仍被拒绝。 [此前检查](../records/reports/roll-factor-zero-entry/README.md)

训练和仿真继续暂停。已核实 WSL 中没有 XGO-Duck 训练或仿真进程，并汇总已完成成绩、中断位置和暂停后的离线检查；原归档及补充快照通过核验。全阶段目标保留，后续训练须由用户明确恢复。 [暂停进度补充](../records/reports/progress-archive-20261114/supplement/README.md)

训练和仿真继续暂停。参数配置与精确摩擦校验的适配层已通过假环境测试，包括重置返回前检查、错误停止及绑定恢复；原守卫流程在假模型下复核。真实执行入口、模型映射、策略接口、观察器和 CUDA 零步仍未验证，不允许物理采样。 [参数与场景守卫适配](../records/reports/roll-factor-guard-adapter/README.md)

训练和仿真继续暂停。后续参数对照的精确摩擦校验已通过 CPU 验证：静态字段要求 33 项齐全，重置后要求 3 项齐全，仅允许指定几何的滑动摩擦变化。14 份保存配置与 32 项异常、绑定检查通过；真实几何名称映射和运行入口仍须另行验证。 [摩擦校验](../records/reports/roll-selective-friction-guard/README.md)

训练和仿真继续暂停。S20 七组保存的零步与采样起点在已记录的姿态、速度、观测及策略接口字段上相同；六个完整组的采样首条接触记录也与各自零步一致。独立核对了原比较器跳过的摩擦数组。完整随机状态、执行器内部状态和未来协议的配对初态仍未验证。 [初态复核](../records/reports/roll-s20-saved-startup-review/README.md)

暂停期间发现参数回调持有外部可变字典：创建回调后更改该字典，会改变实际应用的因素。已将回调参数固定为私有副本，并通过离线验证；发现记录和先前配置核验均保留，训练和仿真继续暂停。

训练和物理仿真继续暂停。后续滚翻参数对照的标称、低摩擦和高电压三个真实配置已通过 CPU 字段比较，S17 冻结的 52 个来源文件哈希一致；参数代码不接受错误单因素标签。本次未建立仿真场景或环境，PyTorch CUDA 未初始化。实际运行入口、配对初态和多臂停止仍需另行验证，恢复执行须由用户明确提出。 [参数配置核验](../records/reports/roll-factor-configuration/README.md)

暂停期间已完善归档保护：既有快照和核验记录保留，检查区分快照完整性、保留文件完整性与后续工程文件变化；重复创建不能覆盖原归档。此项仅检查保存文件，没有启动训练、仿真或真机操作。 [归档完整性检查](../records/reports/archive-integrity-followup/README.md)

本次维持训练与仿真暂停，整理截至 2026-11-14 的模型、实验、录像、环境和未完成事项。阶段归档以现有文件和来源哈希为依据，不覆盖历史证据；全部动作、性能优化与后续真机准备目标继续保留。恢复训练须由用户再次明确提出。 [暂停进度与归档](../records/reports/progress-archive-20261114/README.md)

训练和仿真维持用户要求的暂停。S20 六组原始轨迹已在 CPU 上复评分：进入前进后的偏航失败是多个参数臂的主要失分项；S20 的落地站立过渡为 25 步，S17 为 0 步，两者不能直接作为只改变物理参数的对照。三个低摩擦臂的 `early_stop` 是事后诊断，实际均采到 1,550 步；历史外层循环未落实评分后的安全停止。

独立停止判定已接入新的名义入口和收集器，通过保存轨迹、假环境及故障注入验证；当前暂停状态下入口在导入训练环境前拒绝运行。该入口只接受名义参数，运行入口的参数注入、多臂调用、观察入口和 CUDA 零步仍待验证，不能称为真实训练保护已通过。不新增物理步、学习更新或真机 IO。 [离线复核](../records/reports/roll-domain-parameter-random-s20/offline-review.md) · [入口验证](../records/reports/roll-domain-parameter-random-s20/guarded-entry.md) · [后续草案](../configs/experiments/roll_parameter_matched_review_draft.json)

吞吐与观察器配方已经冻结，S11 阶段验收矩阵已完成。S12 的保存数据机制审查和实际 CUDA 零步准入均已通过，S13 三组短评估也通过原动作门槛；S14 固定阈值筛查和接触转移审计均未形成选择性触发器。S14b 对 109 个因果特征做了留一环境审计；S15 已完成共同路线复核；S16 名义横向扰动三臂通过原门槛但未形成可迁移触发器；S17 官方 seed-1235 固定路线通过 119/128。S18 汇总的四组参数端点、三臂名义扰动和 S17 路线分别通过各自门槛；参数端点与 S17 的落地过渡不同，不能合并为统一抗扰通过。随机化训练收益与可迁移触发器仍未准入。S19 离线真机准备审计已完成：官方模型、策略接口、关节映射、标定记录模板和回退材料均可追溯；实体舵机 ID、机械中心、方向、IMU 和通信仍待现场核验，未做真机 IO。S20 已完成 6 个固定参数组合的评分，另一个臂在 1400/1550 控制步暂停；当前训练和仿真已停止，29 张部分帧、状态、日志及停止记录已保留，部分视频未封装完成且没有可恢复物理检查点。 [S18 汇总](../records/reports/robustness-evidence-s18.md) · [S19 准备审计](../records/hardware/deployment-preparation/s19-readiness.md) · [S20 停止记录](../records/reports/roll-domain-parameter-random-s20/stop-record.json) · [S20 媒体检查](../records/reports/roll-domain-parameter-random-s20/partial-media-audit.json)

本机训练吞吐与可观察性短测已完成并通过独立复核。官方行走同一父检查点、24 步 rollout、两遍反向规模测试中，1,024/2,048/4,096 环境分别约为 9.86–10.05k、16.08–16.30k、23.98–24.58k 转移/秒；4,096 档最高观测显存约 4.52 GiB（16 GiB 显卡的 28.3%），配置、checkpoint、telemetry、逐轮计时和 6 段原片哈希均通过。独立观察器短测中 D3D12 + 4 Hz 两遍约 18.35–18.38k 转移/秒，真实状态采样约 2.25–2.29 Hz，200 帧训练原片和 progress/telemetry 均保存；D3D12 + 15 Hz 没有超过 4 Hz，默认 llvmpipe 不是训练观察方案。当前正式训练建议采用行走 4,096 环境、观察器 D3D12 + 4 Hz，起身继续采用已验收的 3,072 环境任务配方。 [吞吐与观察报告](../records/reports/throughput-selection/README.md) · [规模复核](../records/benchmarks/scale_20261101T154057_s42/verification.json) · [观察器复核](../records/benchmarks/observer_20261101T201418_s42/verification.json)

seed-1212 的连续 router 已按停止规则关闭：746 个控制步、95,488 条转移后，滚翻窗口结束时没有世界完成 `roll → stand`。独立准备度筛查确认第 50 步 128/128 个环境达到连续站立门槛；seed-1214 边界筛查又确认 128/128 个环境都进入 `ROLL`，所以故障不在初始站立或状态机入口。

seed-1215 的同 seed 配对消融只改变跨模型 bridge。保留 25 步 bridge 时头部穿透超限 127/128、末尾完整状态 1/128；关闭 bridge 时头部穿透超限 0/128、末尾完整状态 128/128。该结果把 bridge 作为当前路由的主要故障源。随后 seed-1216 关闭 bridge 完整运行 50 步站立加 450 步滚翻，121/128 环境达到滚翻→落地 latch，超过 116/128 开发门槛；头部穿透最大 3.25 mm、关节限位超限均为 0。

seed-1217 的接力筛查确认关闭 bridge 后 116/128 个环境完成滚翻落地并进入前进相位。seed-1218 已完成完整的 50 步站立、450 步滚翻、50 步落地站立和 1,000 步前进单回合：滚翻入口 128/128，落地 123/128，前进入口 123/128，但原有 20 秒前进判据为 111/128，低于 116/128，完整路线暂不晋级。失败分为 5 个未进入前进和 12 个仅偏航误差超限；速度、线性误差、接触滑移、头部穿透和关节范围均未成为主要失分项。 [全序列分析](../records/reports/continuous-roll-full-sequence-s1218/analysis.json)

route-aware pilot 已完成严格 5 次更新：4096 环境共 491,520 个采样步，1 次 critic warmup 加 4 次 actor 更新，末次采样约 23,232 steps/s；均值奖励由 1.63 增至 18.60，未触发 NaN、跌倒或资源停止线。官方 actor 导入误差为 2.98×10⁻⁷，课程写回 qpos/qvel 误差为 0；导出 `policy.onnx` 和 `model_4.pt` 已保存。seed 1225 同 seed 对照已完成：官方父模型完整前进 125/128、pilot 完整前进 28/128；pilot 候选拒绝晋级，停止继续学习。恢复探针首轮门禁索引问题已修正，随后两次受保护更新均通过（第 2 次均值差 `6.46e-4`、最大差 `1.78e-3`）。seed 1228 开发种子对照中 guarded probe 124/128、官方父模型 123/128，偏航均为 0。seed 1229 独立对照中候选和官方父模型均通过原路线门槛，候选 119/128、官方 121/128。冻结协议声明的 holdout seed 1227 也已完成：候选 124/128、官方 121/128，双方偏航、头部穿透和关节限位均通过。三组种子候选总成功数 367/384、官方 365/384，但逐种子差异为 +3、+1、−2，收益不稳定；候选权重、录像和轨迹保留为开发证据，不晋级、不沿该权重追加训练。 [1227 留出对照](../records/reports/route-aware-probe-parent-compare-s1227/README.md) · [1229 对照](../records/reports/route-aware-probe-parent-compare-s1229/README.md) · [1228 对照](../records/reports/route-aware-probe-parent-compare-s1228/README.md) · [动作漂移分析](../records/reports/route-aware-pilot-parent-compare-s1225/actor-drift.json) · [历史归一化审计](../records/reports/route-aware-pilot-parent-compare-s1225/history-normalization-audit.json) · [冻结探针](../configs/experiments/route_aware_actor_drift_probe_s1226.json) · [训练清单](../artifacts/duck_walk_route-aware-entry_candidate_s1224_20261114T045600/manifest.json)

滚翻六组同初态对照、单因素端点和 seed 1190 交叉复验均已独立核验：标称 123/128、高摩擦 125/128、低电压 124/128、高摩擦低电压 125/128，连续前进均通过 116/128 门槛。参数随机化起身训练的 CPU 配置、GPU 零步和 nominal/candidate 各 8 次更新已完成。随后对两个末次 ONNX 做了统一回归：起身 prone/supine 为 32/32，侧躺为 19/32；滚翻均为 0/32；七指令均完整运行 20 秒，但只有 stand 的保存指标达到门槛。结果说明短训练导出仍是起身局部策略，不能兼任滚翻和行走。 [参数回归总表](../records/reports/parameter-randomized-regression/README.md) · [多技能前置计划](../records/reports/multi-skill-training/README.md)

多技能前置已完成 CPU 模型接口和 GPU reset-only 零步；起身与行走继续使用已验收交付。滚翻 airborne-support 候选已关闭：官方 108/128、控制组 112/128、候选 111/128，未达到晋级门槛。seed-1212 router 的入口与初始站立已被独立排除；seed-1215 配对消融确认跨模型 bridge 导致头部穿透，seed-1216 关闭 bridge 后完整滚翻边界达到 121/128 latch。当前只复盘 7 个 supported rotation 不足的失败环境。 [滚翻失败分析](../records/reports/roll-airborne-support/analysis.json) · [bridge 消融](../records/reports/continuous-roll-bridge-ablation-s1215/analysis.json) · [失败复盘](../records/reports/continuous-roll-bridge-disabled-boundary-s1216/failure-review.json)

历史官方和既有自训权重仍保留各自的单项验收记录；本轮参数随机化导出没有通过统一多技能回归，因此没有新增“最终模型”。交付目录继续保留官方权重、已验收动作权重和本轮候选/control checkpoint，所有失败门槛与视频均可回放。 [七指令历史评分](../records/reports/continuous-routed-turn-feedback-holdout-zero-recovery/README.md) · [回归总表](../records/reports/parameter-randomized-regression/README.md) · [交付清单](../artifacts/delivery/routed-seven-command-simulation.json)

## 后续顺序

0. 以[阶段验收矩阵](../records/reports/stage-acceptance-matrix/README.md)、[S18 抗扰汇总](../records/reports/robustness-evidence-s18.md)、[S19 离线真机准备审计](../records/hardware/deployment-preparation/s19-readiness.md)和[S20 离线复核](../records/reports/roll-domain-parameter-random-s20/offline-review.md)作为当前入口。暂停期间继续准备参数注入和多臂检查；收到明确恢复指令后，先冻结与 S17 一致的 0 步落地过渡、同种子标称对照、因素标记及经验证的停止规则，再核验观察入口和 CUDA 零步，不直接重启旧 S20。中断的 `high-mid` 不可从 1400 步续跑，未完成的两臂不视为通过。
1. 保留端点、交叉复验和参数随机化短训练的全部证据；不把 8 次更新的 candidate 直接晋级。
2. 保留 bridge 消融、seed-1216 边界、seed-1217 接力和 seed-1218 全序列的完整轨迹、失败清单和原片。
3. 从 seed 1220–1222 的真实轨迹提取前进入口状态和前 50 控制步，核验状态字段、模型输入和重置回读。
4. route-aware 五次更新短测、seed 1225 同 seed 对照、动作历史/归一化审计、低学习率输出漂移探针和 holdout seed 1227 已完成；pilot 未通过，探针两次更新均通过漂移门禁。seed 1227、1228、1229 的候选/父模型路线均通过原门槛，但逐种子收益不稳定，旧学习线已关闭。新的教师约束机制已完成 CPU admission、GPU 零步和 3 次更新短训：1 次 critic warmup、2 次教师锚点 actor 步骤，输出漂移门禁通过，导出复核通过。seed 1231 开发对照候选 121/128、官方 122/128；seed 1232 留出候选 122/128、官方 121/128。两组种子合计均为 243/256，逐种子差异相反，教师约束不晋级、不追加训练；候选 ONNX 和检查点保留为开发证据。
5. 仿真交付整理已完成：官方参照作为后续硬件准备基线，教师约束自训权重及所有路线、七指令、S16 扰动和 S17 路由证据均已保留，候选明确未晋级；S19 已把离线真机核验表、策略接口、标定模板、回退路径和现场待办固化。参数随机化和统一扰动门槛完成后，再进入真机只读标定；现场操作必须逐舵机记录并保持 Inference only。 [模型选择](../artifacts/delivery/simulation-model-selection.json) · [S19 准备审计](../records/hardware/deployment-preparation/s19-readiness.md) · [迭代记录](../artifacts/delivery/iteration_record.md) · [标定手册](runbooks/hardware_commissioning.md)

## 近期证据

困难初态、匹配初态、原始跌落三组分别持稳 959/1,024、945/1,024、943/1,024，未复现更高难度，关闭该课程。 [困难初态筛查](../records/reports/getup-hard-start-screen/README.md)

同回合二次起身的触发识别 24/27 个仰卧失败，675 个原成功仰卧场景均未触发。缩短颈部目标行程后，24/24 条离线目标到达并通过 CUDA 控制链检查。实际对照中，38 个共同失败场景均未完成二次起身，原截止前没有形成安静仰卧，已关闭该方案。 [同初态对照和复算](../records/reports/getup-second-attempt-trial/README.md)

右脚承重时序未达门槛。三路失败组分别有 91、21、24 个完整窗口，能同时定位右脚承重与躯干停滞的只有 1、1、0 个，零例满足提前 20 毫秒。关闭这一控制候选，改用四个开发种子的原始策略观测筛查已卡住的仰卧场景，评估同一回合内第二次起身能否留出足够时间。 [时序复算](../records/reports/getup-supine-left-hip-pulse-trial/floor-transfer-order.json) · [冻结的触发筛查](../configs/experiments/getup_supine_second_attempt_screen.json)

左髋四路对照已结案。实际仰卧两次原策略为 647/687、645/687，沿误差和反向为 644/687、646/687。两个方向均未达到原门槛。三路原策略中，触发后 160 毫秒的右脚冲量占比中位数在成功组均为 0%，在失败组为 19.0%–20.8%。下一步冻结右脚承重与躯干停滞的时序复算，再决定是否开展新的支撑顺序对照。 [配对评分、运行观察和原片](../records/reports/getup-supine-left-hip-pulse-trial/README.md) · [载荷筛查结果](../records/reports/getup-supine-left-hip-pulse-trial/floor-transfer-screen.json)

仰卧受力采集完成 3,072 个 11 秒首回合。首次双脚承重时仍有头腿承力，失败组为 39/171、成功组为 24/2,584。左脚单支撑窗口覆盖 91 个失败和 123 个成功场景。双向脉冲在真实 CUDA 零步和 768 环境物理对照后已关闭。 [采集结果](../records/reports/getup-supine-left-hip-load-capture/README.md) · [组件与控制器核验](../records/reports/getup-supine-left-hip-load-capture/pulse-component/README.md)

三批仰卧支撑回读覆盖 523 个实际仰卧场景。第 2.60–3.00 秒，失败组左髋俯仰的跟踪差距中位数为 9.30°–17.80°，成功组为 3.59°–4.19°，四个关节在所查窗口均无超过 0.001 rad 的请求投影差。下一步核对实际力矩与接触受力，草案需通过零步、时点和可视化检查后才执行。 [回读结果](../records/reports/getup-supine-support-target-readback/analysis.json) · [采集草案](../configs/experiments/getup_supine_left_hip_load_capture_draft.json)

四姿态起身的七帧 IMU 筛查已结案。整种子交叉验证只提前覆盖 3/5、0/7 个失败，低于 75% 门槛，成功场景误触发为 5/175、2/159。第三批和物理试验均未启动。下一步核对仰卧转正后实际头腿碰撞、双足支撑和关节目标响应，再决定可测的干预。 [筛查和复现](../records/reports/getup-supine-causal-imu-screen/README.md)

最终留出 2153 完成三路 634,368 条转移，方向反馈组七项各 32/32，前进偏航较两次参考各降低 0.00603、0.00524 rad/s，原七指令与配对门槛通过。首次预检在读取协议时退出，修复后通过 CUDA 零步，正式留出执行一次。现整理通过验收的行走权重与可复现配置，随后推进四姿态起身。 [留出评分](../records/reports/common-walk-right-support-yaw-training/yaw-direction-holdout/analysis.json) · [进度与原片](../records/walk-forward-yaw-direction-holdout-live.html) · [首次预检日志](../records/reports/common-walk-right-support-yaw-training/yaw-direction-fresh/holdout-native-zero.log)

预留开发种子 1153 的三路共完成 634,368 条转移，全部七项均为 32/32。方向反馈的平均绝对偏航较两次参考各下降 0.00720、0.00618 rad/s，完整门槛通过。首次评分缺少首步摘要状态，修复后以同一保存轨迹复算，新增物理步为零。两批开发完成，固定方案进入种子 2153 最终留出准备。 [复验评分](../records/reports/common-walk-right-support-yaw-training/yaw-direction-fresh/analysis.json) · [进度与原片](../records/walk-forward-yaw-direction-fresh-live.html)

连续方向反馈完成种子 1152 的 20 秒七指令评估，三路共 634,368 条转移。候选前进、后退、右转各 32/32，左转与两条参照均为 31/32，其他动作各 32/32。两路配对的前进平均绝对偏航各下降 0.00577、0.00555 rad/s，通过完整开发门槛。先做预留种子 1153 的 CUDA 零步检查，再按原全程门槛复验。 [完整评分](../records/reports/common-walk-right-support-yaw-training/yaw-direction-development/analysis.json) · [进度与原片](../records/walk-forward-yaw-direction-development-live.html) · [复验草案](../configs/experiments/common_walk_forward_yaw_direction_fresh_draft.json)

连续方向反馈完成 96,768 条转移。首步左侧 6 个场景的平均绝对偏航减少 0.01224 rad/s，右侧 8 个场景减少 0.00577 rad/s。随后的 2.32 秒，比两次原反馈各改善 0.00696、0.00706 rad/s，速度最多下降 0.00020 m/s。三组均无提前跌倒或前进关节超限，准入原七指令 20 秒评估。 [独立结果](../records/reports/common-walk-right-support-yaw-training/yaw-direction-pilot/analysis.json) · [进度和原片](../records/walk-forward-yaw-direction-pilot-live.html) · [完整评估草案](../configs/experiments/common_walk_forward_yaw_direction_development_draft.json)

第 85 步的四路脉冲对照完成 33,152 条转移。10 个左支撑和 9 个右支撑均通过即时响应方向核验。右支撑的负脉冲降低偏航，左支撑按预设固定极性加正脉冲反而增大偏航。关闭固定极性方案，下一步用陀螺仪和短时预测核对逐场景偏航方向。 [独立复算](../records/reports/common-walk-right-support-yaw-training/stance-response/analysis.json) · [运行观察](../records/walk-forward-stance-response-live.html)

旧规则与幅度预测均未达门槛。保持相同四帧、模型大小与场景划分，直接拟合方向后，四批开发数据的方向准确率达到 96.2%–97.4%，覆盖 73.4%–77.6%。保存脉冲的逐场景重选通过两侧门槛，准备同初态的连续反馈短试验。 [方向拟合](../records/reports/common-walk-right-support-yaw-training/forward-yaw-direction-fit-cpu.json) · [试验草案](../configs/experiments/common_walk_forward_yaw_direction_pilot_draft.json)

前进反馈从 0.12 提到 0.15 rad/s 的对照已结案。种子 1152 三组共 672,000 条转移。0.15 组右转 32/32、前进 31/32，平均偏航误差较同权重 0.12 组下降 0.00151 rad/s，低于 0.002 的继续门槛。场景 63 仍超限，新种子 1153 未启动。下一步从保存轨迹核对持续漂移、左右支撑时段和修正限幅。 [独立结果](../records/reports/common-walk-right-support-yaw-training/forward-margin/known/analysis.json) · [运行观察](../records/walk-right-support-forward-margin-live.html)

六组保存轨迹显示，场景 36、63 的绝对偏航误差有 94%–97% 出现在单脚支撑期间，左右支撑的平均偏航方向相反。仅用关节与 IMU 的支撑侧识别已通过开发种子 1142、1152 的 127,872 条观测核验，左右精确率至少为 99.99%，召回约 82%–86%。下一步先检查分相位反馈方向和关节投影，再决定是否启动有界物理对照。 [时序复算](../records/reports/common-walk-right-support-yaw-training/forward-yaw-phase-readback.json) · [识别结果](../records/reports/common-walk-right-support-yaw-training/forward-stance-observation-cpu.json) · [反馈草案](../configs/experiments/common_walk_forward_stance_feedback_draft.json)

父策略完整复测已读回。与同种子旧评估的模型、重置、首步输入及关节目标一致，前进成功数由 32/32 变为 30/32，场景 36、63 均仅偏航超限。 [完整回合复算](../records/reports/common-walk-right-support-yaw-training/forward-margin/known/parent-repeat-readback.json)

种子 1152 的四路短对照已完成 89,600 条转移，零学习。一次真实重置后，四路恢复同一份 302 项物理状态。两次父策略在首个控制步的第 2 个子步已出现物理差异。两秒前进平均绝对偏航误差的场景间最大配对差，父策略重复为 0.02654 rad/s，只计算与实际使用候选之间为 0.02684 rad/s。短窗口尚不足以定位 20 秒结果的原因。现用保存输入复算已有连续场景证据的 0.15 rad/s 前进反馈上限。 [短对照独立复算](../records/reports/common-walk-right-support-yaw-training/forward-repeatability/analysis.json) · [进度、曲线和原片](../records/walk-right-support-forward-repeatability-live.html)

右转支撑奖励两组各完成 14 次更新和 1,032,192 条转移。六组七指令共 1,344,000 条评估转移。种子 1141 的右转为父策略 30/32、原奖励 31/32、支撑奖励 32/32。种子 1152 为 31/32、32/32、32/32，两组训练的前进均由父策略的 32/32 降到 31/32，均未晋级。复算确认两例的首步观测、动作和关节目标一致，状态差异先于第 2 步动作差异。下一步做有界的固定策略重复，核对积分波动。 [训练曲线与原片](../records/walk-right-support-paired-ppo-live.html) · [六组评估](../records/reports/common-walk-right-support-yaw-training/README.md) · [短对照草案](../configs/experiments/common_walk_right_support_forward_retention_draft.json)

右转启动 PPO 对照已结案。两批六组完成 1,344,000 条 CUDA 评估转移，原七指令经独立复算。旧种子三组均为 30/32，新种子均为 32/32。两组训练没有挽回旧种子的共同失败，当前没有模型进入独立确认。 [逐项成绩和回放](../records/reports/common-walk-right-startup-seven-command/README.md)

三批父策略的保存轨迹中，0.5–1.5 秒的陀螺仪平均角速度绝对值不超过 0.05 rad/s，识别两例已知失败，94 个成功场景均未触发。随后对比父策略、只计算官方动作、实际切换三组。完成 672,000 条 CUDA 转移，实际切换两例，均未挽回。三组右转同为 30/32，其余六指令各 32/32。关闭本路线，从保存轨迹核对支撑与转速。 [早期观测](../records/reports/common-walk-right-startup-seven-command/zero-step-recovery/early-gyro-review.json) · [独立评分](../records/reports/common-walk-early-official-right/zero-physics-recovery/analysis.json)

首次 CUDA 启动在动作缓冲区写入时退出，完成物理步为零。独立恢复入口保持原模型、分组和预算，三组均通过实际缓冲区检查后正常完成。 [对照记录](../records/reports/common-walk-early-official-right/README.md) · [三组运行观察](../records/walk-early-official-right-recovery-live.html)

右转负重转移复算已完成。三批 94 个成功场景都在 1.5 秒内形成持续单脚支撑，首次支撑脚为右脚 81 次、左脚 13 次。两例失败在 0.5–1.5 秒内保持双脚支撑，机身横向移动约 3.35、3.58 mm，低于各批成功场景下四分位数的最小值 9.86 mm。本轮从成功起步轨迹提取两侧髋、膝和踝的变化，核对摆动脚抬高、向支撑侧移重和实际限幅。满足检查后，用原条件做短时物理对照。 [移重复算](../records/reports/common-walk-early-official-right/zero-physics-recovery/support-transfer-screen.json) · [短对照草案](../configs/experiments/common_walk_right_support_transfer_draft.json)

右转支撑短对照已结案。右侧目标通过 CPU 核验，左侧目标与第三批关节方向不一致。右侧 CUDA 对照完成 134,400 条转移。场景 13 三条分支均未形成持续右脚支撑。场景 198 的试验组在 2.60 秒达成，未修正参照在 2.58 秒也达到。保持原完整七指令门槛，先复算持续支撑与转速能否共同提供启动奖励信号。 [短对照评分](../records/reports/common-walk-right-support-transfer/analysis.json)

持续单脚支撑后的转速条件覆盖三批 94/94 个成功场景。两遍原生接触补采各用 3,072 环境，到 3 秒分别有 29、30 个真实事件。一次性奖励定为 0.07，实际 CUDA 奖励接线验证 26 个事件，终止步奖励增量为零。共享价值入口首次在启动语句退出，物理和梯度更新均为零，随后以相同种子和预算恢复。 [采样与复现](../records/reports/common-walk-right-support-yaw-probe/README.md) · [接线与价值拟合](../records/reports/common-walk-right-support-yaw-training/README.md)

右转腿部修正已完成 1,164,800 条 CUDA 转移和独立复算。旧种子三条分支均为 30/32，两例共同失败均实际修正但未挽回。新种子三条分支均为 32/32，未触发右转修正。该方案关闭。七指令原判据及后续起身、滚翻、同场景切换和扰动验收继续有效。 [评分与录像](../records/reports/common-walk-right-leg-recovery/README.md) · [运行观察](../records/walk-right-leg-recovery-live.html)

右转启动训练已核对共同起点，归档 1,024 条稳定右转输入。候选只增加前 4 秒右转欠速惩罚，保留全程跟踪目标与其他六条指令。两个训练组须共享策略起点、价值网络和样本预算。 [共同起点与样本](../records/reports/common-walk-right-startup-ppo/README.md)

原生右转两遍 CUDA 短测已核验。共 1,474,560 条转移，3,072 环境实测净吞吐分别为 22,694 和 22,723 转移/秒，最高显存 12,167 MiB。提前终止和超时均使用重置前奖励，录像和逐步回报通过独立读回。 [冻结方案](../configs/experiments/common_walk_right_startup_probe.json) · [第一遍观察](../records/walk-right-startup-measure-a-live.html) · [第二遍观察](../records/walk-right-startup-measure-b-live.html)

短测复算分别识别 68、67 个迟启动场景，重合 51 个。按原偏航奖励在迟启动时的尺度，候选先用 0.25 欠速系数。下一步冻结完整首回合的采集与共享价值拟合，在独立开发环境核对预测误差。 [奖励复算](../records/reports/common-walk-right-startup-ppo/probe-reward-signal.json) · [共享价值草案](../configs/experiments/common_walk_right_startup_shared_value_draft.json)

共享价值已通过独立验收。3,072 个完整首回合、100 次价值更新，768 个独立验证环境的解释方差为 0.836、归一化均方误差为 0.00728。策略权重逐位一致。进入等样本对照，每组 14 次更新，先在首个真实 24 步批次核验梯度和显存。 [价值核验](../records/reports/common-walk-right-startup-ppo/shared-value-analysis.json) · [运行观察](../records/walk-right-startup-shared-value-live.html) · [策略对照草案](../configs/experiments/common_walk_right_startup_paired_ppo_draft.json)

右转策略对照已完成。两组各 14 次更新和 1,032,192 条转移，欠速项实际影响 227,451 条转移。第 7、14 次检查点和终点 ONNX 已独立读回。 [对照核验](../records/reports/common-walk-right-startup-ppo/paired-ppo-analysis.json) · [原奖励组观察](../records/walk-right-startup-ppo-control-live.html) · [欠速组观察](../records/walk-right-startup-ppo-candidate-live.html)

两组训练导出已通过右转路由的保存输入检查。每组 960 条非右转输出与原路由逐位一致，160 条右转输入与 ONNX 独立复算一致。下一步在已知种子与新种子上，按原七指令和安全门槛评估父策略、原奖励组和欠速组。 [路由核验](../records/reports/common-walk-right-startup-ppo/trained-right-route-components.json) · [七指令评估草案](../configs/experiments/common_walk_right_startup_seven_command_draft.json)

七指令评估的首个入口因启动语句错误在零物理步退出，原记录保留。修复后按同一模型、分组和预算完成六组，核对实际路由、首步输入、原片和所有场景成绩。 [恢复方案](../configs/experiments/common_walk_right_startup_seven_command_recovery.json) · [六组运行观察](../records/walk-right-startup-seven-command-recovery-live.html)

同进程参考重复完成 67,200 条转移。恢复边界与首个物理子步输入逐位相同，积分后出现差异。32 个右转场景的一秒平均观测角速度最大相差 0.00459 rad/s，低角速度分类相同。该结果用于后续分支对照。 [独立读回与回放](../records/reports/common-walk-shared-prefix-repeat/README.md)

右转启动对照完成四组，共 896,000 条转移。旧种子的两组均为 30/32，新种子均为 32/32，未挽回失败。两批首步动作与目标相同，物理状态从第 1 步开始分歧，未满足配对要求。新种子的一例额外触发在修正前就已出现输入差异。关闭本次修正。 [评分与录像](../records/reports/common-walk-routed-right-onset/README.md) · [首步分歧](../records/reports/common-walk-routed-right-onset/pairing-diagnosis.json)

种子 1141、1142 的六组动态对照已完成。按指令选模型的前进速度达到官方水平，两批后退均为 32/32。右转为 30/32、32/32，首批低于门槛。六组 Windows 观察均通过。CUDA 重放证实整批和分批有首步数值差异，后续固定批次形状。同场景切换待七指令通过。 [评分与录像](../records/reports/common-walk-forward-routing/README.md) · [右转对照图](../records/reports/common-walk-forward-routing/right-turn-keyframes.jpg)

后退 PPO 的六组七指令评估已完成独立动作评分，共 1,344,000 条实际转移。种子 1139 三组后退均为 32/32，种子 1140 两组自训均从官方 30/32 提高到 32/32。两组前进速度在两批均损失约 0.014–0.016 m/s，超过 0.01 m/s 容差，两组均未晋级。首组 Windows 观察少一次快照，轨迹和原片另行核验。 [结果与原片](../records/reports/common-walk-backward-paired-eval/README.md) · [运行观察](../records/walk-backward-paired-eval-live.html)

后退等样本 PPO 两组各 42 次更新和 3,096,576 条转移，候选实际加权 5,800 条停滞样本。两组检查点和 ONNX 已独立回读。末批价值损失异常和退出码缺口均有记录。 [对照](../records/experiments/duck_walk_backward-focus-ppo_control_s1138_20261110T092909/README.md) · [候选](../records/experiments/duck_walk_backward-focus-ppo_candidate_s1138_20261110T092909/README.md)

共享价值从 3,072 个环境的完整首回合拟合，100 次价值更新后的整体验证解释方差为 0.830，归一化均方误差为 0.00757。 [共享价值](../records/experiments/duck_walk_shared-value_reference_s1137_20261110T092228/README.md)

后退并行细测已选定 3,072 环境，两遍净吞吐为 26,657 和 26,358 转移/秒。该档 20 个 PPO 小批量的前向、反向和价值回报均已核验，峰值显存 12,476 MiB，距 85% 上限约 1,450 MiB。下一阶段拟合两路共用的价值起点，按完整首回合核验回报，并在独立环境分组检查拟合。两路学习继续采用相同父模型与样本预算。 [细测与原片](../records/benchmarks/duck_walk_native-scale_reference_s1135_20261110T090325/README.md) · [PPO 核验](../records/evaluations/duck_walk_ppo-headroom_reference_s1136_20261110T091415/README.md) · [价值拟合方案](../configs/experiments/common_walk_backward_shared_value_draft.json)

首轮规模对照中，2,048 环境两遍达到 20,885 和 21,028 转移/秒，分别比 1,024 档高 68% 和 61%。4,096 档因显存超限在零物理步停止。配对训练保留等样本、同父模型及原七指令门槛。 [两遍结果与原片](../records/benchmarks/duck_walk_native-scale_reference_s1134_20261110T085345/README.md)

原生采样已通过。1,024 个 CUDA 环境完成 393,216 条转移，真实自动重置后的动作历史与末步价值目标符合预期，首档净吞吐为 13,279 条转移/秒。 [原生采样与核验](../records/reports/common-walk-backward-online-focus/README.md)

完整状态采集已完成。896 环境筛出 71 个场景，其中 19 个在两路中都持续停滞。磁盘恢复的 309 项状态哈希一致，首帧动作相同，首步物理状态超过原门槛，关闭恢复路线的学习准入。原生重置在线方案已完成 CPU 与 CUDA 轨迹复算，候选在控制步 101–300 对 14,200 条停滞样本加权。下一步核对实际环境的采样接口、价值目标及并行净吞吐，再启动等样本训练。 [采集结果](../records/reports/common-walk-backward-stall-capture/README.md) · [在线加权复算](../records/reports/common-walk-backward-online-focus/README.md)

开发种子 1129 的两组固定策略已完成 76,800 条转移。63 个指定槽位中，困难初态比普通重置多 3 个停滞，低于 4 个的门槛。静态初态路线已关闭。前两秒筛选在十批开发轨迹中选出 163 个场景，63 个到第 6 秒仍近静止。 [初态复验](../records/reports/common-walk-backward-start-enrichment/README.md) · [轨迹筛选](../records/reports/common-walk-backward-stall-prefix/README.md)

63 个困难初态已通过 CPU 和 CUDA 的整批与部分重置核验。未选环境的物理状态和原始动作历史逐位保留，CUDA 首帧输出与官方模型最大差 2.03×10⁻⁷。另外六种指令各有 512 条已核验的参考动作，供两组学习共同使用。 [重置与保留样本](../records/reports/common-walk-backward-start-curriculum/README.md)

63 个初态的关节姿态相同，速度均为零，差别集中在平面位置与偏航。下一步用原策略和新随机流对照两种重置，先验证停滞频率能否增加，再决定是否采用初态课程。首批至少多出 4 个近静止场景且没有候选独有的提前结束，才进入新种子复验。 [复验草案](../configs/experiments/common_walk_backward_start_enrichment_draft.json)

开发种子 1111 的 224 个后退受力场景已完成。15 个自然迟启动场景中仅 5 个提前达到承重门槛，低于 50% 的复验要求，关闭该候选。随后复算十批开发档案的 2,048 个原策略场景，索引出 63 个不同的困难初态，超过覆盖门槛。 [受力核验与原片](../records/reports/common-walk-backward-load-clock/README.md) · [困难初态索引](../records/reports/common-walk-backward-start-curriculum/initial-cases.json)

四批后退自然启动的时序已复算。首次持续单脚支撑前，50%–80% 的启动场景达到质心侧移或侧倾门槛，325 个对齐停滞窗口均未达到。机身变化早于实际膝动作的比例均未过门槛。停滞窗口中有 283 个膝目标变化达标，实际膝角变化达标只有 48 个。关闭固定顺序方案。 [时序方案](../configs/experiments/common_walk_backward_natural_timing.json) · [复算结果](../records/reports/common-walk-backward-natural-timing/README.md)

前进阶段的左右横向扰动已通过开发对照。无扰动、左推和右推分别有 125/128、124/128、125/128 个场景同时通过原全程与两秒恢复。左推有一个场景全段偏航略超限，原始轨迹保留。滚翻接站立与前进的独立复验为 124/128。 [抗扰结果与原片](../records/reports/continuous-forward-lateral-push/README.md) · [独立复验](../records/reports/continuous-forward-yaw-replication/README.md)

四姿态起身方面，右侧奖励已通过 CUDA 接触、释放和计时核验。首批 1,024 场景因训练触发仅 6 个而在拟合前停止。独立扩展的 3,072 场景通过共享价值准入，完成 50 次价值更新，策略权重保持原值。后退、起身接力、全指令切换、其余扰动与最终交付仍保留原验收。 [奖励时钟](../records/reports/getup-right-upright-clock/README.md) · [首批停止记录](../records/reports/getup-right-upright-value/README.md) · [价值准入](../records/reports/getup-right-upright-value-coverage/README.md)

右侧奖励对照已结束。两组各以 3,072 场景完成 17 次更新和 1,253,376 条转移，保存点、导出与原片均已核验。新种子 1102 的同次释放评价为父模型 311/320、对照 316/320、候选 308/320。候选比对照少通过 1 个实际右侧和 6 个实际仰卧场景。三组指定仰卧都未过线。两例共同失败在释放后约 0.58 秒已到 30°以内，但末段一直高于 33°并持续头腿接触。下一阶段先用独立开发档案检验支撑丢失和重新倾斜的先后，再冻结干预和准入标准。 [训练、独立评分和原片](../records/reports/getup-right-upright-ppo/README.md) · [仰卧复盘](../records/reports/getup-right-upright-ppo/evaluation/requested-supine-review.json)

开发种子 1084、1087、1102 的同一父模型共有 523 个实际仰卧场景。回倾和脚离地均未为 18 个失败提供 60 毫秒提前量。第 2.44 秒的 40 毫秒转正幅度规则在父模型的第三批覆盖 5/6 个失败，但原奖励对照用无噪声状态只覆盖 1/3；实际观测覆盖 2/3，误触发 19/174。关闭该规则，保留四姿态起身缺口。 [时序复算](../records/reports/getup-supine-support-timing/README.md) · [早期筛查](../records/reports/getup-supine-early-geometry/README.md) · [实际观测读回](../records/reports/getup-supine-early-signal-readback/analysis.json)

共同接口后退启动的净空分解已完成。59 个自然启动和 325 个对齐停滞窗口均重构原净空变化。四批离地前向支撑侧的侧倾中位数为 1.27–2.92°，贡献 0.70–1.35 毫米；单脚支撑后的 60 毫秒，摆动膝贡献 2.61–3.91 毫米。1° 双腿目标在 13 个停滞姿态的左右方向均通过 CPU 几何门槛。 [分解数据](../records/reports/common-walk-backward-clearance-decomposition/README.md) · [方向核验](../records/reports/common-walk-backward-support-axis/README.md) · [双腿目标复算](../records/reports/common-walk-backward-roll-target/README.md)

后退侧倾首批动态对照已完成。开发种子 1103 共 224 场景、四路同初态、201,600 条转移。左右方案均未挽回 5 个共同停滞场景，右侧另使 1 个原启动场景变为停滞。修正保持结束时，两个方向的实际侧倾中位增量分别只有 0.070°、0.040°，共同停滞场景在四个检查时点均未出现预期的单脚支撑。本轮停止，1104 未使用。下一步用自然启动轨迹对齐脚底接触、机身侧移、实际关节目标和摆动膝，先确定可观测的启动时序，再决定是否值得做小规模对照。 [冻结动态协议](../configs/experiments/common_walk_backward_roll_pair.json) · [核验与原片](../records/reports/common-walk-backward-roll-pair/README.md)

已完成真实 GPU 观察检查。32 个环境共 35,200 条转移、零学习，Windows 读到 23 个运行中状态，其中 12 个已经附完整原片。起身原片覆盖 11 秒、276 帧。本机并行规模短测随后完成。随后 Windows 端在正式 PPO 运行中核验了 17 次真实更新，最后一次附完整 8 秒原片。 [运行观察页](../records/training-live.html) · [本轮文档](../records/experiments/duck_getup_observation_s3061_20261110T002536/README.md) · [观察核验](../records/experiments/duck_getup_observation_s3061_20261110T002536/windows-view-verification.json)

本机资源按实测逐档扩展，目标是缩短达到同一动作门槛的总时间。正式 PPO 将比较同等样本预算下的学习、采样及独立动作表现。

本机起身短测按两遍顺序测试 512、1,024、2,048；两遍均胜过当前最佳且资源仍有余量，才继续试 4,096、6,144、8,192。零学习、每档先热身 100 步再计 400 步。 [冻结方案](../configs/experiments/local_getup_scale.json) · [本轮方案及原始计时](../records/benchmarks/duck_getup_local-scale_s3062_20261110T003001/README.md)

两轮短测已完成。3,072 环境以 24,802 和 27,898 转移/秒入选，约为 512 档的 3 倍。3,584 两遍未形成稳定收益。4,096 在 GPU 零步时达到 15,502 MiB，超过 85% 上限，在采样前停止。两档随后完成等样本 PPO，学习显存和吞吐已核验，动作质量以独立评价为准。 [首轮](../records/benchmarks/duck_getup_local-scale_s3062_20261110T003001/summary.json) · [补测](../records/benchmarks/duck_getup_scale-refine_s3062_20261110T003744/summary.json)

S4 官方滚翻单动作已通过。开发 1026、独立留出 2026 各 117/128，读数与地面、头顶、脚底的物理约束记录一致。滚翻切换与抗扰仍归 S5。从保存检查点复算后，右膝和右髋俯仰贡献第 25 至第 32 次更新间约 69% 的新增平方偏差。保存批次的两组则在同一条右侧倒地 3 秒观测触发颈部俯仰上限。下一步分别检查颈部极值与髋膝整体偏移，达到原约束后再做等样本 PPO 对照。 [实训偏移](../records/reports/getup-recovery-retention/drift-localization.json) · [保存批次复算](../records/reports/getup-success-step-control/sequence-drift-localization.json) [滚翻结果与原片](../records/reports/roll-endpoint-confirmation/README.md)

定向回放组合分别接受 21、29 次更新，低于两组均 32 次的准入要求。两组均因单关节极值越线停止。拒绝已定位到仰卧 4 秒的右髋偏航和右侧倒地 3 秒的头部偏航。自适应回放在两个不同随机种子的保存档案上均通过，两组各完成 32 次更新且未减步幅。实际 CUDA 零步检查也已通过，1,536 和 3,072 环境分别占用 6,747 和 11,927 MiB。PPO 对照随后完成并核验原片、检查点与导出。 [CUDA 检查](../records/benchmarks/duck_getup_ppo-zero_s3063_20261110T010636/README.md) [离线方案与结果](../records/reports/getup-success-step-control/targeted-replay.md)

两组各完成 1,253,376 条训练转移。3,072 和 1,536 环境分别耗时 165.71 和 172.33 秒，显存峰值 12,637 和 7,357 MiB。新种子 1061 同次释放评估中，固定父模型和两组新模型分别为 312/320、303/320、306/320。两组新模型均未通过分姿态门槛，未晋级。8 个共同退化的仰卧场景在第 3 秒仍有约 33° 倾角，固定父模型约 2.8°。保存轨迹的姿态分流复算达到 316/320。下一步用实际观测锁定分支，并在新场景中验证；同时保留第 2.3 到 3.0 秒转正的诊断。 [PPO 过程与原片](../records/reports/getup-local-ppo-20261110T011523/README.md) · [运行观察](../records/training-live.html)

姿态分流已完成 CPU 锁定和场景快照检查。开发种子 1062 分流为 313/320，两支纯策略为 305/320、306/320，通过原门槛。1063 分流为 316/320，两支纯策略为 313/320、310/320，同样通过。预留的 2062 留出分流 314/320，但指定仰卧 30/32，低于门槛 31/32。留出已消费，候选未晋级。 [冻结方案](../configs/experiments/getup_pose_router.json) · [运行观察](../records/getup-routing-live.html)

起身已复核 1062、1063 的 346 个实际仰卧开发样本。10 个失败均未及时起身、也未末段持稳。两批失败组第 3 秒倾角中位约 33°，成功组低于 1°，失败轨迹均延续头腿接触。下一项训练设计优先处理释放后第 2.3–3.0 秒的转正与支撑，并保留四姿态原门槛。 [逐场景复算](../records/reports/getup-pose-routing/development-supine-gap.json) · [起身训练草案](../configs/experiments/getup_supine_early_support_draft.json)

仰卧早期奖励已完成保存轨迹筛查。640 个场景的观测锁存与实际姿态一致，294 个其他姿态的该项奖励全部为零。有短暂头腿接触的 31 个成功场景仍得到正值。下一步进入实际奖励时钟、重置和价值起点核验。 [保存信号筛查](../records/reports/getup-pose-routing/early-support-signal.json)

种子 1081 已通过实际 CUDA 奖励时钟检查。128 个环境完成 70,400 条转移，9 个采样时点的接触记录均与原始物理接触一致。2 个局部重置和 126 个自然重置按预期清除锁存。独立复算 126 个完整首回合，保留 8 秒原片。种子 1082 已用新采样的 1,024 个场景完成共享价值网络的 50 次更新。64 个独立开发验证场景上，两套奖励均通过原价值门槛，策略网络无更新。两组 3,072 环境已通过实际 CUDA 零步检查，峰值均为 11,922 MiB。两组逐项初态哈希一致。同起点 PPO 初次启动在零步时被 Adam 键的序列化差异拦截。核对保存的启动数组后，已单独冻结读回修复。读回修复后，对照完成 17 次更新并通过独立核验，候选在第 115 步的奖励读回停止。候选完成 114 个控制步和 4 次 PPO 更新。两组结果已保留。按本机管理器的乘除顺序复算 409,600 个保存样本后逐位一致。新种子已通过 3,072 环境的实际读回和自然重置检查，完成 1,228,800 条转移，保存完整 8 秒原片。新种子等样本 PPO 两组均完成 17 次更新，各 1,253,376 条转移。两组检查点、ONNX、录像和 Windows 观察均通过核验。320 个新场景评分完成。固定父策略、对照、候选分别为 312/320、306/320、310/320。候选通过原四姿态动作门槛，实际仰卧净增 3 次低于所需 6 次，且总体比父策略少 2 次，未晋级。后退双向诊断已完成，两个方向均未挽回 15 个共同停滞场景。本轮侧移关闭。起身复盘确认旧成功回放缺少侧倒转仰卧类型，新对照数据已用旧开发档案准备。 起身两组均保留早期支撑奖励，新种子的两组 3,072 环境 CUDA 零步及回放读取均通过。两组均完成 17 次更新，各 1,253,376 条转移，检查点和原片独立核验通过。两组实际回放索引序列一致，候选包含 94,526 次侧倒转仰卧样本抽取。新场景评分已核验，父策略、对照、候选分别为 311/320、311/320、315/320。候选在侧倒转仰卧多挽回 3 次；指定仰卧仍为 30/32，实际仰卧净增 3 次低于 6 次门槛，未晋级。 [独立评分与 11 秒原片](../records/reports/getup-side-to-supine-replay/evaluation/README.md) [时钟核验与原片](../records/reports/getup-early-support-clock/README.md) · [价值结果与原片](../records/reports/getup-early-support-value/README.md) · [CUDA 初态核验](../records/reports/getup-early-support-ppo-zero/README.md) · [首次停止记录](../records/reports/getup-early-support-ppo/coordinator.json) · [冻结方案](../configs/experiments/getup_early_support_ppo_recovery.json) · [训练观察](../records/getup-early-support-ppo-recovery-live.html) · [停止复核](../records/reports/getup-early-support-ppo-recovery/stop-analysis.json) · [原生奖励核验与原片](../records/reports/getup-early-support-native-reward/README.md) · [新对照方案](../configs/experiments/getup_early_support_native_pair.json) · [新对照观察](../records/getup-early-support-native-pair-live.html) · [动作评分与原片](../records/reports/getup-early-support-ppo-functional/README.md) · [侧倒转仰卧回放](../records/reports/getup-side-to-supine-replay/README.md)

七指令共同接口已完成 1045 单步偏航脉冲。20 毫秒响应约 +0.00805 rad/s，40 毫秒反向，60 毫秒不通过。保存轨迹上考虑反向响应的两个幅度也未达到 0.01 rad/s 的继续门槛。1046 同目标对照在保留原动作历史时消除了这次 40 毫秒反向响应，机制门槛通过。±0.12 rad/s 执行器反馈经 60,480 条保存观测的限幅核验后，已进入新种子 20 秒闭环准备。 [同目标对照](../records/reports/common-walk-yaw-history-probe/README.md) [实测与原片](../records/reports/common-walk-yaw-pulse/README.md)

七指令闭环两个开发种子均 224/224。独立留出 2047 的前进为 32/32，偏航配对改善 0.01854、0.01749 rad/s，超过 0.01 门槛。三路后退均 30/32，同两个场景几乎静止，整组未晋级。下一步用开发轨迹定位后退启动缺口，保留前进反馈和原判据。 [首次结果与原片](../records/reports/common-walk-actuator-yaw-feedback/README.md) · [复验](../records/reports/common-walk-actuator-yaw-feedback-replication/README.md) · [独立留出](../records/reports/common-walk-actuator-yaw-feedback-heldout/README.md)

已复算两批开发的 64 个后退场景，全部在前 4 秒至少有一个 1 秒区间达到原速度门槛。57 个在前 2 秒达到，7 个到第 3–4 秒才达到。现有开发数据覆盖延迟启动，尚缺稳定复现的未启动样本。下一批先用新场景采集后退启动与真实画面，再决定修改。 [启动复算](../records/reports/common-walk-actuator-yaw-feedback/backward-development-onset.json) · [后退诊断草案](../configs/experiments/common_walk_backward_onset_draft.json)

后退开发种子 1071、1072 已完成。256 个场景中 234 个在 2 秒内启动、17 个迟启动、5 个存活但全程未启动。只用 1071 设定的髋膝活动阈值在 1072 找到全部 4 个停滞和 8 个迟启动，未触及 2 秒内已启动的场景。下一步在新开发种子用同初态对照限幅启动助推。 [诊断记录](../records/reports/common-walk-backward-onset/README.md) · [助推草案](../configs/experiments/common_walk_backward_start_pulse_draft.json)

后退助推 1073、1074 均已独立核验。单步目标限于 0.03 rad，分别挽回 0/6、1/7 个两路参照共同停滞。触发场景未出现启动损失或安全越线，但候选低于双批次门槛。随后复核四批开发轨迹。59 个迟启动场景均在首个速度达标区间结束前出现持续单脚支撑，转移前的双腿目标变化在同批比较中更不对称。主导关节在髋、膝、踝之间变化，后续先核对支撑侧与时序。 [助推结果](../records/reports/common-walk-backward-start-pulse/README.md) · [支撑转移复算](../records/reports/common-walk-backward-start-pulse/support-transfer-review.json)

在进入单脚支撑前的 140 毫秒内，59 个迟启动场景中有 50 个向随后承重的脚移动。按批次和左右侧分组，机身相对双脚中点的侧移中位数为 1.16–8.58 mm，按同一时段对齐的停滞场景为 −0.52 至 +0.54 mm。窗口起点只有 28/59 个场景偏向随后承重的脚，终点为 54/59。应先检验可在线识别的侧移时序。 [侧移轨迹复算](../records/reports/common-walk-backward-start-pulse/lateral-loading-review.json) [CPU 字段核验](../records/reports/common-walk-backward-start-pulse/lateral-probe-cpu.json) · [冻结方案](../configs/experiments/common_walk_backward_lateral_probe.json) · [首批观察](../records/walk-backward-lateral-s1075-live.html) · [复验观察](../records/walk-backward-lateral-s1076-live.html) · [双向结果与原片](../records/reports/common-walk-backward-lateral-probe/README.md) · [有界执行器运动学](../records/reports/common-walk-backward-lateral-probe/bounded-kinematics-preflight.json) · [执行器冻结方案](../configs/experiments/common_walk_backward_actuator_support.json) · [CPU 快照恢复](../records/reports/common-walk-backward-actuator-support/preflight.json) · [本轮方案与观察](../records/reports/common-walk-backward-actuator-support/README.md)

## 本机训练与交付

1. **先测并行规模。** 验收观察入口后，起身从 512、1,024、2,048 个环境开始，行走以实测的 4,096 个环境为锚。固定策略、物理和输入，仅采样，两遍反向测量。首次编译单列，记录 GPU、CPU、显存、主机内存与温度。两遍收益均超过计时波动且资源仍有余量时，继续冻结更大档的短测。初筛显存占比上限沿用 85%。 [既有短测协议](../records/benchmarks/scale_20261101T154057_s42/protocol.json)
2. **再测动作质量。** 从同一保存点续训。起身对照草案用 1,536 和 3,072 个环境，每组 1,253,376 条转移，覆盖同样数量的完整 400 步回合。保持同样的物理、姿态覆盖和独立评估。七指令优先处理共同接口偏航。 [PPO 对照草案](../configs/experiments/local_getup_ppo_draft.json)。候选须通过原有逐动作门槛，随后验证共同场景切换与有界扰动。分开记录采样、PPO 更新和录像写盘，比较达到同一门槛的总墙钟时间。
3. **安排本机资源。** 优先用已核验的 WSL 环境和本机 CUDA 批量采样。若写盘成为瓶颈，用专属 Linux 工作目录暂存高频输出，阶段结束后核验并归档。正式训练通过独立观察入口更新进度、曲线与原片，默认约每三分钟录像。若 WSL 仍是瓶颈，用同机同预算比较原生 Ubuntu。沿用两遍均提速、综合提升至少 15% 且动作指标稳定的迁移参考。 [提速方案](reports/development_report.md)
4. **验收后交付。** `artifacts/delivery/official/` 留存字节一致的官方 ONNX 及其控制接口说明。`artifacts/delivery/trained/` 交付达标的自训 ONNX 和对应 `.pt`，验证导出输出一致性及检查点恢复。按动作列出成绩、适用接口、训练起点、配置和来源哈希。一份迭代记录区分当前参考、开发候选和最终通过项。 [权重与迭代记录](../artifacts/delivery/iteration_record.md)

每批保存训练方案、命令、环境与依赖、源码和父模型哈希、改动原因、种子、逐次更新日志、耗时与资源曲线、保存点、异常停止、原始视频和独立评估。汇总进全流程报告，原始证据按批归档，提供可复现的路径与恢复方式。 [训练归档](../records/training-archive/README.md)

## 最近核验

各阶段的改动、实测结果和缺口见[开发路线](development_roadmap.md)。官方权重和现有自训候选已集中；详细核验结果随原批次保留。 [权重与迭代记录](../artifacts/delivery/iteration_record.md) · [详细核验摘要](../records/reports/goal-review/previous-stage-evidence.md)

后退执行器方案完成两批四路复验。右向修正挽回 3 个共同停滞，同时首批丢失 1 个原启动场景。三次挽回均无规定窗口内的单脚支撑，关闭该方案。后续先对齐脚底支撑和髋膝活动的真实时序，再决定触发条件。起身两批的共同失败已经有双脚着地，下一步区分头腿持续接触和转正停滞的先后。 [后退评分和观察](../records/reports/common-walk-backward-actuator-support/README.md) · [起身失败复算](../records/reports/getup-side-to-supine-replay/evaluation/nominal-supine-review.json)

滚翻修正只对齐接触读数的时点。留出同一条轨迹由缓存读法 111/128 变为对齐后 117/128；原权重和物理保持原样。 [逐场景复算](../records/reports/roll-endpoint-confirmation/heldout-readback.json)

连续动作的滚翻转站立触发已做离线筛查。仅用姿态和角速度会在 11 个滚翻未通过场景误触发。下一步核对可确认落地支撑的传感信号，后续仍需同一环境验证转站立再行走。 [滚翻触发筛查](../records/reports/roll-endpoint-confirmation/stand-readiness-development.json)

## 全部动作与阶段

目标动作：摔倒后站起、站立、前进、后退、左转、右转、左平移、右平移、前滚翻。优先采用一套带速度指令的行走策略、独立起身与滚翻策略，再用显式切换连接。

| 阶段 | 完成要求 | 当前状态 |
| --- | --- | --- |
| S0–S1 | 来源与接口、已有模型导出、七指令参照、真实观察/停止/恢复与开销核验 | 流程已完成；动作通过另行判断 |
| S2a | 站立、前后走，保留全部七指令回归 | 最终留出站立、前进和后退各 32/32。前进偏航较两条参照分别下降 0.00603、0.00524 rad/s |
| S2b | 左右转向，并保持已掌握动作 | 最终留出两侧各 32/32。连续指令切换在 S5 验证 |
| S2c | 左右平移，七指令逐项达标 | 最终留出两侧各 32/32，共同接口固定动作验收通过 |
| S3 | 四姿态起身、随机跌落、及时恢复和持稳，再验证切回站立 | 新独立留出通过，总体 2,983/3,072，实际右侧 179/183。切回站立在 S5 连续评估 |
| S4 | 正向完整旋转、有效支撑和接触顺序、关节可达、稳定落地 | 官方名义仿真单动作通过。修正接触读数后开发 1026、留出 2026 各 117/128，连续切换与抗扰待完成 |
| S5 | 起身→站立→行走、滚翻→站立→行走及有界扰动 | 起身接前进留出 2,990/3,072，起身接七指令留出 2,992/3,072。前进阶段两侧扰动通过。滚翻六组暂停于左推对照，参数随机化仅完成配置预检 |
| S6 | 关节映射、标定、IMU、时序、导出及回退准备 | 文档与离线映射完成；实物操作后置 |

有希望的行为修改须完成同预算成对比较、独立场景及多个训练种子确认。训练种子优先 42、43、44；留出集只作最终确认，不用于反复挑参数。逐条件报告成功数、比例和区间，不用 `status=passed` 的文件核验代替动作验收。

## 训练与停止

1. 每次学习前固定父模型、主要改动、共同适配、源码/模型哈希、种子、环境数、样本预算和评价。官方 ONNX 是推理参照，不能冒充含价值网络、优化器和完整历史的 PPO 续训点。
2. 新单因素诊断先限定每组最多 50 次更新；现有 4096 环境、24 步配置对应每组 4,915,200 个转移。该预算用于判断方向，不保证收敛。恢复时保留应保留的权重、优化器、归一化和计数，并说明重置边界。
3. 一次运行最多 250 次；有证据支持的同轮扩展累计最多 1000 次，每段结束先评估再决定。预算耗尽、失败或异常均不自动重启、不自动追加。原 `next_training.json` 继续保持关闭，新方案单独冻结。
4. 无效数值、接口错误或新出现的持续恶化停止并保留完整点；继承的姿态问题只在预先规定的短窗口内检查趋势。起身倒地与滚翻旋转使用各自阶段判据，不能套用普通行走的倾倒停止规则。
5. 固定评估只统计首次 episode；重置不能洗掉失败。模型权重不变的接口、姿态或评价诊断明确标注零学习更新，不称作训练提升。

## 观察与评价

- VS Code 可用来查看进度与视频，启动终端可选。正式训练前在用户能打开的界面验证两次真实进度更新、曲线追加、最新原片可播放及状态可追踪。使用 VS Code 时保持原窗口布局。 [观察验收](development_roadmap.md)
- 默认关闭原生实时仿真窗口。新训练约每 180 秒安排录像，25 fps；起身和滚翻从 episode 开始记录到结束，站立和连续行走采用 3–5 秒短片，切换动作覆盖切换前后，首段和异常段另存；拍摄不额外推进环境。显示运行名、指令、控制步与采样时间，旧录像不能标成直播。
- S1c 已实测一次开关录像对照，学习段额外墙钟时间为 4.18%；后续继续记录，不能把一次短测当作普遍性能结论。VS Code 视频与原始媒体已验证，自动浏览器页尚未验收。
- 原七指令和各次冻结成绩保留。若发现评价或任务不适配实际步态，先明确理由并冻结新协议，保留旧诊断，不能事后改阈值使旧结果通过。
- 起身采用 2 秒冻结、第 8 秒前开始连续 3 秒持稳，最多观察至 11 秒。滚翻在第 7 秒前完成并开始连续 2 秒持稳，最多 9 秒。原训练时长不变，两项记录均有独立复算。

## 接口、共同物理环境与部署

[接口审计](../records/reports/skill-interfaces/analysis.json)确认：归档运行程序共用约 22° HOME，起身/滚翻模型元数据约为 20°/24°；动作历史是滤波前原始输出，不能用物理目标替代。运行程序的 1 秒起身等待与 1.9 秒滚翻切回不等于当前任务评估。差异需验证，不据元数据直接改实机。

[物理配置](../records/reports/skill-interfaces/physics.json)确认：行走为 5 ms 物理步长及 15–30 ms 延迟，起身/滚翻为 4 ms 及 4 ms；接触与随机化不同。连续切换必须在一个共同环境中重新检查各技能，不能重建环境、重置关节或拼接独立录像充当连续证据。[切换草案](../configs/experiments/skill_transition_protocol.json)仍未冻结。

机器人已装配，App Lab 已安装；当前不刷写、不改 ID/零位、不使能或运行机器人。后续标定、方向/顺序变更、供电通信、IMU、时序、默认姿态、官方基线、自训策略迁移及回退见[部署手册](runbooks/hardware_commissioning.md)。只换 ID/顺序先核对等价映射；动力学、型号或几何改变须重新验证。

## 文档与空间

所有工作限于本工程及专属 `~/XGO-Duck/`，官方归档保持原字节。安装优先清华等镜像，保留官方锁定依赖与哈希；代理节点自动切换或下载中断时，先检查现有进程与缓存，不并行重复部署。

报告持续记录环境部署命令、修改原因、配置、结果、故障、真实截图/视频和复现步骤。逐次历史归入过程记录；新运行使用动作、改动、组别、种子和时间，保留名称与原路径映射。文件职责见[工程导航](project_structure.md)。

独立练习使用明确名称与新开发种子，复制固定控制参数并创建新协议。沿用观察与文档要求，练习结果与阶段验收分开记录。

清理前核对绝对路径、哈希、用途、恢复依赖和引用。保留官方归档、最终/已评估模型、恢复父模型、代表性失败与审计输入；冗余文件总结后再删除。此前已回收约 673 MiB，被自动审批拒绝的临时文件不重复删除。原生 Ubuntu 性能对比保留，当前不重启换系统；另一台电脑的配置总结仍等待源文件，不阻塞本地训练。

长期范围包括完整环境、官方参照、稳定基线、修改对照、多种子确认、舵机变更、真机标定、官方实机、自训 sim2real 与可复现报告。当前执行范围为仿真及离线部署准备，真机工作列在开发路线的后续阶段。


## 2026-11-16 训练观察接入过程

以下为当时逐步更新的目标记录；最新状态以当前目标页为准。

# 当前目标与验收条件

更新日期：2026-11-16。用户已将全阶段目标从暂停恢复为执行。统一训练入口已通过隔离检查，当前核对继承训练配置与保存点，准备新的有界观察和吞吐对照；实际 CUDA 零步与本次可见性通过后才进入采样。旧试验不重跑。机器人已按官方步骤装配，尚未运行官方程序，真机通信、标定和部署后置。本页汇总当前状态；完整原文保存在[目标历史记录](current_goal_history.md)，全流程细节见[开发与部署报告](reports/development_report.html)。

## 总目标

在可复现的仿真环境中完成摔倒后站起、站立、前进、后退、左转、右转、左平移、右平移和前滚翻，并验证动作之间的连续切换与有界扰动。以官方模型为参照，保留有价值的自训模型和对应可恢复保存点；每个模型按实际动作、场景和门槛说明用途，不把多个组件说成一个已通过全部门槛的模型。

交付内容包括官方原始权重、自训 ONNX 与对应 `.pt`、可复现环境与命令、训练曲线和真实录像、每次修改与结果、独立评价、源码和模型哈希。仿真达标且具备现场条件后，再依次完成舵机顺序与方向、零位、IMU、通信、官方基线、自训策略迁移和回退准备。 [权重与迭代记录](../artifacts/delivery/iteration_record.md) · [真机标定手册](runbooks/hardware_commissioning.md)

## 最近进展

修复后的 3,072 环境组完成 17 次更新，1,253,376 条转移耗时 209.13 秒；保存点、ONNX 与 201 帧完整录像均通过独立复核，原 VS Code 已显示进度、曲线并播放到 8 秒终态。现执行等样本对照组，再比较净吞吐。[独立复核](../records/reports/getup-observed-throughput-20261116/json-publication/training/throughput/independent-verification.json)

格式修复方案的两组实际 CUDA 零步已通过，113 项来源与保存点核验一致；现准入独立短对照，仍保留每臂预算和异常停止条件。[独立零步核验](../records/reports/getup-observed-throughput-20261116/json-publication/zero-verification.json)

已用首条真实指标复现 JSON 元组/列表差异，并通过 5 项离线检查。独立适配入口保留原数值与进度约束；新协议重新绑定种子、运行编号及来源，先做实际零步。旧运行保持关闭。[复现与修复检查](../records/reports/getup-observed-throughput-20261116/publication-verification.json)

本轮吞吐组在第 1 次更新后因观察数据格式校验停止：24 控制步、73,728 条转移、120 次价值网络小批量更新，策略梯度更新为 0；对照组未启动，原协议关闭。当前先用保存数据复现并修复格式问题，不追加本轮预算。[停止记录](../records/reports/getup-observed-throughput-20261116/training/throughput/entry-result.json)

两种规模的实际 CUDA 零步均已通过，本次状态在 VS Code 显示并截图；两份初始保存点逐字节一致。现已冻结等样本短对照，每臂最多 1,253,376 条转移，先执行 3,072 环境组。此次验证观察与吞吐，不据此晋级步态模型。[零步核验](../records/reports/getup-observed-throughput-20261116/zero-verification.json)

本机网页 `localhost:8765` 无法访问，当前观察入口改用 VS Code 直接打开的本地状态、曲线和完整动作录像。每次运行仍需核对本次运行编号及刷新时间；历史录像不能替代本次可查看性验收。

新的起身观察与吞吐方案已单独冻结零步协议，准备比较 1,536 和 3,072 个环境。当前只准入 CUDA 场景及保存点读回，训练草案尚未准入；两臂通过本次零步与本地查看后才考虑执行等样本短对照。[本轮方案和记录](../records/reports/getup-observed-throughput-20261116/README.md)

统一起身训练入口已接入本机文件观察、原工作器回调和外层监督，31 项合成进程检查通过。入口核对新运行与零步证据、继承源码和 WSL 依赖；未确认本次画面时不导入训练工作器。短任务结束后另存最后一条指标和最终曲线，修复了刷新前结束导致曲线缺失的问题。尚未启动真实训练或新的动态仿真；下一步为具体训练对照准备对应的实际零步证据和本机查看验收。[接线、失败记录与复核方法](../records/reports/native-ppo-observation-preflight/observed-entry-check/README.md)

历史短训命令会直接启动学习，没有检查当前暂停标记，也没有接入已准备的观察桥和外层监督器；七指令练习虽不更新权重，仍会启动新动态仿真。旧两组起身试验的运行目录和结果已经存在，不能复用旧运行编号。新训练所需的完整受监督入口尚未通过真实运行验收。[入口核对](../records/reports/native-ppo-observation-preflight/entry-audit.json) · [恢复前检查](runbooks/pc_training.md#恢复前先检查什么)

独立的官方标称单臂评估已完成并复核：128 个环境中 123 个通过“站立→滚翻→站立→前进”门槛。VS Code 实际显示了本次状态、速度曲线与自动刷新的画面；完整 31 秒录像、日志和关键帧已保存。该运行没有学习更新；观察器退出与暂停停止只在测试子进程中注入过，真实训练仍需接入并验收。 [评分、录像与操作](../records/reports/duck_roll-native_nominal_s1241_20261115T230228/README.md) · [观察接入测试](../records/reports/native-observer-preflight/native-roll-observation-check.json)

5 个未通过环境累计旋转接近一圈，但原判据的有效支撑旋转在窗口末为 303°–325°，没有达到 330° 的完成条件；后续可围绕支撑时序提出对照，不能把描述性复盘说成训练优化。 [失败复盘](../records/reports/duck_roll-native_nominal_s1241_20261115T230228/failure-review.json)

控制步边界未计入支撑的前向旋转中位数，失败组为 35.21°，已进入站立组为 7.47°。本批使用前向更新后的边界接触读数，并与同一时点的约束接触核对；本批没有记录该边界之间每个物理子步的受力。另一批历史高频记录表明边界无接触不等于区间内无接触；先前空中旋转惩罚训练未晋级。恢复后先核对接触时序，再确定训练修改。 [本批分解](../records/reports/duck_roll-native_nominal_s1241_20261115T230228/support-gap-analysis.json) · [历史高频记录](../records/reports/roll-contact-clock/analysis.json) · [旧训练对照](../records/reports/roll-airborne-support/README.md)

用户反馈无法访问训练观察页。2026-11-16 暂停期间的 Windows TCP 检查没有发现 8765 端口监听；该检查不能确定此前访问失败的原因。VS Code 已验证可自动刷新本机状态文件和真实评估画面，并播放本次录像；训练的进度、损失曲线、最新画面与异常停训仍需逐项核验。 [端口检查](../records/reports/pause-archive-20261115/local-viewer-pause-check.json) · [检查记录与截图](../records/reports/native-observer-preflight/README.md)

已用一份归档记录中的 17 次更新制作回报、价值损失与采样速度曲线，并核对原始指标和录像哈希；VS Code 可打开图像。该示例是历史数据，下一步需设计并验收真实运行接入，不改变已冻结方案。 [历史训练观察示例](../records/reports/native-observer-preflight/historical-example.md)

暂停期间已把同父点、等样本的两组历史起身训练整理为逐次曲线，并核对 51 条记录和两段完整训练录像。3,072 环境在这一轮的全程吞吐约高 4%，显存峰值多 5,280 MiB；两份模型均未通过全部姿态门槛。图中的数据是历史回放，不能作为真实训练观察准入。 [训练对照与录像](../records/reports/historical-getup-training-comparison/README.md)

已新增独立 PPO 本机观察桥和起身工作器回调接线，以测试子进程及合成状态检查暂停、进度、媒体和观察器退出；尚未在真实训练中验收。历史中断样本显示 `stopped-partial.pt` 的优化器计数已进入下一次更新，不能按文件名认定为完整保存点；精确物理续跑也需要另外保存场景状态。 [接线与保存点检查](../records/reports/native-ppo-observation-preflight/README.md)

交付及研究目录的 9 份保存点已检查内容和来源哈希，五个当前仿真组件的网络与优化器已在 CPU 加载，策略对 32 条保存观测与 ONNX 的输出一致。起身右侧价值网络为 75 维，另两份起身组件为 76 维；行走为 77 维。实际恢复训练与原物理状态续跑仍未验证。 [检查结果](../records/reports/native-ppo-observation-preflight/README.md#保存点边界)

外层训练监督器已用合成进程检查暂停、冻结命令、训练锁、进度停滞、时间上限与退出信号；其中一项连接了实际观察子进程。强制结束合成监督器后，测试工作进程退出并释放训练锁，22 项隔离检查通过。真实 PPO 训练中的监督、异常退出及中断保存点恢复仍未验收。 [监督范围与测试](../records/reports/native-ppo-observation-preflight/README.md)

实际观察进程接到合成工作进程的检查中，旧接线在监督器被强制结束后约 32.93 秒才标记来源过期。现加入工作进程身份检查，三次模拟分别在 1.86、1.97、1.86 秒后标记异常；正常观察的 17 项和监督器的 22 项隔离检查通过。真实训练中的观察延迟和异常停止仍需验收。 [观察退出核验](../records/reports/native-ppo-observation-preflight/observer-owner-guard-verification.json) · [原检查](../records/reports/native-ppo-observation-preflight/observer-parent-loss-verification.json)

WSL 替换本机图像后，VS Code 的图片预览也自动刷新；检查使用的是两张已保存的预检截图，不能当作实时仿真画面或新运行的准入记录。

独立的本机运行观察适配器已通过历史记录与故障样本检查，可显示来源时间、曲线和实际画面；它尚未接入训练控制器，也不能自行停训。下一步需冻结新运行的本机观察方案，接入进程、心跳和动作停止检查，并验证真实运行，不能用离线结果充当准入。 [适配器核验](../records/reports/native-observer-preflight/adapter-verification.json)

观察器进程与心跳判定已完成离线核验：实际测试子进程在健康时被识别，退出或来源过期后被拒绝，另覆盖编号、来源、时间和无效指标等故障。下一步仍需将判定接入有界运行协调器，并在真实运行中验证。 [进程与心跳核验](../records/reports/native-observer-preflight/observer-guard-verification.json)

已用保存轨迹与测试子进程完成 6 项离线接线检查：观察器退出和用户暂停均在下一回调前停止，头部碰撞超限的状态被保留；没有产生新物理轨迹。动态停止仍待真实运行验证。 [离线接线记录](../records/reports/native-observer-preflight/guarded-loop-verification.json)

原冻结方案、WSL 依赖、观察器与离线接线证据的哈希已核对；来源检查本身不证明动态采样或学习已经准入。 [来源核验](../records/reports/native-observer-preflight/native-zero-provenance.json)

来源核验对暂停、训练或仿真已运行、范围越权、源码变化及证据范围错误的 8 项拒绝检查已通过。下一步准备单独的零步协调入口，并在任何运行前核验实际可见的本机状态和进程心跳。 [拒绝检查](../records/reports/native-observer-preflight/native-zero-refusal-check.json)

零步协调入口已完成离线准入和模拟生命周期检查：错误观察凭据不会调用零步回调，模拟暂停或观察器退出后会清理运行状态。上述演练没有初始化 CUDA，不能替代真实运行验收。 [准入检查](../records/reports/native-observer-preflight/native-zero-coordinator-check.json) · [生命周期检查](../records/reports/native-observer-preflight/native-zero-lifecycle-check.json)

独立的本机观察零步方案已执行一次，VS Code 实际显示了该运行的刷新状态。CUDA 初始化后，执行器映射检查因数组类型报错停止；运行契约记录控制步和物理子步均为 0，接口检查尚未完成。当前没有训练或仿真运行，不自动重试。 [冻结方案](../configs/experiments/roll_factor_native_zero_s1241_20261115.json) · [停止记录](../records/reports/duck_roll-factor_nominal_s1241_20261115T214019/native-zero-run/result.json) · [运行契约](../records/reports/duck_roll-factor_nominal_s1241_20261115T214019/zero/runtime-contract.json)

当前先分析执行器字段的实际类型、已有零步证据与原检查器的假设，保留失败现场和原冻结方案；修复需要单独制定并核验方案，不追加原次运行预算。原命令的完整控制台输出没有保存，仅有停止记录、运行契约及已观察到的部分输出，后续入口需补齐日志。

同一 MuJoCo 版本的独立 CPU 小模型将限力标志暴露为 `bool`，原检查器要求整数，因而复现了相同报错；旧假环境使用 `uint8`。失败现场没有保存真实 XGO 标志数组，故这是有证据支持的原因推断，仍需实际读回。兼容候选保存在新文件中，原冻结源码和失败运行未改动。 [类型诊断](../records/reports/native-observer-preflight/force-dtype-diagnosis.json)

布尔标志兼容候选先通过独立 CPU 小模型与 11 项无效输入检查，原模型数组保持不变；原失败运行没有保存真实 XGO 标志，需另行读取。 [原失败与诊断](../records/reports/native-observer-preflight/zero-attempt-20261115.md)

独立修复方案已完成标称 CUDA 零步并通过保存数据复核：真实模型 14 个限力标志均为 `bool` 且已启用；7.7 V 对应的编译力限为 ±0.97816 N·m。32 个接口样本的最大输出差为 5.96×10⁻⁷，128 环境的两脚摩擦为 1.0；控制步、物理子步与学习更新均为 0。VS Code 实际显示本次状态，完整进程日志与退出码已保存。旧失败未记录标志，因此原故障原因仍是有证据支持的推断；成对初态、动态停止和训练观察尚未验收。 [独立复核](../records/reports/duck_roll-factor_nominal_s1241_20261115T224902/independent-verification.json) · [日志](../records/reports/duck_roll-factor_nominal_s1241_20261115T224902/native-zero-execution.log) · [截图](../records/reports/duck_roll-factor_nominal_s1241_20261115T224902/native-zero-run/ui-check.jpg)

历史滚翻快照的 305 项字段及六个分支恢复回执已核对，覆盖随机数、执行器和延迟状态；它是在第 58 步、同一物理模型内建立的，不能直接证明新参数组的零步初态一致。若后续复用，需要重新冻结快照源码并核验允许变化的物理字段。 [复用核对](../records/reports/resume-20261115/paired-snapshot-audit.json)

标称参数采用种子 1241、128 个环境和 0 步落地过渡；本机文件观察已替代受限网页完成上述零步检查。成对初态和动态停止仍待核验。 [恢复准备](../records/reports/resume-20261115/README.md)

主报告的本地链接与媒体引用已通过静态检查；内置浏览器拒绝 `file:` 地址，因此该报告的浏览器排版与播放尚未核验。 [媒体核验范围](../records/reports/report-media-check.json)

WSL 原始训练日志共 398 项，已逐一核验；在所检查项目目录中未找到同字节副本的 202 项已按原路径集中归档，并逐项复核。WSL 原件全部保留。 [WSL 日志与归档](../records/reports/progress-archive-20261114/wsl-training-logs/README.md)

已为 Windows 训练归档的 21,135 个文件建立路径、大小和 SHA-256 清单，并复核全部路径及 21 个文件内容。旧清单中 10,149 项一致，1 个最近评估状态文件发生变化；没有删除或移动原文件。该清单不覆盖 WSL 文件系统。 [完整文件清单](../records/reports/progress-archive-20261114/training-files/README.md)

已盘点训练、评估和模型文件：训练归档约 65.92 GiB，主要是轨迹；已发现的重复路径仍需核对用途，本次没有删除。 [存储盘点](../records/reports/storage-review-20261114/README.md) · [当前进度补充归档](../records/reports/progress-archive-20261114/current-state/README.md)

最近一次运行是官方固定策略的摩擦、电压**评估**，没有 PPO 更新。八组预留条件中六组完成，第七组在 **1,400/1,550** 控制步中断，最后一组未启动。中断组保存了 29 张画面、状态和日志，但没有完整轨迹或可恢复物理检查点，不能从第 1,400 步直接续跑。 [暂停记录与录像](../records/reports/roll-domain-parameter-random-s20/README.md) · [停止记录](../records/reports/roll-domain-parameter-random-s20/stop-record.json)

六个完整组中，低摩擦三组的滚翻分别为 110/128、108/128、112/128；中摩擦/低电压为 125/128，高摩擦/低电压为 124/128；中摩擦/高电压滚翻 117/128，但连续路线只有 25/128。每组使用固定参数，不是逐环境随机化。S20 落地过渡为 25 步，已验收的 S17 路线为 0 步，种子也不同，不能把两者当作只改变物理参数的对照；部分 `early_stop` 是事后诊断，原采集实际跑完整个预算。 [评分与原因](../records/reports/roll-domain-parameter-random-s20/offline-review.md)

暂停期间补充了单因素配置、摩擦字段和编译电机力限值的零步检查。后续标称模型与 CUDA 零步已验证；不同参数组的完整执行器/随机数初态和多臂停止仍未验证。 [初态审计](../records/reports/matched-start-source-audit/README.md) · [力限值检查](../records/reports/force-limit-guard/README.md)

## 全部动作与阶段

| 阶段 | 已有仿真结果 | 剩余工作 |
| --- | --- | --- |
| 来源与流程 | 环境、官方参照、导出、过程观察和停止流程已有验证记录。 | 新方案需重新核对冻结来源、观察入口和运行条件。 |
| 七种行走指令 | 共同接口的最终留出中，站立、前进、后退、左右转和左右平移各 **32/32**；方案使用多个策略组件和反馈。 | 在共同场景继续验证连续切换、扰动和最终模型组合。 [行走清单](../artifacts/delivery/walking-simulation.json) |
| 四姿态起身 | 独立留出 **2,983/3,072**，实际右侧 **179/183**，右侧相对两组参照分别净增 **4、5** 例，原留出门槛通过。 | 总体相对参照分别少 4、5 例；保留参照与失败样本，继续验证完整技能组合。 [原评分与原片](../records/reports/getup-right-robustness/holdout/README.md) · [门槛核对](../records/reports/getup-gate-clarification/README.md) |
| 前滚翻 | 官方策略在独立开发和留出中均为 **117/128**，单动作门槛通过。 | 分别完成连续切换和扰动验收。 [滚翻评分](../records/reports/roll-endpoint-confirmation/README.md) |
| 连续动作与扰动 | 起身接七指令留出为 **2,992/3,072**；官方滚翻→站立→前进固定路线为 **119/128**。 | 参数抗扰和滚翻阶段扰动仍有开放门槛，不合并不同控制器的结果。 [阶段矩阵](../records/reports/stage-acceptance-matrix/README.md) · [官方路线](../records/reports/official-route-independent-s1235/README.md) |
| 真机准备 | 已完成离线模型接口、软件关节映射、标定模板和回退材料。 | 实物 ID、机械零位、方向、IMU、通信、供电和使能尚未现场验证。 [准备审计](../records/hardware/deployment-preparation/s19-readiness.md) |

已有自训权重按各自用途保留。路线感知短训的候选在同种子对照中为 **28/128**，官方父模型为 **125/128**，因此停止该学习线；教师约束候选与官方父模型两种子合计均为 **243/256**，差异不稳定，候选未晋级。 [短训对照](../records/reports/route-aware-pilot-parent-compare-s1225/README.md) · [教师约束对照](../records/reports/route-aware-teacher-anchor-parent-compare-s1232/README.md) · [模型选择](../artifacts/delivery/simulation-model-selection.json)

## 后续顺序

1. **完成新运行的准入。** 用户已恢复目标。先核对当前进程、计划、源码和权重哈希，准备可独立于 VS Code 终端查看的真实进度、曲线和原片。已有草案不等于冻结协议，也不从中断位置重启评估。
2. **先完成参数对照准入。** 保留已完成的标称零步，另行冻结与 S17 一致的 0 步落地过渡、同种子单因素变化及停止规则。保存并比较随机数、执行器内部状态和各环境起点，未解释差异不能进入动态采样；训练观察和动态停止需要真实运行验收。 [待冻结草案](../configs/experiments/roll_parameter_matched_review_draft.json) · [初态审计](../records/reports/matched-start-source-audit/README.md)
3. **逐步评估并停止无效运行。** 先进行名义与单因素有界对照，按原动作门槛、头部穿透与关节范围检查，并在每臂结束后检查能否进入下一臂。异常、无效数值、预算耗尽或门槛已不可达时保留证据并停止，不自动重启或追加预算。若需要完整失败诊断，事先单列条件和预算。
4. **再决定训练修改。** 从同一父保存点做等样本对照，记录改动原因、配置与影响。小规模学习对照每组最多 50 次更新；单次运行不超过 250 次，有证据支持的分段累计最多 1,000 次，具体范围以新冻结协议为准。原官方 ONNX 是推理参照，不等于包含优化器、价值网络和历史的 PPO 保存点。
5. **独立复验并交付。** 保持各动作原门槛，用未用于挑参的留出场景和多个训练种子核验，记录成功数、比例及失败原因；再验证共同场景切换和扰动。达标后交付官方参照、自训 ONNX 与对应 `.pt`，核对导出一致性、恢复能力和来源哈希。
6. **真机后置。** 达到仿真门槛并具备现场条件后，再按标定手册逐项核对。舵机只调整顺序时先验证软件映射；型号、几何或动力学变化需要重新评估。实际写入、使能和部署当前不进行。

## 本机训练与观察

已完成的同父点规模短测中，行走 1,024、2,048、4,096 环境分别约为 **9.86–10.05k、16.08–16.30k、23.98–24.58k 转移/秒**，4,096 档最高显存约 4,630 MiB、CPU 约 100%。这是已测范围内的结果，并不证明更大规模一定更快。观察器 D3D12 + 4 Hz 的两遍吞吐约 **18.35–18.38k 转移/秒**，实际状态采样约 2.25–2.29 Hz。 [规模和观察器记录](../records/reports/throughput-selection/README.md)

恢复后优先使用已核验的 WSL、本机 CUDA 和上述行走配方；起身使用已记录的独立配方，并在固定父点、样本量和动作门槛下比较。分开记录采样、更新、录像、CPU、显存和磁盘开销，以达到同一动作门槛的总时间选择方案。若 WSL 成为瓶颈，再与原生 Ubuntu 做同机同预算对照；两遍均提速、综合提升至少 15% 且动作指标稳定时再考虑迁移。

训练过程须在用户可打开的页面或工具中显示真实运行名、状态、进度和曲线，并按动作保存完整原片；VS Code 终端可选。默认不打开卡顿的持续实时窗口，约每三分钟在动作起点安排录像：起身训练约 8 秒、评估约 11 秒，滚翻和切换覆盖实际完整过程，异常或中断片段明确标记。不得为录像额外推进物理步。 [训练手册](runbooks/pc_training.md) · [录像规则](../configs/environments/action_recording.json)

## 文件与证据入口

- [全流程报告](reports/development_report.html)：环境部署、训练、修改原因、结果、截图、视频和真机准备；[完整过程记录](reports/development_history.html)保留逐次历史。
- [权重与迭代记录](../artifacts/delivery/iteration_record.md)：官方参照、自训组件及保存点；[模型选择](../artifacts/delivery/simulation-model-selection.json)注明哪些候选没有晋级。
- [训练记录归档](../records/training-archive/README.md)和[暂停进度归档](../records/reports/progress-archive-20261114/README.md)：按批定位方案、日志、轨迹、原片和快照。快照不是脱离工程目录的完整备份。
- [最新暂停进度归档](../records/reports/pause-archive-20261115/README.md)：暂停状态、阶段结论、最新评估、模型入口和快照；权重、轨迹和原片仍按原路径保留。[此前快照](../records/reports/progress-archive-20261115/README.md)保留本机观察、零步失败、修复和独立核验。
- [观察与监督准备归档](../records/reports/pause-archive-20261115/supervision-preparation.zip)：暂停后整理的相关源码、记录和当前文档；大文件仍按原路径保留。[归档清单](../records/reports/pause-archive-20261115/supervision-preparation-manifest.json)
- [起身接七指令完整原片](../records/evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/restored-gyro/clip-step-0.mp4) · [左转关键帧](../records/reports/stage-media/cards/N628.jpg) · [全部录像总览](reports/assets/all-video-overview.jpg)。它们是已保存的评估画面，不是当前直播。
- [工程导航](project_structure.md) · [目标历史记录](current_goal_history.md) · [原文保全记录](../records/reports/goal-review/goal-organization-source.json)：历史内容仅供追溯，以本页和实际证据为准。

清理前先核对绝对路径、来源哈希、引用、保留价值和恢复依赖；保留官方归档、最终或已评价模型、恢复父点、代表性失败与审计输入。安装优先使用可用镜像源并记录过程，保持官方依赖锁定；代理断线时先检查现有进程与缓存。新运行必须先冻结对应方案并通过观察及运行准入，不自动重启中断评估或追加旧预算。
