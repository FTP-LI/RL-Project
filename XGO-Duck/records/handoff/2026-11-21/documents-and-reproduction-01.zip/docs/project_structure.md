# 工程导航

日常从[当前目标](current_goal.md)、[全流程报告](reports/development_report.html)和[阶段验收矩阵](../records/reports/stage-acceptance-matrix/README.md)进入。训练、评估和回看的实际入口见[VS Code训练记录](../records/training-current.md)，实时进度和归档评分各自对应运行编号。整理前目标原文保留在[目标历史记录](current_goal_history.md)。

## 目录职责

| 目录 | 放什么 | 使用原则 |
| --- | --- | --- |
| `.vscode/` | 单个共享终端的任务入口 | 只保留当前日常任务；旧编号配置已归档 |
| `configs/experiments/` | 冻结实验、评估协议、下一次训练草案 | 先写改动、预算、父模型和验收；历史协议不覆盖 |
| `configs/environments/` | 下载、显示及 VS Code 偏好 | 旧冻结显示配置用于原协议，日常观察见开发路线 |
| `scripts/setup/` | WSL、依赖、镜像与环境核验 | 首次安装或有依据的修复时使用 |
| `scripts/training/` | 当前训练入口、恢复、观察及历史实验 | 日常通过 `training_workflow.sh`；旧入口用于复查 |
| `scripts/validation/` | 导出、固定评估、分析、绘图和核验 | 当前入口见下表；独立诊断脚本保留原因和源码 |
| `records/deployment/` | 安装命令、日志、来源和退出码 | 不含密码 |
| `records/training-archive/` | 训练、评估、基准和性能诊断的实体目录 | 批次名和字节保留，按清单查找及恢复 |
| `records/experiments/`、`records/evaluations/` | 历史报告与脚本的兼容入口 | 原相对路径继续使用，实际文件见训练归档 |
| `records/reports/` | 从原始数据复算的摘要、图像、阶段核验 | 保留输入哈希、命令和结论范围 |
| `artifacts/` | `delivery/` 集中官方权重、自训权重和迭代记录 | 已评估的历史模型及恢复父模型沿用原路径 |
| `workspace/` | 下载、固定官方参照与临时运行状态 | 不等同于正式成果；清理前核对引用 |
| `official_resources/` | 官方源码、快照、来源清单 | 保持原始字节，不直接训练或修改 |

Linux 工作副本和环境在 `/home/atlas/XGO-Duck/workspace/xgoduck_rl`，训练 checkpoint 在其 `logs/rsl_rl/` 内。Windows 工程保存报告、协议和恢复副本。按动作选择仿真模型或查找清理记录时，先打开[训练产物保留索引](../records/reports/training-curation/README.md)。

角度输入对照已结束并按门槛关闭；共同场景回归和起身碰撞规则诊断均已结束，完整碰撞策略对照已结束，候选因门槛上限冲突停止；独立姿态覆盖已完成但功能未通过，当前复盘失败，不追加旧学习。协议与证据分别集中在 `configs/experiments/` 和 `records/reports/` 的对应主题内。速度时间统计学习已关闭，相关源码、权重与失败结果保留；不修改官方归档或旧实验。

## 当前代码入口

| 用途 | 文件 |
| --- | --- |
| 暂停后的名义入口 | [入口与离线核验](../records/reports/roll-domain-parameter-random-s20/guarded-entry.md)；只完成假环境验证，参数注入和真实 CUDA 零步仍待验收 |
| 单因素零步入口 | [力限值与来源检查](../records/reports/force-limit-guard/README.md)；假环境检查通过，真实模型和 CUDA 零步仍未验收，动态采样未开放 |
| 日常任务分发 | [training_workflow.sh](../scripts/training/training_workflow.sh) |
| 共同接口七指令 | [冻结及批量评价](../scripts/validation/common_walk_confirmation.py)、[独立采样修复](../scripts/validation/recover_common_walk_resets.py)、[失败与计数复算](../scripts/validation/review_common_walk_closure.py)、[证据索引](../records/reports/common-walk-confirmation/README.md)；本轮已关闭，留出不再挑参数 |
| 当前连续切换复验 | [冻结与采样](../scripts/validation/run_routed_getup_ramped_forward.py)、[观察与评分](../scripts/validation/verify_routed_getup_ramped_forward.py)、[复验记录](../records/reports/continuous-routed-getup-ramped-forward/README.md) |
| 起身持续接触 | [证据索引](../records/reports/getup-persistent-contact/README.md)、[计时及价值输入](../scripts/training/getup_persistent_contact.py)、[配对协调器](../scripts/validation/getup_persistent_contact_pair.py)、[保存轨迹复核](../scripts/validation/review_getup_persistent_contact_pair.py) |
| 当前状态与真实进程 | [current_status.py](../scripts/validation/current_status.py)，不根据陈旧状态文件推断进程仍活跃 |
| 有界训练、恢复与保存 | [guarded_training.py](../scripts/training/guarded_training.py) |
| 动作完整录像 | [按动作选时长](../configs/environments/action_recording.json)、[完整动作录像器](../scripts/training/action_video.py)、[重置边界检查](../scripts/validation/check_action_video.py)、[保存状态完整回放](../scripts/validation/render_complete_getup.py)；旧3秒原片不改 |
| 监控与真实短片 | [VS Code训练记录](../records/training-current.md) · [training_watch.py](../scripts/training/training_watch.py) · [本机文件观察器](../scripts/training/native_run_observer_bounded.py) |
| 低摩擦起身对照 | [同释放快照的仿真入口](../scripts/validation/run_nominal_low_friction_release_integrator.py) · [评分及原片](../records/reports/nominal-skill-composition/low-friction-release-integrator/README.md) · [4ms扭矩复算](../records/reports/nominal-skill-composition/low-friction-first-support-effort/README.md) |
| 已结束的髋姿态对照 | [hip_limit_repair.py](../scripts/training/hip_limit_repair.py)、[准备与预检](../scripts/validation/prepare_hip_pair.py)、[结果复算](../scripts/validation/analyze_hip_pair.py) |
| 官方策略初始化 | [网络导入](../scripts/training/official_actor.py)、[初始化短训](../scripts/training/official_bootstrap.py)、[导入核验](../scripts/validation/verify_official_actor.py) |
| 官方起点适应与恢复 | [适应训练](../scripts/training/official_continuation.py)、[剩余预算恢复](../scripts/training/resume_official_adaptation.py)、[记录写入](../scripts/training/record_io.py) |
| 适应结果筛查 | [固定评估](../scripts/validation/evaluate_adaptation_screen.py)、[预定门槛复算](../scripts/validation/analyze_official_adaptation.py) |
| 速度奖励宽度对照 | [训练适配](../scripts/training/tracking_precision.py)、[冻结与预检](../scripts/validation/prepare_tracking_precision.py)、[判定](../scripts/validation/analyze_tracking_precision.py) |
| 速度时间统计对照 | [奖励改动](../scripts/training/planar_velocity_reward.py)、[配对入口](../scripts/validation/run_planar_filter_pair.py)、[结果复算](../scripts/validation/analyze_planar_filter_pair.py)，已关闭 |
| 官方响应与评价尺度 | [19 档采集](../scripts/validation/command_response_probe.py)、[多尺度复盘](../scripts/validation/review_velocity_timescales.py)、[固定输入映射](../scripts/validation/command_input_mapping.py) |
| 前后走独立确认 | [分组采集](../scripts/validation/batched_velocity_confirmation.py)、[独立轨迹核验](../scripts/validation/verify_batched_velocity_confirmation.py)，原瞬时成绩同时保留 |
| 七指令完整确认与练习 | [确认入口](../scripts/validation/seven_command_confirmation.py)、[轨迹核验](../scripts/validation/verify_seven_command_confirmation.py)、[打包汇总](../scripts/validation/summarize_seven_command_confirmation.py)、[新名称练习](../scripts/validation/practice_walking.py) |
| 转向反馈和平移 | [冻结与可见入口](../scripts/validation/turn_feedback_probe.py)、[转向反馈](../scripts/validation/gyro_turn_controller.py)、[通用分组采集](../scripts/validation/grouped_motion_collection.py)、[核验](../scripts/validation/verify_turn_feedback_probe.py) |
| 实际奖励分项 | [原采集](../scripts/validation/reward_incentive_audit.py)、[采样时点修正后的复算](../scripts/validation/analyze_reward_incentives.py)，固定已有策略，不发生学习 |
| 起身评估 | [四姿态评估](../scripts/validation/evaluate_standup_reference.py)、[独立核验](../scripts/validation/verify_standup_reference.py)、[判据](../scripts/validation/standup_metrics.py)、[边界检查](../scripts/validation/verify_standup_metrics.py) |
| 侧卧覆盖补充 | [有界采集与分析](../scripts/validation/evaluate_lateral_recovery.py)、[首轮姿态诊断](../scripts/validation/diagnose_standup_release.py) |
| 随机跌落覆盖 | [固定采集与分析](../scripts/validation/evaluate_random_recovery.py)，复用已核验的起身记录与独立持稳计算 |
| 滚翻参照 | [固定评估](../scripts/validation/evaluate_roll_reference.py)、[判据](../scripts/validation/roll_metrics.py)、[独立轨迹核验](../scripts/validation/verify_roll_reference.py)，实际参照已完成，动作未达原定门槛 |
| 滚翻失败与初始化 | [失败阶段及真实帧](../scripts/validation/analyze_roll_reference.py)、[初始姿态对照](../scripts/validation/evaluate_roll_reset_pair.py)，固定模型无学习更新 |
| 滚翻输出滤波 | [原公式与 CPU 重放](../scripts/validation/review_roll_action_memory.py)、[固定对照](../scripts/validation/roll_action_memory_pair.py)、[零步导入恢复](../scripts/validation/recover_roll_action_memory.py)、[独立核验](../scripts/validation/verify_roll_action_memory.py) |
| 滚翻短训与支撑诊断 | [头顶奖励短训](../scripts/validation/roll_top_contact_pair.py)、[独立模型筛查](../scripts/validation/roll_model_screen.py)、[支撑损失分解](../scripts/validation/analyze_roll_support_losses.py)、[完成奖励对照](../scripts/validation/completion_frontier_pair.py)、[零步启动恢复](../scripts/validation/recover_completion_frontier.py)；旧协议与失败记录保持原样 |
| 站立后滚翻 | [连续准备采集](../scripts/validation/roll_standing_preparation.py)、[固定对照与核验](../scripts/validation/stand_preparation_pair.py)、[六帧图](reports/assets/standing-roll-sequence.jpg)；结案保留原跨时点比较停止 |
| 官方角度输入准备 | [离线输入审计](../scripts/validation/inspect_roll_angle_inputs.py)、[对照草案](../configs/experiments/roll_angle_feature_draft.json)，仅 CPU 核验，不是已训练改进 |
| 技能切换准备 | [接口审计](../scripts/validation/inspect_skill_contracts.py)、[物理配置核对](../scripts/validation/inspect_skill_physics.py)、[后续操作说明](runbooks/skill_switching.md)，连续仿真尚未验收 |
| 滚翻角度输入 | [原适配与预检](../scripts/validation/angle_feature_pair.py)、[零步检查修复](../scripts/validation/recover_angle_feature_pair.py)、[因果重力观察器](../scripts/validation/roll_angle_observer.py)、[含角度导出核验](../scripts/validation/verify_angle_feature_training.py)；旧失败与单独修复协议均保留 |
| 共同物理环境准备 | [纯配置适配](../scripts/validation/common_skill_plant.py)、[CPU 编译核验](../scripts/validation/inspect_common_skill_plant.py)、[筛查草案](../configs/experiments/common_plant_screen_draft.json)，不代表各技能或切换已通过 |
| 共同场景固定回归 | [冻结与可见入口](../scripts/validation/common_plant_screen.py)、[物理和零步接口契约](../scripts/validation/common_scene_contract.py)、[附加核验](../scripts/validation/verify_common_plant_screen.py)，原技能判据保持不变 |
| 起身价值预检 | [固定策略数据采集与价值拟合](../scripts/training/getup_value_bootstrap.py)、[坐标和传感器](../scripts/training/getup_contact_training.py)、[单独零步类型恢复](../scripts/training/recover_getup_value_startup.py)、[独立复算](../scripts/validation/verify_getup_value_startup_recovery.py)，actor 未更新 |
| 起身策略对照 | [有限PPO与冻结策略掩码](../scripts/training/getup_masked_ppo.py)、[执行](../scripts/training/getup_contact_pilot.py)、[关闭复核](../scripts/validation/review_getup_contact_stop.py)，部分候选不作为效果证据 |
| 起身姿态覆盖 | [冻结与批量采集](../scripts/validation/getup_release_coverage.py)、[判据](../scripts/validation/getup_coverage_metrics.py)、[独立核验](../scripts/validation/verify_getup_release_coverage.py)，完整11秒、无学习、不重采样 |
| 起身末段解困 | [颈部控制规则](../scripts/training/getup_neck_relief.py)、[CPU检查](../scripts/validation/check_getup_neck_relief.py)、[冻结与对照](../scripts/validation/getup_neck_relief_pair.py)、[完整采集](../scripts/validation/fixed_getup_collection.py)、[独立核验](../scripts/validation/verify_getup_neck_relief.py)；不改变权重，原始动作历史保留 |
| 起身接力对照 | [冻结与执行](../scripts/validation/getup_stand_handoff_pair.py)、[连续采集](../scripts/validation/collect_getup_stand_handoff.py)、[独立轨迹核验](../scripts/validation/verify_getup_stand_handoff.py)；共同噪声和目标过渡，两模型独立原始历史，无切换重置 |
| 接力失败复盘 | [全部失败分量](../scripts/validation/review_getup_stand_handoff.py)、[单颈部观测条件推理](../scripts/validation/audit_getup_neck_state_sensitivity.py)、[新草案](../configs/experiments/getup_neck_home_order_draft.json)；条件推理不能当作实际恢复 |
| 颈部归位顺序 | [目标与就绪条件](../scripts/training/getup_neck_home_order.py)、[CPU检查](../scripts/validation/check_getup_neck_home_order.py)、[冻结及顺序执行](../scripts/validation/getup_neck_home_order_study.py)、[公共完整采集](../scripts/validation/collect_fixed_recovery.py)、[独立核验](../scripts/validation/verify_getup_neck_home_order.py)、[最后持稳](../scripts/validation/recovery_end_hold.py)；旧冻结源码不改 |
| 起身失败几何 | [保存状态接触与颈部扫描](../scripts/validation/review_getup_neck_clearance.py)、[证据](../records/reports/getup-release-coverage/neck-clearance/analysis.json)；静态几何不能当作动态成功 |
| 起身解困复盘 | [失败分量](../scripts/validation/review_getup_neck_relief.py)、[精确保存状态回放](../scripts/validation/render_getup_relief_replay.py)、[回放核验](../records/reports/getup-neck-relief/replay/verification.json)；不新增物理步或episode |
| 站立接力接口 | [CPU首次请求审计](../scripts/validation/audit_getup_stand_handoff.py)、[噪声及目标跳变](../records/reports/getup-stand-handoff/analysis.json)、[接力组件](../scripts/training/getup_stand_handoff.py)、[CPU组件检查](../scripts/validation/check_getup_stand_handoff.py)；动态切换尚未验证 |
| 已有训练动力学 | [标量与探索幅度复算](../scripts/validation/analyze_training_dynamics.py)，仅读取保存模型与 TensorBoard |
| 真机准备 | [标定与部署手册](runbooks/hardware_commissioning.md)、[关节映射](../configs/hardware/policy_joint_mapping.csv)、[离线核验](../scripts/validation/verify_deployment_mapping.py) |
| 已有模型补导出 | [s1_reference_inputs.py](../scripts/validation/s1_reference_inputs.py) |
| 七指令证据收集 | [s1_reference_evaluation.py](../scripts/validation/s1_reference_evaluation.py) |
| 逐 episode 复算 | [analyze_walking_suite.py](../scripts/validation/analyze_walking_suite.py) |
| 前进偏航对照 | [结果、录像与复现入口](../records/reports/common-walk-forward-phase/README.md) |
| 前滚翻头部支撑 | [原判据、轨迹复算和驱动余量](../records/reports/roll-common-confirmation/rng-recovery/README.md) · [脚掌触地](../records/reports/roll-common-confirmation/rng-recovery/development-foot-transfer.json) · [动态对照与完整录像](../records/reports/roll-neck-support/README.md) |
| 前滚翻接触计时 | [实际采样、缓存复现及原片](../records/reports/roll-contact-clock/README.md) · [接触字段读取](../scripts/validation/roll_contact_endpoint.py) · [同轨迹比较条件](../configs/experiments/roll_endpoint_readback_draft.json) |
| 前滚翻接触对照 | [同轨迹结果与录像](../records/reports/roll-endpoint-readback/README.md) · [独立确认条件](../configs/experiments/roll_endpoint_confirmation_draft.json) |
| 起身实际释放 | [历史释放近配对](../records/reports/getup-teacher-anchor-pair/release-match-review.json) · [同一释放对照、日志与原片](../records/reports/getup-anchor-same-release/README.md) · [仰卧成对训练与评估](../records/reports/getup-supine-weighted-learning/README.md) · [动作保持与停止复核](../records/reports/getup-recovery-retention/README.md) |
| 起身更新步幅 | [更新与回滚](../scripts/training/getup_success_step_control.py) · [单次 CPU 核验](../records/reports/getup-success-step-control/preflight.json) · [连续检查](../records/reports/getup-success-step-control/sequence-preflight.json) |
| 真实观察、停止与恢复验收 | [s1_observer_integration.py](../scripts/validation/s1_observer_integration.py) |
| 已完成运行与保存索引核验 | [verify_s1_integration.py](../scripts/validation/verify_s1_integration.py) |
| 结果图与关键帧 | [S1 图表](../scripts/validation/render_s1_evidence.py)、[S2 真实帧对照](../scripts/validation/render_hip_comparison.py) |
| 后续录像索引 | [来源解码、选帧与缓存](../scripts/validation/render_stage_media.py)、[阶段图册](reports/stage-video-gallery.html)、[合并全部录像](../scripts/validation/build_all_video_overview.py)、[单张总览](reports/assets/all-video-overview.jpg) |
| 髋目标与限位分析 | [analyze_hip_saturation.py](../scripts/validation/analyze_hip_saturation.py)，只复算保存的轨迹，不启动仿真或学习 |
| 训练草案 | [next_training.json](../configs/experiments/next_training.json) |
| 动作课程与门槛 | [motion_curriculum.json](../configs/experiments/motion_curriculum.json) |
| 运行名称映射 | [run_catalog.json](../configs/experiments/run_catalog.json) |

其余脚本用于已记录的安装、性能诊断、旧实验复现或专题分析。保留路径可以使记录中的源码、模块导入和命令继续有效；当前入口集中到任务菜单，避免逐个尝试历史脚本。

## 共同释放诊断

仰卧支撑转换的复算、伸膝草案和准入检查集中在[伸膝诊断](../records/reports/getup-knee-support/README.md)。

起身起点的前缀复盘、零步停止、场景适配和记录集中在[释放状态索引](../records/reports/getup-shared-release/README.md)。

首次头腿接触后的配对轨迹、支撑几何和复算入口集中在[仰卧接触与转正](../records/reports/getup-contact-entry/README.md)。

## 报告与历史

[主报告](reports/development_report.md)组织当前操作和结论，[完整过程记录](reports/development_history.md)保留此前所有过程，[步态图册](reports/training-gait-gallery.html)保存逐段关键帧。原稿字节备份和整理清单在 `records/reports/project-organization/`；备份用于校验，不作为相对链接的阅读入口。

HTML 使用原始图片和视频的相对路径、延迟加载与播放控件。分享或迁移需带上被引用的目录，不能只复制 HTML。主报告不再重复内嵌全部历史录像。

## 保留与清理

清理以实际路径、哈希、恢复依赖和证据用途为依据。纯清单提到一个文件名不自动要求永久保留；真正用于评估、恢复或审计的文件不能直接删除。先保存清理清单，再检查路径属于 XGO-Duck 或专属 Linux 目录，最后核验结果。

不清理兄弟工程、官方归档、未知用途的用户文件或正在写入的记录。此前被自动审批拒绝删除的临时浏览器目录保留待处理，不重复执行相同删除。虚拟环境和可复用下载缓存不是失败训练结果。


共同环境回归与诊断继续沿用现有目录：`common_plant_screen.py` 及其冻结协议保留原字节；`review_common_plant_screen.py` 复算已保存失败，`inspect_common_recovery_contacts.py` 只做 CPU 接触几何核对，`render_common_plant_review.py` 绘制真实轨迹。`getup_contact_isolation.py` 为有界碰撞规则诊断，零步启动姿态修复单列在 `recover_getup_contact_release.py`。记录分别在 `records/reports/common-plant-screen/`、`getup-contact-isolation/` 与 `getup-contact-release-recovery/`，旧失败不覆盖。

起身适配接口在 `scripts/training/getup_model_coordinates.py`，CPU 检查在 `scripts/validation/check_getup_model_coordinates.py`，结果在 `records/reports/getup-adaptation/`。`getup_collision_adaptation_draft.json` 尚未冻结，不可据其自动启动训练。六帧重放入口为 `render_getup_contact_replay.py`，来自原始完整状态、没有新增物理步；实际接触和姿态一致性由 `verify_getup_contact_diagnosis.py` 独立核对。

颈部归位顺序的完整录像、分组成绩和全样本复盘见[阶段证据索引](../records/reports/getup-neck-home-order/README.md)。`scripts/validation/review_getup_neck_home_order.py` 只读取保存轨迹；已冻结的采样器和控制器保持原字节。

全身目标审计及下一项训练准备见[证据索引](../records/reports/getup-target-feasibility/README.md)，共同接口价值起点见[价值预检](../records/reports/getup-interface-value/README.md)。分析、训练目标和只读恢复入口均位于既有 `scripts/validation/`、`scripts/training/`，旧冻结文件未修改。

末段可达目标训练的代码、预算、独立评价和完整动作录像见[证据索引](../records/reports/getup-late-feasibility/README.md)。`review_getup_late_feasibility.py`只读取已保存轨迹并提取原片关键帧；原片不剪短，图册显示时间范围、帧数和帧率。

早期支撑审计和单一解困对照分别见[保存数据索引](../records/reports/getup-early-support/README.md)与[动态对照索引](../records/reports/getup-early-guard/README.md)。完整11秒原片、保存状态回放和实际事件截图单列；`render_getup_early_guard_events.py`只解码已有视频，不新增机器人状态。已关闭入口归入任务历史。S4准备使用`check_roll_batched_import.py`与`roll_common_confirmation_draft.json`，草案尚不可执行。

官方滚翻扩大确认与随机状态修复见[结果索引](../records/reports/roll-common-confirmation/rng-recovery/README.md)，主目录保留原零步失败。`collect_roll_confirmation.py`保存完整首次轨迹，`verify_roll_confirmation.py`独立复算，`recover_roll_import_rng.py`只保护导入随机状态；三者冻结后不改。下一项起身方向见[累计漂移](../records/reports/getup-policy-drift/README.md)和[成功动作保持准备](../records/reports/getup-teacher-anchor/README.md)，数据、辅助目标与正式训练准入分开记录。


当前起身阶段的[统一索引](../records/reports/getup-teacher-anchor-pair/README.md)集中列出训练、固定评价、完整录像和复核命令；[价值准入](../records/reports/getup-anchor-value-check/scale-recovery/README.md)单列零更新测量。新奖励仅为`configs/experiments/getup_persistent_contact_draft.json`草案，不能按它启动动态任务。
