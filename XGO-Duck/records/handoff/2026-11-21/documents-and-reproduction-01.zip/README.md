# XGO-Duck

在VS Code打开当前训练记录，可查看最近训练与评估的状态、曲线、日志和完整录像。[当前训练记录](records/training-current.md) · [当前目标](docs/current_goal.md) · [全流程报告](docs/reports/development_report.html)

训练已暂停。标称连续动作已有独立仿真结果。当前工作为阶段归档和已装配官方套机的零点、站姿与飞智黑武士4Pro遥控准备。[阶段归档与下载](records/handoff/2026-11-21/README.md) · [真机首次部署手册](docs/runbooks/xgo_duck_first_deployment_and_vader4pro.md)

## 从这里开始

| 入口 | 用途 |
| --- | --- |
| [当前训练记录](records/training-current.md) | 在VS Code查看正在运行或已完成的训练、采样曲线、完整原片和日志 |
| [标称连续动作](records/reports/nominal-skill-composition/README.md) | 起身、站立和滚翻的同场景评分、七指令入口、原片与下一轮对照 |
| [暂停归档](records/reports/pause-archive-20261116-monitored/README.md) | 保存当时的结果、模型、归档范围及恢复顺序 |
| [固定路径性能对照](records/reports/getup-canonical-path-20261116/README.md) | 实际耗时、修改原因、完整录像与数值差异 |
| [历史训练过程对照](records/reports/historical-getup-training-comparison/README.md) | 两组起身训练的逐次曲线、显卡采样、实际录像和动作结果 |
| [真实训练观察与吞吐](records/reports/getup-observed-throughput-20261116/README.md) | 本次实际指标、完整录像、来源、错误修复与等样本比较 |
| [七指令留出观察](records/walk-forward-yaw-direction-holdout-live.html) | 查看实际进度、吞吐曲线和原片 |
| [权重与迭代记录](artifacts/delivery/iteration_record.md) | 官方模型、自训 ONNX、对应最终保存点及每阶段结果 |
| [全流程报告](docs/reports/development_report.html) · [Markdown](docs/reports/development_report.md) | 当前进展、环境部署、操作步骤、修改原因、结果、截图和视频 |
| [当前目标](docs/current_goal.md) | 本轮阶段、预算、验收和执行约束 |
| [目标历史记录](docs/current_goal_history.md) | 整理前的完整原文，状态以当前目标为准 |
| [暂停进度与归档](records/reports/pause-archive-20261115/README.md) | 暂停时的阶段结论、模型、录像和带哈希的快照；当前状态以目标页为准 |
| [当前进度补充归档](records/reports/progress-archive-20261114/current-state/README.md) | 最新目标、报告和离线检查快照 |
| [训练归档完整文件清单](records/reports/progress-archive-20261114/training-files/README.md) | Windows 训练归档的逐项路径、大小及 SHA-256 |
| [WSL 训练日志归档](records/reports/progress-archive-20261114/wsl-training-logs/README.md) | 原始日志核验、未匹配资料归档及历史曲线查看 |
| [训练资料存储盘点](records/reports/storage-review-20261114/README.md) | 文件大小、重复内容、保留理由和清理记录 |
| [归档完整性检查](records/reports/archive-integrity-followup/README.md) | 区分历史快照、当前文件变化与大文件缺失 |
| [滚翻参数配置核验](records/reports/roll-factor-configuration/README.md) | 标称、低摩擦和高电压配置的实际字段差异与边界 |
| [参数筛查初态复核](records/reports/roll-s20-saved-startup-review/README.md) | 零步与采样起点、接触及摩擦字段的保存数据对照 |
| [参数对照初态审计](records/reports/matched-start-source-audit/README.md) | 构造与重置种子、未保存状态和源码范围 |
| [电机力限值检查](records/reports/force-limit-guard/README.md) | 零步入口的限值与源码检查，以及真实运行边界 |
| [摩擦字段精确校验](records/reports/roll-selective-friction-guard/README.md) | 静态及重置后的摩擦字段检查与运行边界 |
| [参数与场景守卫适配](records/reports/roll-factor-guard-adapter/README.md) | 假环境中的调用、错误停止和未完成的真实验证 |
| [暂停后的有界入口](records/reports/roll-domain-parameter-random-s20/guarded-entry.md) | 停止判定、准入测试和未完成的 CUDA／参数验证 |
| [阶段验收矩阵](records/reports/stage-acceptance-matrix/index.html) · [文字版](records/reports/stage-acceptance-matrix/README.md) | S2–S6 源 JSON 计数、连续路线、失败证据和开放门槛 |
| [滚翻阶段扰动复盘](records/reports/roll-phase-perturbation-review/index.html) · [文字版](records/reports/roll-phase-perturbation-review/README.md) | S12–S14b 机制复盘、关键帧、原片和准入审计 |
| [全阶段路线](docs/development_roadmap.md) | 已完成、每轮改动与结果、观察方式和后续验收 |
| [工程导航](docs/project_structure.md) | 每类文件放在哪里，哪些入口日常使用，哪些是历史证据 |
| [训练产物保留索引](records/reports/training-curation/README.md) | 按动作选模型、定位恢复点、查看清理依据 |
| [训练记录归档](records/training-archive/README.md) | 中间产物的实体位置、核验和历史路径恢复 |
| [完整过程记录](docs/reports/development_history.html) · [Markdown](docs/reports/development_history.md) | 原始安装、训练、诊断及媒体时间线 |
| [训练操作手册](docs/runbooks/pc_training.md) | 详细安装和恢复命令；历史训练命令按当时条件理解 |
| [全部录像总览](docs/reports/assets/all-video-overview.jpg) | 历史与当前阶段的原片和标注帧 |
| [早期步态总览](docs/reports/training-gait-overview.jpg) · [逐段图册](docs/reports/training-gait-gallery.html) | 较早 131 段训练、评估录像的真实关键帧与标注 |
| [阶段录像总览](docs/reports/assets/stage-video-overview.jpg) · [逐段索引](docs/reports/stage-video-gallery.html) | 后续髋诊断、官方初始化、速度对照与起身评估的真实录像 |

## 当前操作

使用VS Code查看本地留档。打开[当前训练记录](records/training-current.md)，按`Ctrl+Shift+V`预览目录，再选择本轮状态、曲线、实景或完整原片。模型入口集中在[权重与迭代记录](artifacts/delivery/iteration_record.md)。

滚翻开发与留出各 117/128，均通过单动作门槛。接触读数与当前姿态对齐，官方权重保持原样。 [滚翻结果与原片](records/reports/roll-endpoint-confirmation/README.md)

需要恢复运行时，先确认用户指令和[当前目标](docs/current_goal.md)中的观察、来源及阶段条件。七指令练习会创建独立协议与录像，不覆盖历史；当前可复用模型和控制器见[仿真包](artifacts/simulation/duck_walk_command-gyro_reference_20261103/README.md)。

日常入口是 [training_workflow.sh](scripts/training/training_workflow.sh) 和 [.vscode/tasks.json](.vscode/tasks.json)。历史编号任务放在 [vscode_tasks_history.json](configs/environments/vscode_tasks_history.json)，不重复启动旧长训练。

## 工程目录

```text
XGO-Duck/
├── docs/                 操作说明、报告、图片和专题研究
├── configs/              实验协议、环境及显示偏好
├── scripts/              setup / training / validation
├── records/              部署、实验、评估、性能和核验证据
├── artifacts/            最终 ONNX、模型清单和恢复副本
├── workspace/            运行状态、下载缓存与固定参照副本
├── official_resources/   不修改的官方源码和快照
├── project.json          机器可读状态
└── AGENTS.md             项目约定
```

Linux 训练副本为 `/home/atlas/XGO-Duck/workspace/xgoduck_rl`，项目缓存为 `/home/atlas/XGO-Duck/cache`。本机实测 GPU 是 RTX 3080 Laptop 16 GB；Ubuntu 24.04 是本机选择，官方训练说明未指定这一发行版。依赖按官方锁文件恢复，下载优先镜像。

## 专题资料

- [官方来源与恢复](official_resources/README.md)：固定提交、逐文件哈希与快照。
- [开发路线](docs/development_roadmap.md)、[部署研究](docs/rl_deployment_plan.md)：长期路线和策略接口。
- [硬件与配件](docs/hardware_and_accessories.md)：供电、相机、音频与 ToF。
- [相机适配](docs/camera_fit_analysis.json)、[相机与语音选型](docs/camera_voice_selection.json)：既有尺寸研究和待定项。
- [官方策略接口](docs/policy_contract_report.json)：原归档 ONNX 结构记录。
- [项目状态](project.json)：最新执行状态；历史记录不作为自动恢复指令。

报告页面使用相对路径加载原始媒体。离线阅读或换电脑时，请保留 XGO-Duck 的目录结构；不要只复制 HTML。训练环境、模型和缓存不随普通源码 Git 恢复，具体边界见官方归档说明及工程导航。
