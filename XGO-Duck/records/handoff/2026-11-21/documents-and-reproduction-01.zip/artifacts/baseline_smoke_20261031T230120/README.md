# 短训练模型

本包用于电脑端训练、导出和仿真流程验证，尚未验证稳定行走或实机部署。

- `policy.onnx`：导出策略。
- `manifest.json`：来源、训练设置与检查路径。
- `contract.json`：实际导出接口与待对齐项。

实验报告见项目的 `docs/reports/pc_pipeline_validation.md`。
