# 行走仿真参照

此包保留官方 ONNX 原字节，并加入固定输入映射与转向 gyro 反馈。适用于已记录的行走仿真环境；没有执行真机部署。

在现有环境中，将本目录的三个 Python 文件放在同一导入路径。调用 `walking_command_controller.create_controller(num_envs, 0.02)`；每个控制步用 `controller.map(desired_commands, actor_observations)` 得到第 48–50 项指令输入，再进行 ONNX 推理。其余观测保持原义。

原始输出保存为下一步动作历史；物理目标为模型元数据 HOME 加原始输出。重置相应环境时清零动作历史，并调用 `controller.reset(env_ids)`。切勿将已滤波目标写入原始动作历史。

安装、VS Code 练习入口、三种子结果和原始视频见工程中的 `docs/reports/development_report.md`。完整接口及来源哈希见 `contract.json`。后续共同物理环境、技能切换和官方运行程序的动作滤波仍须验证。
