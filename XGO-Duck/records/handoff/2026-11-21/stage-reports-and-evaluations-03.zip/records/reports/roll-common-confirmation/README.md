# 滚翻确认记录

扩大确认已结束，见[完整结果与复核入口](rng-recovery/README.md)：开发117/128、116/128，留出112/128，可靠性确认未通过，关闭不追加。

本目录保留首次CPU准入、启动器换行修复及GPU零步随机状态失败。父协议只执行到0物理步，保持原87份冻结来源；独立88份来源修复及384个首次episode存于`rng-recovery/`，没有覆盖原失败。

| 文件 | 用途 |
| --- | --- |
| [原协议](../../../configs/experiments/roll_common_confirmation.json) | 原87份来源，零步失败后关闭 |
| [CPU输入核验](cpu-import-check.json) | 512组旧滚翻真实观测，官方ONNX与批量导入数值比较 |
| [完整CPU准入](preflight.json) | 原32次评分复算、边界与场景字段 |
| [启动换行修复](launcher-repair.json) | Python前退出，统一LF并通过Bash检查 |
| [GPU零步关闭](startup-failure-analysis.json) | 实际物理、学习和开发episode均为0 |
| [随机状态根因](rng-root-cause.json) | CPU spy确认原导入函数调用CUDA全设备设种子 |
| [独立修复与结果](rng-recovery/README.md) | 原断言保留，三种子完整9秒评价与关闭结论 |

真机运行后置，旧轮次不重新执行。全部目标和后续训练入口以[当前目标](../../../docs/current_goal.md)为准。
