# 仰卧释放加权训练

从已训练的起身检查点启动两组等预算训练。候选仅把实际仰卧释放后首秒的 PPO 策略损失权重从 1 提高到 2。两组保留相同的物理、奖励、观测、价值损失和成功动作保持约束。 [同一释放结果](../getup-anchor-same-release/README.md) · [训练草案](../../../configs/experiments/getup_supine_weighted_learning_draft.json)

| CPU 检查 | 结果 |
| --- | --- |
| 检查点 | 41 次父模型更新。恢复 actor、critic、固定归一化和 Adam 状态，两个 Adam 计数分别为 620 和 870 |
| 推理 | 使用 320 个实际释放观测与已导出的 ONNX 对比，最大动作差 1.31×10⁻⁶ rad |
| 仰卧分类 | 320 个保存状态逐场景一致。实际仰卧 171 次，仅在从 0 计数的控制年龄 100–149 进入加权窗口 |
| 优化器 | 权重为 1 或无加权样本时，更新与原 PPO 一致。含 280 个仰卧加权样本的 CPU 临时批次只改变 actor，critic、Adam 的价值部分和回放采样保持一致 |
| 场景 | 两组使用相同的 512 环境配置，四个指定起始姿态各 128 个，33 项静态场景字段与父实验一致 |

训练种子为 45，独立开发评价种子为 1057。每组 50 次更新，24 步 × 512 环境，最多 614,400 条学习转移。评价继续使用四姿态覆盖、第 8 秒前开始持稳以及末段连续持稳门槛。正式训练前，两组实际 GPU 初始物理状态、随机数和父模型优化器状态已核对。 [检查点核验](checkpoint-preflight.json) · [优化器核验](optimizer-preflight.json) · [冻结协议](../../../configs/experiments/getup_supine_weighted_learning.json) · [GPU 零步核验](zero-step/verification.json)

在原 VS Code 的 `Terminal → Run Task…` 选择 `XGO-Duck · 仰卧释放加权成对训练`。任务复用共享终端，运行日志保存在本目录。首次操作使窗口短暂恢复为 1202×802，正式启动前已恢复原位置及 1707×1019 边界。 [任务日志](execution.log) · [窗口记录](terminal-layout.json)

![训练终端](../../../docs/reports/assets/getup-supine-weighted-terminal.jpg)

## 实际训练

两组均完成 1,200 个批量控制步、6,000 个物理子步。起点的两套 Adam 状态一致，累计训练步和实际仰卧窗口由独立核验器从存档复算。两组第一轮释放时的仰卧计数相差一次，后两轮的计数一致。后续用共享释放快照对照模型表现。

| 分支 | PPO 更新 | 训练转移 | 窗口内样本 | 成功样本末次 RMS |
| --- | ---: | ---: | ---: | ---: |
| 等权对照 | 50 | 614,400 | 38,650 | 0.03976 rad |
| 仰卧加权 | 50 | 614,400 | 38,700 | 0.03777 rad |

等权组也记录仰卧窗口，损失权重保持 1。两段训练原片均从初始跌落录至重置前终态，覆盖完整 8 秒、25 fps、201 帧。 [等权对照核验](control-training-verification.json) · [仰卧加权核验](candidate-training-verification.json) · [等权对照原片](../../experiments/duck_getup_supine-weighted_control_s45_20261109T211329/clip-step-0.mp4) · [仰卧加权原片](../../experiments/duck_getup_supine-weighted_candidate_s45_20261109T211329/clip-step-0.mp4)

![成功样本动作偏差](../../../docs/reports/assets/getup-supine-learning-drift.png)

## 独立评估

三模型共用前 2 秒的实际跌落及 345 项释放状态。各自从同一释放状态运行至 11 秒，三组共采集 464,000 条评估转移、7,250 个物理子步。每组各场景的及时起身和末段持稳判定一致。表中按指定姿态和实际释放姿态分开计数。 [独立结果](analysis.json)

| 分组 | 父模型 | 等权对照 | 仰卧加权 | 至少通过 |
| --- | ---: | ---: | ---: | ---: |
| 总体 | 303/320 | 302/320 | 310/320 | 304 |
| 指定俯卧 | 32/32 | 32/32 | 32/32 | 31 |
| 指定仰卧 | 27/32 | 26/32 | 30/32 | 31 |
| 指定左侧 | 123/128 | 124/128 | 125/128 | 122 |
| 指定右侧 | 121/128 | 120/128 | 123/128 | 122 |
| 实际俯卧 | 32/32 | 32/32 | 32/32 | 31 |
| 实际仰卧 | 170/186 | 173/186 | 180/186 | 177 |
| 实际左侧 | 61/61 | 61/61 | 61/61 | 58 |
| 实际右侧 | 40/41 | 36/41 | 37/41 | 39 |

实际仰卧中，加权模型相对等权组挽回 11 次、损失 4 次，净增 7 次。两组续训的实际右侧均少于父模型。加权模型未保住父模型的 3 次实际右侧和 2 次指定仰卧，相关失败都在第 3 秒时或之前出现头腿接触，且末段仍有头腿接触和倾角超限。加权候选仍未通过两项姿态门槛，本协议关闭，无模型进入独立确认。 [逐场景复盘](mechanism-review.json)

两个开发种子的父模型成功样本提供 900 条观测，其中 576 条来自 96 次实际右侧，324 条来自 54 次指定仰卧。保存动作与父模型 ONNX 一致。按观测右侧选择父模型的离线拼接估计可恢复实际右侧至 40/41，指定仰卧仍为 30/32。下一组拟在同一加权检查点上单独测试动作保持约束，使用新的训练和评价种子。 [样本复盘](recovery-retention-audit.json) · [回放检查](../getup-recovery-retention/replay-preflight.json) · [训练草案](../../../configs/experiments/getup_recovery_retention_draft.json)

## 完整评估原片

每段为 25 fps、276 帧，覆盖 0–11 秒。仰卧环境 0 为预先固定机位，父模型和等权组失败，加权组通过。指定右侧的录像实际释放为仰卧，按真实姿态标注。 [逐段图册](../../../docs/reports/stage-video-gallery.html)

| 分支 | 指定姿态 | 实际释放 | 原片 |
| --- | --- | --- | --- |
| 父模型 | 仰卧 | 仰卧 | [环境 0](../../evaluations/duck_getup_supine-weighted_paired_s1057_20261109T211329/evaluation-fixed-parent-supine/clip-step-0.mp4) |
| 等权对照 | 仰卧 | 仰卧 | [环境 0](../../evaluations/duck_getup_supine-weighted_paired_s1057_20261109T211329/evaluation-unweighted-continuation-supine/clip-step-0.mp4) |
| 仰卧加权 | 俯卧 | 俯卧 | [环境 7](../../evaluations/duck_getup_supine-weighted_paired_s1057_20261109T211329/evaluation-supine-weighted-continuation-prone/clip-step-0.mp4) |
| 仰卧加权 | 仰卧 | 仰卧 | [环境 0](../../evaluations/duck_getup_supine-weighted_paired_s1057_20261109T211329/evaluation-supine-weighted-continuation-supine/clip-step-0.mp4) |
| 仰卧加权 | 左侧 | 左侧 | [环境 3](../../evaluations/duck_getup_supine-weighted_paired_s1057_20261109T211329/evaluation-supine-weighted-continuation-left-side/clip-step-0.mp4) |
| 仰卧加权 | 右侧 | 仰卧 | [环境 1](../../evaluations/duck_getup_supine-weighted_paired_s1057_20261109T211329/evaluation-supine-weighted-continuation-right-side/clip-step-0.mp4) |

## 复查命令

实际入口为 `bash scripts/training/training_workflow.sh getup-supine-weighted-learning`，已归档到 VS Code 任务历史。协调器在运行中依次调用 `--verify-training` 和 `--verify-evaluation`。这两个入口有阶段守卫。若在隔离工作副本复查原 CPU 准入，可从 WSL 工程根目录使用以下命令。

```bash
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/check_getup_supine_parent.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/check_getup_supine_ppo.py
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/prepare_getup_supine_training.py
```

当前工程的训练曲线和逐场景失败可通过 `scripts/validation/review_getup_supine_learning.py` 复算，物理步为零。
