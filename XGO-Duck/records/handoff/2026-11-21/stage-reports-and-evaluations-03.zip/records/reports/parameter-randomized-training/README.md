# 参数随机化起身训练前置核验

本阶段把上一轮固定策略端点证据转成 PPO 训练前置条件。父策略、观测、动作历史、HOME、奖励和控制周期保持不变，只准备两组环境配置：

| arm | 脚底摩擦范围 | 供电范围 | GPU 零步显存 |
| --- | --- | --- | ---: |
| nominal control | 1.0–1.0 | 7.7–7.7 V | 4,522 MiB |
| randomized candidate | 1.0–1.3 | 7.4–7.7 V | 4,862 MiB |

CPU 配置预检和两个 GPU 零步均通过。两组都保持 0.004 s 物理步、0.02 s 控制步、5 倍 decimation，actor/critic/action 形状分别为 61、75、14；没有物理步、学习更新或硬件输入。candidate 的显存占用约 29.7%，低于 85% 上限。

## 证据

- [CPU 配置预检](preflight.json)
- [GPU 零步汇总](zero-step-summary.json)
- [8 次更新指标摘要](metrics-summary.json)
- [训练草案](../../configs/experiments/parameter_randomized_getup_training_draft.json)
- [冻结 8 次更新协议](../../configs/experiments/parameter_randomized_getup_training.json)
- [末次模型回归草案](../../configs/experiments/parameter_randomized_getup_regression_draft.json)
- [预检失败归档](preflight-failures/README.md)

运行冻结的同父点、同 seed、同环境数和同 196,608 条转移预算的 nominal/candidate 对照，记录了首个 PPO 更新的显存、逐次曲线和真实片段。训练结果仍需回到原四姿态起身、滚翻和七指令连续门槛；任何后续延长都必须沿用当前 checkpoint 和同一协议。

8 次更新已完成，candidate 与 control 各 196,608 条转移、960 个物理子步。candidate 末次稳定率 93.75%、drift RMS 0.03450 rad、最大 drift 0.13657 rad、最大显存 30.73%；control 分别为 91.89%、0.03454 rad、0.14318 rad、34.34%。两组最大 KL 都约 0.0084，均未触发 85% 显存上限或 drift 守卫。完整指标、checkpoint、ONNX 和原始 3.84 秒片段保留在各自实验目录：

- candidate：[实验记录](../../experiments/duck_getup_parameter-randomized_candidate_s1201_20261113T230043/README.md) · [视频](../../experiments/duck_getup_parameter-randomized_candidate_s1201_20261113T230043/clip-step-0.mp4) · [ONNX](../../../artifacts/duck_getup_parameter-randomized_candidate_s1201_20261113T230043/policy.onnx)
- control：[实验记录](../../experiments/duck_getup_parameter-randomized_control_s1201_20261113T230114/README.md) · [视频](../../experiments/duck_getup_parameter-randomized_control_s1201_20261113T230114/clip-step-0.mp4) · [ONNX](../../../artifacts/duck_getup_parameter-randomized_control_s1201_20261113T230114/policy.onnx)

这些是短预算训练过程结果，尚不能说明动作门槛改善；下一步对两个末次模型做原四姿态起身和连续滚翻/七指令回归，再决定是否延长预算。
