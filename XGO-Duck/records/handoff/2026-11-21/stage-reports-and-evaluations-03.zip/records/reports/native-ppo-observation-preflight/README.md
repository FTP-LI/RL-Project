# PPO 本机观察接线

用户已恢复全阶段目标。这里准备下一次训练的本机观察与回调接线，当前检查只使用合成状态、历史录像副本和测试子进程，没有启动新训练、物理仿真或真机操作。此项尚未完成真实训练验收。

## 已准备的功能

[本机 PPO 观察桥](../../../scripts/training/native_ppo_observation.py)读取训练器刚写入的 `state.json` 和 `observation.json`，核对运行名称、更新数、采样步数、来源时间和本轮媒体路径，再交给独立观察进程。观察页文件可以在 VS Code 中打开，显示运行状态、回报、策略损失、价值损失、采样速度、最新画面与完整动作录像路径。尚无实际指标或录像时会显示等待状态。

[起身训练回调接线](../../../scripts/training/native_getup_ppo_hooks.py)在独立进程内临时接入现有起身 PPO 工作器的发布和检查回调，保留原有显存及异常检查；历史冻结源码没有修改。每次检查回调都会检查暂停授权和观察进程是否退出，观察健康文件最多缓存 1 秒。来源过期、观察器退出、记录长期无进展、暂停或协议条件改变时，回调发出停止异常，具体异常保存由训练器负责。

观察进程只负责显示和发出拒绝条件，不能凭自身终止挂在 GPU 调用中的训练进程。训练器必须定期调用检查回调，实际动作偏离还需要原有的姿态、关节和动作专用守卫。[观察桥测试](fixture-verification.json) · [真实工作器回调测试](hook-verification.json)

新增的[外层监督器](../../../scripts/training/supervised_ppo_process.py)可检查冻结命令、项目暂停标记、训练锁、来源心跳、实际控制步和更新数，以及启动和运行时间上限。若需要停止，先向它持有的工作进程请求中断；超时后才终止该工作进程所属的独立进程组。标准输出和错误、停止原因、信号、退出码及日志哈希都写入本轮记录。进程正常退出本身不代表动作或保存点验收通过。

测试中使用合成工作进程，其中一项连接了实际观察子进程：即使观察心跳持续刷新，控制步长期不变仍会触发停止；测试还覆盖锁冲突、命令与冻结方案不符、暂停、来源损坏及强制退出。新增的 [WSL 父进程退出联动](../../../scripts/training/parent_exit_exec.py)通过隔离测试：强制结束合成监督进程后，测试工作进程退出、锁被释放，且没有伪造完成回执。22 项检查均通过，测试没有产生物理步或学习更新。[检查结果](parent-exit-verification.json) · [测试输出](parent-exit-fixture-logs.txt)

此前用实际监督器和观察子进程连接合成工作进程，强制结束监督器后：工作进程约 0.004 秒内停止；观察器仍保留上一状态，约 32.93 秒后才提示来源过期并退出。该次源码和记录已保留。 [原检查记录](observer-parent-loss-verification.json) · [原源码与记录快照](observer-parent-loss-snapshot.zip) · [快照清单](observer-parent-loss-snapshot.json)

现在观察桥会向观察器传入工作进程编号；观察器在每次刷新前后核对父进程，发现工作进程退出时立即写入异常状态，原有来源过期检查仍保留。三次合成进程测试中，监督器强制退出后，观察器分别在 1.86、1.97、1.86 秒后标记异常并退出。正常观察和停止回调的 17 项检查、监督器的 22 项回归检查均通过；错误编号、缺少编号、来源过期以及刷新前后退出也已检查。 [检查结果](observer-owner-guard-verification.json) · [监督回归](owner-guard-supervisor-check/parent-exit-verification.json) · [源码与记录快照](observer-owner-guard-snapshot.zip) · [快照清单](observer-owner-guard-snapshot.json)

上述耗时是本机合成进程的测量，并非对任何负载的保证；若观察器本身卡在渲染中，它不能在渲染返回前检查。测试没有取得被重挂观察器的退出码，也没有运行真实 PPO 或 GPU。真实训练中的观察延迟、异常停止和保存点仍需单独验收。

该联动使用 Linux 父进程退出信号；信号与创建子进程的父线程有关，权限变化等情况可能清除设置，因此入口要求 WSL 主线程、检查可执行文件并在启动前后核对父进程。子进程若改变信号处理方式，也可能影响效果。实际 PPO 工作进程、系统挂起和异常后的保存点仍未验收，不能把合成测试当作真实训练保证。参见 [Linux 父进程退出信号](https://man7.org/linux/man-pages/man2/PR_SET_PDEATHSIG.2const.html) 和 [Python 子进程接口](https://docs.python.org/3/library/subprocess.html)。

此前 20 项检查及当时的源码保存在[原记录](supervisor-verification.json)和[源码快照](supervisor-pre-parent-exit.zip)中；[快照清单](supervisor-pre-parent-exit.json)记录各文件哈希。当前源码与当时不同，因此核验旧记录应读取快照中的源码。

新训练方案须为每个运行编号冻结完整的 `supervisor_workers` 命令，并记录 `supervisor_sha256`、`parent_exit_guard_sha256` 及观察桥和观察器源码哈希；启动、停滞、心跳和总时间上限需按实际训练速度设置。监督器持有 `~/XGO-Duck/training.lock`，经联动入口传给 Python 工作进程，因此命令不应再次套用同一把 `flock`；否则会互相等待或被拒绝。这个监督器仍须接入新训练协调入口，并在真实运行前验证用户能看到该运行的观察文件。

## 当前入口边界

用户恢复目标后，已新增统一起身入口，将上述观察器、监督器和工作器接在一起，并通过 31 项合成进程检查。它还补上了短任务结束时遗漏最终曲线的问题；真实训练、实际 CUDA 零步及桌面观察仍未验收。旧入口核对反映的是接线前状态。[新入口与检查](observed-entry-check/README.md)

已只读核对历史入口：短训脚本会启动学习，但未检查本项目当前暂停标记，也没有接入上述观察桥和监督器；七指令练习会启动新动态仿真。两组旧起身运行编号已经使用，`next_training.json` 已关闭。现有部件尚未组成经真实训练验收的完整入口；恢复后应另建运行、冻结新方案，并核验本次观察方式和 CUDA 零步。[入口核对](entry-audit.json) · [核对结果](entry-audit-followup-verification.json) · [核对前源码快照](entry-audit-source-snapshot.zip) · [快照清单](entry-audit-source-snapshot.json) · [操作条件](../../../docs/runbooks/pc_training.md#恢复前先检查什么)

## 保存点边界

已在 CPU 上只读检查交付目录内 8 份训练保存点和 1 份教师约束研究保存点：9 份均可按安全加载模式读取，均含策略、价值网络和优化器状态，上述网络及优化器中的浮点张量均为有限值。8 份带独立来源路径的文件与来源字节一致；教师约束保存点与原记录哈希一致，但原记录没有列出单独的来源副本。6 份有明确命名的随机数状态字段；另 3 份在本次遍历的字典字段中未发现随机数状态字段。[内容与哈希](delivery-checkpoint-contents-checked.json)

对其中五个当前仿真组件，按各自网络结构在 CPU 加载策略、价值网络和 Adam 优化器，并检查优化器矩阵形状。每个策略分别使用 32 条已保存观测与对应 ONNX 对照，最大输出差不超过 1.08×10⁻⁶；没有执行优化步骤。[加载检查](delivery-checkpoint-cpu-loader-checked.json)

| 组件 | 已完成更新 | 策略输入维度 | 价值网络输入维度 |
| --- | ---: | ---: | ---: |
| 行走基础 | 42 | 61 | 77 |
| 行走右转 | 14 | 61 | 77 |
| 起身回退 | 17 | 61 | 76 |
| 起身仰卧 | 17 | 61 | 76 |
| 起身右侧 | 17 | 61 | 75 |

价值网络输入维度不同，恢复时要使用对应训练配置和模型结构。上述检查仅证明指定 CPU 模型和优化器状态能够加载、选定观测上的策略输出与 ONNX 一致；没有执行恢复后的训练或物理采样。本次遍历没有发现名为 `qpos`、`qvel`、`actuator_state` 或 `delay_state` 的保存字段，也不能据此声称能从原物理轨迹精确续跑。两个检查脚本的合成加载失败均返回非零状态；此前内联测试命令曾在 shell 解析时失败，没有执行检查，随后使用独立脚本完成测试。[失败退出核验](delivery-checkpoint-failure-exit.json) · [检查源码与记录快照](delivery-checkpoint-audit-checked.zip) · [快照清单](delivery-checkpoint-audit-checked.json)

在 Windows 项目根目录的终端中，可以用已安装的 WSL 环境自行重复五个主要组件的 CPU 加载检查。命令不启动训练；它会写入一个新的检查结果，如果目标文件已存在，请换一个文件名。

```powershell
wsl -d Ubuntu-24.04 -- /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/inspect_delivery_checkpoint_loader.py /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/records/reports/native-ppo-observation-preflight/delivery-checkpoint-cpu-loader-personal.json
```

对一份历史中断保存点做了 CPU 只读复核。最后公开的完整更新为 42 次，策略和价值优化器分别完成 603、840 步；`stopped-partial.pt` 同样写着完成 42 次，但计数已变成 609、846，说明第 43 次更新已执行部分优化。此前的 `model-25.pt` 与第 25 次完整更新计数一致。这些保存点属于已关闭试验，不自动恢复。[原始计数与哈希](checkpoint-boundary-review.json)

该历史部分点没有保存名为 `qpos`、`qvel`、执行器状态或延迟状态的完整物理现场，不能用它声称会从中断的物理轨迹原样续跑。后续新训练须明确区分完整更新保存点、部分优化保存点与完整物理状态；中断后先核对模型、优化器、随机数、计数和场景状态，再决定恢复方式。现有自适应 PPO 代码在优化器异常时包含回滚逻辑，但本次没有在真实 GPU 训练中注入观察器故障，不能将它视为已经验收的断点恢复。

## 检查范围

两项测试分别使用实际观察子进程和现有起身工作器的发布、检查回调，覆盖项目暂停、编号不匹配、过期数据、媒体越界、未完成录像、进度倒退、停滞、观察器退出和回调恢复。测试数据在运行名称和用途中明确标注“非训练”；所有测试副本结束后已清理。历史保存点复核单独读取真实文件，未改变文件内容。四份既有训练源码与原冻结方案中的哈希一致。[源码核验](source-audit.json)

恢复训练前还需要冻结新的训练方案、在实际运行前验证用户可以打开该运行的本机观察文件，并验证真实训练中的进度、动作录像、暂停和异常退出。现有停止接线不等于完整训练验收，也不授权重启任何已关闭试验。
