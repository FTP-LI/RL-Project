# 训练入口接线

用户恢复目标后，新增了[统一起身入口](../../../../scripts/training/observed_getup_entry.py)，把已有工作器、本地文件观察和外层监督器接在同一运行下。当前完成的是隔离进程检查，没有执行新的真实训练、CUDA 零步或动态仿真。

## 入口做什么

| 环节 | 行为 |
| --- | --- |
| 运行前 | 核对当前阶段与暂停标记、独立运行名称、新冻结方案、继承配置内的源码清单及 WSL 依赖。 |
| 零步证据 | 检查证据对应本次运行、有效训练配置和源码；核对初始模型与初态文件哈希。旧试验的零步记录不能直接复用。 |
| 开始观察 | 先启动本机文件观察器，显示本次运行的状态；确认记录必须对应当前进程、运行名称和截图。尚未确认时不导入训练工作器。 |
| 开始训练 | 由监督器持有训练锁并启动工作器，保留原有采样、显存、动作和优化器检查；不改变旧冻结脚本。 |
| 运行中 | 保存命令与输出，核对观察心跳、实际进度、时间预算和暂停标记；发生异常时请求退出，超时再终止所属进程组。 |
| 结束后 | 保存退出记录，从工作器最后写入的指标重新生成最终曲线；最终界面标为历史记录，独立于运行中的观察文件。 |

每次运行使用新的目录，已有目录和结果会被拒绝，不自动重试。运行说明中的方案和日志链接也会指向本次记录，避免继承旧工作器的过时链接。入口本身不选择奖励、动作策略或训练预算。

## 检查结果

当前源码通过 **31 项隔离检查**。使用真实入口、监督器、观察器和回调代码，工作器、零步回执与查看确认均为合成数据。正常流程结束后，最终指标包含最后一条更新，曲线来源哈希与工作器最终快照一致；未确认画面、确认属于其他运行、暂停和进度停滞均会停止。测试中的观察进程均已退出。[完整结果](source-bound-entry/verification.json) · [进程日志](source-bound-entry/fixture-logs.zip) · [源码快照](source-bound-entry/checked-sources.zip)

这次修复了一个观察问题：短任务结束得快，运行中的绘图刷新可能尚未发生，原流程虽然显示已完成，却只留下空指标表。增加最终导出后，第一次尝试因为复用了已存在的观察目录而被拒绝；随后改为独立的 `final-view` 目录，保存最后一次指标和曲线。原检查、失败日志与修复后的证据均保留。[首次进程检查](verification.json) · [首次源码](first-check-sources.zip) · [导出失败](final-view-check/verification.json) · [导出修复](final-artifacts/verification.json)

后续又核对了真实父配置，发现源码清单位于 `training.candidate` 内层。入口现会核对该层清单、Linux 工作副本及依赖；额外的两项检查分别修改合成依赖、移除继承源码条目，均在导入工作器前被拒绝。

## 如何查看

新运行启动后，在 VS Code 打开该组报告目录的 `native-view/native-status.txt`、`native-view/native-curve.png` 和最新画面。结束后打开同目录的 `final-view/native-status.txt` 和 `final-view/native-curve.png`；它们来自最终保存的指标，不再刷新。原始逐次指标、录像与保存点仍在该运行的实验目录中；`execution.log`、`entry-result.json`、`supervisor-result.json` 和 `final-view.json` 说明命令、退出和导出情况。

目前没有可供此入口执行的新训练协议。下一步需先确定有意义的修改与同父点对照，生成与各运行配置匹配的实际 CUDA 零步证据，再确认真实本机观察和运行条件。这里的合成回执不能用于训练准入。

## 自行复核

在 Windows 项目根目录执行以下命令，只运行隔离检查。输出目录若已存在，需要改成新的名称；不会覆盖先前结果。

```powershell
wsl -d Ubuntu-24.04 -- /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/check_observed_getup_entry.py --output /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/records/reports/native-ppo-observation-preflight/manual-entry-check
```

这些检查不证明实际 PPO 更新、GPU 异常后的保存点或恢复训练已通过，也没有验收本次真实桌面查看。完整动作目标、同场景切换、扰动验证和真机准备继续按[当前目标](../../../../docs/current_goal.md)执行。
