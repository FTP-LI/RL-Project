# 全身目标与训练准备

[逐关节审计](analysis.json)读取颈部归位顺序三组的全部保存轨迹，保留原评分。控制后状态与发出请求的控制前时刻分别核对，原始数据不改。[图像核验](figure-analysis.json)及主报告第7.7.10节解释各时段。

[辅助目标CPU检查](auxiliary-preflight.json)覆盖解析梯度、合法/早期目标、零系数逐位等价、正系数只改变行为网络及冻结期Adam不前进。CPU例程不算新仿真训练。

[训练草案](../../../configs/experiments/getup_late_feasibility_draft.json)随后形成可执行冻结对照，已经按预算结案，官方295/320、对照283/320、候选283/320，候选未晋级；见[后续证据](../getup-late-feasibility/README.md)。共同接口价值起点另见[价值预检](../getup-interface-value/README.md)。完整说明与复核命令见[全流程报告](../../../docs/reports/development_report.md)。
