# 官方完整路线独立复核

S17 在官方滚翻、官方行走和固定 0.15 rad/s 前进反馈下，只更换随机种子为 1235，执行 50 步站立、450 步前滚翻、50 步落地站立和 1,000 步前进。bridge 保持关闭，学习更新为 0，硬件 IO 为 false。

结果为滚翻入口 128/128、滚翻落地 120/128、前进入口 120/128、完整路线 119/128，超过 116/128 的原路线门槛。8 个世界在 supported rotation 完成边界前退出，1 个前进世界的偏航误差为 0.200685 rad/s；头部最大穿透 3.317 mm，头部穿透超限和关节越限均为 0。速度、接触滑移和 block error 均在原门槛内。

这次结果支持官方固定路线在新种子上通过开发门槛，但不改变模型选择，也不启动 PPO。下一步仍需把滚翻阶段扰动、参数随机化和同一套完整路线放在统一验收中。

## 证据

- [冻结协议](../../configs/experiments/route_official_independent_s1235.json)
- [CPU/GPU zero-step 前置](preflight.json) · [zero-step 记录](zero/)
- [完整路线评分](analysis.json)
- [失败复盘](failure-review.json)
- [关键帧拼图](keyframes.jpg) · [关键帧清单](keyframes.json)
- [完整路线视频](../../records/evaluations/duck_switch_roll-stand-walk_development_s1235_20261114T104326/clip-step-0.mp4)
- [状态轨迹](../../records/evaluations/duck_switch_roll-stand-walk_development_s1235_20261114T104326/trace.npz)
- [实际动作目标](../../records/evaluations/duck_switch_roll-stand-walk_development_s1235_20261114T104326/commands.npz)
- [首次关键帧脚本失败记录](keyframe-render-failure.json)

复现离线评分：

```powershell
python scripts/validation/analyze_router_full_sequence.py records/evaluations/duck_switch_roll-stand-walk_development_s1235_20261114T104326 --out records/reports/official-route-independent-s1235/analysis.json
python scripts/validation/review_router_full_sequence_failures.py records/evaluations/duck_switch_roll-stand-walk_development_s1235_20261114T104326 --out records/reports/official-route-independent-s1235/failure-review.json
```
