# 历史起身训练对照

本页只读取已经完成的两组起身 PPO 训练和已有评估。训练仍按用户要求暂停；本次没有启动训练、物理仿真或真机操作。两组从同一父保存点出发，使用同一个训练种子，各采集 1,253,376 条转移；并行环境数、更新次数和小批量划分不同，因此不能把每一次更新直接一一对应。[冻结方案](../../../configs/experiments/local_getup_ppo.json) · [训练核验](../getup-local-ppo-20261110T011523/training-verification.json) · [原始对照报告](../getup-local-ppo-20261110T011523/README.md)

本页和图表在[暂停快照](../pause-archive-20261115/README.md)生成后补充。重新核验该快照时，当前目标和报告可能被列为已变化；快照内部仍按当时的清单核对，不会因后续更新而覆盖。

## 过程与资源

![历史起身训练指标](training-curves.png)

横轴使用各次更新时已采集的累计转移数，以便比较相同数据量。图中回报、价值损失和成功样本动作偏移来自训练日志；偏移虚线是该轮设定的 0.05 rad RMS 上限。训练时回报或损失的变化不能单独说明起身是否成功，动作结果须看后面的独立评估。

图中的吞吐以训练开始采样后的累计转移和时间计算。下表的全程吞吐以整轮实际转移除以全程耗时，包含初始化、采样、更新、录像和记录开销，因此与曲线末点的口径不同。

| 指标 | 1,536 个环境 | 3,072 个环境 |
| --- | ---: | ---: |
| 完整更新 | 34 | 17 |
| 训练转移 | 1,253,376 | 1,253,376 |
| 全程耗时 | 172.33 秒 | 165.71 秒 |
| 全程吞吐 | 7,273 转移/秒 | 7,564 转移/秒 |
| 整卡显存峰值 | 7,357 MiB | 12,637 MiB |
| 整卡 GPU 利用率采样中位数 | 35% | 23% |

在这一次记录中，3,072 环境的全程吞吐约高 4%，但整卡显存峰值多 5,280 MiB。GPU 利用率分别有 163、153 次周期采样，包含启动及其他进程，是整卡观测，不是训练进程独占利用率；仅凭这些数据不能确定 CPU、仿真同步、录像或写盘哪一项是瓶颈，也不能断定更大的并行规模一定更快。[整理数据与来源哈希](comparison.json) · [逐次指标](training-metrics.csv) · [只读核验](verification.json)

## 动作结果

两组训练完成后，在同一次新种子评估中从相同释放状态比较固定父模型及两个训练结果。下面是原记录中的综合成功数；原协议还要求各姿态分别通过。两组训练结果均未通过全部姿态门槛，没有选入后续独立确认。

| 策略 | 综合成功 | 实际仰卧 | 实际右侧 |
| --- | ---: | ---: | ---: |
| 固定父模型 | 312/320 | 176/180 | 45/49 |
| 1,536 环境训练 | 303/320 | 167/180 | 46/49 |
| 3,072 环境训练 | 306/320 | 166/180 | 49/49 |

这次对照说明：提高吞吐没有让这两份模型通过完整动作门槛；它不能推导出所有训练规模的效果。保存的评估只有这一组开发种子，固定父模型也没有通过该轮全部姿态门槛。[评估记录](../getup-local-ppo-20261110T011523/evaluation-analysis.json)

## 在 VS Code 中查看

打开 `XGO-Duck` 文件夹后，可直接打开本页、上方图像或 CSV；Markdown 按 **Ctrl+Shift+V** 预览。下面的视频是各自运行时保存的实际画面，并非当前直播；两段训练录像各覆盖一个完整 8 秒动作，不能把不同运行的画面当作同一物理样本。

- [1,536 环境训练录像](../../experiments/duck_getup_adaptive-scale_control_s3063_20261110T011523/clip-step-0.mp4) · [逐次原始记录](../../experiments/duck_getup_adaptive-scale_control_s3063_20261110T011523/observation.json)
- [3,072 环境训练录像](../../experiments/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/clip-step-0.mp4) · [逐次原始记录](../../experiments/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/observation.json)
- [固定父模型仰卧评估](../../evaluations/duck_getup_local-ppo_paired_s1061_20261110T012327/evaluation-fixed-weighted-supine/clip-step-0.mp4) · [1,536 环境模型仰卧评估](../../evaluations/duck_getup_local-ppo_paired_s1061_20261110T012327/evaluation-n1536-supine/clip-step-0.mp4) · [3,072 环境模型仰卧评估](../../evaluations/duck_getup_local-ppo_paired_s1061_20261110T012327/evaluation-n3072-supine/clip-step-0.mp4)。三段是该轮保存的 11 秒评估画面，来源见原评估记录。

在 Windows 项目根目录执行以下只读命令，可核验图、CSV、51 条逐次数据及两段训练原片的哈希；它不会重新评估模型，也不会启动训练：

```powershell
py -3 -B scripts/validation/verify_saved_training_visualization.py
```

图表由 [visualize_saved_getup_training.py](../../../scripts/validation/visualize_saved_getup_training.py) 读取保存的 `observation.json` 和 `learning-metrics.jsonl` 生成；脚本拒绝覆盖已有结果。下一次真实训练仍须单独接入本机实时观察和异常停止，不能把历史回放当作实时验收。
