# 仰卧起身锁存评估

三路共用一次释放快照。候选仅在首帧观测识别为实际仰卧时启用末层策略，并在当回合保持选择。实际仰卧 813/813 均选择末层策略，其他姿态 0/211 误选。独立复算 2,869 条实际输入，动作最大差为 2.15×10⁻⁶ rad。原先的 95% 门槛和持稳时限均沿用。 [冻结方案](../../../../configs/experiments/getup_teacher_head_supine_latch_evaluation_s1163.json) · [CUDA 零步](independent-zero/proof.json)

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 实际右侧 | 原片 |
| --- | ---: | ---: | ---: | ---: | --- |
| 父策略 A | 979/1,024 | 633/672 | 772/813 | 51/54 | [父策略 A](../../../evaluations/duck_getup_teacher-head-latch_development_s1163_20261110T181652/evaluation-reference-a-supine/clip-step-0.mp4) |
| 父策略 B | 980/1,024 | 634/672 | 772/813 | 52/54 | [父策略 B](../../../evaluations/duck_getup_teacher-head-latch_development_s1163_20261110T181652/evaluation-reference-b-supine/clip-step-0.mp4) |
| 仰卧锁存 | 984/1,024 | 636/672 | 775/813 | 52/54 | [仰卧锁存](../../../evaluations/duck_getup_teacher-head-latch_development_s1163_20261110T181652/evaluation-candidate-supine/clip-step-0.mp4) |

实际仰卧比两路父策略各净增 3 例，其他实际姿态的持稳数均达到两路参照。指定仰卧少 3 例才达到 639/672，候选未晋级。两路父策略在 29 个场景的结果不同，其中 23 个同时为指定和实际仰卧。三路实际采样零学习，最终留出保持封存。 [独立评分](analysis.json) · [晋级记录](decision.json)

共采样 1,484,800 条转移，含写盘 204.59 秒，约 7,258 条/秒。整卡显存峰值 5,398 MiB，利用率采样均值 29.3%。Windows 观察端记录 30 次运行中刷新，其中 29 次含真实画面。三段 11 秒原片每段 276 帧，标注图对齐 2 秒释放与 11 秒持稳终点。 [运行观察](../../../getup-teacher-head-latch-s1163-live.html) · [三段媒体核验](media-review.json)

两批中共有 28 个三路均失败的指定且实际仰卧场景。末两秒持续双脚着地、头腿接触和倾角超线的有 27 例。另选两路父策略均成功但候选失败的 16 例，以及仅候选成功的 16 例，整理成同输入纠正回放。两组共用 900 条观测，450 条只改变有界腿部标签，另外 450 条标签相同。 [逐场景复盘](../paired-failure-review.json) · [回放来源和哈希](../corrective-replay/analysis.json)

用原生 PPO 辅助损失核对两次平衡抽样。CUDA 候选加权梯度范数为 0.3550、0.3429，对照均小于 4.1×10⁻⁶。CPU 与 CUDA 均确认梯度只进入演员末层的十个腿部输出。首次逐元素跨设备比较超出初设容差，改用双精度参考复核，两端候选梯度最大相对 L2 误差为 0.00138%。该检查的优化器步和物理步均为零。 [首次日志](../corrective-replay/native-loss-first-attempt.log) · [双精度复核](../corrective-replay/native-loss-preflight.json) · [等预算训练草案](../../../../configs/experiments/getup_latched_head_corrective_ppo_draft.json)

按归档训练的 76 项价值输入和 0.10 rad 标准差，在 CPU 和 CUDA 各做两次临时 Adam 更新。只改动末层腿部行及对应动量，检查点保持原哈希。2,048 条保存输入的两端价值输出最大差为 4.77×10⁻⁷。本次无持久学习。 [临时 Adam 和价值读回](../corrective-replay/checkpoint-adam-preflight.json)
