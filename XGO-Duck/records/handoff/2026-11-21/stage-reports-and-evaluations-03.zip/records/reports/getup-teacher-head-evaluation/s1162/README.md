# 起身末层候选评估

1,024 个新场景共用一次完整释放快照。两路父策略使用相同权重，候选只替换按开发动作包络约束的末层腿部输出。三路保持相同的接触模型、控制周期和计分。原判据要求所有请求和实际姿态及总体至少 95% 按时起身并持稳，同时实际仰卧相对两路参照均净增至少两例。 [末层拟合与可恢复检查点](../../../experiments/duck_getup_teacher_head_offline_s1160_20261110T175320/README.md) · [冻结方案](../../../../configs/experiments/getup_archived_policy_teacher_head_evaluation_s1162.json)

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 实际右侧 | 原片 |
| --- | ---: | ---: | ---: | ---: | --- |
| 父策略 A | 987/1,024 | 640/672 | 785/820 | 47/49 | [父策略 A](../../../evaluations/duck_getup_teacher-head_development_s1162_20261110T180149/evaluation-reference-a-supine/clip-step-0.mp4) |
| 父策略 B | 988/1,024 | 640/672 | 786/820 | 47/49 | [父策略 B](../../../evaluations/duck_getup_teacher-head_development_s1162_20261110T180149/evaluation-reference-b-supine/clip-step-0.mp4) |
| 末层候选 | 989/1,024 | 641/672 | 788/820 | 46/49 | [末层候选](../../../evaluations/duck_getup_teacher-head_development_s1162_20261110T180149/evaluation-candidate-supine/clip-step-0.mp4) |

仰卧净增 3、2 例达到配对要求。实际右侧少通过 1 例，低于 47/49，候选未晋级。两路父策略有 33 个场景成败不同。三路释放时 345 项状态字段一致。 [评分](analysis.json) · [晋级记录](decision.json)

CUDA 共采样 1,484,800 条转移，含写盘约 200 秒，约 7,411 条转移/秒。整卡显存峰值 5,398 MiB，利用率采样均值 29.1%。Windows 核对 30 次运行中刷新，29 次含真实画面。三段原片各 11 秒。 [运行观察](../../../getup-teacher-head-s1162-live.html) · [起始 CUDA 核验](independent-zero/proof.json)

三批保存的释放观测共覆盖 2,450 个实际仰卧，全部进入仰卧选择，其他 622 个姿态均未误选。对本批已知结果按仰卧用候选、其他姿态用父策略组合，两路均为 990/1,024。组合只反映保存结果，实际锁存策略需新物理场景验证。 [离线锁存预检](../supine-latch-preflight.json)

CPU 和 CUDA 分别复核本批 1,024 个释放输入与 1,024 个后续输入。仰卧场景逐值输出候选动作，其他姿态逐值输出父策略动作，后续重力变化不会重选。新场景按原动作门槛验证，最终留出保持封存。 [原生零步核验](../supine-latch-component.json) · [新场景草案](../../../../configs/experiments/getup_teacher_head_supine_latch_evaluation_draft.json) · [三段标注帧核验](media-review.json)
