# 参数随机化模型回归

本协议固定 seed 1202、原四姿态起身、官方前滚翻和七指令连续屏幕，比较同一次 8 更新短训练得到的 candidate/control 两个 ONNX 导出。全程无学习更新、无硬件输入；每个动作都保留实际 CUDA 轨迹和完整录像。

## 结果

- 起身：两组 `prone=32/32`、`supine=32/32`、`left-side=19/32`、`right-side=19/32`。侧躺的 13 个失败均为冻结结束时实际释放姿态转为 `supine`，两组完全一致；这与官方 seed 1001 记录中的侧躺释放问题同类，因此不能宣称四姿态全通过。
- 前滚翻：candidate/control 均为 `0/32`，主要原因是没有 feet→head-top 接触序列和前向旋转。起身导出不具备滚翻能力，不能把该权重当作滚翻策略。
- 七指令：两组 224 个并行环境均完整运行 20 秒且没有跌倒，但保存指标显示前后进退和平移的线速度误差、左右转的角速度误差均超过原门槛；只有 `stand` 的保存指标屏幕通过。该结果是能力边界诊断，不是行走验收。

因此 candidate 在短训练内部稳定率略高于 control，但尚未通过原动作回归，不能晋级为最终模型，也不启动无目标的延长训练。下一阶段应分别为起身、滚翻和行走建立技能训练/路由协议，再用统一接口做组合回归。

## 证据

- [冻结协议](../../../configs/experiments/parameter_randomized_getup_regression.json) · [冻结核验](freeze.json) · [冻结修订](freeze-revision.json) · [结果汇总修订](protocol-summary-revision.json)
- [起身总表](getup-completed.json) · [起身终端日志](getup-console.log)
- [滚翻总表](roll-completed.json) · [滚翻终端日志](roll-console.log)
- [七指令总表](seven-command-completed.json) · [七指令终端日志](seven-command-console.log)
- [候选起身记录](candidate/summary.json) · [对照起身记录](control/summary.json)
- [失败执行归档](failed-attempts/attempt-20261113-1/candidate/evaluation.json)

每个 `records/evaluations/duck_*parameter-randomized-regression*` 目录包含运行协议、环境 YAML、保存轨迹、逐姿态或逐命令视频、哈希和执行状态；`artifacts/duck_getup_parameter-randomized_*` 保留两个可部署 ONNX 导出。
