# 低摩擦起身步长对照

种子1257的896个场景使用0.8足底滑动摩擦。从第100步、仿真2.00秒的同一释放快照恢复三次，核对346项状态及首个实际动作和延迟电机输入。候选仅将释放后首1.2秒的物理积分由4ms改为2ms。各组电机按4ms更新，策略和观测按20ms更新。滚翻段统一采用首1.2秒1ms、其后2ms，起身、滚翻和七指令评分沿用原路线。模型与控制器权重均未更新。[冻结配置](../../../../configs/experiments/nominal_low_friction_release_integrator.json) · [释放快照](../../../evaluations/duck-getup-release-clock-friction080-s1257-20261121T162131/fork.json) · [七批失分复算](../low-friction-failure-recurrence/README.md)

## 动作评分

| 指标 | 4ms起身参照一 | 4ms起身参照二 | 首1.2秒2ms起身候选 |
| --- | ---: | ---: | ---: |
| 请求仰卧起身并持稳，至少213/224 | 211/224 | 212/224 | 213/224 |
| 实际仰卧场景进入滚翻 | 520/535 | 520/535 | 521/535 |
| 全部场景进入滚翻 | 878/896 | 879/896 | 879/896 |
| 滚翻完成且落地持稳，至少812/896 | 855/896 | 859/896 | 859/896 |
| 七指令总入口，至少852/896 | 855/896 | 859/896 | 859/896 |
| 站立入口，至少122/128 | 124/128 | 125/128 | 122/128 |
| 前进入口，至少122/128 | 119/128 | 119/128 | 122/128 |
| 后退入口，至少122/128 | 123/128 | 123/128 | 123/128 |
| 左转入口，至少122/128 | 121/128 | 119/128 | 119/128 |
| 右转入口，至少122/128 | 124/128 | 125/128 | 125/128 |
| 左平移入口，至少122/128 | 121/128 | 126/128 | 123/128 |
| 右平移入口，至少122/128 | 123/128 | 122/128 | 125/128 |

候选满足原起身覆盖判据，前进入口比两遍参照各多3个。左转仍有5个场景在开始滚翻前失分，另4个场景进入滚翻后未达到指令入口。三组均在第1125步、22.50秒处停止，七指令各20秒的完整动作评分待完成。[逐项评分](analysis.json) · [阶段失分与场景编号](paired-failure-readback.json)

共用快照中，535个实际仰卧和151个实际右侧卧均进入对应起身策略。此前至少四批重复失分的9个实际仰卧场景中，7个在本次三组均未进入滚翻。后续对照将以这些场景和条件相近的成功场景为起点，核对早段作用力、躯干转正与足地承重时序。独立低摩擦种子2246留作最终确认。[重复场景和路由复算](paired-failure-readback.json)

## 本机计算与回看

本次在本机CUDA上完成2,844,800条固定权重仿真转移、24,725次批量物理求解，整卡显存峰值5,851MiB。三组起身首1.2秒的净采样速率依次约为9,057、8,622和7,339条场景转移/秒。评分工具用32位浮点逐次重建模拟时钟，所有积分切换时刻和终点与记录一致。[CUDA采样日志](sample-command.log) · [评分日志](score-command.log) · [时钟复算说明](time-readback-protocol.json)

[运行中状态核验](live-readback.json) · [VS Code最终状态](final-view/native-status.txt) · [采样曲线](final-view/native-curve.png) · [最新实景](final-view/native-latest.jpg) · [关键帧来源](keyframe-source.json)

![低摩擦起身与滚翻对照](keyframes.jpg)

每组原片均为25帧/秒、564帧，覆盖共同跌倒准备、起身、滚翻和指令入口边界。

| 分支 | 原片 |
| --- | --- |
| 4ms起身参照一 | [4ms起身参照一原片](../../../evaluations/duck-getup-release-clock-friction080-s1257-20261121T162131/reference-4ms-first/clip-step-0.mp4) |
| 4ms起身参照二 | [4ms起身参照二原片](../../../evaluations/duck-getup-release-clock-friction080-s1257-20261121T162131/reference-4ms-repeat/clip-step-0.mp4) |
| 首1.2秒2ms起身候选 | [首1.2秒2ms起身候选原片](../../../evaluations/duck-getup-release-clock-friction080-s1257-20261121T162131/release-2ms-candidate/clip-step-0.mp4) |

[冻结日志](../low-friction-release-integrator-freeze-command.log) · [失分复算日志](failure-readback-command.log) · [录像与观察档案生成日志](media-command.log)
