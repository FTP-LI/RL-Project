# 低摩擦前进起身的接触与扭矩

种子1257，896个场景，足底滑动摩擦系数0.8。第100步保存共同释放快照，物理、控制器、延迟和随机状态一并恢复。两遍同权重父策略、原奖励对照和承重转正候选各采样至第200步。在实际4ms求解后读取接触法向力、执行器扭矩和占空比，保留151个场景的逐子步读数，包括全部前进分组及原归档中的13对匹配场景。每条轨迹覆盖最初4秒的跌倒、释放和早期承重。完整起身及滚翻入口另见此前12秒评价。[冻结配置](../../../../configs/experiments/nominal_low_friction_forward_support.json) · [运行前核验](preflight.json) · [此前完整动作评分和原片](../low-friction-early-transfer-authority/loaded-upright-ppo/README.md)

预先沿用两足各超过标称机重2%、合计达到50%、保持五次4ms求解作为持续承重的计时条件。场景439用于核对双足承重后的头部再接触，场景779用于核对首次转正。场景283和727用于观察同策略波动。原动作门槛与独立确认种子2246保持原配置。

运行编号为`duck-getup-forward-support-friction080-s1257-20261121T204249`。VS Code入口会显示采样状态、进度和真实仿真帧。[当前训练记录](../../../training-current.md)

## 实测时序

实际恢复346项状态，每组读取第501–1000次求解。151个场景在全部20ms边界的原始求解器四元数均逐值对齐，采集总计448,000条转移、2,500次批量求解，GPU峰值6,037MiB。两遍父策略的首步策略输出和关节目标逐值一致，首20ms内全场景电机扭矩请求的最大差为0.00500N·m。首轮离线核对误读了重新换算后的连杆四元数，两字段的最大差为1.19×10⁻⁷。切换到原始求解器字段后，以上精确核验全部通过。[运行命令](sample-command.log) · [首轮核对记录](pose-field-first-score-command.log) · [修正后的核对记录](score-command.log)

| 候选场景 | 首次持续双足承重（释放后ms） | 双足承重且头部卸载（释放后ms） | 头部持续再承重（释放后ms） | 双足承重后80ms转正量（°） |
| --- | ---: | ---: | ---: | ---: |
| 前进分组439 | 840 | 864 | 928 | −0.14 |
| 前进分组779 | 796 | 804 | 880 | −4.97 |

头部卸载和再承重均用标称机重2%的法向载荷分界和五次4ms连续读数确认。候选中两个场景都达到双足载荷门槛，两次确认之间分别为64ms和76ms。两遍父策略在场景439的首次持续双足承重分别为760ms、728ms，再承重分别在864ms、804ms。场景779的两遍对应时点为780ms、820ms和1,048ms、920ms，提供同策略重复波动的实测幅度。[四组逐场景载荷、姿态及关节扭矩](analysis.json)

候选两场景在首次双足承重后80ms内的颈部俯仰扭矩积分分别为−0.0735和−0.0734N·m·s，峰值均达到固件占空比上限。此前归档配对场景399和848在候选策略下的同期积分为+0.0191和+0.0139N·m·s，分别转正8.46°和1.49°。这些读数用于选择颈部和腿部的同状态调整方向。[逐关节80ms窗口](analysis.json)

| 4秒机制采集原片 | VS Code记录 |
| --- | --- |
| [父策略](../../../evaluations/duck-getup-forward-support-friction080-s1257-20261121T204249/parent-policy/clip-step-0.mp4) · [父策略同权重复测](../../../evaluations/duck-getup-forward-support-friction080-s1257-20261121T204249/parent-policy-repeat/clip-step-0.mp4) · [原奖励对照](../../../evaluations/duck-getup-forward-support-friction080-s1257-20261121T204249/original-reward/clip-step-0.mp4) · [承重转正候选](../../../evaluations/duck-getup-forward-support-friction080-s1257-20261121T204249/loaded-upright-reward/clip-step-0.mp4) | [运行中读回](live-readback.json) · [最终状态](final-view/native-status.txt) · [采样曲线](final-view/native-curve.png) · [实际末帧](final-view/native-latest.jpg) |

[实时采集代码](../../../../scripts/validation/run_nominal_low_friction_forward_support.py) · [读回复算代码](../../../../scripts/validation/review_nominal_low_friction_forward_support.py)

![承重、倾角与颈部扭矩](forward-support-timing.png)

图中为承重转正候选的同策略轨迹。浅蓝区间标出头部卸载和再承重的两个确认时点，横轴截取释放后0.45–1.16秒，保留4ms原始读数。[图源与排版核验](figure-source.json)

## 同初态短回放

从首次双足承重前约40ms的20ms控制边界开始，对每个状态做两遍原扭矩回放和两种调整。每遍200ms，第一子步沿用原扭矩，再施加最多76ms的调整。以实测供电和原占空比为基准，按当前关节速度重算反电动势并使用原扭矩限幅。34个初态共6,800次CPU物理步，30个初态在足底承重时点及机身倾角上达到参照对齐要求，包含全部8个目标初态。[冻结配置](../../../../configs/experiments/nominal_low_friction_forward_support_torque.json) · [逐样本回放](short-torque-replay/analysis.json) · [执行日志](short-torque-replay/replay-command.log)

| 扭矩调整 | 场景439达到3°转正增益 | 场景779达到3°转正增益 | 两遍父策略原准入保护 |
| --- | ---: | ---: | --- |
| 颈部俯仰增加0.06N·m | 0/4 | 0/4 | 12/13、10/13 |
| 两侧髋膝各调整0.025N·m | 0/4 | 0/4 | 12/13、10/13 |

两种调整均达到规定的指令幅度，目标初态的最大转正增益为0.30°。保护统计同时要求参照对齐并保持原倾角、头部载荷和双足承重指标。后续将从首次持续双足承重前的轨迹核验足底接触区域与质心运动，筛选新的控制或训练改动，再按原起身、滚翻及七指令门槛逐级评分。[逐关节实际调整及保护判定](short-torque-replay/analysis.json)
