# 2ms连续路线独立确认

开发种子1257两遍均通过原完整动作判据后，使用保留种子2256重新生成896个场景，每条指令分配128个场景。沿用开发评估的权重、关节目标与滚翻段2ms时钟，足地摩擦系数为1.0。从实际跌倒和第100步释放开始计时，评价四姿态起身、滚翻落地和七指令。按原门槛观察至动作结束。保留种子2246用于独立低摩擦评估。

[资格来源](../closed-loop-timestep-repeat/analysis.json) · [确认设计](../../../../configs/experiments/nominal_roll_timestep_confirmation_design.json) · [冻结协议](../../../../configs/experiments/nominal_roll_timestep_confirmation.json) · [冻结命令](../closed-loop-timestep-repeat/confirmation-preflight-command.log) · [来源与观察入口预检](preflight.json) · [CUDA初始化命令](zero-command.log)

实际CUDA初始化确认各模型输出与ONNX对应，最大绝对差为2.38×10⁻⁶。初始化记录为零物理步，评估恢复了第100步实际释放的346项状态。完整采样结束于第2125步。[CUDA零步凭据](zero/proof.json) · [最终状态](final-view/native-status.txt) · [全程采样曲线](final-view/native-curve.png) · [最终仿真帧](final-view/native-latest.jpg) · [运行中读回](live-readback.json) · [采样命令](sample-command.log)

## 独立通过结果

| 实际释放姿态 | 按时起身并保持 | 原要求 |
| --- | ---: | ---: |
| 俯卧 | 112/112 | 107/112 |
| 仰卧 | 517/524 | 498/524 |
| 左侧卧 | 113/113 | 108/113 |
| 右侧卧 | 146/147 | 140/147 |

按时起身并保持共888/896。滚翻并落地及进入七指令共872/896。完成原20秒指令后，完整连续路线仍为872/896，高于852/896门槛。

| 分配指令 | 完成场景 | 门槛 |
| --- | ---: | ---: |
| 站立 | 125/128 | 122/128 |
| 前进 | 125/128 | 122/128 |
| 后退 | 126/128 | 122/128 |
| 左转 | 124/128 | 122/128 |
| 右转 | 124/128 | 122/128 |
| 左平移 | 123/128 | 122/128 |
| 右平移 | 125/128 | 122/128 |

原评分使用动作持续时间、速度与偏航、机身姿态、足底接触与滑移以及关节限位。评估保存1,904,000条场景转移、12,875次批量求解，显存峰值5,617MiB，滚翻段含录像与写盘的净吞吐为7,300条转移/秒。42.5秒原片共1,064帧，各帧与相同控制步的物理状态摘要核验一致。[逐动作评分](analysis.json) · [评分命令](score-command.log) · [42.5秒原片](../../../evaluations/duck-roll-fixed-policy-2ms-heldout-s2256-20261121T121926/heldout-nominal/clip-step-0.mp4) · [2ms时钟与延迟量核对](../../../evaluations/duck-roll-fixed-policy-2ms-heldout-s2256-20261121T121926/heldout-nominal/closed-loop-clock.json)

## 仿真交付

用同一个清单索引这次运行的七个策略、其中五份可恢复训练保存点、三份与原文件逐字节一致的官方运行包权重、官方仿真行走来源、控制时钟、配置和原片。低摩擦及扰动另按相同原判据验证。[标称连续仿真清单](../../../../artifacts/delivery/nominal-continuous-simulation.json) · [汇总与哈希核验日志](delivery-command.log)
