# 起身后滚翻启动状态训练对照

两组从同一官方前滚翻权重和同一组PPO初始化状态出发，训练目标是改善起身、站稳、滚翻和七指令的连续质量。标称开发种子1256的886个场景提供实际滚翻启动状态。训练用种子为1258，动作对照用种子为1257，最终确认种子2256和2246保留。

| 项目 | 方案 |
| --- | --- |
| 原始站立重置训练组 | 使用官方训练环境的站立重置 |
| 起身后启动状态课程训练组 | 在1,152/4,608个环境中加载真实站姿、速度和上一段关节目标，样本按重置计数循环 |
| 共同学习设置 | 各30次更新，每次24步，先15次更新价值网络，再15次同时更新策略和价值网络 |
| 样本与保存点 | 每组最多3,317,760条环境转移，保存第15、24和30次的完整更新 |
| 运算规模 | 使用本机实测净吞吐胜出的4,608个并行环境，按顺序复用同一张显卡 |
| 连续动作评分 | 同一真实状态恢复后比较官方滚翻、原始站立重置训练组、起身后启动状态课程训练组，使用原滚翻和七指令门槛 |

源场景为平面，网格间距2m。原始释放的最大平面偏移约0.500m，起身走动后的候选启动偏移最大0.736m，仍在原场景网格内。训练把坐标移到各自场景原点，保留姿态、关节状态、速度和旧关节目标。真实滚翻开始时动作历史清零，候选训练同样清零动作历史。上一关节目标写入执行器目标缓冲；执行器仍使用官方训练环境的延迟和随机化。

CUDA核对覆盖两组各4,608个环境。候选的1,152个训练环境覆盖全部886个源状态，其余3,456个环境的物理初态逐项一致。两组脚底摩擦、随机状态和官方速度指令一致。965个环境含非零的原训练速度指令，连续动作评估的滚翻入口按原规则使用零指令。两组零步检查的整卡显存峰值为8,462MiB。首次预检把起身移动误用为重置位置范围，修正为按实际网格边界计算。早期零步分别修正了速度指令断言和批量关节索引，均在积分与学习前结束。[冻结训练方案](../../../../configs/experiments/roll_post_getup_start_training.json) · [原点与关节数据](entry-state-audit.json) · [配对CUDA核验](matched-reset.json) · [初始坐标预检日志](../post-getup-curriculum-qualification-initial.log) · [速度指令检查日志](../post-getup-roll-curriculum-initial-zero/qualification.log) · [关节索引检查日志](../post-getup-roll-curriculum-index-zero/qualification.log)

## VS Code观察

在工程内打开状态、曲线和画面文件，可以随训练进度在VS Code中刷新。状态按更新记录，回报和损失定期重绘，实景每隔4次更新保存一帧。每组记录完整的滚翻训练片段。

- 原始站立重置训练组已完成30次更新。[最终状态](official-standing-reset/final-view/native-status.txt) · [完整训练曲线](official-standing-reset/final-view/native-curve.png) · [实际画面](official-standing-reset/final-view/native-latest.jpg) · [逐更新表](official-standing-reset/final-view/native-metrics.csv)
- 起身后启动状态课程训练组已完成30次更新。[最终状态](post-getup-start-curriculum/final-view/native-status.txt) · [完整训练曲线](post-getup-start-curriculum/final-view/native-curve.png) · [实际画面](post-getup-start-curriculum/final-view/native-latest.jpg) · [逐更新表](post-getup-start-curriculum/final-view/native-metrics.csv)

运行入口在现有WSL环境执行，训练观测从项目文件读取。[训练入口](../../../../scripts/training/run_roll_post_getup_training.sh) · [重置实现](../../../../scripts/training/roll_post_getup_reset.py) · [资格与训练日志](../post-getup-curriculum-qualification.log) · [训练命令日志](../post-getup-curriculum-training.log)

## 训练结果

| 分支 | 价值网络与策略更新次数 | 环境转移 | 净吞吐（条/秒） | 整卡利用率中位数 | 整卡显存峰值（MiB） |
| --- | --- | ---: | ---: | ---: | ---: |
| 原始站立重置训练组 | 30与15 | 3,317,760 | 24,631 | 71% | 9,444 |
| 起身后启动状态课程训练组 | 30与15 | 3,317,760 | 24,577 | 73% | 9,442 |

第336和686步的训练持稳比例，原始站立重置组为95.31%和95.64%，起身后启动状态课程组为95.38%和95.29%。这两处读数用于在训练中捕捉动作退化。训练阶段实际耗时134.70秒和134.99秒，包含更新、保存点和实际画面记录。两组保存点、逐更新日志、各176帧的原始录像与61输入、14输出的ONNX均已核对。[逐组证据及导出路径](paired-training-results.json) · [独立核验日志](../post-getup-curriculum-training-verification.log)

[原始站立重置训练组录像](../../../experiments/duck-roll-official-standing-reset-e4608-s1258-20261121T081905/clip-step-0.mp4) · [起身后启动状态课程训练组录像](../../../experiments/duck-roll-post-getup-start-curriculum-e4608-s1258-20261121T081905/clip-step-0.mp4)

两段训练录像均为首次完整7秒滚翻，取自策略权重仍处于冻结阶段的采样。训练完成后的模型动作见下方三段对照原片。

## 同状态连续动作评估

种子1257、896个场景。跌倒、起身和站立准备共用前600步。从该时刻恢复仿真和控制器状态，分别采用官方滚翻、原始站立重置训练组和起身后启动状态课程训练组的权重。候选晋级要求滚翻及完整七指令达到原门槛，滚翻通过数相对官方至少净增5个、相对训练对照至少净增1个，并保留各完整参照的通过数。[冻结动作评估方案](../../../../configs/experiments/roll_post_getup_action_comparison.json) · [评估状态](action-comparison/native-view/native-status.txt) · [评估命令日志](../post-getup-actor-comparison.log)

| 分支 | 滚翻并落地持稳（各896） | 站立 | 前进 | 后退 | 左转 | 右转 | 左平移 | 右平移 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 官方滚翻模型 | 853 | 122 | 121 | 124 | 122 | 116 | 125 | 123 |
| 原始站立重置训练组 | 848 | 121 | 119 | 119 | 119 | 121 | 124 | 125 |
| 起身后启动状态课程训练组 | 847 | 121 | 123 | 123 | 119 | 116 | 120 | 125 |

七项计数取第1125步，每项预分配128个场景。完整七指令入口要求每项至少122/128且合计852/896。三组均在22.50秒的入口结束。候选相对官方滚翻增加23个、减少29个通过场景，净差−6个。相对同预算训练对照增加29个、减少30个，净差−1个。候选的前进、后退入口相比训练对照各增加4个，同时右转减少5个、左平移减少4个。这些分组反映哪些场景进入末段，末段指令的20秒跟踪属于下一项评分。

346项物理与控制器状态从共同滚翻时刻逐项恢复。三组开头的实际观测、此前关节目标和首个4ms电机输入一致，已审计候选权重在滚翻边界生效和每条录像的物理帧。评估共1,948,800条场景转移。采样末尾读取了旧计数字段，恢复步骤核对了10,875个物理子步的账本与原片，再用其独立评分。[独立评分](action-comparison/analysis.json) · [计数复核](action-comparison/closeout-readback.json) · [评分命令日志](action-comparison/independent-score.log)

[官方滚翻模型原片](../../../evaluations/duck-roll-post-getup-actor-comparison-s1257-20261121T082647/official-reference/clip-step-0.mp4) · [原始站立重置训练组原片](../../../evaluations/duck-roll-post-getup-actor-comparison-s1257-20261121T082647/official-standing-reset/clip-step-0.mp4) · [起身后启动状态课程训练组原片](../../../evaluations/duck-roll-post-getup-actor-comparison-s1257-20261121T082647/post-getup-start-curriculum/clip-step-0.mp4)

![起身后滚翻训练对照关键帧](action-comparison/keyframes.jpg)

## 分姿态结果

| 实际释放姿态 | 预分配场景 | 共同滚翻入口 | 官方滚翻模型通过 | 原始站立重置训练组通过 | 起身后启动状态课程训练组通过 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 俯卧 | 112 | 112 | 108 | 105 | 109 |
| 仰卧 | 533 | 520 | 505 | 501 | 501 |
| 左侧卧 | 97 | 97 | 93 | 96 | 92 |
| 右侧卧 | 154 | 150 | 147 | 146 | 145 |

三组共用879个滚翻入口，另外17个场景在共同前段止于起身站立。候选进入后失分32个，均因有效支撑下的正向转角不足。其中19个实际释放姿态为仰卧，官方组在同一仰卧入口群体中为15个。候选首步关节目标相对官方模型和原始站立重置组的逐场景均方根差中位数分别为0.01033rad和0.00500rad。此次增加启动状态覆盖主要改变了不同场景的通过分布，整组通过数仍低于原模型；后续优先检查仰卧起身后的头足支撑交接。[分姿态复算与首步关节目标](action-comparison/release-subgroups.json) · [关键帧时间及来源](action-comparison/keyframe-source.json)

在既定的滚翻后0.54–0.92秒窗口，按20ms评分边界核算正向转角。仰卧组中，候选新增通过的15个场景在无地面接触时发生的转角相对官方减少22.59°，变为未通过的19个场景增加25.46°，两项均为对应场景配对差的中位数。全部520个共同进入的仰卧场景的配对差中位数为0°。该窗口能解释两类场景结果的交换，为后续支撑交接对照提供了时间范围。[仰卧支撑窗口](action-comparison/supine-support-window.json) · [轨迹复算脚本](../../../../scripts/validation/analyze_roll_post_getup_comparison.py)
