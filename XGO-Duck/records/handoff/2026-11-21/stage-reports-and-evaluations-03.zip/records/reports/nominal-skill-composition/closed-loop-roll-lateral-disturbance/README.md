# 标称连续路线滚翻横向扰动

独立种子2257的896个场景使用标称足底滑动摩擦系数1.0、7.7V、4ms电机更新与20ms策略周期。沿用已通过独立验证的模型组和滚翻段2ms积分。三组共同完成跌倒、起身、站稳与前滚翻的前160ms，在第608步、12.16秒恢复同一快照。沿第600步机身朝向的水平横向分别施加0、+0.08和−0.08m/s速度增量。885个正在滚翻的场景符合扰动条件，左右扰动组分别对同一集合施加增量，其余场景仍计入全部评分。[冻结配置](../../../../configs/experiments/nominal_roll_lateral_disturbance.json) · [模型与标称确认](../closed-loop-timestep-confirmation/README.md) · [共同快照与扰动覆盖](../../../evaluations/duck-roll-lateral-disturbance-2ms-s2257-20261121T171005/fork.json) · [覆盖读数](../../../evaluations/duck-roll-lateral-disturbance-2ms-s2257-20261121T171005/impulse-coverage.json)

同一快照核对346项状态。实际CUDA零步先对448个环境核对指定速度坐标和恢复，再在每个真实分支读回首个物理求解输入。三组首个策略观测、动作目标和首个延迟电机输入一致。两组扰动的水平速度写入误差最高1.49×10⁻⁸m/s。[CUDA零步](zero/push-writer.json) · [冻结与准入日志](../closed-loop-roll-lateral-disturbance-entry-command.log) · [物理读回与评分](analysis.json)

## 完整路线结果

三组共同的起身结果为884/896，实际俯卧112/112、仰卧508/514、左侧卧113/113、右侧卧151/157。三组均完成42.5秒，含落地后20秒的预分配指令。使用原起身、滚翻、单项指令及完整路线判据，三组均通过。[原判据逐场景复算](analysis.json)

| 指标 | 无扰动 | 左向0.08m/s | 右向0.08m/s | 原最低通过数 |
| --- | ---: | ---: | ---: | ---: |
| 滚翻完成并落地持稳 | 877/896 | 869/896 | 874/896 | 812/896 |
| 完整连续路线 | 874/896 | 867/896 | 873/896 | 852/896 |
| 站立 | 128/128 | 125/128 | 126/128 | 122/128 |
| 前进 | 123/128 | 124/128 | 125/128 | 122/128 |
| 后退 | 123/128 | 123/128 | 124/128 | 122/128 |
| 左转 | 125/128 | 125/128 | 123/128 | 122/128 |
| 右转 | 125/128 | 122/128 | 125/128 | 122/128 |
| 左平移 | 126/128 | 123/128 | 126/128 | 122/128 |
| 右平移 | 124/128 | 125/128 | 124/128 | 122/128 |

与无扰动逐场景配对，左向组完整通过新增9例、失去16例，净少7例。右向组新增10例、失去11例，净少1例。左向扰动后的右转恰好达到原门槛。低摩擦工况沿独立流程验收，保留种子2246。[方向配对与逐指令结果](analysis.json)

## VS Code观察与原片

三组在本机CUDA上完成4,622,464条场景转移和32,465次批量物理求解，整卡峰值5,860MiB。每段原片具有1,064帧。标注图使用实际受到扰动的环境0，该环境的末段指令是右平移。[运行中读回](live-readback.json) · [VS Code最终状态](final-view/native-status.txt) · [采样曲线](final-view/native-curve.png) · [最终实景](final-view/native-latest.jpg) · [采样日志](sample-command.log) · [评分日志](score-command.log)

![滚翻横向扰动对照](keyframes.jpg)

[无扰动42.5秒原片](../../../evaluations/duck-roll-lateral-disturbance-2ms-s2257-20261121T171005/no-push/clip-step-0.mp4) · [左向扰动42.5秒原片](../../../evaluations/duck-roll-lateral-disturbance-2ms-s2257-20261121T171005/left-push/clip-step-0.mp4) · [右向扰动42.5秒原片](../../../evaluations/duck-roll-lateral-disturbance-2ms-s2257-20261121T171005/right-push/clip-step-0.mp4) · [关键帧来源](keyframe-source.json)
