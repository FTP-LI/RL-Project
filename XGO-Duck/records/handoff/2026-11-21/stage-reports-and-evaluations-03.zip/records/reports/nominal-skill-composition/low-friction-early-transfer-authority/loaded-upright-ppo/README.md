# 低摩擦承重转正配对训练

沿用0.8足底摩擦、4ms求解、20ms策略周期、原61维策略观测及同一父检查点。右脚首次连续三次4ms读到超过标称机重2%的载荷后，从下一次求解起计80ms。每步只在两脚各超过2%且合计达到50%时，以双足载荷权重计入有符号转正量。两组都读取同样的解算数据，候选组在原奖励上以0.35为整窗上限加入这一项。[归档对照与CUDA计分核验](../README.md) · [实际采样配置](../../../../../configs/experiments/nominal_low_friction_loaded_upright_ppo_capacity_friction_readback_rate_readback.json)

## 实际采样和本机并行规模

种子5517，三档各运行160个控制步。奖励采集窗内，每个控制步用五次原求解的载荷与前后姿态复算。三档的独立接触力比较最大差为3.34×10⁻⁶N，单步加权角度最大差为1.06×10⁻⁵°，奖励管理器的浮点读回逐值相等。吞吐取第124–138步及第139–153步两段中较慢的一段，包含实际模型推理、求解及奖励读回。进程CPU时间覆盖全轮初始化、观测、计算和归档。压缩读数统计实际的载荷、姿态与奖励数组大小。[运行初态、计分和场景核验](measured-capacity/preflight.json) · [容量选择](measured-capacity/selection.json)

| 并行场景 | 保守采样吞吐（条/秒） | 整卡显存峰值（MiB） | 进程CPU时间（秒） | 压缩读数（MiB） | 运行凭据 |
| ---: | ---: | ---: | ---: | ---: | --- |
| 1,536 | 17,630 | 8,031 | 19.13 | 12.82 | [结果、时间与显存](measured-capacity/n1536/result.json) · [真实载荷核验](measured-capacity/n1536/live-solver-parity.json) |
| 2,304 | 21,389 | 10,647 | 22.34 | 19.22 | [结果、时间与显存](measured-capacity/n2304/result.json) · [运行中真实帧与曲线凭据](measured-capacity/n2304/live-readback.json) |
| 3,072 | 24,645 | 13,355 | 26.41 | 25.63 | [结果、时间与显存](measured-capacity/n3072/result.json) · [运行中真实帧与曲线凭据](measured-capacity/n3072/live-readback.json) |

以3,072场景冻结原奖励组与候选组，各17次更新、408个控制步、1,253,376条转移。GPU显存上限为整卡的85%。上列吞吐为无学习短测，正式训练的回报、更新速度、状态、视频、模型和动作验收单独记录。[冻结训练配置](../../../../../configs/experiments/nominal_low_friction_loaded_upright_ppo.json)

首轮在零物理步发现继承的标称参考表与预定0.8系数恰好差两处，随后恢复既有的两足系数匹配检查。第二轮1,536场景运行至160步，离线检查发现CUDA标量除法和NumPy运算顺序引入舍入差，本机数组实验复现该差异。最终执行按CUDA的binary32运算逐值复算，并为三档保存原载荷、四元数与奖励数组。[零步停止](capacity/n1536/result.json) · [采样结束后的核对停止](verified-capacity/n1536/result.json) · [CUDA舍入实验](capacity-rate-diagnostic.log)

## 训练与产物

CUDA零步的观测、策略、价值网络和优化器签名一致，训练的锚点和保留样本抽取逐次一致。两组各完成17次更新、1,253,376条转移、1,560次策略梯度步和2,040次价值网络梯度步。实际训练到第100步时，3,072个场景中有2个仰卧分类不同，四元数对应旋转距离的中位数为0.0088°，最大65.56°。动作评价另用同一次跌倒释放快照。[CUDA初态签名](cuda-zero/matched.json) · [权重、保存点、原片和观测核验](training-verification.json)

| 训练组 | 净训练吞吐（条/秒） | 整卡显存峰值（MiB） | VS Code记录与8秒原片 | 模型和可恢复保存点 |
| --- | ---: | ---: | --- | --- |
| 原奖励对照 | 13,673 | 13,406 | [逐次训练曲线](control/final-view/native-curve.png) · [运行中读回](control/live-readback.json) · [原片](../../../../experiments/duck-getup-loaded-upright-friction080-control-s5517-20261121T200255/clip-step-0.mp4) · [命令日志](control/training-command.log) | [ONNX](../../../../../artifacts/duck-getup-loaded-upright-friction080-control-s5517-20261121T200255/policy.onnx) · [包含优化器的保存点](../../../../experiments/duck-getup-loaded-upright-friction080-control-s5517-20261121T200255/model-final.pt) |
| 承重后转正候选 | 13,611 | 13,393 | [逐次训练曲线](candidate/final-view/native-curve.png) · [运行中读回](candidate/live-readback.json) · [原片](../../../../experiments/duck-getup-loaded-upright-friction080-candidate-s5517-20261121T200255/clip-step-0.mp4) · [命令日志](candidate/training-command.log) | [ONNX](../../../../../artifacts/duck-getup-loaded-upright-friction080-candidate-s5517-20261121T200255/policy.onnx) · [包含优化器的保存点](../../../../experiments/duck-getup-loaded-upright-friction080-candidate-s5517-20261121T200255/model-final.pt) |

原奖励组计算了相同的计分，新增项实际进入奖励管理器的记录为0。候选组对应5,157条非零记分的场景控制步，其中5,123条为正、34条为负。两组各在224个保存的61维观测上验证导出ONNX，实际最大输出绝对差为1.04×10⁻⁶。原片各201帧，覆盖第一个8秒回合，终态在环境自动重置前验证。[原奖励组计算记录](control/reward-audits.json) · [候选组计算记录](candidate/reward-audits.json) · [复核命令](training-verify-command.log)

## 同一跌倒释放的动作对照

种子1257、足底摩擦系数0.8。父策略、原奖励对照、承重后转正候选从第100步的同一份释放快照分支，复核346项物理和控制器状态。在第600步按原15°倾角与25步持稳条件，计数符合滚翻入口的起身场景。三组共1,433,600条评价转移，实际仰卧释放533/896。每段12秒原片覆盖跌倒、释放、起身及持稳，当前评分对应滚翻入口。[冻结配置](../../../../../configs/experiments/nominal_low_friction_loaded_upright_ppo_action.json) · [逐项评分](action-comparison/analysis.json) · [运行日志](action-sample-command.log) · [评分日志](action-score-command.log)

| 指标 | 父策略 | 原奖励对照 | 承重后转正候选 |
| --- | ---: | ---: | ---: |
| 原起身评分及滚翻前准入（各896场景） | 880 | 882 | 881 |
| 实际仰卧释放的滚翻前准入（各533场景） | 520 | 522 | 522 |
| 目标仰卧的原起身评分（各224场景，门槛213） | 212 | 213 | 213 |
| 站立分组滚翻前准入（各128场景） | 127 | 127 | 127 |
| 前进分组滚翻前准入（各128场景） | 125 | 126 | 125 |
| 后退分组滚翻前准入（各128场景） | 126 | 127 | 127 |
| 左转分组滚翻前准入（各128场景） | 122 | 123 | 123 |
| 右转分组滚翻前准入（各128场景） | 127 | 127 | 127 |
| 左平移分组滚翻前准入（各128场景） | 125 | 124 | 124 |
| 右平移分组滚翻前准入（各128场景） | 128 | 128 | 128 |
| 12秒仿真原片 | [父策略](../../../../evaluations/duck-getup-loaded-upright-action-friction080-s1257-20261121T201135/parent-policy/clip-step-0.mp4) | [原奖励对照](../../../../evaluations/duck-getup-loaded-upright-action-friction080-s1257-20261121T201135/original-reward/clip-step-0.mp4) | [承重后转正候选](../../../../evaluations/duck-getup-loaded-upright-action-friction080-s1257-20261121T201135/loaded-upright-reward/clip-step-0.mp4) |

候选相对父策略新增4例、失去3例，相对原奖励对照新增2例、失去3例。前进分组相对两组分别净变0例和−1例，距分别净增2例的门槛差2例和3例。本轮归档候选ONNX、可恢复保存点及全过程，完整低摩擦路线留待满足入口条件的方案，独立种子保留2246。[配对场景与晋级结果](action-comparison/analysis.json)

## 起身轨迹复核

相对原奖励对照，候选新增左转场景672。第600步，候选倾角1.29°且头部离地，原奖励组倾角32.11°且头部接地。前进场景283中，候选倾角34.01°且头部接地，原奖励组为1.46°且头部离地。候选11个实际仰卧未准入场景在末25步均持续头部与双足接地且倾角超过15°。前进分组的场景439、779在三组均呈现这项特征。[逐帧轨迹及配对场景](action-comparison/motion-review.json)

左转场景863实际为右侧释放，三组使用相同的右侧策略。原奖励组与候选组第100步的观测输入、原始动作和实际关节目标逐值相等。首批5个求解子步的电机扭矩请求最大差为5.19×10⁻⁵N·m，记录的姿态从第101步出现差别。该场景计入原路线保护门槛，作为并行闭环轨迹差异单独记录。[释放动作与轨迹复核](action-comparison/motion-review.json)

![仰卧起身关键帧](action-comparison/support-credit-keyframes.jpg)

[VS Code历史状态](action-comparison/final-view/native-status.txt) · [实际采样曲线](action-comparison/final-view/native-curve.png) · [实际末帧](action-comparison/final-view/native-latest.jpg) · [运行中读回](action-comparison/live-readback.json)

## 前进分组的起身时序

将本轮三组与此前同快照、同父权重的两遍4ms参照分批复算。每组前进分组均有80个实际仰卧场景。以连续三个20ms观测确认双足接地与头部离地，同时核对倾角是否进入15°。五组各自最终准入的实际仰卧场景为77、78、77、75、75例，截至第200步各组准入场景均满足该姿态组合。两遍同权重参照的前进准入各123/128，126个场景的准入判定相同，场景283和727交换结果。因此将283用于重复性检查，将五遍均未准入的439与779用于后续支撑响应核验。[逐场景事件与来源哈希](action-comparison/forward-getup-readback.json) · [复算命令](forward-getup-readback-command.log)

| 场景 | 候选的早段轨迹 | 后续核验 |
| --- | --- | --- |
| 439 | 第144步确认双足接地且头部离地，第149步确认头部重新接地 | 核对这100ms的承重转移及转正角 |
| 779 | 第101–200步未出现连续三次双足接地且头部离地 | 核对首次双足承重的姿态和关节执行量 |

## 源码与复现入口

在VS Code打开[当前训练记录](../../../../training-current.md)，可从对应运行编号打开学习曲线、执行日志、真实画面及视频。电脑环境、一般训练任务和观察操作见[电脑环境与训练手册](../../../../../docs/runbooks/pc_training.md)。本轮的四个入口依次负责实时采样、两组配对、原门槛动作评分及归档复算。[采样奖励](../../../../../scripts/training/getup_loaded_upright_sampler.py) · [容量和训练入口](../../../../../scripts/validation/recover_nominal_low_friction_loaded_upright_rate.py) · [动作评分入口](../../../../../scripts/validation/verify_nominal_low_friction_loaded_upright_ppo.py) · [时序复算入口](../../../../../scripts/validation/review_nominal_low_friction_forward_getup.py)
