# 连续路线供电与舵机时延对照

独立种子2258的三组均使用896个场景、足底滑动摩擦系数1.0和原连续路线模型。三组请求的释放姿态和后续指令分配逐场景一致，各自只在起点重置一次。参照设置为7.7V和4ms舵机延迟，另两组分别设置7.4V或8ms舵机延迟。策略周期保持20ms，滚翻第600至1050步的求解间隔保持2ms，舵机仍每4ms更新。三组共完成4,816,000条场景转移，执行33,625次并行物理求解，学习更新为0。[冻结配置](../../../../configs/experiments/nominal_route_voltage_delay.json) · [执行与复算脚本](../../../../scripts/validation/run_nominal_route_voltage_delay.py) · [综合评分](analysis.json)

## 动作结果

原评分要求起身实际姿态逐项过线、滚翻至少812/896、七指令各至少122/128、全路线至少852/896。右转入口121/128使标称参照在第1125步结束。7.4V供电与8ms舵机延迟各自跑满第2125步，并分别通过881/896和891/896条路线。两组七项指令的独立完成人数均达到原门槛。标称参照只取得入口评分，完整路线的相对增益待配对终局评分。[原评分复算及场景编号](paired-phase-readback.json) · [汇总命令](consolidate-command.log)

| 工况 | 起身及持稳 | 滚翻并落地持稳 | 右转入口 | 完整路线 | 录像覆盖的仿真时间 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 标称7.7V与4ms舵机延迟 | 884/896 | 872/896 | 121/128 | 阶段止于入口 | 22.50秒 |
| 7.4V供电与4ms舵机延迟 | 889/896 | 884/896 | 125/128 | 881/896 | 42.50秒 |
| 7.7V供电与8ms舵机延迟 | 893/896 | 891/896 | 127/128 | 891/896 | 42.50秒 |

| 分配指令 | 标称组准入 | 7.4V组完整通过 | 8ms组完整通过 |
| --- | ---: | ---: | ---: |
| 站立 | 125/128 | 126/128 | 126/128 |
| 前进 | 127/128 | 127/128 | 127/128 |
| 后退 | 125/128 | 125/128 | 128/128 |
| 左转 | 125/128 | 124/128 | 127/128 |
| 右转 | 121/128 | 125/128 | 127/128 |
| 左平移 | 126/128 | 127/128 | 128/128 |
| 右平移 | 123/128 | 127/128 | 128/128 |

按相同场景编号比较，7.4V供电组相对参照新增19个、减少7个七指令准入，右转分组新增6个、减少2个。8ms舵机延迟组新增24个、减少5个七指令准入，右转分组新增7个、减少1个。两组分别有11和38个场景的实际释放姿态类别改变。工况从回合开始生效，观测差异包括跌倒准备、起身和滚翻的累积影响。[逐场景配对复算](paired-phase-readback.json) · [复算命令与输出](paired-phase-command.log)

## 执行器读回

在滚翻切换前后读取连续20个4ms舵机周期，逐步核对所请求目标、实际延迟目标、电压及同一舵机输入下的两次2ms求解。7.4V组测得的带载电压中位数为7.173V，执行器下限实读为7.000V。8ms组实际延迟为两个4ms周期。首次零步核验将供电组初力矩设成相等，后续从原数组更正为按7.4/7.7的比例核验，最大绝对误差2.98×10⁻⁸N·m。三组初态位置、速度、策略观测与场景字段的匹配已复核。[首次预检记录](../closed-loop-voltage-delay-entry-command.log) · [零步修订与复核](zero-comparison.json) · [命令记录](zero-recovery-command.log)

| 工况 | 实际舵机延迟 | 滚翻切换窗口带载电压中位数 | 整卡显存峰值 |
| --- | ---: | ---: | ---: |
| 标称7.7V与4ms舵机延迟 | 4ms | 7.465V | 5,535MiB |
| 7.4V供电与4ms舵机延迟 | 4ms | 7.173V | 5,615MiB |
| 7.7V供电与8ms舵机延迟 | 8ms | 7.494V | 5,693MiB |

## VS Code观察与关键帧

在VS Code打开[当前训练记录](../../../training-current.md)，从相应工况进入状态文本、曲线或录像。供电组和时延组分别留下两次运行中抽查，覆盖第50步至第100步，验证状态更新和真实仿真帧一致。标称组保留出场日志和完成后的观察快照。[7.4V运行中读回](voltage-7p4v/live-readback.json) · [8ms运行中读回](delay-8ms/live-readback.json) · [观察归档命令](observer-closeout.log)

| 工况 | VS Code状态及真实曲线 | 仿真原片及执行记录 |
| --- | --- | --- |
| 标称7.7V与4ms舵机延迟 | [状态](nominal-7p7v-4ms/final-view/native-status.txt) · [曲线](nominal-7p7v-4ms/final-view/native-curve.png) · [采样记录](nominal-7p7v-4ms/final-view/native-metrics.csv) | [22.50秒原片](../../../evaluations/duck-route-nominal-7p7v-4ms-2ms-s2258-20261121T180719/clip-step-0.mp4) · [采样日志](nominal-7p7v-4ms/sample-command.log) · [评分日志](nominal-7p7v-4ms/score-command.log) · [执行器核验](nominal-7p7v-4ms/actuator-audit.json) |
| 7.4V供电与4ms舵机延迟 | [状态](voltage-7p4v/final-view/native-status.txt) · [曲线](voltage-7p4v/final-view/native-curve.png) · [采样记录](voltage-7p4v/final-view/native-metrics.csv) | [42.50秒原片](../../../evaluations/duck-route-voltage-7p4v-2ms-s2258-20261121T180719/clip-step-0.mp4) · [采样日志](voltage-7p4v/sample-command.log) · [评分日志](voltage-7p4v/score-command.log) · [执行器核验](voltage-7p4v/actuator-audit.json) |
| 7.7V供电与8ms舵机延迟 | [状态](delay-8ms/final-view/native-status.txt) · [曲线](delay-8ms/final-view/native-curve.png) · [采样记录](delay-8ms/final-view/native-metrics.csv) | [42.50秒原片](../../../evaluations/duck-route-delay-8ms-2ms-s2258-20261121T180719/clip-step-0.mp4) · [采样日志](delay-8ms/sample-command.log) · [评分日志](delay-8ms/score-command.log) · [执行器核验](delay-8ms/actuator-audit.json) |

![供电与舵机时延对照关键帧](keyframes.jpg)

关键帧来自实际原片的场景0。标称组末帧处于指令入口，两个因素组末帧分别完成所分配的右平移动作。本批作用范围为摩擦系数1.0的单因素仿真，低摩擦工况另行验收。[帧号、时间及来源哈希](paired-phase-readback.json) · [低摩擦阶段记录](../low-friction-right-support-trial/support-timing/README.md)
