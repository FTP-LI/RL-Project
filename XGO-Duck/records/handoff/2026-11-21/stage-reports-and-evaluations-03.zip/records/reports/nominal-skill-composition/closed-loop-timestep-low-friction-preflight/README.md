# 低摩擦初态核验

开发种子1257分别在脚底滑动摩擦系数1.0与0.8加载同一套已验收的策略，各准备896个CUDA场景。两组的33项编译模型字段一致。实际GPU初始化后逐项比较关节阻尼、关节摩擦损失和碰撞几何摩擦，仅两个足底几何的滑动分量从1.0变为0.8。初始广义位置、速度、电机控制和策略观测逐位相同。两组新增物理步均为0。种子2246保留。[实际字段核验](rng-recovery/analysis.json) · [标称初态](rng-recovery/nominal/proof.json) · [低摩擦初态](rng-recovery/lower-friction/proof.json) · [实际执行日志](rng-recovery/zero-readback-command.log)

首次读取在零步触发偏航预测器随机状态检查。沿用标称路线的隔离加载后，CPU随机状态一致，3条固定探针输入的预测输出逐位一致。[首次日志](zero-readback-command.log) · [加载复算](rng-recovery/rng-readback.json) · [修正后冻结协议](../../../../configs/experiments/nominal_timestep_low_friction_preflight_rng_recovery.json)
