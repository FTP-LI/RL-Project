# 低摩擦起身配对训练

## 奖励与对照

两组使用同一仰卧策略父检查点、Adam状态、3,072个并行场景、训练种子5417和每组17次更新。仿真足底滑动摩擦系数为0.8。每次更新采样24步，每组预算1,253,376条场景转移。训练仍只更新策略最后一层的腿部输出。两组均在释放后的480ms至1秒记录五次4ms求解并取平均。候选增加承重交接奖励，整个窗口的最大折扣贡献为0.35。原奖励组的新增项系数为0。结算时使用相同的原起身、滚翻前准入、前进分组与左转分组判据。[训练冻结配置](../../../../../configs/experiments/nominal_low_friction_support_ppo.json) · [承重交接测量与候选依据](../README.md)

## 本机并行规模

| 并行场景 | 实际控制步 | 整卡显存峰值 | 真实奖励采样 |
| ---: | ---: | ---: | --- |
| 3,072 | 150 | 13,089MiB | 第125–137步24,186条转移/秒，第137–149步24,875条转移/秒 |
| 3,328 | 11 | 13,967MiB | 到达显存上限后结束 |
| 3,584 | 0 | — | 3,328场景已达到上限 |

显卡总显存为16,384MiB，预先冻结的使用上限为85%。实际使用3,072场景。短测包括策略推理、仿真和奖励读回，正式PPO吞吐从两组训练记录计算。3,072场景短测在两个控制步逐一核对十次4ms求解，GPU与CPU法向合力最大绝对差3.25×10⁻⁶N。[规模选择凭据](verified-capacity/selection.json) · [3,072场景短测](verified-capacity/n3072/result.json) · [求解时序与奖励读回](verified-capacity/n3072/native-clock-parity.json) · [3,328场景资源记录](verified-capacity/n3328/result.json)

首次零步预检沿用标称摩擦参考表，定位到两处足底滑动系数差异。更正预期表后，保留其它场景字段、执行器初态和观测接口的逐项比较。首次预检产生0条物理转移。[首次预检命令](capacity/profile-n3072-command.log) · [更正后的预检](verified-capacity/preflight.json)

## 训练过程与产物

两组实际CUDA初态及优化器签名一致。两组各完成17次更新、1,253,376条场景转移、1,560次策略梯度步和2,040次价值网络梯度步。实测整卡峰值均为13,185MiB，约为总显存的80.5%。按训练资源采样计算，原奖励组和候选组的GPU利用率中位数分别为50.0%和52.5%。第100步释放时，3,072个训练场景中有10个仰卧分类不一致，配对旋转距离中位数为0.00777°。动作对照使用另一次评估的共同释放快照。[匹配初态凭据](cuda-zero/matched.json) · [权重、优化器、回放抽样与视频核验](training-verification.json) · [训练与动作原档复算](archive-recheck-command.log)

| 分组 | 正式训练净吞吐 | 端到端吞吐 | VS Code曲线及原片 | 权重及可恢复保存点 |
| --- | ---: | ---: | --- | --- |
| 原奖励对照 | 13,602条转移/秒 | 12,508条转移/秒 | [训练曲线](control/final-view/native-curve.png) · [8秒原片](../../../../experiments/duck-getup-support-credit-friction080-control-s5417-20261121T154357/clip-step-0.mp4) | [ONNX](../../../../../artifacts/duck-getup-support-credit-friction080-control-s5417-20261121T154357/policy.onnx) · [最终保存点](../../../../experiments/duck-getup-support-credit-friction080-control-s5417-20261121T154357/model-final.pt) |
| 承重交接奖励候选 | 12,774条转移/秒 | 11,807条转移/秒 | [训练曲线](candidate/final-view/native-curve.png) · [8秒原片](../../../../experiments/duck-getup-support-credit-friction080-candidate-s5417-20261121T154357/clip-step-0.mp4) | [ONNX](../../../../../artifacts/duck-getup-support-credit-friction080-candidate-s5417-20261121T154357/policy.onnx) · [最终保存点](../../../../experiments/duck-getup-support-credit-friction080-candidate-s5417-20261121T154357/model-final.pt) |

两段视频各201帧，终态在自动重置前记录。第17次更新包含新回合的前8个控制步，日志末行的瞬时持稳率对应新回合起点。净吞吐从训练状态开始计时，端到端吞吐计入初始化及最终写盘。[VS Code过程记录](../../../../training-current.md) · [原奖励组命令及输出](control/training-command.log) · [承重交接奖励候选命令及输出](candidate/training-command.log)

## 同快照动作结果

种子1257在第100步记录共同释放的346项物理、控制器及随机状态。三组均由此恢复，只在仰卧路由替换策略，统一运行至第600步。评估共1,433,600条场景转移，原起身评分要求按时进入并连续持稳，滚翻前准入按原15°与25步持稳规则复算。此轮按后续指令分配场景，三组录像到滚翻启动前结束。[冻结配置](../../../../../configs/experiments/nominal_low_friction_support_ppo_action.json) · [逐场景配对和七指令分组](action-comparison/analysis.json) · [采样命令与输出](action-sample-command.log) · [评分命令与输出](action-score-command.log)

| 策略 | 原起身通过 | 滚翻前准入 | 实际仰卧场景的滚翻前准入 | 前进分组滚翻前准入 | 左转分组滚翻前准入 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 父策略 | 885/896 | 885/896 | 523/532 | 126/128 | 123/128 |
| 原奖励对照 | 878/896 | 878/896 | 518/532 | 126/128 | 122/128 |
| 承重交接奖励候选 | 880/896 | 880/896 | 520/532 | 126/128 | 123/128 |

候选相对原奖励对照新增通过6个场景，转为失分4个，净增2个。相对父策略新增通过2个，转为失分7个，净减5个。前进分组净增为0，未达到晋级要求的2个。父策略继续用于低摩擦连续路线的后续验证，候选ONNX及检查点作为实验记录保存。独立种子2246留作确认。[同释放快照凭据](../../../../evaluations/duck-getup-support-credit-action-friction080-s1257-20261121T155133/fork.json)

三段原片各301帧，从回合起点录至第12秒。相机对应预先固定的场景0。[父策略12秒原片](../../../../evaluations/duck-getup-support-credit-action-friction080-s1257-20261121T155133/parent-policy/clip-step-0.mp4) · [原奖励对照12秒原片](../../../../evaluations/duck-getup-support-credit-action-friction080-s1257-20261121T155133/original-reward/clip-step-0.mp4) · [承重交接奖励候选12秒原片](../../../../evaluations/duck-getup-support-credit-action-friction080-s1257-20261121T155133/support-credit-reward/clip-step-0.mp4) · [运行中观察读回](action-comparison/live-readback.json)

## 起身姿态复盘

第150步奖励窗结束时，532个实际仰卧场景中，两组自训权重各有517个机身倾角进入15°以内、510个双足接地且头部离地。父策略对应为521个和515个。第600步，候选的12个实际仰卧未准入场景在末25个20ms采样点均保持头部及双足接地，倾角持续超过15°。本轮改善了部分场景的最终准入，奖励窗口结束时的整体支撑读数仍与原奖励组相同。[逐时刻姿态和接触复算](action-comparison/support-credit-motion-review.json)

图中取相对父策略分别转为通过和失分的最小编号实际仰卧场景。场景167在第12秒，父策略倾角32.7°且头部接地，原奖励与候选分别为1.0°和1.5°且头部离地。场景223中，父策略为1.7°且头部离地，原奖励与候选分别为33.5°和32.6°且头部接地。[评估最终状态](action-comparison/final-view/native-status.txt) · [评估采样曲线](action-comparison/final-view/native-curve.png)

![低摩擦仰卧起身关键帧](action-comparison/support-credit-keyframes.jpg)
