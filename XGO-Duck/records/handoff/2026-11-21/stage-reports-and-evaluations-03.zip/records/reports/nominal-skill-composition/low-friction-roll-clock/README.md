# 低摩擦滚翻求解时钟核验

低摩擦连续路线中有6个前进或左转场景在滚翻阶段因有效支撑转角不足失分。各自有效转角峰值前，滚翻最初1.20秒的20ms采样漏计34.55°至43.43°。从原种子1257第600步选取这6个场景及10个达到后续指令入口的场景。读取归档位置、速度及首个控制步的5份实际电机输入，作为两种积分步长共用的输入。[原失分场景与时序复算](../closed-loop-timestep-low-friction-development/standing-and-roll-mechanisms.json) · [冻结配置](../../../../configs/experiments/nominal_low_friction_roll_clock.json)

| CUDA求解步长 | 4ms电机区间 | 每区间求解次数 | 共用电机信号的批量求解次数 | 仿真时间 |
| --- | ---: | ---: | ---: | ---: |
| 2ms | 5 | 2 | 10 | 20ms |
| 1ms | 5 | 4 | 20 | 20ms |

两组六项起点读回一致，CUDA读回确认两脚滑动摩擦为0.8。16个场景共完成480次场景求解。每个电机区间的输入逐次核对。核验采用开环归档电机信号，覆盖一个控制步。完整滚翻、后续动作及扰动成绩由后续闭环试验计分，种子2246留作独立确认。[实际CUDA时钟与命令](clock-readback.json) · [全过程命令和输出](../early-getup-load/support-progress/low-friction-action-comparison/next-stage-clock-command.log)
