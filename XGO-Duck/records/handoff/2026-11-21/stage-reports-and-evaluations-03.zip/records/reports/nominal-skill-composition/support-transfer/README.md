# 仰卧恢复后滚翻支撑交接

以实际仰卧释放的场景为主，复算滚翻后0.54–0.92秒中评分边界无接触的正向转动区间。整机、头部和脚部承重定义为各自4ms求解的法向载荷超过标称整机重量的2%。足部持续承重要求至少一只脚连续3次求解承重。

## 种子1256归档复算

11个有效支撑转角失分场景共出现49次卸载，45次在头部重新承重后结束，4次在脚部重新承重后结束。495个通过滚翻的仰卧场景中，565次卸载的接触恢复类型分别为头部到头部416次、头部到其他接触36次、脚部到脚部113次。两组卸载时长的中位数均为4ms，头部到首个持续足部承重的间隔中位数均为84ms。[逐场景归档复算](archived-support-transfer.json) · [复算命令](../nominal-support-transfer-archive.log)

## 种子1257补录

种子1257沿用已经评分的原站立、官方滚翻和其余动作策略。滚翻开始后0.40–1.40秒记录4ms求解载荷、积分前位姿与速度、14路目标、延迟与滤波后的目标、实际电压和求解力矩。与种子1256比较时统一使用0.40–1.10秒窗口。动作评分沿用原始门槛和指令进入规则。

首次入口在创建CUDA场景前遇到上下文管理器类型错误。恢复入口重新登记，沿用同一采样范围及初态要求。[原冻结方案](../../../../configs/experiments/nominal_roll_support_transfer.json) · [恢复冻结方案](../../../../configs/experiments/nominal_roll_support_transfer_entry_recovery.json) · [首次运行日志](../nominal-support-transfer-run.log) · [恢复运行日志](../nominal-support-transfer-recovery.log)

种子1257的实际CUDA初态和归档初态逐项一致，14路关节、执行器、电机和力矩读取列已对齐。[CUDA初态](zero/proof.json) · [关节与力矩读取顺序](zero/actuation-layout.json)

[采样状态](native-view/native-status.txt) · [采样曲线](native-view/native-curve.png) · [最近实景](native-view/native-latest.jpg)

## 动作与支撑结果

种子1257补录的起身与持稳为882/896，滚翻与落地站立为860/896。七指令的合计入口达到852/896门槛。站立组为121/128，运行在第1125步下发指令前结束。此前同种子原策略的滚翻通过数为848/896。两次实际初态逐项一致，轨迹在第1控制步已出现数值差异，4ms读回从第620步之后开始。[原动作评分](analysis.json) · [采集账本与原片](../../../evaluations/duck_nominal_roll_support_transfer_recovery_s1257_20261121T073129/collection.json)

| 种子与仰卧组 | 场景数 | 4ms读回确认的卸载事件 | 头部卸载后由头部再承重 | 头足接棒时长中位数 |
| --- | ---: | ---: | ---: | ---: |
| 种子1256有效支撑转角不足 | 11 | 49 | 45/49 | 84ms |
| 种子1256通过滚翻 | 495 | 565 | 416/565 | 84ms |
| 种子1257有效支撑转角不足 | 10 | 46 | 42/46 | 84ms |
| 种子1257通过滚翻 | 513 | 610 | 454/610 | 84ms |

表中均用0.40–1.10秒共同窗口。种子1257的全姿态有效支撑转角失分组有103个评分边界无接触的正向转动区间。101个区间的末子步有承重，紧接着的求解已卸载。正向转角的87.89%发生在承重子步。[各场景卸载和接棒时序](support-transfer-comparison.json) · [载荷与姿态对齐](contact-load-review.json)

![仰卧滚翻的头部再接触](head-recontact-example.png)

选取头部再接触的最小场景编号及首条事件。场景1在4ms后恢复头部承重。[图中数值及位置](head-recontact-example.json)

## 单项改动筛选

对种子1257仰卧失分组的42次头部再接触复算14路电机。原电机力矩的最大复算误差为5.96×10⁻⁸N·m。卸载时头部间隙中位数约0.034mm，最近脚底间隙中位数约172mm。12个腿部±0.02rad设置中，脚底均未进入1mm的近地范围。颈部俯仰目标上调0.02rad在36/42个事件的固定状态复算中同时缩小头部间隙并产生向下的法向加速度变化。[力矩与几何复算](actuator-geometry-review.json)

先评估了180°–270°内欠载正向转角能否作为训练信号。两个种子中，仰卧失分组的中位数分别比通过组高0.46°和1.15°。预先规定两个种子的差值均至少达到1°，这项奖励复算在此结束。[冻结筛选方案](../../../../configs/experiments/nominal_roll_physical_support_replay.json) · [逐场景奖励复算](physical-support-reward-replay.json)

同初态对照选择抑制颈部目标快速下调。42个头部再接触事件在卸载前一个控制步的原颈部目标变化中位数为−0.0332rad。候选只在指定前翻相位对下降超过0.02rad的原目标作正向修正，单步修正上限0.02rad。用归档姿态代理和实测俯仰角速度核对，10/10个场景至少有一处达到0.005rad调整量，42个事件共23处。下一步在实际策略观测上核对动作接口，并在第600步保存共同状态做三分支对照。[候选草案](../../../../configs/experiments/nominal_roll_neck_descent_limit_draft.json) · [归档预检](neck-descent-limit-preflight.json)

## 运行与录像

本机RTX 3080 Laptop GPU完成1,008,000条仿真转移，250个批量物理子步保存了224,000条场景载荷与力矩记录。121个整卡采样中，GPU利用率中位数为40%，显存峰值5,354MiB。22.50秒原片的564帧通过逐帧检查及解码。[完整22.50秒原片](../../../evaluations/duck_nominal_roll_support_transfer_recovery_s1257_20261121T073129/clip-step-0.mp4) · [运行日志](../nominal-support-transfer-recovery.log)
