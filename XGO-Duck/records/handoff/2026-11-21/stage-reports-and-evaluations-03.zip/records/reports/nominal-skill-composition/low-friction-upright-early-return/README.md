# 起身目标提前交还对照

此前有3个调整场景在第550步交还原策略后才抬头，晚于原站立切换。本轮把交还时点提前100步，即第450步。保留25个腿部目标、观测触发条件、目标限位和限速。两个原策略参照与候选共用新的第250步实际CUDA快照。继续按原第550步站立切换和第600步滚翻前门槛计分。[此前交还响应](../low-friction-upright-recovery/return-response.json) · [冻结方案](../../../../configs/experiments/nominal_low_friction_upright_early_return.json) · [启动核验](preflight.json) · [CUDA采样命令和输出](sample-command.log)

可在VS Code查看[实时状态](native-view/native-status.txt)、[采样曲线](native-view/native-curve.png)和[最新画面](native-view/native-latest.jpg)。

## 原门槛评分

种子1257三组共用第250步快照，核对346项物理与控制状态。三组均识别18个持续前倾场景，候选在16个场景实际调整目标。

| 评分 | 原策略参照一 | 原策略参照二 | 第450步交还候选 |
| --- | ---: | ---: | ---: |
| 原及时起身及末段持稳 | 878/896 | 878/896 | 878/896 |
| 第600步滚翻前总体准入 | 878/896 | 878/896 | 879/896 |
| 左转分组滚翻前准入 | 123/128 | 123/128 | 123/128 |
| 左平移分组滚翻前准入 | 124/128 | 124/128 | 125/128 |

新增准入的是左平移分组场景263。候选在第468步抬头离地，实际倾角在第550步为1.01°，第600步为2.12°。原起身要求最迟第8秒开始连续持稳3秒，交还发生于第9.00秒，场景263抬头为第9.36秒。原起身评分为878/896，左转增量为0，候选留在开发对照。[逐项评分和轨迹](analysis.json)

## 目标跟踪复算

按每组交还前的末25个控制步对齐实际目标与下一物理状态。第550步交还组的15个调整场景、提前交还组的16个调整场景，均在各自最后25步持续头部接地。各场景关节跟踪均方根误差的中位数为0.0659和0.0738rad。相对触发时倾角，末端保持的配对中位变化分别为增加1.58°、1.55°。图中取前一轮出现迟发抬头的左转场景297，按保存姿态回放。每轮配对独立恢复自己的实际快照。[逐场景目标与物理读回](target-tracking.json) · [回放帧来源](return-keyframes.json)

![腿部目标交还时点](return-keyframes.jpg)

本机CUDA共采集1,164,800条场景转移、6,500次批量求解，显存峰值5,945MiB。场景0三段原片各为12秒、301帧，作为同机位过程录像。[原策略参照一原片](../../../evaluations/duck-getup-leg-return-early-friction080-s1257-20261121T142739/original-first/clip-step-0.mp4) · [原策略参照二原片](../../../evaluations/duck-getup-leg-return-early-friction080-s1257-20261121T142739/original-repeat/clip-step-0.mp4) · [提前交还候选原片](../../../evaluations/duck-getup-leg-return-early-friction080-s1257-20261121T142739/early-return-leg-recovery/clip-step-0.mp4)

[运行中读回](live-readback.json) · [最终状态](final-view/native-status.txt) · [最终曲线](final-view/native-curve.png) · [最终画面](final-view/native-latest.jpg)
