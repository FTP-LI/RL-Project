# 仰卧起身早段足底载荷

复用原起身和站立策略，在第98–170个控制步之间记录每次4ms求解的足底、头部和整机法向力。从仿真回合起点运行到第600步，按原15°倾角、连续25步持稳及关节、足地与高度条件复算滚翻准入。[采集方案](../../../../configs/experiments/nominal_supine_early_load_design.json) · [此前的首次碰地及迈脚对照](../supine-pre-bilateral-support/README.md)

| 项目 | 冻结设置 |
| --- | --- |
| 开发与复核 | 种子1256用于选择条件，种子1257沿用同一条件复核，每批896个并行场景 |
| 触地记号 | 求解记录中至少一足有足地接触点 |
| 持续足部载荷 | 任一足法向力超过标称机重2%，连续3次求解 |
| 持续双足承重 | 两足各超过标称机重2%，合计至少达到机重50%，连续5次求解 |
| 录像范围 | 12秒，覆盖跌倒、起身与滚翻前站稳检查 |

脚部是否带载取当前积分对应的求解力，姿态同时记录积分前后状态。采集器停在第600步，环境仍沿用原完整路线的时限和随机参数。[种子1256冻结配置](../../../../configs/experiments/nominal_supine_early_load_verified_s1256.json) · [种子1257冻结配置](../../../../configs/experiments/nominal_supine_early_load_verified_s1257.json)

两次入口核验均结束于零物理步。先按归档文件修正种子1256的初态凭据哈希，再修正采集入口的上下文绑定表达式。旧入口与协议保留，修正后的两份协议和CUDA初态检查单独记录。[冻结日志](../early-getup-load-freeze.log) · [首次入口日志](seed-1256/command.log) · [修正后的运行入口](../../../../scripts/validation/run_nominal_supine_early_load.py)

## 载荷与站稳复算

两批共1,075,200条仿真转移，其中645,120条场景子步有4ms载荷。4ms积分前后位姿与20ms控制边界逐位核对。标称机重7.826N。第600步原滚翻前准入分别为886/896和879/896，前进分组分别为128/128和123/128。这些计数记录进入滚翻前的站稳情况。第100–150步载荷采集段实测净吞吐分别为8,448和8,282条转移/秒，包含观察和写盘，整卡峰值分别为5,385和5,392MiB。[两批独立复算](analysis.json) · [实际复算日志](analysis-command.log)

下表以实际仰卧释放为统计单位。时间都从第100步释放起算，数值为各组中位数。

| 种子 | 站稳分组 | 场景数 | 首次足部受力 | 持续足部载荷 | 持续双足承重 | 确认双足承重时倾角 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 1256 | 进入滚翻 | 508 | 48ms | 56ms | 596ms | 10.83° |
| 1256 | 未获滚翻准入 | 6 | 44ms | 52ms | 696ms | 26.18° |
| 1257 | 进入滚翻 | 520 | 48ms | 56ms | 596ms | 10.40° |
| 1257 | 未获滚翻准入 | 14 | 44ms | 52ms | 656ms | 25.06° |

以往第131步前移试验对应释放后620ms。本次两批实际仰卧未准入场景在该时刻前分别只有1/6与3/14已达到持续双足承重。达到该条件时，未准入组仍有2/6与3/14的场景存在头部载荷。两批进入滚翻的场景在双足承重确认时分别为0/508与0/520存在头部载荷。头部载荷取大于标称机重2%的同一步求解值。

![仰卧起身足底载荷时序](support-load-chronology.png)

上排灰色点线为全部仰卧场景的首次足地接触，蓝线与棕线分别为两组达到持续双足承重的累积比例。下排曲线是逐时刻的双足法向力中位数，阴影为四分位区间。竖线定位以往前移试验的第131步，横向点线表示标称机重50%。[图与数据的核验记录](support-load-figure.json)

## 提前识别复核

用种子1256选出的条件在第128步读取倾角和最近5次求解的平均足部载荷。场景尚未确认持续双足承重、倾角至少30.10°且足载荷不超过0.887倍机重时触发。识别有效要求早于持续双足承重确认至少60ms。种子1256覆盖6/6个原未准入场景，原准入组触发22/508。种子1257沿用同一条件，覆盖9/14个原未准入场景，原准入组触发27/520。两项原预检门槛分别是覆盖≥75%和触发≤5%，种子1257分别为64.3%和5.19%。[条件、逐场景名单与载荷来源](analysis.json)

官方运行包的反馈结构提供IMU加速度、角速度及舵机角度、速度和目标。仿真足底法向力适合作为训练监督与机制诊断，部署候选的观测输入按官方反馈字段设计。[官方反馈结构](../../../../official_resources/xgoduck_runtime_arduino/python/wire.py)

## 承重前后的机身转动

在每个种子内以第100步释放时的重力方向及前20ms的转正速度匹配。6个和14个仰卧未准入场景分别配到不同的原准入场景。随后以每个场景各自的首次持续双足承重确认对齐。表中是配对场景的倾角差中位数，数值为未准入场景减对应准入场景。

| 相对承重确认 | 种子1256，6对 | 种子1257，14对 |
| --- | ---: | ---: |
| −80ms | +5.42° | +13.87° |
| 0ms | +11.70° | +15.07° |
| +80ms | +16.98° | +21.31° |
| +160ms | +23.31° | +23.30° |

从确认前80ms到确认后80ms，未准入场景的倾角改善量配对中位数分别少11.56°和9.83°。两批均在确认前已有差距，并在承重交接期间进一步扩大。[配对方案](../../../../configs/experiments/nominal_supine_support_rotation_alignment.json) · [逐场景姿态和载荷](rotation-aligned-to-load.json) · [配对复算日志](rotation-alignment-command.log) · [后续站稳带奖励与父点核验](support-progress/README.md)

## VS Code观察与原片

- 种子1256。[最终状态](verified-entry/seed-1256/final-view/native-status.txt) · [曲线](verified-entry/seed-1256/final-view/native-curve.png) · [实景](verified-entry/seed-1256/final-view/native-latest.jpg) · [逐次指标](verified-entry/seed-1256/final-view/native-metrics.csv) · [运行中读回](verified-entry/seed-1256/live-readback.json) · [命令日志](verified-entry/seed-1256/command.log) · [12秒原片](../../../evaluations/duck-getup-early-load-s1256-20261121T104422/clip-step-0.mp4)
- 种子1257。[最终状态](verified-entry/seed-1257/final-view/native-status.txt) · [曲线](verified-entry/seed-1257/final-view/native-curve.png) · [实景](verified-entry/seed-1257/final-view/native-latest.jpg) · [逐次指标](verified-entry/seed-1257/final-view/native-metrics.csv) · [命令日志](verified-entry/seed-1257/command.log) · [12秒原片](../../../evaluations/duck-getup-early-load-s1257-20261121T104422/clip-step-0.mp4)

每段原片均为301帧，逐帧对照原回合的物理位姿。固定相机位于场景0，曲线汇总表中的实际仰卧场景。两个最终留出种子继续保留。[录像与计数校验](analysis.json)
