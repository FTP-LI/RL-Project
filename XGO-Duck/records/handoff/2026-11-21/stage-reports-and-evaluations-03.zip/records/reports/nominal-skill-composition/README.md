# 标称场景连续动作

每个场景从请求的倒地姿态开始，在同一物理回合完成起身、站立、官方前滚翻和落地站立，再执行一条预分配的指令。标称参数为脚底摩擦系数1.0、供电7.7V、物理步长4ms、控制周期20ms。共896个场景，七条指令各128个。四种请求姿态分别为俯卧112、仰卧224、左侧卧224和右侧卧336个。实际释放姿态另行复算。[冻结协议](../../../configs/experiments/nominal_skill_composition.json) · [模型与原判据](../goal-review/nominal-skill-composition-sources.json)

| 环节 | 控制边界 | 控制器 |
| --- | ---: | --- |
| 跌倒与姿态分流起身 | 第100步释放，第550步结束 | 已验证的三份自训练起身ONNX |
| 起身后站立 | 第550–600步 | 七指令的站立模型，前25步限制目标变化 |
| 官方前滚翻与落地站立 | 第600–1100步 | 原滚翻判据在第1050步截止，完成后按原条件站立50步 |
| 换回七指令站立 | 第1100–1125步 | 25步内限制关节目标变化，使用站立模型的新动作历史 |
| 指令动作 | 第1125–2125步 | 预分配站立、前进、后退、左转、右转、左平移或右平移，完整20秒 |

CPU预检已核对共同场景字段、头脚接触几何和切换入口。运行程序分别记录实际CUDA初态、物理执行的关节目标、接触记录、采样曲线、显存、原片和独立评分。站立与滚翻切换按各策略的默认关节位置换算观测，并保留其原始动作历史。实验将未进入下游动作的场景计入各自的原始分组。[CPU预检](preflight.json) · [执行命令与退出记录](../nominal-skill-composition-execution.log)

首次CUDA检查在0个物理步时退出。旧方向预测器恢复权重前，线性层构造推进了CPU随机数状态。已隔离构造过程，两次加载的预测输出逐位一致。恢复协议保留原判据、模型与观测噪声。实际CUDA在32条初态观测上核对了七份模型，最大输出误差为2.15×10⁻⁶rad。切换检查也核对了观测默认位姿、历史和限速。[首次退出](../nominal-skill-composition-execution.log) · [初始化隔离检查](zero-recovery/preflight.json) · [实际CUDA零步](zero-recovery/zero/proof.json) · [恢复方案](../../../configs/experiments/nominal_skill_composition_zero_recovery.json)

VS Code可直接打开采样状态、曲线和最新实景。环境0的预分配指令为左平移，录像由实际仿真状态生成。原始接触和关节目标采用固定大小分片存储，采样结束后用独立脚本按原门槛复算。[状态](zero-recovery/native-view/native-status.txt) · [速度曲线](zero-recovery/native-view/native-curve.png) · [最近实景](zero-recovery/native-view/native-latest.jpg) · [采集命令](../nominal-skill-composition-run.log)

## 标称运行结果

种子1256实际执行1,125个控制步、5,625个物理子步和1,008,000条环境转移。全程只执行一次初始重置。起身及末段持稳复算为886/896，整体和四种实际释放姿态均达原95%门槛。按实际释放姿态，俯卧112/112、仰卧508/515、左侧卧106/106、右侧卧160/163。滚翻通过865/896，高于812/896门槛。865个滚翻通过场景均完成了指令前的落地和站立。[独立评分](zero-recovery/analysis.json) · [采集凭据](../../evaluations/duck_nominal_skill_composition_zero_recovery_s1256_20261121T063200/collection.json)

| 分配指令 | 滚翻前已站立 | 符合指令入口 | 入口要求 |
| --- | ---: | ---: | ---: |
| 站立 | 128/128 | 127/128 | 122/128 |
| 前进 | 127/128 | 125/128 | 122/128 |
| 后退 | 127/128 | 118/128 | 122/128 |
| 左转 | 126/128 | 121/128 | 122/128 |
| 右转 | 125/128 | 124/128 | 122/128 |
| 左平移 | 125/128 | 124/128 | 122/128 |
| 右平移 | 128/128 | 126/128 | 122/128 |

后退和左转的入口上限低于原门槛，运行在下发指令前结束。31个未进入末段的场景中，10个未进入滚翻，21个有效支撑转角不足。后退分组分别有1和9个，左转分组分别有2和5个。末段20秒七指令整体仍待动态评分。[逐场景滚翻复算](zero-recovery/pre-command-handoff-analysis.json) · [复算方案](../../../configs/experiments/nominal_skill_composition_handoff_review.json) · [复算日志](zero-recovery/pre-command-handoff.log)

首次滚翻关节目标的最大单步变化为0.9120rad。起身接站立和滚翻后换回七指令站立的最大单步变化均为0.0400rad。另一个已验证的官方标称路线在滚翻入口的机身倾角中位数为0.60°，本轮滚翻通过和滚翻失分场景分别为1.55°和1.54°。两条路线的种子和前置动作不同。下一项使用同一实际快照，只替换滚翻前最后25步的零指令站立模型，加入两次相同原策略参照，再按原门槛对照。[下一项对照方案](../../../configs/experiments/nominal_skill_composition_pre_roll_stand_draft.json)

采样期间记录121个整卡读数，GPU利用率中位数39%，显存峰值5,355MiB。环境0的标注帧与22.50秒原片包含跌倒、起身、滚翻和落地站立，原片末帧对齐实际停止时刻。[22.50秒原片](../../evaluations/duck_nominal_skill_composition_zero_recovery_s1256_20261121T063200/clip-step-0.mp4) · [关键帧来源](zero-recovery/keyframe-source.json)

![标称连续动作关键帧](zero-recovery/keyframes.jpg)

## 共用快照预检

896场景的真实CUDA零步中，改动位置、动作历史、滚翻计时和随机数状态后成功恢复。336项场景状态逐项一致，起身路由、原始动作历史和转向滤波也按保存值恢复。预检读取约238MiB的Warp状态，采样显存由4,930MiB变为5,153MiB。本检查停在第0步，正式对照将在第575步核对各分支的共同初态。[快照预检](pre-roll-stand-snapshot-preflight.json) · [执行记录](../nominal-skill-composition-pre-roll-snapshot.log)

[滚翻前站立策略对照](pre-roll-stand-pair/README.md)记录了正式采样的方案、实时状态和结果。

标称种子1256的原站立路线随后加入4ms载荷读回，按原门槛完整通过866/896。91个支撑转角失分区间的末子步均有承重，紧随的求解已卸载。[载荷核验、曲线及原片](contact-load/README.md)

独立种子1257沿用原控制器，起身与持稳880/896，滚翻与落地848/896。仰卧恢复后的有效支撑转角失分集中在滚翻后0.54–0.92秒。[独立评估与分姿态复算](independent-development/README.md)

两组仰卧场景的4ms复算显示，多数相关卸载事件为头部重新承重，四组头足接棒间隔的中位数均为84ms。颈部目标下调候选在两条原策略参照855/896和859/896之间通过856/896。后续以真实起身后的启动状态构建滚翻训练课程。[支撑和力矩对照](support-transfer/README.md) · [颈部目标下调对照](neck-descent-pair/README.md)
