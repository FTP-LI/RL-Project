# 仰卧起身站稳带奖励

## 父策略和保存点

起身策略来自当前连续动作路线中的仰卧分支。使用128条已记录的真实起身观测核对导出模型与保存点，14个关节输出的最大绝对差为1.04×10⁻⁶。策略输入61维，价值网络输入76维，两份Adam均逐项加载。配对训练从保存点的网络和优化器开始，两组重新初始化同种子仿真回合。[父点、观测和复算凭据](preflight.json) · [父点复算命令](../support-progress-preflight.log)

## 窗口和奖励

固定第100步释放后480–820ms，使用0.99折扣。最初的逐步余弦变化量在过大倾角时更易积累。两批归档的原准入场景只在2/6与4/14对中获得较高分，按准入减未准入的折扣收益中位差分别为−0.0854与−0.0474。该次归档检查结束在零物理步。[原信号的冻结参数](../../../../../configs/experiments/nominal_supine_support_progress_preflight.json)

有界方案让机身倾角从30°向15°收敛时线性增加姿态得分，进入原15°站稳带后满分。窗口起点已有的姿态计入首步，之后按得分的有符号变化记奖励，机身再次倾倒时扣回。这样，达到站稳带和保持姿态都反映在窗口的折扣收益中。

| 归档种子 | 原准入分数较高的配对 | 原准入减未准入的有界折扣收益中位差 |
| --- | ---: | ---: |
| 1256 | 6/6 | +0.807 |
| 1257 | 13/14 | +0.728 |

归档检查沿用相同轨迹、配对和时间窗。备选信号达到两批的预检要求，接入实际训练后仍以连续动作的原评分评价。[有界奖励源码](../../../../../scripts/training/getup_upright_band_reward.py) · [边界样例与逐场景复算](upright-band-preflight.json) · [复算命令](../upright-band-preflight.log)

## 配对训练协议

两组计划各3,072个并行环境、17次更新，每次24步。共用仰卧父保存点、Adam状态、重置和动作空间。两组均只更新策略最后一层的十个腿部输出，保留原头颈输出。候选在原奖励上添加0.35倍的有界姿态变化量。每组计划保存初始点、第8次更新和最终保存点，并记录完整8秒训练原片。独立动作评估仍用原起身、滚翻和七指令判据。[配对方案](../../../../../configs/experiments/nominal_supine_upright_band_training_design.json)

两组实际CUDA初始化峰值均为12,237MiB，网络、Adam状态和重置场景的签名相同。首次原奖励组在第24步完成一次PPO更新后停止，累计73,728条场景转移和120次批量物理解算。该更新在释放前，策略梯度步为0，价值网络梯度步为120。首个指标里的Python元组在JSON中写为数组，导致本机观察入口拒绝快照。日志、部分保存点及包含0–0.48秒状态的中断原片已保留。修复按JSON格式比较快照，冻结新的运行编号；两组从原父点开始，使用原采样配置和同一预算。[首次CUDA初态](training/cuda-zero/matched.json) · [首次训练日志](training/control-training-command.log) · [首次部分保存点](../../../../experiments/duck-getup-upright-band-control-s5117-20261121T111441/stopped-partial.pt) · [首次中断原片](../../../../experiments/duck-getup-upright-band-control-s5117-20261121T111441/clip-step-0.mp4)

原奖励组随后完成训练。候选首次启动在零物理步、零更新时触发授权检查，保存了零步现场。候选的完整运行沿用原暂停条件，在训练进程内直接刷新授权，读取间隔0.1秒。两组均分别读回原奖励、候选奖励在窗口内的实际值和窗口后的零响应。[观察修复核验](observed-training/observation-repair.json) · [首次候选零步记录](observed-training/candidate/result.json) · [候选同步授权预检](observed-training/authorization-recovery/authorization-preflight.json) · [实际授权耗时](observed-training/authorization-recovery/candidate/authorization-monitor.json)

## 训练结果

| 同父点训练组 | 更新次数 | 场景转移 | 净吞吐（转移/秒） | 进程端到端（转移/秒） | 显存峰值 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 原奖励对照组 | 17 | 1,253,376 | 12,636 | 11,602 | 12,962MiB |
| 新增站稳带奖励候选组 | 17 | 1,253,376 | 12,928 | 11,882 | 12,959MiB |

净吞吐从训练状态开始计时，进程端到端统计同时计入初始化和最终写出。显卡总显存16,384MiB，实测峰值约79%。显卡忙碌度的全程采样中位数分别为43.5%和40.5%。PPO优化段累计分别为38.24秒和38.77秒，进程总用时分别为108.03秒和105.49秒。两组使用同一场景规模和记录频率，本轮只有一组有效配对，吞吐差用于记录本机运行表现。

初始、第8次和第17次更新的保存点均可读回。策略的参数更新限于末层十个腿部输出，头颈输出对应参数逐位相同。每组策略网络和价值网络分别执行1,560和2,040个梯度步。224条观测的ONNX输出与保存点比较，最大绝对差分别为9.24×10⁻⁷和1.01×10⁻⁶。

两进程CUDA重置一致，实走至第100步释放时，在3,072个训练场景中有8个仰卧分类不一致。释放旋转距离中位数0.00749°、第95百分位1.11°，10个场景超过5°。动作效果使用独立的同释放快照评估。[完整数值核验](observed-training/authorization-recovery/training-verification.json)

| 同父点训练组 | VS Code回看 | PNG曲线和CSV | 8秒原片 | 权重与完整保存点 |
| --- | --- | --- | --- | --- |
| 原奖励对照组 | [状态](observed-training/control/final-view/native-status.txt) · [命令与更新输出](observed-training/control-training-command.log) | [原奖励曲线](observed-training/control/final-view/native-curve.png) · [原奖励CSV](observed-training/control/final-view/native-metrics.csv) | [原奖励训练原片](../../../../experiments/duck-getup-upright-band-control-observed-s5117-20261121T112216/clip-step-0.mp4) | [原奖励ONNX](../../../../../artifacts/duck-getup-upright-band-control-observed-s5117-20261121T112216/policy.onnx) · [原奖励最终保存点](../../../../experiments/duck-getup-upright-band-control-observed-s5117-20261121T112216/model-final.pt) |
| 新增站稳带奖励候选组 | [状态](observed-training/authorization-recovery/candidate/final-view/native-status.txt) · [命令与更新输出](observed-training/authorization-recovery/candidate-training-command.log) | [候选曲线](observed-training/authorization-recovery/candidate/final-view/native-curve.png) · [候选CSV](observed-training/authorization-recovery/candidate/final-view/native-metrics.csv) | [候选训练原片](../../../../experiments/duck-getup-upright-band-candidate-direct-s5117-20261121T112756/clip-step-0.mp4) | [候选ONNX](../../../../../artifacts/duck-getup-upright-band-candidate-direct-s5117-20261121T112756/policy.onnx) · [候选最终保存点](../../../../experiments/duck-getup-upright-band-candidate-direct-s5117-20261121T112756/model-final.pt) |

各视频均包含起始跌落、实际释放、起身及回合重置前终态。仿真区间为0–8秒，各201帧，按25帧/秒编码。第17次更新包含第一个8秒回合结束后的8个控制步，训练日志该行的瞬时站稳比例对应新回合开头。动作对照单独使用原按时起身、末段站稳和滚翻准入计分。[本轮运行索引](../../../../training-current.md)

## 同释放快照对照

用种子1257的896个场景运行共同跌落至第100步。三组分别从同一快照恢复，核对346项物理、观察和随机状态，以及控制器状态签名。只替换仰卧分支策略，535个场景进入该分支。保留第550步的起身计分、第600步的滚翻前准入及15°、连续25步的原站稳判据。本轮累计1,433,600条评估转移，评估结束于滚翻启动前。[冻结评分方案](../../../../../configs/experiments/nominal_supine_upright_band_action_comparison.json) · [三个分支逐项评分](action-comparison/analysis.json) · [共同释放凭证](../../../../evaluations/duck-getup-upright-band-action-comparison-s1257-20261121T113723/fork.json)

| 策略 | 按时起身并保持 | 滚翻前总准入 | 实际仰卧准入 | 前进分组滚翻前准入 |
| --- | ---: | ---: | ---: | ---: |
| 现行仰卧父策略 | 877/896 | 877/896 | 518/535 | 122/128 |
| 原奖励对照组 | 882/896 | 882/896 | 524/535 | 124/128 |
| 新增站稳带奖励候选组 | 884/896 | 884/896 | 525/535 | 125/128 |

候选相对原奖励组新增6个准入、转为失分4个，总准入净增2个。在实际仰卧组和前进分组各净增1个。前进分组相对两条参照的净增分别为3个和1个，晋级门槛为相对每组均至少净增2个。另有1个场景相对父策略在其它路由失分。候选作为实验权重保存，仿真交付使用现行仰卧父策略。

奖励窗结束时，535个实际仰卧场景中，两训练组进入15°姿态带的分别为513和512个，候选减原奖励的倾角配对中位差为−0.001°。到第600步，该差值为−0.043°。两个时刻的配对差与总体准入增量一起记录，可区分末段站稳变化和训练信号所针对的转正时段。

其余361个场景沿用同一策略。三组释放时的首个观察、动作输出、关节目标和首个延迟力矩逐位一致。相对父策略转为失分的右侧场景9在完成第101步后已有位置差异，随后的观察和动作从第101个采样起出现差异。到第600步，候选与原奖励组在这些共用策略场景中的姿态旋转距离中位数为0.85°，43个场景超过5°。这项复算把物理轨迹分歧纳入对两组得分的解读。[共用策略场景轨迹对照](action-comparison/unchanged-route-review.json)

![仰卧起身与滚翻前站稳](action-comparison/comparison-keyframes.jpg)

场景229是前进分组内两训练组准入有差异的最小编号实际仰卧场景。释放快照相同，奖励窗结束时原奖励组倾角7.6°，候选组20.4°。滚翻前准入时分别为1.8°和32.5°。上图为该场景的保存状态回放。三段12秒原片均为同一个预设机位场景，包含跌倒、释放、起身和滚翻前站稳。[关键帧和全部仰卧倾角复算](action-comparison/comparison-keyframes.json)

[仰卧父策略原片](../../../../evaluations/duck-getup-upright-band-action-comparison-s1257-20261121T113723/parent-policy/clip-step-0.mp4) · [原奖励对照组原片](../../../../evaluations/duck-getup-upright-band-action-comparison-s1257-20261121T113723/original-reward/clip-step-0.mp4) · [新增站稳带奖励候选组原片](../../../../evaluations/duck-getup-upright-band-action-comparison-s1257-20261121T113723/upright-band-reward/clip-step-0.mp4) · [VS Code评估回看](action-comparison/final-view/native-status.txt) · [评估命令日志](action-comparison/sampling-command.log) · [轨迹复算命令日志](action-comparison/score-command.log)

同种子2ms滚翻旧试验中，前进指令前通过120/128，门槛122/128。在该次评估的5个滚翻前失分场景中，本轮按初始仿真姿态和实际仰卧释放匹配场景编号。父策略、原奖励组、候选分别有1、1、2个通过本轮滚翻前准入。旧评估还有3个失分发生在滚翻阶段。将两个批次的动作分数分别保留，下一阶段在同策略下复测2ms连续路线的波动。[五个场景的跨批次对账](action-comparison/timestep-forward-readiness.json) · [旧2ms完整阶段记录](../../closed-loop-timestep/README.md)

## 复现入口

先按[电脑训练手册](../../../../../docs/runbooks/pc_training.md)检查WSL环境，再从VS Code打开[训练记录](../../../../training-current.md)。奖励的姿态带和有符号增量位于[奖励源码](../../../../../scripts/training/getup_upright_band_reward.py)，采样量和权重位于[配对训练设计](../../../../../configs/experiments/nominal_supine_upright_band_training_design.json)。原奖励与候选的实际冻结文件分别链接在各运行说明中。训练命令日志记录了完整WSL命令、启动参数及退出码。[原奖励组运行说明](../../../../experiments/duck-getup-upright-band-control-observed-s5117-20261121T112216/README.md) · [候选组运行说明](../../../../experiments/duck-getup-upright-band-candidate-direct-s5117-20261121T112756/README.md)

保存数据核验按[配对训练核验脚本](../../../../../scripts/validation/verify_nominal_supine_upright_band_training.py)和[动作离线评分脚本](../../../../../scripts/validation/score_nominal_supine_upright_band_comparison.py)执行。若要尝试另一个奖励权重或时间窗，登记独立的配对，给原奖励组和修改组相同的父点与采样预算，并用相同的跨分支物理快照做动作验收。开发与最终确认种子列表写入冻结配置。

从Windows Python运行归档对账入口时加`-X utf8`，使项目登记文件与WSL使用同一编码。本次Windows运行后的登记文件已转回UTF-8，并核对转换前后的JSON字段完全一致。[登记文件编码核验](action-comparison/registry-encoding-readback.log)
