# 低摩擦右髋膝起身对照

种子1257和0.8足底滑动摩擦，896个并行场景。第136步、仿真2.72秒从共同快照恢复三次。候选对当时已进入仰卧策略且前倾20°至60°的场景，右髋减0.02rad、右膝加0.02rad，持续4个控制步。三组共用权重、观测、原动作范围及起身和滚翻前站稳判据。释放后首1.2秒共用2ms积分，电机及观测分别沿用4ms和20ms。[冻结配置](../../../../configs/experiments/nominal_low_friction_right_support_trial.json) · [位置目标的固件复算](../low-friction-right-support-position/README.md) · [共同状态](../../../evaluations/duck-getup-right-support-friction080-s1257-20261121T174251/fork.json)

三组首个策略输入、原始动作和首个延迟电机输入一致。候选自第136步开始调整指定的两个关节目标。在首个收到新目标的4ms电机输入，21个触发场景中20个在两关节均达到0.005N·m的指定方向变化。相对两遍参照取较小变化，双关节场景中位数各约0.021N·m。[实际位置和电机输入核验](analysis.json)

## 12秒动作评分

| 指标 | 原起身参照一 | 原起身参照二 | 右髋膝位置候选 |
| --- | ---: | ---: | ---: |
| 原起身评分 | 884/896 | 884/896 | 885/896 |
| 滚翻前准入 | 884/896 | 884/896 | 885/896 |
| 21个触发场景的滚翻前准入 | 12/21 | 12/21 | 13/21 |
| 左转分组的滚翻前准入 | 124/128 | 124/128 | 124/128 |
| 站立分组的滚翻前准入 | 127/128 | 127/128 | 128/128 |

两遍参照的逐场景准入结果一致，候选新增场景218。该场景在3秒的两遍参照倾角为21.55°和21.50°，候选为11.66°。另外8个触发场景在三组均未准入，末25步持续头部与双足接地且倾角超过15°。左转分组与两遍参照同为124/128，继续完整路线需各净增至少2例。本轮归档为起身闭环短测，种子2246保留。[原动作评分](analysis.json) · [逐时刻姿态与接触](motion-readback.json)

## VS Code回看

三组共采集1,369,088条场景转移和8,180次批量物理求解，整卡显存峰值5,724MiB，学习更新为0。三段12秒原片各301帧。标注图按场景编号选出两遍参照均未准入的第一个触发场景152，使用保存姿态回放。[运行中状态](live-readback.json) · [VS Code最终状态](final-view/native-status.txt) · [采样曲线](final-view/native-curve.png) · [最终实景](final-view/native-latest.jpg) · [执行命令](sample-command.log) · [复算与媒体日志](review-command.log)

![低摩擦右髋膝起身对照](keyframes.jpg)

[原起身参照一12秒原片](../../../evaluations/duck-getup-right-support-friction080-s1257-20261121T174251/original-first/clip-step-0.mp4) · [原起身参照二12秒原片](../../../evaluations/duck-getup-right-support-friction080-s1257-20261121T174251/original-repeat/clip-step-0.mp4) · [右髋膝候选12秒原片](../../../evaluations/duck-getup-right-support-friction080-s1257-20261121T174251/right-hip-knee-candidate/clip-step-0.mp4) · [标注图来源](keyframe-source.json)
