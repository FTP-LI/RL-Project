# XGO Duck

用户已购买套件，并确认拥有 Arduino UNO Q、机器人扩展板和舵机。2026-11-01 用户确认已按官方步骤完成装配，尚未运行官方程序；当前推进电脑充分训练与评估，并准备真机首次运行、舵机零位和 IMU 核验。

## 项目入口

| 文档 | 内容 |
| --- | --- |
| [全流程开发报告](docs/reports/development_report.html) · [Markdown](docs/reports/development_report.md) | 主报告：环境部署、问题修复、训练修改、结果与截图、真机标定和部署验证 |
| [当前目标与验收条件](docs/current_goal.md) | 最新授权、正在执行的阶段及完成标准；历史暂停记录不覆盖当前状态 |
| [Development roadmap](docs/development_roadmap.md) | 当前主路线：目录管理、官方复现、修改训练、sim2real 与阶段验收 |
| [PC training runbook](docs/runbooks/pc_training.md) | 可见安装、锁定依赖、短训练、回放、修改与导出的逐步操作 |
| [PC validation report](docs/reports/pc_pipeline_validation.md) | 本机已执行结果、两组训练与 ONNX 检查、实际截图及继续操作 |
| [Deployment record](records/deployment/2026-10-31/README.md) | 当前主机核查、安装过程、问题和未完成项 |
| [Development handoff](../HANDOFF.md) | 换电脑恢复、当前成果、未完成事项和下一次开发入口 |
| [Official resources](official_resources/README.md) | 官方硬件、运行和训练仓库，以及音视频开发分支的来源、固定版本、快照和校验 |
| [RL deployment plan](docs/rl_deployment_plan.md) | 官方步态基线 → PC 训练 → ONNX 兼容检查 → UNO Q 部署 |
| [Hardware and accessories](docs/hardware_and_accessories.md) | 缺件核对、供电和结构、USB 摄像头、音频与 ToF 的实际支持状态 |
| [Camera fit analysis](docs/camera_fit_analysis.json) · [section drawing](docs/assets/camera_fit_sections.png) | OV2710 (A) 与原版头部结构的初步尺寸检查；尚未完成装配验证 |
| [Camera and voice selection](docs/camera_voice_selection.json) · [OV2735 section drawing](docs/assets/ov2735_fit_screening.png) | 最新候选：OV2735、ReSpeaker Lite、紧凑 USB 声卡和小喇叭；原壳安装及实机效果待验证 |
| [Policy contract report](docs/policy_contract_report.json) | 5 个官方 ONNX 的接口、元数据与文件哈希；未执行推理 |
| [Project metadata](project.json) | 已确认资产、未知项、当前阶段和文档索引 |

新增目录和文件使用英文名称；官方仓库保持原始内容。本项目研究说明采用中文。文档中的官方源码引用指向归档提交，便于直接在 GitHub 阅读。

## 目录说明

```text
XGO-Duck/
├── README.md                 # 项目入口与阶段边界
├── project.json              # 机器可读的项目状态
├── AGENTS.md                 # 本项目执行和文件组织规则
├── scripts/                  # setup 环境、training 训练、validation 核验入口
├── configs/experiments/      # 冻结的训练、性能诊断与评估方案
├── records/                  # 部署、实验、性能、评估和媒体证据
├── artifacts/                # 恢复 checkpoint 与导出的模型交付包
├── workspace/                # 项目运行状态与缓存；训练副本位于 WSL 专属目录
├── docs/                     # 部署、配件、策略与相机研究
│   └── assets/               # 文档引用的图示
└── official_resources/       # 官方来源、版本与恢复说明
    ├── source_manifest.json
    ├── manifests/            # 各源码树的逐文件哈希
    ├── snapshots.sha256
    ├── snapshots/            # 4 个随 Git 保存的原始 ZIP
    └── <source directories>  # 4 份随 Git 保存的官方源码树
```

## 当前状态

| 字段 | 当前值 |
| --- | --- |
| 项目 ID | `xgo-duck` |
| 已购买/持有 | 套件；UNO Q、机器人扩展板和舵机由用户确认 |
| 待确认 | 板卡版本、UNO Q 内存、舵机型号/数量、电源、结构件和线束完整性 |
| 官方模型 | 训练仓库提供 XGO-Duck URDF/MJCF、网格及 1910 执行器模型 |
| 推进路线 | 先完成电脑仿真、官方短训练与修改训练；装配后建立官方实机基线，再部署新策略 |
| 历史计算环境记录 | 2026-10-25 记录为 RTX 5070、约 12 GB 显存，Ubuntu-24.04 WSL2 内 GPU 可见；本次未重新核验 |
| 当前电脑实测 | 2026-10-31：RTX 3080 Laptop 16 GB、约 64 GB 内存；环境、官方和修改组短训练、导出、1000 帧 ONNX 闭环及 Runtime 兼容检查通过，见验证报告 |
| 官方模型 CPU 检查 | 5 个归档 ONNX 在 Runtime 1.22.1 下通过图、接口及合成输入推理检查；不代表仿真或实机验收 |
| 官方行走模型仿真 | 原归档及当前模型均已评估，各 160/160 存活，均只有停止达到原运动标准；当前模型姿态参照见主报告第 24.5 节 |
| 正式训练 | 原长训练保留累计 5751 次模型；任务 28 两组各 250 次及导出、固定评估均完成，两组均未通过步态及姿态。诊断与试验见主报告第 22、23 节 |
| 训练效率 | 4096 环境入选；连续显示短测中 GPU 条件吞吐约为默认条件的 1.53 倍，实际画面仍未达流畅标准，见主报告第 21、25 节 |
| 原生 Ubuntu | 同一 VS Code 入口、环境核查与镜像安装步骤已准备；原生系统尚未切换、核验或测试，见主报告第 13 节 |
| 实测边界 | 未接机器人、未刷写；短训练、导出与运动策略验收以实验记录为准 |
| 资料研究日期 | 2026-10-25 |
| 文档整理日期 | 2026-11-01 |

当前任务 34 已在原 VS Code 任务终端启动。任务 33 因查看器关闭中断，其最新完整模型包含累计 5151 次更新；新的两组从该模型各训练 250 次，均关闭原生实时窗口，保留可见终端、曲线和录像。完整恢复账目与操作步骤见主报告第 26.7 节；长训练异常限制保留，不重复启动已有批次。

## 优先注意事项

- 上电前核对官方 2026-10-02 旧扩展板 U3/U4/U5 的 GND/SIGNAL 接线更正是否适用。
- 现有行走策略依赖关节状态和 IMU，不需要先买摄像头。成品扩展板已有 IMU 的情况下也不需要先重复购买。
- 新训练模型部署前须统一默认关节姿态：归档训练行走配置为 ±24°，主运行程序为 ±22°，音视频预览分支为 ±23°。观测/动作维度相同不代表可直接互换。
- 官方 `next-audio-video-tof` 分支已有 USB 图传和音频，ToF 尚未实现；先以主分支建立行走基线。
- 用户希望看着自己聊天并听懂动作口令，优先 USB / USB-C。当前媒体分支只有采集、播放和文字转语音，完整对话、人脸跟踪和动作口令尚需开发；语音板是否接受外置小背包仍未决定。

## 归档边界

`official_resources/` 下的 585 个官方源文件与 4 个 ZIP 均由 RL-Project 跟踪，保留原始字节、来源版本和 SHA-256。换电脑后普通 `git clone` 即可取得这些资料，校验和离线解压步骤见[归档说明](official_resources/README.md#restore-on-another-computer)。

源码按普通目录归档，不使用子模块或 Git LFS；上游 Git 提交历史不包含在源码快照中。原归档机器的 Git 元数据备份位于被忽略的 `.upstream_git/`，不随仓库恢复。归档不包含已安装的训练环境、板端系统或未经记录的实物校准，也不等于实物验收通过。

2026-10-31 工作区复核：585 个源码文件、4 份文件清单和 4 个 ZIP 的大小与哈希全部通过；ZIP 的 CRC 及包内文件与源码逐字节比较也通过。此前缺失的本地源码与快照现已补齐；未执行训练、板端推理或实机测试。
