# 暂停进度归档

训练与仿真已暂停，目标仍未全部完成。Windows 与 WSL 未发现本项目工作进程，训练锁空闲；当前协议的启动授权已关闭。最新同步检查组在 2026-11-16 10:02 完成，监控候选没有训练。本次整理只读取保存文件，不增加学习、物理步或真机操作。[暂停核验](process-check.json) · [数据复核](saved-evidence-readback.json)

## 当前进度

| 范围 | 已有结果 | 剩余事项 |
| --- | --- | --- |
| 环境与流程 | WSL、CUDA、官方依赖、训练、导出及本地观察已有运行记录。 | 继续降低实测开销；本机算力利用仍不足。 |
| 站立与六方向运动 | 共同接口最终留出七项各 32/32，使用多个策略和反馈。 | 完整技能组合、切换与扰动验证。 |
| 四姿态起身 | 留出 2,983/3,072，实际右侧 179/183，原右侧门槛通过。 | 总体比两组参照分别少 4、5 例，不能称所有姿态均改善。 |
| 前滚翻 | 官方策略开发与留出各 117/128，单动作门槛通过。 | 共同控制器下的切换和参数抗扰。 |
| 连续动作 | 起身接七指令留出 2,992/3,072；最近官方标称滚翻路线 123/128。 | 各结果适用协议不同，最终统一组合尚未全部验收。 |
| 真机 | 已装配，离线接口、关节映射、标定模板与回退材料已准备。 | 通信、ID、零位、方向、IMU、供电和部署待现场验收。 |

动作成绩沿用各自的独立评分，本次没有重新执行评价。[全部目标与原始证据](../../../docs/current_goal.md) · [阶段矩阵](../stage-acceptance-matrix/README.md) · [模型选择](../../../artifacts/delivery/simulation-model-selection.json)

## 最近训练

本轮想减少反复读取文件带来的等待：将完整检查移至独立线程，训练侧检查结果是否有效、是否过期。初始化和外层监督仍同步执行。CPU 故障检查及两组 CUDA 零步通过，123 份冻结来源保持一致；只完成了同步组，候选尚未训练。

| 同步检查组 | 保存结果 |
| --- | --- |
| 规模 | 3,072 环境，17 次更新，1,253,376 条转移 |
| 训练过程总时间 | 172.19 秒，约 7,279 转移/秒 |
| GPU | 利用率中位数 35%，峰值显存 12,577 MiB |
| 文件检查回调 | 2,075 次，累计 34.18 秒 |
| 环境控制步计时 | 408 次，累计 57.83 秒 |
| 留档核验 | 保存点有限值与优化器计数、ONNX 输出、17 行指标、完整 8 秒原片均通过 |
| 候选 | 仅零步完成，训练更新和转移均为 0 |

各计时可能嵌套，不能直接相加。外层进程耗时 232.19 秒，含启动和观察确认等待；与训练过程计时区分保存。本轮没有成对加速结论，也没有最终动作改善的独立评价。此前固定路径对照的 36.5% 吞吐提升属于上一批，不能套到本轮。[完整方案、计时和导出核验](../getup-monitored-authorization-20261116/README.md)

## 查看训练过程

本机网页无法访问，以下入口不依赖网页服务。在 VS Code 按 **Ctrl+P** 输入 `records/training-current.md`，回车后按 **Ctrl+Shift+V**，即可查看状态、曲线、视频和逐轮日志。当前是历史快照，不会刷新。

- [最终状态](../getup-monitored-authorization-20261116/training/control/final-view/native-status.txt) · [训练曲线](../getup-monitored-authorization-20261116/training/control/final-view/native-curve.png) · [逐轮指标](../getup-monitored-authorization-20261116/training/control/final-view/native-metrics.csv)
- [完整起身原片](../../experiments/duck_getup_auth-sync_e3072_s3266_20261116T095241/clip-step-0.mp4) · [执行日志](../getup-monitored-authorization-20261116/training/control/execution.log) · [命令和退出码](../getup-monitored-authorization-20261116/training/control/supervisor-result.json)
- [全流程报告](../../../docs/reports/development_report.html) · [环境与操作手册](../../../docs/runbooks/pc_training.md) · [修改与结果记录](../../../artifacts/delivery/iteration_record.md)

视频也可用系统播放器直接打开。冻结的原始观察文件、截图和协议保持原样；当前导航统一指向运行结束后的 `final-view`。

## 保留和归档

官方与已评估自训模型仍在[交付目录](../../../artifacts/delivery/iteration_record.md)。20 份既有交付文件均与上次归档一致。最新[保存点](../../experiments/duck_getup_auth-sync_e3072_s3266_20261116T095241/model-final.pt)与[ONNX](../../../artifacts/duck_getup_auth-sync_e3072_s3266_20261116T095241/policy.onnx)保留在诊断批次，未替换交付组件。当前没有一个已通过九类动作、全部切换和扰动门槛的单一自训模型。

`snapshot.zip` 收录本次源码、协议、日志、文档、状态与图片；`manifest.json` 记录每个条目的路径、大小和 SHA-256，`verification.json` 保存逐字节回读核验。`external-assets.json` 登记模型、轨迹、原片与前次快照。大文件继续放在原路径，避免复制占用空间；因此 ZIP 是增量快照，需要与完整工程一起保存。

原始文件未删除或移动。`records/experiments`、`evaluations` 等是通往 `records/training-archive` 的目录联接，并非两份重复数据。旧快照保持原字节；上次归档的 57 份外部资产也重新通过哈希核验。[前次归档](../pause-archive-20261116/README.md) · [工程结构](../../../docs/project_structure.md) · [打包程序](../../../scripts/validation/archive_monitored_training_pause.py)

## 恢复位置

当前保持暂停，收到明确恢复指示后再执行：

1. 审查未完成性能对照的比较条件与来源，决定是否运行尚未启动的候选；不重跑已完成同步组，不自动延长预算。
2. 根据分段耗时选择能减少总时间的优化，继续检查初态与首步数值差异；不能以显存占用率代替训练有效性。
3. 完成统一控制器的参数对照准入，先固定初态、单因素变化和停止条件，再进行有界评估。
4. 根据失败证据决定训练改动，用等样本和同父点对照，再独立评价九类动作、连续切换与扰动。
5. 达到门槛后整理最终官方模型、自训组件、可恢复保存点和完整复现记录；真机继续后置。

完整范围和各阶段验收条件见[当前目标](../../../docs/current_goal.md)，未完成项不会因暂停归档而被标记为完成。
