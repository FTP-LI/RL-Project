# 当前目标与验收条件

更新日期：2026-11-16。用户已恢复全阶段目标。当前先核验上轮归档，分析保存数据中的首步数值差异和剩余性能开销，再冻结下一项有界试验。旧对照已结束，不自动追加预算；新训练仍须通过来源、观察入口和实际运行准入。全部九类动作、连续切换、扰动与交付目标保留，真机部署后置。[上次暂停归档](../records/reports/pause-archive-20261116/README.md) · [全流程报告](reports/development_report.html) · [目标历史](current_goal_history.md)

## 总目标

在可复现的仿真环境中完成摔倒后站起、站立、前进、后退、左转、右转、左平移、右平移和前滚翻，并验证动作之间的连续切换与有界扰动。以官方模型为参照，保留有价值的自训模型和对应可恢复保存点；每个模型按实际动作、场景和门槛说明用途，不把多个组件说成一个已通过全部门槛的模型。

交付内容包括官方原始权重、自训 ONNX 与对应 `.pt`、可复现环境与命令、训练曲线和真实录像、每次修改与结果、独立评价、源码和模型哈希。仿真达标且具备现场条件后，再依次完成舵机顺序与方向、零位、IMU、通信、官方基线、自训策略迁移和回退准备。 [权重与迭代记录](../artifacts/delivery/iteration_record.md) · [真机标定手册](runbooks/hardware_commissioning.md)

## 最近进展

本机网页无法访问，现已在原 VS Code 窗口实际核验本地训练状态、曲线和录像；窗口大小和位置保持不变。网页访问不再是查看训练记录的前提。

两组均已完成，每组采集 1,253,376 条转移。3,072 环境组的训练过程总耗时为 209.13 秒，1,536 环境组为 229.33 秒，包含初始化、导出和收尾；按该范围的吞吐约为 5,993 和 5,465 转移/秒，前者提高约 9.7%，多用约 5.16 GiB 峰值显存。从采样开始至最后一次指标发布的窗口另算，吞吐提高约 11.3%；两种计时范围分别保留。两组保存点、ONNX 和完整 8 秒录像均通过独立复核；GPU 利用率中位数仅 33% 和 31%，尚未达到充分利用算力的目标。[本轮方案、结果与修复](../records/reports/getup-observed-throughput-20261116/README.md)

首次运行因 Python 元组写入 JSON 后成为列表而误报观察数据不一致，在 24 控制步后关闭；只发生 120 次价值网络小批量更新，策略梯度更新为 0。独立入口只统一序列化表示，仍严格检查数值、进度和来源；旧失败、部分保存点和不完整片段保留。[复现检查](../records/reports/getup-observed-throughput-20261116/publication-verification.json)

本轮用于核验真实训练记录与吞吐，尚未做动作改善的独立评估，不替换现有交付模型。此前官方标称连续路线为 123/128；多参数配对初态、扰动和最终技能组合仍需继续。[官方路线录像](../records/reports/duck_roll-native_nominal_s1241_20261115T230228/README.md) · [此前观察准备](current_goal_history.md)

固定路径对照现已完成：同父点、种子、3,072 环境，每组 17 次更新、1,253,376 条转移。训练过程总耗时从 209.16 秒降为 153.18 秒，对应吞吐提高 36.5%；两组各 2,075 次检查回调，累计耗时从 80.20 秒降为 32.50 秒。每次暂停判断、文件读取及哈希校验保留，118 份冻结来源未变。GPU 利用率中位数为 33% 和 33.5%，仍未充分利用本机算力。[方案、代码与结果](../records/reports/getup-canonical-path-20261116/README.md)

两组保存的初态一致，但第一控制步已出现约 10⁻⁷ 的数值差异，最终模型也不同；差异来源尚未确定。本轮只有一次顺序对照，尚未独立评价最终动作效果，两份模型作为诊断材料保留，不替换交付权重。暂停后仅重新读取模型、日志并完整解码两段 8 秒录像，没有新增学习或物理步。[暂停复核](../records/reports/pause-archive-20261116/saved-evidence-readback.json)

## 全部动作与阶段

| 阶段 | 已有仿真结果 | 剩余工作 |
| --- | --- | --- |
| 来源与流程 | 环境、官方参照、导出、过程观察和停止流程已有验证记录。 | 新方案需重新核对冻结来源、观察入口和运行条件。 |
| 七种行走指令 | 共同接口的最终留出中，站立、前进、后退、左右转和左右平移各 **32/32**；方案使用多个策略组件和反馈。 | 在共同场景继续验证连续切换、扰动和最终模型组合。 [行走清单](../artifacts/delivery/walking-simulation.json) |
| 四姿态起身 | 独立留出 **2,983/3,072**，实际右侧 **179/183**，右侧相对两组参照分别净增 **4、5** 例，原留出门槛通过。 | 总体相对参照分别少 4、5 例；保留参照与失败样本，继续验证完整技能组合。 [原评分与原片](../records/reports/getup-right-robustness/holdout/README.md) · [门槛核对](../records/reports/getup-gate-clarification/README.md) |
| 前滚翻 | 官方策略在独立开发和留出中均为 **117/128**，单动作门槛通过。 | 分别完成连续切换和扰动验收。 [滚翻评分](../records/reports/roll-endpoint-confirmation/README.md) |
| 连续动作与扰动 | 起身接七指令留出为 **2,992/3,072**；官方滚翻→站立→前进固定路线为 **119/128**。 | 参数抗扰和滚翻阶段扰动仍有开放门槛，不合并不同控制器的结果。 [阶段矩阵](../records/reports/stage-acceptance-matrix/README.md) · [官方路线](../records/reports/official-route-independent-s1235/README.md) |
| 真机准备 | 已完成离线模型接口、软件关节映射、标定模板和回退材料。 | 实物 ID、机械零位、方向、IMU、通信、供电和使能尚未现场验证。 [准备审计](../records/hardware/deployment-preparation/s19-readiness.md) |

已有自训权重按各自用途保留。路线感知短训的候选在同种子对照中为 **28/128**，官方父模型为 **125/128**，因此停止该学习线；教师约束候选与官方父模型两种子合计均为 **243/256**，差异不稳定，候选未晋级。 [短训对照](../records/reports/route-aware-pilot-parent-compare-s1225/README.md) · [教师约束对照](../records/reports/route-aware-teacher-anchor-parent-compare-s1232/README.md) · [模型选择](../artifacts/delivery/simulation-model-selection.json)

## 后续顺序

按以下顺序推进。当前阶段先检查保存状态与实际代码，不重启已经关闭的试验。

1. **继续定位性能与数值差异。** 已复核首步输入、原始动作和下发目标一致，差异出现于物理计算之后；GPU 数值归约是文档支持的解释，但尚未唯一归因。固定路径回调仍占总耗时约 21.2%。新监控方案通过 11 项 CPU 故障检查，当前进入两组 CUDA 零步；随后每组最多 17 次更新、1,253,376 条转移，新增分段计时，用实际结果决定是否采用。[分析与来源](../records/reports/getup-runtime-review-20261116/README.md) · [本轮方案](../records/reports/getup-monitored-authorization-20261116/README.md)
2. **先完成参数对照准入。** 保留已完成的标称零步，另行冻结与 S17 一致的 0 步落地过渡、同种子单因素变化及停止规则。保存并比较随机数、执行器内部状态和各环境起点，未解释差异不能进入动态采样；训练观察和动态停止需要真实运行验收。 [待冻结草案](../configs/experiments/roll_parameter_matched_review_draft.json) · [初态审计](../records/reports/matched-start-source-audit/README.md)
3. **逐步评估并停止无效运行。** 先进行名义与单因素有界对照，按原动作门槛、头部穿透与关节范围检查，并在每臂结束后检查能否进入下一臂。异常、无效数值、预算耗尽或门槛已不可达时保留证据并停止，不自动重启或追加预算。若需要完整失败诊断，事先单列条件和预算。
4. **再决定训练修改。** 从同一父保存点做等样本对照，记录改动原因、配置与影响。小规模学习对照每组最多 50 次更新；单次运行不超过 250 次，有证据支持的分段累计最多 1,000 次，具体范围以新冻结协议为准。原官方 ONNX 是推理参照，不等于包含优化器、价值网络和历史的 PPO 保存点。
5. **独立复验并交付。** 保持各动作原门槛，用未用于挑参的留出场景和多个训练种子核验，记录成功数、比例及失败原因；再验证共同场景切换和扰动。达标后交付官方参照、自训 ONNX 与对应 `.pt`，核对导出一致性、恢复能力和来源哈希。
6. **真机后置。** 达到仿真门槛并具备现场条件后，再按标定手册逐项核对。舵机只调整顺序时先验证软件映射；型号、几何或动力学变化需要重新评估。实际写入、使能和部署当前不进行。

## 本机训练与观察

已完成的同父点规模短测中，行走 1,024、2,048、4,096 环境分别约为 **9.86–10.05k、16.08–16.30k、23.98–24.58k 转移/秒**，4,096 档最高显存约 4,630 MiB、CPU 约 100%。这是已测范围内的结果，并不证明更大规模一定更快。观察器 D3D12 + 4 Hz 的两遍吞吐约 **18.35–18.38k 转移/秒**，实际状态采样约 2.25–2.29 Hz。 [规模和观察器记录](../records/reports/throughput-selection/README.md)

恢复后优先使用已核验的 WSL、本机 CUDA 和上述行走配方；起身使用已记录的独立配方，并在固定父点、样本量和动作门槛下比较。分开记录采样、更新、录像、CPU、显存和磁盘开销，以达到同一动作门槛的总时间选择方案。若 WSL 成为瓶颈，再与原生 Ubuntu 做同机同预算对照；两遍均提速、综合提升至少 15% 且动作指标稳定时再考虑迁移。

训练过程须在用户可打开的页面或工具中显示真实运行名、状态、进度和曲线，并按动作保存完整原片；VS Code 终端可选。默认不打开卡顿的持续实时窗口，约每三分钟在动作起点安排录像：起身训练约 8 秒、评估约 11 秒，滚翻和切换覆盖实际完整过程，异常或中断片段明确标记。不得为录像额外推进物理步。 [训练手册](runbooks/pc_training.md) · [录像规则](../configs/environments/action_recording.json)

## 文件与证据入口

- [全流程报告](reports/development_report.html)：环境部署、训练、修改原因、结果、截图、视频和真机准备；[完整过程记录](reports/development_history.html)保留逐次历史。
- [本次暂停进度归档](../records/reports/pause-archive-20261116/README.md)：当前结果、过程文件、保留模型、暂停核验及快照说明。
- [权重与迭代记录](../artifacts/delivery/iteration_record.md)：官方参照、自训组件及保存点；[模型选择](../artifacts/delivery/simulation-model-selection.json)注明哪些候选没有晋级。
- [训练记录归档](../records/training-archive/README.md)和[暂停进度归档](../records/reports/progress-archive-20261114/README.md)：按批定位方案、日志、轨迹、原片和快照。快照不是脱离工程目录的完整备份。
- [此前暂停进度归档](../records/reports/pause-archive-20261115/README.md)：当时的暂停状态、阶段结论、评估、模型入口和快照；权重、轨迹和原片仍按原路径保留。[更早快照](../records/reports/progress-archive-20261115/README.md)保留本机观察、零步失败、修复和独立核验。
- [观察与监督准备归档](../records/reports/pause-archive-20261115/supervision-preparation.zip)：暂停后整理的相关源码、记录和当前文档；大文件仍按原路径保留。[归档清单](../records/reports/pause-archive-20261115/supervision-preparation-manifest.json)
- [起身接七指令完整原片](../records/evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/restored-gyro/clip-step-0.mp4) · [左转关键帧](../records/reports/stage-media/cards/N628.jpg) · [全部录像总览](reports/assets/all-video-overview.jpg)。它们是已保存的评估画面，不是当前直播。
- [工程导航](project_structure.md) · [目标历史记录](current_goal_history.md) · [原文保全记录](../records/reports/goal-review/goal-organization-source.json)：历史内容仅供追溯，以本页和实际证据为准。

清理前先核对绝对路径、来源哈希、引用、保留价值和恢复依赖；保留官方归档、最终或已评价模型、恢复父点、代表性失败与审计输入。安装优先使用可用镜像源并记录过程，保持官方依赖锁定；代理断线时先检查现有进程与缓存。新运行必须先冻结对应方案并通过观察及运行准入，不自动重启中断评估或追加旧预算。
