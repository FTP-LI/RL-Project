# 仰卧起身左髋对照

[冻结方案](../../../configs/experiments/getup_supine_left_hip_bilateral_pulse.json) · [运行观察](../../getup-supine-left-hip-pulse-live.html) · [执行记录](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/README.md)

从同一仿真初态开始。第 115 步保留物理、观察历史与随机状态，随后两次原策略和两个脉冲方向各走完 11 秒。只有实际仰卧、左脚连续五个物理子步承重、右脚未承重、头与右脚有持续接触且左髋跟踪误差达到 2°，才在下一次控制修改左髋俯仰目标。脉冲序列为 0.015、0.030、0.030、0.015、0 rad，沿用关节限位。控制器保留原策略动作输入和原碰撞规则。

准入同时检查三项。两次参照和两个方向应在至少 12 个场景得到相同首触发，其中至少 5 个场景在两次参照均失败。候选对两个参照的接触冲量和倾角均须改善，95% 自助法区间下限大于零，中位改善分别至少 0.005 N·s 和 1°。候选还须达到原四姿态及时与终点持稳门槛，实际仰卧至少净增 2 例，其他姿态无净退步。

## 操作顺序

在工程目录中的 WSL Python 环境依次调用 [仿真脚本](../../../scripts/validation/run_getup_left_hip_pulse_trial.py) 的 `freeze`、`zero`、`sample`。三步均设置 `PYTHONPATH=scripts/training`，物理采样另设 `MUJOCO_GL=egl`。冻结后由 Windows Python 运行 [观察核验](../../../scripts/validation/observe_getup_left_hip_pulse_trial.py)，写入准备记录后才调用 `sample`。采样完毕，再用同一 WSL 环境调用 [独立评分](../../../scripts/validation/verify_getup_left_hip_pulse_trial.py)。

本次证据使用唯一的运行编号。后续复现应登记独立开发种子、目录和冻结方案，使本轮原片、退出码和轨迹继续可核对。

## 实测结果

| 组别 | 总体及时且终点持稳 | 实际仰卧持稳 | 指定仰卧持稳 | 触发场景 |
| --- | ---: | ---: | ---: | ---: |
| 原策略 A | 728/768 | 647/687 | 601/640 | 53 |
| 原策略 B | 725/768 | 645/687 | 599/640 | 55 |
| 沿跟踪误差方向 | 724/768 | 644/687 | 598/640 | 54 |
| 反向 | 727/768 | 646/687 | 600/640 | 53 |

共同触发 47 个场景，其中 16 个在两次原策略均失败。沿误差方向相对参照 A、B 分别净少 3、1 个实际仰卧成功场景。反向分别净少 1、净多 1，头腿接触冲量的配对中位改善为 0.00078、0.00033 N·s，倾角为 0.092°、0.068°，均低于门槛。两路原策略之间已有 12 个实际仰卧场景的成败不同。两个候选均关闭。 [配对分数与接触复算](analysis.json)

从同一状态恢复 345 项字段和控制器历史。四路首个策略输入、原始动作及首次电机写入逐位一致。独立复算 3,996,996 条接触记录，并确认只有左髋目标收到脉冲。共执行 1,424,640 条转移，耗时 228.37 秒，整段约 6,238 条转移/秒。整机显存峰值 4,620 MiB，GPU 利用率采样均值 31%，最高 46%。这轮规模受完整状态恢复上限约束。正式起身 PPO 的 3,072 环境仍使用已核验的吞吐配置。 [采集日志](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/execution.log) · [GPU 采样](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/sample-gpu-telemetry.json)

Windows 核验 78 次运行中刷新，77 次含真实画面。下列原片各 11 秒、276 帧。预先指定的环境 0 四路均未触发脉冲，原片用于查看动作全程。触发后的效果来自逐场景轨迹。 [运行观察](../../getup-supine-left-hip-pulse-live.html) · [Windows 记录](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/windows-view-verification.json)

[原策略 A](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/evaluation-reference-a-supine/clip-step-0.mp4) · [原策略 B](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/evaluation-reference-b-supine/clip-step-0.mp4) · [沿误差方向](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/evaluation-toward-target-supine/clip-step-0.mp4) · [反向](../../evaluations/duck_getup_left-hip-pulse_paired_s1156_20261110T154433/evaluation-away-from-target-supine/clip-step-0.mp4)

## 执行器与支撑复看

沿误差方向相对反向脉冲，在共同触发的 47 个场景中，前 20 毫秒的左髋驱动力矩中位差为 0.0128 N·m，100 毫秒的实际髋位移中位差为 1.39°。在两次参照均失败的 16 个场景，沿误差方向相对反向的左脚冲量中位差为 −0.0161 N·s，右脚为 +0.0201 N·s。方向改变确实传到髋关节和两脚，但本轮没有形成达到门槛的卸载和持稳改善。反向在这 16 例中通过 2 例，四路整体评分见上表。 [保存轨迹复算](saved-mechanism.json)

按预定的 160 毫秒窗口，在较大采集和两路原策略中分别复算触发后的右脚冲量占比。三路成功组中位数均为 0%，失败组分别为 19.0%、19.0% 和 20.8%，三组差值的 95% 自助法区间均未跨零。参照 A、B 共享种子。 [载荷筛查方案](../../../configs/experiments/getup_supine_floor_transfer_screen.json) · [逐组复算](floor-transfer-screen.json)

## 右脚承重时序

按 4 毫秒时钟对齐右脚受力和躯干倾角。原大批次、参照 A 和参照 B 的失败组分别有 91、21、24 个完整窗口，同时出现右脚持续承重和躯干停滞的分别只有 1、1、0 例。两例的右脚承重确认分别晚于停滞窗口起点 16 和 24 毫秒。三路均没有失败场景满足至少提前 20 毫秒的门槛，关闭基于这一时序的干预方向。

首次读回检查要求两份四元数逐位相同，在比较原始物理缓冲与独立归一化的观测时退出。用项目既有的 2×10⁻⁶ 分量容差复核，通过全部 126 个批量控制边界，最大分量差为 1.19×10⁻⁷。事件阈值和时间窗口沿用冻结方案。 [冻结方案](../../../configs/experiments/getup_supine_floor_transfer_order.json) · [首次检查日志](floor-transfer-order-clock-check.log) · [逐场景时序](floor-transfer-order.json)

## 二次起身触发筛查

在释放时从模型实际收到的重力方向识别仰卧。第 3.20–4.00 秒内，如果过去 0.40 秒的观测倾角始终至少 22°，且变化范围不超过 5°，记一次触发。四个开发种子分别检测到 7/8、4/5、5/5、8/9 个原仰卧失败，首触发落在 3.20–3.58 秒。原成功仰卧 675 个、其他姿态 578 个，均未触发。按原策略成功回合的第 95 百分位耗时估算，以最晚触发、0.8 秒返回和原 8 秒起身截止计算，尚余 1.96–2.19 秒。此估算用于筛选物理试验，实际能否回到仰卧并第二次起身仍需验证。 [筛查方案](../../../configs/experiments/getup_supine_second_attempt_screen.json) · [逐场景结果](second-attempt-trigger-screen.json)

完整返回从触发前最后一条真实下发目标起算，每 20 毫秒最多改变 0.04 rad，0.8 秒预算内为 0/24。24 条均有初始越界请求，最大目标差均来自颈部俯仰。短程方案将颈部目标设置在原 −2.356 rad 下限内侧 0.15 rad，其余 13 个关节仍使用原起始目标。24 条均在相同限速和时长下到达，第 0.7 秒最坏目标误差 0.063 rad，第 0.8 秒全部为零。当前验证范围是目标序列。实际舵机响应、躯干回到安静仰卧和二次起身仍需同初态试验。 [完整返回复算](second-attempt-return-preflight.json) · [短程回撤复算](second-attempt-neck-retreat.json) · [下一轮草案](../../../configs/experiments/getup_supine_second_attempt_native_draft.json)

[关键帧 A](../stage-media/cards/N572.jpg) · [关键帧 B](../stage-media/cards/N573.jpg) · [沿误差方向关键帧](../stage-media/cards/N574.jpg) · [反向关键帧](../stage-media/cards/N575.jpg) · [图像核对](media-review.json)
