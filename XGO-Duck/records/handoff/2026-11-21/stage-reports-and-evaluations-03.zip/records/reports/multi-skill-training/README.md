# 多技能训练前置计划

当前两个参数随机化起身导出只用于起身回归，不能直接承担滚翻和七指令。下一阶段按 getup → roll → walk → router 的顺序分别训练和验收；每一项先做 CPU 场景核验与 GPU 零步，再做同父点、同转移量的短对照。

- [训练计划草案](../../../configs/experiments/multi_skill_training_plan_draft.json)
- [上一阶段回归](../parameter-randomized-regression/README.md)
- [全流程报告](../../../docs/reports/development_report.md)

CPU-only 模型接口前置已通过：官方 getup/roll/walk 与 candidate/control getup 共五个 ONNX 均为 61→14、14 个关节名、action scale=1.0，SHA-256 已记录。GPU reset-only 零步也已通过：getup 1024 环境、roll 128 环境、walk 224 环境均为 0 物理步，最大显存占用约 27.52%。学习更新和硬件 IO 均为零。训练窗口使用周期完整录像、JSONL 指标和 GPU/主机资源记录；只在 paired control 与 candidate 都通过接口检查后才进入学习。任何显存、数值、关节顺序或动作门槛异常都会保留最近保存点并停止。

- [CPU 接口前置](preflight.json) · [GPU 零步](gpu-zero-step.json) · [前置状态](preflight-status.json) · [零步修订](gpu-zero-step-revision.json) · [失败归档](preflight-failures/README.md)

## 转入滚翻单项训练

CPU 接口和 GPU reset-only 零步通过后，复核了已有交付：起身使用 `artifacts/delivery/getup-simulation.json`，行走使用 `artifacts/delivery/walking-simulation.json`。两项不再重复同类短训。滚翻 airborne-support 配对训练已完成，控制组 112/128、候选 111/128，候选未达到 116/128 和相对控制组 +4 门槛；本轮关闭且 router 仍等待滚翻单项通过。 [失败分析](../roll-airborne-support/analysis.json)
