# 多技能前置失败归档

第一次 CPU-only 读取器运行在解析上一阶段汇总时使用了 `name` 字段，而汇总使用 `arm` 字段；没有创建物理环境、没有物理步、没有学习更新。第一次 GPU 零步入口遗漏 `scripts/training` 的导入路径，也在创建环境前停止。修正后，WSL CPUExecutionProvider 对官方 getup/roll/walk 和 candidate/control getup 共五个 ONNX 完成 61→14、14 个关节名、action scale=1.0 与 SHA-256 核验，三种 GPU reset-only 环境也通过。

- [修正后前置结果](../preflight.json)
- [CPU 字段失败](attempt-1.json) · [GPU 导入路径失败](attempt-2.json)
