# WSL 训练日志归档

训练和仿真保持暂停。本次检查的是 WSL 中 `/home/atlas/XGO-Duck/workspace/xgoduck_rl/logs/rsl_rl/`；其他 WSL 目录不在范围内。原目录的 **398 个文件、约 591.06 MiB** 已逐一记录路径、大小和 SHA-256，归档后再次完整读回核验。 [WSL 文件清单](manifest.json) · [完整源文件核验](full-source-verification.json)

## 哪些资料已在项目中

按文件大小和 SHA-256 对照 Windows 训练归档、模型交付、报告、工作区、官方资料、文档、日志、配置和脚本目录，**196 个 WSL 文件**在上述范围内找到字节相同的文件，包括 36 个模型文件。对照中实际重算了匹配的 Windows 文件哈希。两段性能采样原片对应 [T023](../../training-review/videos/T023.mp4) 和 [T024](../../training-review/videos/T024.mp4)。 [原对照](manifest.json) · [其他项目目录对照](additional-project-matches.json)

补查项目其他目录时，首次从 WSL 遍历 Windows 文件的只读过程因元数据访问缓慢而中止，随后改用 Windows Python 完成同一比对；首次过程没有生成结果文件，也没有改动源数据。

另有 **202 个文件**在上述比较范围中没有找到同字节副本：94 个 `.pt`、25 个 `.onnx`、39 个 TensorBoard 事件日志、42 个 YAML 配置和 2 个轨迹数组。没有匹配只表示未在列出的范围找到相同字节，不能排除其他位置或语义相同但序列化不同的模型。

这 202 项已按原 WSL 相对路径集中复制到[归档包](unmatched-snapshot.zip)，解压后的每项内容均复核了 SHA-256 和 ZIP 校验。包内原始数据约 417.49 MiB，压缩包占约 379.83 MiB；WSL 原件全部保留。本次没有删除或移动原文件。 [归档清单](unmatched-snapshot-manifest.json) · [归档核验](unmatched-snapshot-verification.json) · [Windows 复核](windows-archive-verification.json)

## 查看和核验

在 Windows 项目根目录核验归档包，不需要启动 WSL 或训练：

```powershell
py -X utf8 -B scripts/validation/archive_wsl_training_logs.py verify-archive
```

重新核对 WSL 原始目录及全部文件哈希：

```powershell
wsl.exe -d Ubuntu-24.04 -- python3 -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/archive_wsl_training_logs.py verify --full
```

这两项检查的是生成清单时的快照。日后新增训练文件或更新日志后，原目录检查会报告变化，需重新盘点；若需从归档恢复，先解压到独立目录并核对清单，再决定如何放回，不直接覆盖现有训练目录。

## 查看历史训练曲线

现有 WSL 环境的 TensorBoard 为 2.20.0。一份滚翻训练事件日志已用 `--inspect` 离线读出 `Train/mean_reward`、`Loss/value`、`Perf/total_fps` 等标量；检查同时报告事件步数有倒序，不能只凭曲线横轴推断完整训练更新数。该环境未安装 TensorFlow，TensorBoard 提示部分功能受限。 [检查记录](tensorboard-inspection.json)

需要自行浏览时，可在终端前台运行下面的命令，再尝试在浏览器打开 `http://127.0.0.1:6006`；关闭终端前用 `Ctrl+C` 停止。该命令读取历史日志，不启动训练。网页服务和 WSL 到 Windows 的地址转发尚未在本次启动验证。

```powershell
wsl.exe -d Ubuntu-24.04 -- /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/tensorboard --logdir /home/atlas/XGO-Duck/workspace/xgoduck_rl/logs/rsl_rl --host 127.0.0.1 --port 6006
```

该归档包只包含上述 202 项，剩余匹配文件位于清单标出的 Windows 路径或 WSL 原目录；它不是完整工程或异地备份。 [全部训练归档](../../../training-archive/README.md) · [全流程报告](../../../../docs/reports/development_report.html)
