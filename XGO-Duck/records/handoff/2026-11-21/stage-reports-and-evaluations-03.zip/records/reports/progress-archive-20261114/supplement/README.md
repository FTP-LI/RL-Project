# 暂停进度补充

整理日期：2026-11-14。训练与仿真保持暂停；本次只归纳已有结果、记录进程状态并核对文件。全阶段目标继续保留，恢复须由用户明确提出。 [原暂停归档](../README.md) · [全流程报告](../../../../docs/reports/development_report.html) · [过程记录](../../../../docs/reports/development_history.html)

## 已有结果

| 内容 | 已保存的结果 | 还需完成 |
| --- | --- | --- |
| 七种行走指令 | 共同接口最终留出中，站立、前进、后退、左右转及左右平移各为 32/32。方案使用多个策略组件和反馈。 | 继续验证扰动和与其他动作的切换，不能把单项通过当成整机验收。 [行走清单](../../../../artifacts/delivery/walking-simulation.json) |
| 起身 | 四姿态独立留出 2,983/3,072，实际右侧 179/183，满足该次功能门槛。 | 候选相对父参考的净差未满足晋级要求；真实设备尚未标定。 [评分与录像](../../getup-right-robustness/holdout/README.md) |
| 滚翻与衔接 | 官方滚翻独立开发和留出各为 117/128；官方滚翻→站立→前进固定路线为 119/128。 | 不同控制器下的参数评估不能合并为统一抗扰通过。 [滚翻](../../roll-endpoint-confirmation/README.md) · [路线](../../official-route-independent-s1235/README.md) |
| 训练效率 | 行走 4,096 环境的两遍规模短测约 23.98–24.58 千转移/秒；可观察的 D3D12、4 Hz 配方约 18.35–18.38 千转移/秒。 | 这些是短测吞吐，不能代替动作质量；起身和新方案仍须分别核对。 [性能与观察](../../throughput-selection/README.md) |

上述结果均来自各自记录的仿真条件，并非单一自训模型已经完成全部目标。官方权重和自训组件分别位于 [official](../../../../artifacts/delivery/official/) 与 [trained](../../../../artifacts/delivery/trained/)；模型用途、保存点、修改原因和结果见[权重与迭代记录](../../../../artifacts/delivery/iteration_record.md)。按原批次保存的训练日志、评估、原片及配置见[训练记录归档](../../../training-archive/README.md)。

## 最近中断位置

最近执行的是官方固定策略的摩擦、电压筛查，没有 PPO 更新。八组中六组完成；高摩擦、名义电压组在 1,400/1,550 控制步暂停，最后一组未开始。中断组保存 29 张画面、状态和日志，但无完整轨迹和可恢复物理检查点，部分视频未封装，不能从第 1,400 步直接续跑。 [停止记录](../../roll-domain-parameter-random-s20/stop-record.json) · [结果与完整原片](../../roll-domain-parameter-random-s20/README.md)

![中断前保存的画面](../../../evaluations/duck_roll-domain-parameter_high-mid_s1240_20261114T113334/frame-step-1400.jpg)

六个完整组的原片均为 31 秒，例如[低摩擦、低电压完整原片](../../../evaluations/duck_roll-domain-parameter_low-low_s1240_20261114T113333/clip-step-0.mp4)。中断组画面只是部分帧，不能代表完整动作。

## 暂停后查出的主要问题

1. 最近筛查每组使用固定参数，而非逐环境随机采样。它的落地过渡为 25 步，已验收的官方路线为 0 步，因此不能把两者当作只改动物理参数的对照；低摩擦三组的 `early_stop` 也是事后诊断，实际已跑完整个采样预算。 [离线复核](../../roll-domain-parameter-random-s20/offline-review.md)
2. 七组已保存的起点在位置、速度和观测等字段上一致，但完整随机状态、执行器内部状态和未来对照的完整初态仍未证明一致。原比较器跳过了摩擦字段；独立检查已补核保存的摩擦数组，实际模型的脚部几何名称映射仍未核验。 [初态复核](../../roll-s20-saved-startup-review/README.md)
3. 后续单因素配置与摩擦守卫已通过配置对象、保存数据和假环境检查；它们尚未接入真实运行入口，真实策略接口、观察器和 CUDA 零步没有验证。不能据此宣称真实训练保护或参数抗扰通过。 [配置](../../roll-factor-configuration/README.md) · [摩擦守卫](../../roll-selective-friction-guard/README.md) · [适配边界](../../roll-factor-guard-adapter/README.md)

## 文件与核验

[补充快照](snapshot.zip)保存原归档之后的离线检查报告、协议、代码及其失败记录；[清单](manifest.json)记录文件大小和 SHA-256，[核验记录](verification.json)记录压缩包和成员检查。原始模型、轨迹和视频仍在原路径，补充快照和[原快照](../snapshot.zip)均不是可脱离工程目录的完整备份。原快照与原清单没有覆盖。 [原归档完整性检查](../../archive-integrity-followup/README.md)

Windows 工程根目录下可重新核验：

```powershell
Set-Location 'C:\Users\atlas-win\Desktop\RL-Project\XGO-Duck'
py -X utf8 -B scripts/validation/archive_pause_supplement.py verify
py -X utf8 -B scripts/validation/archive_paused_progress.py verify
```

WSL 进程检查记录见[进程快照](wsl-processes.txt)。实际设备仍未进行通信、舵机零位、方向或 IMU 校验；相关材料只作为后续准备。 [真机准备](../../../hardware/deployment-preparation/s19-readiness.md) · [标定手册](../../../../docs/runbooks/hardware_commissioning.md)

恢复后先冻结与已验收路线一致的控制器和同种子对照，验证实际入口、观察器、停止规则及 CUDA 零步，再决定新的评估；暂停期间不自动启动。
