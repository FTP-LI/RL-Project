# 当前进度补充归档

整理日期：2026-11-14。训练和仿真保持暂停。这里保存原暂停快照之后的最新目标、全流程报告、存储盘点与离线检查；它补充原归档，不覆盖原始记录。 [原暂停归档](../README.md) · [早期补充](../supplement/README.md)

当前结果、九类动作的剩余工作与现场部署边界见[当前目标](../../../../docs/current_goal.md)。最近一次官方固定策略评估完成六组，第七组在 1,400/1,550 控制步中断，没有可从该步恢复的物理检查点。官方权重、自训组件及其评价边界见[权重与迭代记录](../../../../artifacts/delivery/iteration_record.md)。

[文本和代码快照](snapshot.zip)与[清单](manifest.json)保存本次选定文件及哈希。大模型、原始轨迹和视频继续保留在工程原路径；[原归档清单](../manifest.json)只逐项记录其中选定的 83 个文件，并不覆盖全部资料。Windows 训练归档的逐文件清单见[训练归档文件清单](../training-files/README.md)。这些快照均不是可脱离工程目录的完整备份。空间占用和保留原因见[存储盘点](../../storage-review-20261114/README.md)。

训练和真机操作不会因归档而启动。用户明确要求恢复后，再按当前目标核对方案、观察入口和实际运行条件。

在 Windows 工程根目录运行 `py -X utf8 -B scripts/validation/archive_current_paused_state.py verify`，可核对快照成员和当前文件差异；83 个选定文件的检查见[归档完整性检查](../../archive-integrity-followup/README.md)。

快照创建后，目标文档和归档说明又为补充完整文件清单而更新；因此复核可能报告 `passed-with-live-source-changes`。请以输出的具体文件列表区分当前说明的变化与快照本身的完整性。
