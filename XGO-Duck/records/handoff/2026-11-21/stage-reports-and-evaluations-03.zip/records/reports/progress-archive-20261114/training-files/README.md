# 训练归档文件清单

本清单记录 Windows 工程 `records/training-archive/` 中的每个普通文件，包括文件路径、字节数和 SHA-256；训练和仿真继续暂停。旧路径中的目录联接指向同一批实体文件，不再重复计算。WSL 文件系统中的训练日志、官方原始资料及其他工程目录不在本清单范围内。

WSL 原始训练日志已另外建立[文件清单与归档](../wsl-training-logs/README.md)。

本次记录 **21,135 个文件、约 65.92 GiB**。逐个计算哈希后，再复查全部路径、大小和修改时间，并重新读取 21 个样本（含最大文件）；抽样复核通过。与首次训练目录归档清单比较，10,149 项内容一致，1 项发生变化，没有发现原清单中的文件缺失。

变化项为 `evaluations/current-evaluation.json`，它保存最近评估的路径和进程号，评估脚本会更新该文件；其新旧哈希及路径见[清单](manifest.json)。这只说明文件内容有变化，不能根据其中的进程号判断任务仍在运行；当前暂停状态应结合实际进程和项目状态检查。

生成时逐个读取文件并核对读取前后状态，再复查目录文件列表与文件状态。清单是盘点时的快照；未来有新训练、文件移动或资料更新时，需单独生成新的核验记录，不能将快照描述为实时内容。

具体文件和哈希见[清单](manifest.json)；检查范围与结果见[核验记录](verification.json)。暂停归档中单列的模型和媒体另由[原清单](../manifest.json)核验，后者只包含选定的 83 项，不等于整棵工程目录。

在 Windows 工程根目录运行下列命令，可重新核对文件清单、目录状态和抽样内容；`--full` 会重新读取目录中的全部数据。

```powershell
py -X utf8 -B scripts/validation/archive_training_file_manifest.py verify
py -X utf8 -B scripts/validation/archive_training_file_manifest.py verify --full
```

这些校验用于检查工程内文件是否仍与快照一致，不是异地备份，也不能证明模型效果或实物状态。 [原暂停归档](../README.md) · [存储盘点](../../storage-review-20261114/README.md)
