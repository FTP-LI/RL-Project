# 暂停时的进度归档

归档时间：2026-11-14。训练和仿真保持暂停；恢复前必须收到用户明确指令。本次归档整理已有证据，没有新增物理仿真、训练更新或真机操作。

原快照之后的参数配置、初态和场景守卫离线检查已另行整理，见[暂停进度补充](supplement/README.md)。原快照和历史核验记录保持原样。

最新目标、报告与存储盘点另存于[当前进度补充归档](current-state/README.md)。

Windows 训练资料的完整目录清单和 WSL 原始训练日志分别核验；未在项目所查目录找到副本的 WSL 文件已集中打包，原件保留。 [Windows 清单](training-files/README.md) · [WSL 日志与归档](wsl-training-logs/README.md)

## 完成到哪里

| 内容 | 已有结果 | 当前边界 |
| --- | --- | --- |
| 环境与观察 | WSL 训练环境、检查点、ONNX 导出、曲线和真实录像的流程已验证。训练环境选用了 Ubuntu 24.04，不把它称为官方指定发行版。 | 本次没有重新安装或启动训练。 [环境与操作](../../../docs/reports/development_report.md) · [过程记录](../../../docs/reports/development_history.md) |
| 站立与六方向运动 | 共同接口最终留出中，七项各为 32/32；运行方案包含官方与自训组件及方向反馈。 | 这是约定仿真场景和门槛下的结果，不能代替整机抗扰验收。 [训练与评价](../../../artifacts/delivery/walking-simulation.json) |
| 四姿态起身 | 独立留出为 2,983/3,072，四类实际姿态分别过线；对应自训组件与保存点已保留。 | 相比父参考的净差未达到候选晋级要求。 [评分](../getup-right-robustness/holdout/README.md) · [组件清单](../../../artifacts/delivery/getup-simulation.json) |
| 前滚翻 | 官方策略的独立开发与留出各为 117/128，单动作门槛通过。 | 抗扰与接站立、行走需要单独验收。 [评分与原片](../roll-endpoint-confirmation/README.md) |
| 动作衔接与扰动 | 起身接七指令留出为 2,992/3,072；滚翻路线的官方固定路线在 seed 1235 为 119/128。 | 参数端点和该固定路线的落地过渡不同，不能合并判定统一控制器的参数抗扰通过。 [阶段矩阵](../stage-acceptance-matrix/README.md) · [路线结果](../official-route-independent-s1235/README.md) |
| 真机准备 | 已整理官方模型接口、软件关节映射、标定模板及回退材料。 | 实际舵机 ID、零位、方向、IMU、通信和供电均待现场验证；尚无真机 IO。 [准备记录](../../hardware/deployment-preparation/s19-readiness.md) · [标定手册](../../../docs/runbooks/hardware_commissioning.md) |

## 当前中断位置

最近一次是官方固定策略的摩擦与电压筛查，不是 PPO 训练。六个固定参数组合已完整评分，其中低摩擦三组滚翻分别为 110/128、108/128、112/128；中摩擦／低电压为 125/128，高摩擦／低电压为 124/128。中摩擦／高电压虽滚翻 117/128，连续路线只有 25/128。第七组停在 1,400/1,550 控制步；第八组没有开始。

中断组保留 29 张采样帧、状态和日志，没有完整轨迹或可恢复的物理检查点；部分 MP4 未封装完成，不能作为完整录像。恢复时不能从第 1,400 步直接续跑。六组的原录像与评分入口见[暂停记录](../roll-domain-parameter-random-s20/README.md)，具体停止信息见[机器记录](../roll-domain-parameter-random-s20/stop-record.json)。

![中断时保存的画面](../../evaluations/duck_roll-domain-parameter_high-mid_s1240_20261114T113334/frame-step-1400.jpg)

离线复核确认：筛查实际是每臂固定参数，而不是逐环境随机化；S20 落地过渡为 25 步，已验收的 S17 路线为 0 步；三个低摩擦组的 `early_stop` 为事后诊断，原采集均运行了 1,550 步。这些差异阻止将 S20 直接解释为单因素或同控制器的抗扰结论。 [离线复核](../roll-domain-parameter-random-s20/offline-review.md)

暂停后准备的停止入口只经过保存轨迹和 CPU 假环境验证；非名义参数注入、多臂调用、真实观察器和 CUDA 零步尚未验证。 [入口检查](../roll-domain-parameter-random-s20/guarded-entry.md)

## 模型和训练记录在哪里

- 官方行走、起身与滚翻权重保存在 [official](../../../artifacts/delivery/official/)；行走仿真参照也在此目录，具体来源和哈希见[模型选择](../../../artifacts/delivery/simulation-model-selection.json)。
- 七指令和起身所用的自训组件及对应 `.pt` 保存点保存在 [trained](../../../artifacts/delivery/trained/)，按用途和评价边界阅读[行走清单](../../../artifacts/delivery/walking-simulation.json)与[起身清单](../../../artifacts/delivery/getup-simulation.json)。组件并非单个已通过全部抗扰门槛的统一模型。
- 路线感知教师约束候选及保存点保留在模型选择清单中：两种子合计与官方父参考均为 243/256，候选未晋级。早期失败模型作为历史证据保留。 [模型选择与路径](../../../artifacts/delivery/simulation-model-selection.json) · [迭代记录](../../../artifacts/delivery/iteration_record.md)
- 训练日志、评估、基准、曲线、配置和原片按原批次保存在 [训练记录归档](../../training-archive/README.md)，现有兼容路径继续可读。本次不移动或删除这些文件。

官方原件、所列行走与起身组件、教师候选及其保存点共 16 项已按记录哈希核对，字节一致；这项检查不代表真机就绪。 [模型核验](model-verification.json)

## 归档方式与查看顺序

1. 先阅读本页和[全流程报告](../../../docs/reports/development_report.html)，了解环境、改动、效果、截图及录像；训练过程见[完整记录](../../../docs/reports/development_history.html)。
2. 对照[阶段验收矩阵](../stage-acceptance-matrix/README.md)和[权重迭代记录](../../../artifacts/delivery/iteration_record.md)，定位实际通过项、失败项与模型。
3. [文本和代码快照](snapshot.zip)保存本次归档的关键报告、配置、入口代码与评分摘要；[清单](manifest.json)记录快照及选定的 83 个模型、轨迹和媒体文件的路径、大小与 SHA-256，并不覆盖全部资料。Windows 训练归档的逐文件记录见[训练归档文件清单](training-files/README.md)。大体积轨迹、视频和模型仍保留在原工程路径，**快照不是可脱离工程目录的完整备份**。
4. 恢复后需重新冻结与 S17 一致的控制器、同种子名义对照和停止规则，并验证观察入口及真实 CUDA 零步；实际训练或仿真只有在用户再次明确要求恢复后才考虑。

在工程根目录运行 `py -X utf8 -B scripts/validation/archive_paused_progress.py verify` 可重新核对快照和清单。 [归档核验](verification.json)

此前来源审计发现两份说明文档的三条历史哈希已变化，旧值及当时矩阵快照保留；数值结果源 JSON 未发现哈希偏差。 [来源审计](../stage-acceptance-matrix/source-hash-audit.json)
