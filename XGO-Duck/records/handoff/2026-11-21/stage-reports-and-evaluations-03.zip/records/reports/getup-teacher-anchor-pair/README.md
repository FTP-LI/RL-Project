# 起身成功动作保持对照

本轮已关闭，未选出可靠起身方案。固定官方285/320、原奖励训练287/320、保持约束303/320；每组都是seed1030的320个完整11秒首次episode。候选实际仰卧154/170，需要162次；原指定仰卧28/32，需要31次，原指定左侧121/128，需要122次。

两组训练均为seed43、1024环境、24步×41更新，合计2015232学习转移。对照累计输出RMS在第41次达到0.05154rad并停止；候选在同预算内为0.02422rad，降低53%，未触线。三组评价528000转移，零评价学习；不使用最终留出，不自动延长。

| 证据 | 用途 |
| --- | --- |
| [冻结协议](../../../configs/experiments/getup_teacher_anchor_pair.json) | 87份来源、唯一系数变化、预算和选择规则 |
| [汇总](analysis.json) | 实际计数及关闭决定 |
| [对照训练复核](control/training-verification.json) · [候选训练复核](candidate/training-verification.json) | 优化器、归一化、目标、随机采样与录像 |
| [官方评价](original-analysis.json) · [对照评价](control-analysis.json) · [候选评价](candidate-analysis.json) | 所有首次episode、指定与实际姿态、及时和末段持稳 |
| [机制分析](mechanism-review.json) · [失败分析](failure-review.json) | 保持作用与仍未解决的接触/倾角 |
| [持稳图](../../../docs/reports/assets/getup-success-anchor-hold.png) · [偏离图](../../../docs/reports/assets/getup-success-anchor-drift.png) | 真实数据；区间为单开发种子的Wilson区间 |
| [关键时刻](../../../docs/reports/assets/getup-success-anchor-sequence.jpg) | 预先固定仰卧环境，未按结果挑选 |
| [完整播放截图](vscode-training-complete-playback.jpg) | 原VS Code的8秒终态及同一共享终端 |

每个训练记录保留一段完整8秒201帧原片和一段停止时3.68秒93帧的明确中断段；不为凑时长增加物理步。每个评价记录保留四种预选相机的完整11秒276帧、25fps原片，总计12段，逐帧qpos来源核验通过。训练片段中模型会更新，不能当作最终固定策略演示。最终策略表现以独立评价为准。

全部17次候选失败都在最后8–11秒倾角超限，并出现头腿接触，倾角中位约33°；高度、双脚接触、角速度和关节范围均未导致这些末段失败。冻结前100个零动作控制步已出现数值分歧，不能按同编号逐项宣称因果改善。保持约束是有用线索，尚未解决持续卡住；下一奖励草案仍不可执行。

日常可见入口为VS Code的Terminal → Run Task…；本轮任务已完成后归入任务历史，直接重复执行会被拒绝。复核已有结果不推进物理：

```bash
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_teacher_anchor_pair.py --verify-train control
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_teacher_anchor_pair.py --verify-train candidate
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_teacher_anchor_pair.py --verify-eval original
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_teacher_anchor_pair.py --verify-eval control
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_teacher_anchor_pair.py --verify-eval candidate
```

学习入口、PPO类和独立复核分别在`scripts/training/getup_teacher_anchor_train.py`、`getup_anchor_ppo.py`及`scripts/validation/verify_getup_teacher_anchor_train.py`，开头注释解释改动和动机。源码按已冻结字节保存，未修改官方归档；后续试验另建名称、协议和记录，不能覆盖本轮。


[清理记录](intermediate-cleanup.json)列出两个已删除的未采用25更新检查点及原哈希，共回收9.26MiB；初始/最终检查点和全部复核输入保持可读。
