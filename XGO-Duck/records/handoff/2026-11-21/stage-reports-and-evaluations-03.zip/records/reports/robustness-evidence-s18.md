# 固定策略抗扰证据汇总

**适用范围补充：** 后续对原始指令的离线复核发现，S18 引用的参数端点使用 25 步落地站立过渡，而 S17 已验收路线使用 0 步；这些结果应分别理解，不能合并为同一控制器在整个参数范围内的抗扰通过。 [控制器与原始轨迹复核](roll-domain-parameter-random-s20/offline-review.md)

S18 只读取既有记录，不增加物理步、学习更新或硬件 IO。四组参数端点交叉复验均通过原滚翻和连续前进门槛：标称 123/128、摩擦 1.3 / 7.7 V 为 125/128、1.0 / 7.4 V 为 124/128、1.3 / 7.4 V 为 125/128。候选区间为脚底摩擦 1.0–1.3、供电 7.4–7.7 V；低摩擦 0.7 与高电压 8.0 V 不纳入候选范围。

S16 seed-1234 名义横向扰动三臂也通过原路线门槛：参考 123/128、左推 119/128、右推 127/128，动作目标没有修改。S17 官方 seed-1235 固定完整路线为 119/128，滚翻落地 120/128，前进入口 120/128，头部穿透和关节越限通过。

这些结果只证明各自记录的控制器与测试条件达到当时的门槛，不能合并证明当前无过渡路线在参数范围内通过。它们不证明参数随机化训练收益；参数随机化短训的统一回归仍未通过，训练候选不晋级。S16 留一环境触发审计也未准入可迁移的扰动控制信号，因此不启动 PPO 或新的动态臂。

证据：

- [机器可读汇总](robustness-evidence-s18.json)
- [参数端点交叉复验](roll-domain-parameter-cross-check/README.md)
- [S16 横向扰动评分](roll-phase-perturbation-review/s16-score.json)
- [S16 时序审计](roll-phase-perturbation-review/s16-temporal-audit.json)
- [S17 官方路线报告](official-route-independent-s1235/README.md)
- [参数随机化回归](parameter-randomized-regression/README.md)
