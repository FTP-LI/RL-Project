# XGO-Duck 当前进度与归档

整理日期：2026-11-15。训练按用户要求暂停；这次只核对已有进度、复算保存数据并整理文件，没有启动新训练或新评估。2026-11-16 的 WSL 项目脚本进程检查未发现活动工作进程；这是检查时刻的状态。恢复运行需要用户明确指令。[最新进程检查](process-check-20261116.json) · [前次检查](process-check.json) · [当前目标](../../../docs/current_goal.md)

## 已完成与未完成

| 项目 | 已有记录 | 还需完成 |
| --- | --- | --- |
| 站立、前后走、左右转和左右平移 | 共同接口的七项最终留出分别为 32/32，使用多个模型组件和反馈。 | 继续检查统一场景中动作切换和扰动，不能说一个 ONNX 已覆盖全部功能。[行走方案](../../../artifacts/delivery/walking-simulation.json) |
| 跌倒后起身 | 四姿态独立留出为 2,983/3,072，实际右侧为 179/183；实际右侧相对两组参照净增 4、5 例，原留出门槛通过。 | 总体相对参照分别少 4、5 例；保留参照与失败样本，继续验证完整技能组合。[原评分与录像](../getup-right-robustness/holdout/README.md) · [汇总更正](../getup-gate-clarification/README.md) |
| 前滚翻 | 官方策略的独立开发和留出均为 117/128，通过单动作门槛。 | 在统一场景完成连续切换和参数抗扰验收。[官方评分](../roll-endpoint-confirmation/README.md) |
| 滚翻接站立和前进 | 最近一组固定官方策略、标称条件的连续路线为 123/128，达到该组 116/128 门槛。 | 这只是一个开发种子；不同摩擦、电压的随机数和执行器初态尚未完成成对核验。[结果与完整录像](../duck_roll-native_nominal_s1241_20261115T230228/README.md) |
| 现场标定与部署 | 已整理舵机映射、标定模板和回退材料。 | 实物舵机 ID、零位、方向、IMU、通信和供电尚未现场核验；真机运行后置。[标定手册](../../../docs/runbooks/hardware_commissioning.md) |

这些数字来自不同模型组件、任务和评估条件，不能合并成一个已通过全部动作及抗扰的模型。

## 训练修改与问题

滚翻的一次训练对照只增加空中前向旋转惩罚：官方、对照和候选分别为 108/128、112/128 和 111/128；候选未达到预设晋级条件，已关闭。行走教师约束候选在两个种子合计为 243/256，与官方父参考相同，种子间差异方向相反，未晋级。两项都保留模型和过程记录，不自动追加训练。[滚翻训练](../roll-airborne-support/README.md) · [行走对照](../route-aware-teacher-anchor-parent-compare-s1232/README.md)

最近官方标称路线的 5 个失败环境均进入滚翻，机身累计旋转接近一圈，但按原判据计入的有效支撑旋转为 303°–325°，未达到 330° 完成条件。评估录像的环境 0 在约 1.56 秒头部接触地面、双脚离地；本次没有测量接触力。控制步边界读数已与同一时点的约束接触核对，边界之间每个物理子步的受力没有记录。这些观察可用于提出下一轮假设，不能直接当作训练改进或实物安全结论。[失败复盘](../duck_roll-native_nominal_s1241_20261115T230228/failure-review.json) · [接触复核](../duck_roll-native_nominal_s1241_20261115T230228/roll-contact-review.json)

![官方路线关键帧](../duck_roll-native_nominal_s1241_20261115T230228/keyframes.jpg)

## 模型和过程在哪里

- [官方模型](../../../artifacts/delivery/official/)保存原始行走、起身、滚翻参照及行走仿真参照；[自训模型](../../../artifacts/delivery/trained/)保留 ONNX 和对应训练保存点。使用范围、修改原因和结果见[权重与迭代记录](../../../artifacts/delivery/iteration_record.md)。
- [训练和评估归档](../../training-archive/README.md)按批次保留日志、轨迹、录像与恢复材料。`records/experiments` 等路径是兼容入口，指向同一归档实体，不应直接当作重复文件删除。
- [全流程报告](../../../docs/reports/development_report.md)记录环境部署、命令、模型、结果、截图和真机准备；[完整过程记录](../../../docs/reports/development_history.md)保存较早逐次记录。
- 最近评估的[完整观看副本](../duck_roll-native_nominal_s1241_20261115T230228/evaluation-view.mp4)、[原始录像](../../evaluations/duck_roll-native_nominal_s1241_20261115T230228/clip-step-0.mp4)、[速度曲线](../duck_roll-native_nominal_s1241_20261115T230228/native-view/native-curve.png)和[结束状态](../duck_roll-native_nominal_s1241_20261115T230228/native-view/native-status.txt)均可直接打开。这是固定策略评估，速度曲线不是训练损失曲线。
- [历史训练曲线与录像](../native-observer-preflight/historical-example.md)来自一次已完成的 17 次更新训练，可对照实际指标和视频；它不是当前直播。[WSL 原始日志归档](../progress-archive-20261114/wsl-training-logs/README.md)保留日志清单及查看方法。

在 VS Code 打开 `XGO-Duck` 文件夹后，可使用 **Ctrl+P** 输入上述文件的工程相对路径。打开 Markdown 后按 **Ctrl+Shift+V** 预览；视频和图片可直接用 VS Code 查看。本机训练网页在当前应用中无法访问，以上查看方式不依赖该网页。2026-11-16 暂停期间 Windows 上没有发现 8765 端口监听，此记录不能确定此前访问失败的原因。[端口检查](local-viewer-pause-check.json) 真实训练的自动刷新、最新画面与异常停训还没有接入验收。

暂停后又整理了起身训练历史对照和 PPO 观察、监督准备：两组起身模型均未通过全部姿态门槛；监督器的 22 项合成进程检查通过，真实训练接入和中断恢复仍未验收。[历史训练对照](../historical-getup-training-comparison/README.md) · [观察与监督记录](../native-ppo-observation-preflight/README.md) · [补充快照](supervision-preparation.zip) · [快照清单](supervision-preparation-manifest.json)

交付保存点随后完成只读核对：9 份内容可读，五个当前仿真组件的网络和优化器可按各自结构在 CPU 加载；实际恢复训练和物理现场续跑尚未验证。检查源码与结果另有[小型快照](../native-ppo-observation-preflight/delivery-checkpoint-audit-checked.zip)，不包含模型文件。 [检查说明](../native-ppo-observation-preflight/README.md#保存点边界)

观察器异常退出检查使用实际观察子进程和合成数据；加入工作进程身份检查后，三次模拟在 1.86–1.97 秒后标记异常，之前的一次检查为 32.93 秒。真实训练中的表现仍未验证。[检查与快照](../native-ppo-observation-preflight/README.md)

历史短训命令会启动学习，七指令练习会启动新动态仿真；暂停期间以查看已有文件为准。新训练的观察、监督与实际停止仍须接入并验收，旧试验不能直接重启。[入口核对](../native-ppo-observation-preflight/entry-audit.json) · [恢复前检查](../../../docs/runbooks/pc_training.md#恢复前先检查什么)

## 快照和完整性

[本次快照](snapshot.zip)收录当时的目标、报告、关键源码、评估摘要和截图；[清单](manifest.json)列出每个入包文件的 SHA-256，[原位置保留文件清单](external-references.json)记录选定模型、录像和轨迹的大小及哈希。后续整理的相关源码和记录收录在补充快照中，原快照保持不变。模型、完整录像、原始轨迹、历史训练目录和环境仍留在工程原位置，没有复制进快照。因此这些快照不是独立完整备份；迁移时需要一起保留这些原文件及目录结构。[快照核验](verification.json) · [原文件核验](external-verification.json) · [模型重查](model-recheck.json)

在 Windows 的项目根目录，可只读核验快照、清单和选定原文件，不启动训练：

```powershell
py -3 -B scripts/validation/archive_pause_snapshot_20261115.py verify
```

最近评估在本次整理中只读复算，重新得到 123/128；核对了已保存轨迹、策略输入和录像帧数，没有新增物理步或学习更新。[复算结果](baseline-check-output.json) · [完整输出](baseline-check-output.log)

此前快照和原始资料均保留。训练归档在 2026-11-14 盘点约为 65.92 GiB，主要是压缩轨迹；这是当时的 Windows 逻辑大小，不包括 WSL。先前已按清单删除 36 个中间保存点；本次没有删除任何已有训练文件。[历史快照](../progress-archive-20261115/README.md) · [存储盘点与清理依据](../storage-review-20261114/README.md)

## 恢复后的顺序

收到恢复指令后，先确认冻结来源、配对初态、真实训练的观察与异常停止，再按有界预算比较训练修改。完成单动作和连续切换的独立评价后，再核对参数扰动；只有仿真门槛与现场条件具备后才进行标定和部署。具体阶段和门槛以[当前目标](../../../docs/current_goal.md)为准。
