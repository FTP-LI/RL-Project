# 滚翻 airborne-support 配对训练

本轮只处理滚翻动作的中段空中旋转损失。起身和行走已有通过验收的交付，继续复用其结果；官方滚翻权重保持原样，控制组与候选组从同一个官方父模型、同一个 seed、同一个环境规模和同一个更新预算开始。

## 为什么启动这一轮

此前三条滚翻修改线已经结案，保存的支持诊断显示 21/21 个 head-top 失败都主要表现为空中旋转损失，而不是横向偏移损失。这个结论来自保存轨迹的逐回合比较，见 [支持诊断](../roll-support-diagnosis/analysis.json)。因此候选只增加一个奖励项：当累计前向旋转位于 30–240°、仍有前向角速度、且脚、头和机身均未接触地面时施加 `-0.35` 的小惩罚。观测、动作历史、默认姿态、官方 actor 和着地奖励均保持不变。

## 运行前核验

| 项目 | 结果 | 证据 |
| --- | --- | --- |
| CPU 场景与奖励差异 | 通过；控制组奖励项不变，候选仅增加一项 | [cpu-preflight.json](cpu-preflight.json) |
| GPU reset-only | 通过；控制组和候选组各 1024 环境，0 物理步、0 学习更新，最大 reset 显存占用约 15.58% | [gpu-zero-step.json](gpu-zero-step.json) |
| 父模型 | 官方 `xgoduck_roulade.onnx`，SHA-256 `8adb1e6b…c8248e97` | [冻结协议](../../../configs/experiments/roll_airborne_support_pair.json) |
| 旧候选 | 保留并关闭，不覆盖 | [top-contact](../roll-top-contact/analysis.json)、[frontier](../roll-completion-frontier/startup-recovery/analysis.json)、[neck-support](../roll-neck-support/README.md) |

首次 CPU 预检曾在创建物理环境前因读取错误字段停止，已保存为历史失败记录；修复后重新通过。该失败没有物理步或学习更新，不计入训练结果。

训练启动时的 model-HOME 适配遗漏和评估角色切换闭包问题也分别在 [启动失败记录](failures/attempt-20261114-1.json) 与 [评估失败记录](failures/evaluation-attempt-20261114-1.json) 中保留；两次都在对应的物理或学习边界前停止，后续重跑使用新的运行编号。

## 冻结预算和停止线

协议位于 [roll_airborne_support_pair.json](../../../configs/experiments/roll_airborne_support_pair.json)，控制组和候选组分别位于 `configs/experiments/roll_airborne_support/`。每组使用 1024 个环境、24 个控制步、50 次更新，其中前 14 次只更新 critic，随后 36 次更新 actor，共 1,228,800 条转移。每 180 秒保存一个 3 秒完整滚翻片段，指标按更新写入运行目录；不打开持续渲染窗口。

训练过程中出现非有限值、接口或关节顺序不一致、意外物理重置、显存超过 85%、固定 probe 漂移超过阈值，或候选在第 14/28/42 次观察点相对控制组明显退化时立即停止。没有自动重试和预算延长。

## 独立评估门槛

训练完成后，控制组和候选组都必须导出 ONNX，并以 seed 1211 独立运行 128 回合、每回合最多 9 秒，要求末段保持 2 秒。候选只有同时满足以下条件才允许进入下一阶段：至少 116/128，且比控制组多至少 4 个成功回合，并且没有新增头部穿透或关节限位失败。否则保留官方权重、失败候选和完整证据，停止扩展。

## 运行命令

在 WSL 的项目目录中依次运行控制组和候选组，两个命令都使用同一个可见终端并保留标准输出：

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
/home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -u -B scripts/validation/run_roll_airborne_support_pilot.py configs/experiments/roll_airborne_support/control.json
/home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -u -B scripts/validation/run_roll_airborne_support_pilot.py configs/experiments/roll_airborne_support/candidate.json
```

每次运行的 `state.json`、`training.log`、`learning-metrics.jsonl`、保存点、原片和导出清单都位于 `records/experiments/<run-id>/`；Linux 训练副本中的 TensorBoard 和 checkpoint 路径会写入同一运行记录。训练中可打开 [运行观察页](../../training-live.html) 查看状态、更新时间、曲线和最近原片。

## 当前状态

本轮已关闭。CPU 差异核验、GPU reset-only 零步、控制组和候选组各 50 次更新以及 seed 1211 独立评估均已完成。官方为 108/128，控制组为 112/128，候选为 111/128；候选没有新增头部穿透或关节限位失败，但低于 116/128 且比控制组少 1 个成功，因此不晋级、不延长、不启动 router。逐回合分析见 [analysis.json](analysis.json)，完整评估见 [evaluation.json](evaluation.json)。三组模型、保存点、日志、轨迹和视频均保留，候选只作为失败研究证据。

## 视频和关键帧

三组评估都保留了 env0 的 9 秒 MP4 和全量轨迹。下面的对照图从同一时间点抽取官方、控制组和候选组画面；原始视频路径记录在 [evaluation.json](evaluation.json) 中。

[官方评估视频](../../evaluations/duck_roll_airborne-support_eval_official_s1211_20261114T005451/videos/forward-roll_env0.mp4) · [控制组评估视频](../../evaluations/duck_roll_airborne-support_eval_control_s1211_20261114T005451/videos/forward-roll_env0.mp4) · [候选评估视频](../../evaluations/duck_roll_airborne-support_eval_candidate_s1211_20261114T005451/videos/forward-roll_env0.mp4)

训练阶段原片：[控制组 3 秒片段](../../experiments/duck_roll_airborne-support_control_s1210_20261114T004321/clip-step-0.mp4) · [候选组 3 秒片段](../../experiments/duck_roll_airborne-support_candidate_s1210_20261114T004321/clip-step-0.mp4)

![滚翻三组关键帧对照](../../../docs/reports/assets/roll-airborne-support-comparison.jpg)

同一 seed 的首次官方参考因评估脚本切换失败而单独完成了 114/128；修复后的三组同进程对照官方为 108/128。该差异已写入 [analysis.json](analysis.json)，提示 CUDA 评估存在重复性波动；控制组与候选组的配对比较仍来自同一进程。
