# 本机观察零步检查

这次检查使用种子 1241、128 个环境、脚底摩擦 1.0 和 7.7 V 标称参数，范围仅为 CUDA 环境初始化及零步接口核验。没有授权动态采样、学习或真机操作。 [冻结方案](../../../configs/experiments/roll_factor_native_zero_s1241_20261115.json) · [原方案](../../../configs/experiments/roll_factor_zero_nominal_s1241_20261115.json)

VS Code 实际显示了该次运行的状态并自动刷新，截图记录的是零步准备，不是训练画面。 [观察截图](../duck_roll-factor_nominal_s1241_20261115T214019/native-zero-run/ui-check.jpg) · [观察凭据](../duck_roll-factor_nominal_s1241_20261115T214019/native-zero-run/ui-proof.json)

![零步状态](../duck_roll-factor_nominal_s1241_20261115T214019/native-zero-run/ui-check.jpg)

环境初始化后，执行器限力检查报出 `actuator mapping and flags must be integer arrays` 并停止。运行契约记录控制步和物理子步均为 **0**，接口检查为 **0**；静态场景字段比较记录为通过，但限力数组和模型接口尚未通过检查。 [停止结果](../duck_roll-factor_nominal_s1241_20261115T214019/native-zero-run/result.json) · [运行契约](../duck_roll-factor_nominal_s1241_20261115T214019/zero/runtime-contract.json) · [场景记录](../duck_roll-factor_nominal_s1241_20261115T214019/zero/scene-static-contract.json)

控制台完整输出没有保存，现有[输出摘录](zero-attempt-console-excerpt.txt)只包含当时观察到的部分信息。Warp 输出识别到了 CUDA 设备；ONNX Runtime 的设备发现警告和执行器配置警告需要分别复查，不能据此认定为本次停止原因。后续运行必须同时将标准输出和错误输出完整写入日志，并保留退出状态。

## 原因分析

失败现场保存的 XGO 执行器映射为 `int32`，但没有保存限力标志和传动类型数组。在同一 MuJoCo 版本构建的独立 CPU 小模型中，映射和传动类型为 `int32`，限力标志为 `bool`；原检查器对三项均要求整数，因此在小模型上复现了同一报错。旧假环境将限力标志设为 `uint8`，没有覆盖这个差异。已安装的仿真库将场景模型作为 `mujoco.MjModel` 使用，这支持类型兼容问题的判断；但真实 XGO 标志数组没有保存，仍需实际读回确认。 [CPU 类型诊断](force-dtype-diagnosis.json) · [原检查器](../../../scripts/validation/model_force_limit_guard.py)

候选修复在独立文件中仅将布尔限力标志复制并规范化给原检查器，返回的证据仍保留原始布尔数组；映射、传动类型、限力是否启用和力范围的检查保持不变。CPU 小模型通过，11 项无效输入被拒绝，原模型数组未改变。该结果不代表真实 XGO 的限力范围已验证。 [候选实现](../../../scripts/validation/model_force_limit_guard_bool.py) · [CPU 核验](force-bool-candidate-check.json)

下一次检查需使用独立方案和新的运行目录，先固定候选源码、日志和观察条件，再在零物理步时保存真实限力标志、传动类型与力范围并独立核对。原失败记录和冻结方案保留，不自动重启原运行；动态采样与训练继续等待后续准入。
