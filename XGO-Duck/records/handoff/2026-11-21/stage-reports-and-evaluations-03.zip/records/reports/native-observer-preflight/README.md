# 本机观察方式检查

2026 年 11 月 15 日，在没有运行训练或仿真的情况下，检查了 VS Code 查看本地文件的能力。用户报告训练网页无法访问；检查时本机 8765 端口没有监听服务，先前应用内浏览器访问该地址也受到已保存权限或管理策略限制。

## 已核验内容

1. 在 VS Code 中打开 [状态文件](status.txt)。第一次显示真实采样编号 1，随后 Windows 程序写入编号 2；编辑器无需重新打开文件即显示了新编号、采样时间和当时的 GPU 读数。再由 WSL 写入编号 3，Windows 的 VS Code 同样自动显示更新。 [采样记录](samples.jsonl) · [状态截图](status-check.jpg) · [WSL 写入截图](wsl-refresh-check.jpg)
2. 在同一个 VS Code 窗口中播放[既有仿真录像](../../evaluations/duck_switch_routed-turn-gyro_holdout-zero-recovery_s2175_20261110T230520/restored-gyro/clip-step-0.mp4)，观察到画面变化和进度从 0:00 到 0:03，再到 0:32。该录像来自已完成的起身与行走评估，**不是当前实时训练**。 [播放截图](video-check.jpg)
3. 本次使用已存在的 VS Code 布局，没有调整窗口或面板大小；未新建可见终端。状态采样脚本见[本机预检脚本](../../../scripts/validation/native_file_observer_preflight.py)。
4. 根据归档训练的 17 次更新绘制了实际回报、价值损失与采样速度，并在 VS Code 打开图像。指标与录像的原文件及哈希均可追溯。 [历史训练观察示例](historical-example.md)
5. WSL 通过原子替换更新一张临时图片，VS Code 的图片预览自动由状态截图切换到录像截图。两张图片都是已保存的预检证据；临时图片已清理，真实运行的曲线刷新仍需单独验证。 [检查结果](ui-verification.json)
6. 本机观察适配器已离线读取一份归档训练的 17 条实际指标，生成[状态](adapter-offline/native-status.txt)、[曲线](adapter-offline/native-curve.png)、[真实帧](adapter-offline/native-latest.jpg)和[指标表](adapter-offline/native-metrics.csv)。运行编号不符、来源过期、来源已结束、无效指标及越界媒体路径均产生错误；故障样本不会被当作训练数据。 [核验结果](adapter-verification.json)
7. 对独立进程与心跳判定运行了 14 项状态检查和 4 项输入故障检查；另使用明确标为测试的子进程验证健康、退出、过期及旧帧清理。整个检查没有物理步和学习更新。 [进程与心跳核验](observer-guard-verification.json) · [复现脚本](../../../scripts/validation/check_native_observer_guard.py)
8. 用保存轨迹和测试子进程完成 6 项滚翻循环接线检查：观察器在第 2 步后退出或收到用户暂停时，不再执行第 3 步；头部碰撞超限时保留第 5 步并停止。数据来自旧轨迹，本次没有新增物理步。 [接线核验](guarded-loop-verification.json) · [复现脚本](../../../scripts/validation/check_native_guarded_roll_loop.py)
9. 只读核验了当前零步方案相关的工程文件、WSL 训练与依赖源码及本机观察证据；检查项可能重复引用同一文件。原浏览器准入仍未通过，来源一致不代表零步已经运行。 [来源核验](native-zero-provenance.json) · [核验脚本](../../../scripts/validation/audit_native_zero_provenance.py)
10. 使用模拟输入对暂停、已有运行、范围越权、源码变化及证据范围错误进行 8 项拒绝检查，未启动运行时。 [拒绝检查](native-zero-refusal-check.json)
11. 后续实际启动了独立零步检查，并在 VS Code 核验运行状态；执行器字段类型检查报错后停止，运行契约记录物理子步为 0。CPU 小模型诊断及兼容候选已留档，真实 XGO 的限力字段仍待读回；完整控制台日志未保存。 [零步检查记录](zero-attempt-20261115.md)
12. 另行冻结并运行只允许零物理步的修复方案：VS Code 实际显示了该运行的状态，14 个真实模型限力标志为 `bool`；完整日志、退出码、原始数组和独立复核均已保存。该结果不证明训练观察或动态停止已经接入。 [本次记录](../duck_roll-factor_nominal_s1241_20261115T224902/README.md) · [独立复核](../duck_roll-factor_nominal_s1241_20261115T224902/independent-verification.json) · [日志检查](recorded-process-check.json)
13. 动态评估接入的首次测试因评估目录别名与解析后的归档路径不一致而拒绝，测试没有物理步；统一使用解析后的路径后，通过子进程、曲线、媒体路径、暂停和退出检查。首次测试的完整终端流未保存，仅保留观察到的报错。 [首次报错摘录](native-roll-path-failure.txt) · [后续检查](native-roll-observation-check.json)

![状态文件](status-check.jpg)

![跨环境刷新](wsl-refresh-check.jpg)

![录像播放](video-check.jpg)

## 如何查看

在 VS Code 中打开 XGO-Duck 文件夹，打开本目录的 `status.txt` 查看最近一次预检样本，打开 `samples.jsonl` 查看采样历史。录像可以通过上面的链接打开，或在资源管理器中找到原文件后直接播放。这些文件均位于项目目录内，不依赖训练网页。

这里的状态是**一次性预检样本**，不会自行持续更新；要复现一次采样，可在项目目录运行 `py -X utf8 -B scripts/validation/native_file_observer_preflight.py sample`。不要把它当成训练进度或运行中的 GPU 利用率曲线。

要复现归档数据的适配器示例，在 WSL 终端进入本项目目录后运行下面的命令。输出目录必须是尚不存在的新目录；命令只读取历史记录，不启动训练：

```bash
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python scripts/training/native_run_observer.py \
  --source records/training-archive/experiments/duck_getup_early-support-ppo-native_control_s1085_20261110T034608/observation.json \
  --output records/reports/native-observer-preflight/my-example \
  --run-id duck_getup_early-support-ppo-native_control_s1085_20261110T034608 \
  --mode historical
```

在 VS Code 打开新目录的 `native-status.txt`、`native-curve.png` 和 `native-latest.jpg`。状态文件给出来源时间、运行编号和录像路径，曲线旁的来源记录给出图中数据的更新时间。图像不是直播；真实训练是否稳定需以相应评估与录像判断。

## 尚未完成

本机适配器已连接一组[官方动态评估](../duck_roll-native_nominal_s1241_20261115T230228/README.md)，在 VS Code 显示了该运行的进度、曲线和真实画面；评估循环接入了观察进程和暂停检查。真实运行没有主动注入观察器故障。适配器尚未连接训练器，也**不能自行停止训练**；训练仍需核验进程、心跳、曲线、画面和异常停止。不同参数的成对初态尚未核验。

复现进程与故障检查时，在 WSL 项目目录运行 `~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python scripts/validation/check_native_observer_guard.py`。检查会创建并清理本目录内的临时测试文件，结果写入上面的核验记录。
