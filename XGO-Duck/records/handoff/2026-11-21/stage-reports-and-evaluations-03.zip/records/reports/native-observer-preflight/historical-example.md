# 历史训练观察示例

这是已归档训练记录，**当前没有训练或仿真**。训练记录时间为 2026-11-10T03:48:40+08:00，共完成 17 次更新，使用 3072 个环境。训练曲线来自该运行保存的逐次更新数值，不能单独证明动作质量或模型改进。

![历史训练指标](historical-metrics.png)

[原始指标](../../training-archive/experiments/duck_getup_early-support-ppo-native_control_s1085_20261110T034608/observation.json) · [训练录像](../../training-archive/experiments/duck_getup_early-support-ppo-native_control_s1085_20261110T034608/clip-step-0.mp4) · [数据来源与哈希](historical-example.json) · [观察预检](README.md)

图中“环境回报”是记录中的环境步平均回报，“价值损失”是价值网络损失，“采样速度”是该训练记录中的净转移数/秒。此例只有一个训练组，不能判断修改是否带来收益。录像为训练时保存的实际画面，并非当前直播。

本图由项目内的 `scripts/validation/build_native_observer_example.py` 读取原始记录生成。运行需要已安装 Matplotlib 的项目 Python 环境；脚本不执行物理步或学习更新。新训练要有自己的实时数据、录像和停止记录，不能使用本示例充当准入凭据。
