# 仰卧困难初态筛查

[冻结方案](../../../configs/experiments/getup_supine_hard_start_screen.json) · [运行观察](../../getup-hard-start-live.html) · [执行日志](execution.log)
