# 归档起身策略对照

1,024 个场景共用前 2 秒物理跌落。两路固定参照和两份归档自训策略从同一释放状态继续至第 11 秒，保留足部接触、关节限位和原 8 秒前进入 3 秒持稳的判据。本次只评估固定权重。

[运行观察](../../getup-archived-policy-s1160-live.html) · [冻结方案](protocol.json) · [CUDA 零步](../../reports/getup-archived-policy-comparison/s1160/native-zero.json) · [执行日志](execution.log)
