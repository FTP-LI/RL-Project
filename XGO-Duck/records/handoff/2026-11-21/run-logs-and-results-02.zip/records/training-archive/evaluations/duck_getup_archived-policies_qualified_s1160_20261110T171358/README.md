# 归档起身策略同释放对照

四路共享 2 秒物理跌落。初始 CUDA 读回、运行与配对使用同一进程。

[冻结方案](protocol.json) · [运行观察](../../getup-archived-policy-qualified-s1160-live.html) · [执行日志](execution.log)
