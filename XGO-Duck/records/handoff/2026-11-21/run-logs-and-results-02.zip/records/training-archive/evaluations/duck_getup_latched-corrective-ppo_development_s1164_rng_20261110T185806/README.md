# 起身纠正回放评估

[冻结方案](protocol.json) · [运行观察](../../getup-latched-head-corrective-evaluation-rng-live.html) · [日志](execution.log)
