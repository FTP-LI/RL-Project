# 双姿态起身分流评估

[冻结方案](protocol.json) · [运行观察](../../getup-dual-pose-route-live.html) · [日志](execution.log)
