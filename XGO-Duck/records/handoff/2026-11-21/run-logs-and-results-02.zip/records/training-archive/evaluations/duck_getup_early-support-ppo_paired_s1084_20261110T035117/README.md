# 起身早期支撑独立评估

三组共用一次物理释放，按原四姿态门槛评分。

[冻结方案](../../../configs/experiments/getup_early_support_ppo_evaluation.json) · [状态](evaluation.json) · [日志](execution.log)
