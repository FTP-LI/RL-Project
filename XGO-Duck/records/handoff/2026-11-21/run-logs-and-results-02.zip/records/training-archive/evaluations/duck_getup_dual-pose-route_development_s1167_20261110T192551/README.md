# 双姿态起身独立复验

[冻结方案](protocol.json) · [运行观察](../../getup-dual-pose-route-s1167-live.html) · [日志](execution.log)
