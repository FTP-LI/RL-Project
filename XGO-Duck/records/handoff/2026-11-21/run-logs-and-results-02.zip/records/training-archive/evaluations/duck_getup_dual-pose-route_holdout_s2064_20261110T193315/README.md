# 双姿态起身最终留出

[冻结方案](protocol.json) · [运行观察](../../getup-dual-pose-route-holdout-live.html) · [日志](execution.log)
