# 原生奖励读回检查

新种子用于核对实际 CUDA 奖励边界。两路分别启动 3,072 个环境，初态签名逐项一致。候选随后由固定策略完成完整回合，保留原生奖励的乘除时间步顺序和原有严格核对。

| 核验 | 结果 |
| --- | --- |
| 实际采样 | 1,228,800 条转移，2,000 次物理子步 |
| 第 115、125、150 步正奖励 | 50、1,315、1,504 个环境 |
| 奖励窗外 | 第 114、151、400 步均为零 |
| 自然重置 | 3,072 个环境全部清除锁存 |
| 策略与价值网络 | 均保持原值，零更新 |
| 录像 | 8 秒，201 帧，逐帧对应已保存物理状态 |
| Windows 观察 | 16 个运行状态，15 个附真实帧 |

[冻结方案](../../../configs/experiments/getup_early_support_native_reward.json) · [执行日志](candidate.log) · [独立核验](analysis.json) · [运行观察](../../getup-early-support-native-reward-live.html) · [完整原片](../../experiments/duck_getup_early-support-native-reward_development_s1085_20261110T034245/clip-step-0.mp4)
