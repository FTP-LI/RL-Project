# 仰卧困难初态筛查

用同一固定策略比较困难初态、几何匹配的成功初态和原始跌落分布，每组 1,024 个环境。前两组来自 45 对原始跌落状态，同一对施加相同的高度与朝向扰动。三组在 GPU 批次中交错排列。复位仍消费原随机抽样，前两组只替换根部高度和朝向，原分布组保留全部原始抽样。

判据沿用原 8 秒前进入连续 3 秒持稳和回合末端持稳。困难组的失败率须分别高出两组参照至少 5 个百分点，并通过按原始样本对分块的自助法区间与样本覆盖要求，才考虑纳入新训练。四姿态和独立留出各有后续验收。

[初态库](../getup-hard-start-bank/README.md) · [冻结方案](../../../configs/experiments/getup_supine_hard_start_screen.json) · [CUDA 复位零步](native-zero.json) · [运行观察](../../getup-hard-start-live.html)

## 结果

三组释放时均为实际仰卧。困难组的失败率较两组参照分别低 1.37 和 1.56 个百分点。以原始样本对为单位复算的 95% 区间分别为 −3.51 至 +0.68、−3.60 至 +0.39 个百分点。仅 15/45 对的困难初态比匹配初态更容易失败。历史失败无法仅用释放前高度和朝向重现，这批初态不进入新课程。 [独立评分](analysis.json)

| 初态 | 达到完整持稳 | 失败率 | 11 秒原片 |
| --- | ---: | ---: | --- |
| 历史失败初态 | 959/1,024 | 6.35% | [困难组](../../evaluations/duck_getup_hard-start_development_s1159_20261110T165306/evaluation-challenge/clip-step-0.mp4) |
| 匹配成功初态 | 945/1,024 | 7.71% | [匹配组](../../evaluations/duck_getup_hard-start_development_s1159_20261110T165306/evaluation-matched/clip-step-0.mp4) |
| 原始跌落分布 | 943/1,024 | 7.91% | [原分布组](../../evaluations/duck_getup_hard-start_development_s1159_20261110T165306/evaluation-nominal/clip-step-0.mp4) |

3,072 个环境共完成 1,689,600 条转移，采样用时 116.92 秒，约 14,452 条/秒。显存峰值 12,188 MiB，采样 GPU 利用率均值 36.1%。Windows 浏览器观察留档核对了 23 次运行中刷新。 [媒体核验](media-review.json)

## 复现

在工程 WSL 根目录设置 `PYTHONPATH=scripts/training`，用已有 Python 调用 [采样入口](../../../scripts/validation/run_getup_hard_start_screen.py) 的 `freeze`、`zero` 和 `sample`。在采样前运行 [Windows 观察核验](../../../scripts/validation/observe_getup_hard_start_screen.py)，采样设置 `MUJOCO_GL=egl`。采样后调用 [独立评分](../../../scripts/validation/verify_getup_hard_start_screen.py)。
