# 起身 PPO 初态

同一开发种子用 3,072 个并行环境分别启动原奖励和候选奖励。两个独立进程均停在第一步物理之前。两组共享固定策略、76 项价值输入、权重、归一化和 50 步的价值 Adam 状态，策略 Adam 初始为空。唯一区别是早期支撑奖励开关。

| 核验 | 对照 | 候选 |
| --- | --- | --- |
| CUDA 显存峰值 | 11,922 MiB | 11,922 MiB |
| 显存占比 | 72.77% | 72.77% |
| 物理子步 | 0 | 0 |
| 策略和价值更新 | 0 | 0 |

两组的物理坐标、速度、执行器、动作历史、观测、模型、优化器、随机状态及扩展物理字段哈希逐项一致。零步显存低于 85% 上限。PPO 期间继续监控显存与动作保护，完成后仍需独立四姿态评估。

[冻结方案](../../../configs/experiments/getup_early_support_ppo_zero.json) · [零步结果](analysis.json) · [协调日志](coordinator.log) · [对照初态](control/matched-state.json) · [候选初态](candidate/matched-state.json) · [同起点草案](../../../configs/experiments/getup_early_support_ppo_draft.json)
