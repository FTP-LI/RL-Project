# 起身并行规模短测

用同一套固定策略、初始跌落程序、状态快照、离屏录像和压缩轨迹，比较 2,048 与 3,072 个环境。每档最多采样 280 个批量控制步。每段录像 3.2 秒，供核对吞吐和写盘开销。正式起身仍按完整 11 秒和原持稳判据评估。

先核验独立 CUDA 零步和 Windows 观察入口，再采样。以含轨迹写盘的转移速度比较规模，同时记录显存、CPU 时间、进程内存峰值和文件大小。 [冻结方案](../../../../configs/experiments/getup_right_robustness_scale.json) · [新开发草案](../../../../configs/experiments/getup_right_robustness_development_draft.json)

| 并行环境 | 观察 | 执行记录 |
| ---: | --- | --- |
| 2,048 | [进度与原片](../../../getup-right-robustness-scale-2048-live.html) | [冻结输入](n2048/protocol.json) · [CUDA 零步](n2048/zero.log) · [结果](n2048/result.json) |
| 3,072 初次检查 | [停止状态](../../../getup-right-robustness-scale-3072-live.html) | [冻结输入](n3072/protocol.json) · [停止记录](n3072/stopped.json) |
| 3,072 快照复核 | [进度与原片](../../../getup-right-robustness-scale-3072-snapshot-live.html) | [冻结输入](n3072-snapshot-recovery/protocol.json) · [复核范围](../../../../configs/experiments/getup_right_robustness_scale_recovery.json) · [结果](n3072-snapshot-recovery/result.json) |

3,072 个环境的初次检查在物理步为零时停止。完整快照需要 1,175,359,520 字节，超过原 1 GiB 上限。单独冻结一次 1.25 GiB 快照复核，整卡显存上限保持 85%，采样预算和策略保持原值。

## 实测结果

| 环境数 | 转移 | 含录像与写盘用时 | 转移/秒 | 显存峰值 | 进程内存峰值 | 轨迹 |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 2,048 | 573,440 | 62.40 秒 | 9,189 | 9,235 MiB | 3,446 MiB | 362 MiB |
| 3,072 | 860,160 | 77.13 秒 | 11,152 | 13,253 MiB | 3,907 MiB | 543 MiB |

选用 3,072 个环境。含写盘吞吐提高 21.4%，显存峰值占整卡 80.9%。两档 GPU 利用率采样均值分别为 27.3% 和 27.2%。短测覆盖加载后的采样、录像与写盘，保留的 CPU 时间可用于后续定位开销。两档均零学习更新，未使用留出。 [独立核对及选择](selection.json)

Windows 两档分别收到 5 次和 8 次包含真实帧的运行刷新。六段原片各 3.2 秒，文件哈希、81 个时间戳及最终录像状态均核对。下一批开发保留 3,072 个环境，完整采样 11 秒，且在释放后继续前先检查实际右侧样本数。 [新开发草案](../../../../configs/experiments/getup_right_robustness_development_draft.json)
