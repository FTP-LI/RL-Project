# 右侧起身开发评估

双姿态分流在此前最终留出的实际右侧成绩为 69/73，低于 70/73。留出已封存。本轮沿用两路同权参照及候选权重，使用新开发种子，将请求右侧跌倒的环境增至 2,176 个，其余三组分别为俯卧 96、仰卧 672、左侧 128。 [前次最终留出](../../getup-dual-pose-route/holdout/README.md) · [并行规模选择](../scale/README.md)

## 方法

三路从同一跌落释放状态开始。释放时先按躯干重力方向复算实际姿态，实际右侧至少 384 例、每个实际姿态至少 32 例才继续。正式评估持续 11 秒，按及时起身、连续持稳和末段持稳的原判据评分。留出、学习更新和实物操作均为零。 [冻结方案](../../../../configs/experiments/getup_right_robustness_development_s1168.json) · [CPU 核验](freeze.json)

运行页保留进度、吞吐曲线和真实画面，原片使用事前固定镜头。实际右侧回放从首次释放时的最小实际右侧编号生成，选取发生在三路第一步主动控制之前。 [运行观察](../../../getup-right-robustness-development-live.html)

释放检查得到俯卧 96、仰卧 1,951、左侧 65、右侧 960。用三路共用的关节状态复算，3,072 个分类全部一致。运行原片的场景 0 在释放时为仰卧，实际右侧回放使用场景 1。 [释放记录](../../../evaluations/duck_getup_right-robustness_development_s1168_20261110T200128/release-coverage.json) · [CUDA 零步](independent-zero/proof.json)

## 执行记录

采样完成 4,454,400 条转移、7,250 个批量物理子步。含录像和写盘用时 360.47 秒，约 12,357 条转移/秒。整卡显存峰值 13,278 MiB，占整卡 81.0%，GPU 利用率采样均值为 35.2%。Windows 观察通过，30 次运行刷新中有 29 次含真实帧。 [采样日志](sample.log) · [运行观察核验](../../../evaluations/duck_getup_right-robustness_development_s1168_20261110T200128/windows-view-verification.json)

## 评分

| 分组 | 参照 A | 参照 B | 右侧专用策略 |
| --- | ---: | ---: | ---: |
| 全部 | 2,985/3,072 | 2,979/3,072 | 3,010/3,072 |
| 指定俯卧 | 96/96 | 96/96 | 96/96 |
| 指定仰卧 | 651/672 | 653/672 | 651/672 |
| 指定左侧 | 128/128 | 128/128 | 128/128 |
| 指定右侧 | 2,110/2,176 | 2,102/2,176 | 2,135/2,176 |
| 实际俯卧 | 96/96 | 96/96 | 96/96 |
| 实际仰卧 | 1,914/1,951 | 1,915/1,951 | 1,913/1,951 |
| 实际左侧 | 65/65 | 65/65 | 65/65 |
| 实际右侧 | 910/960 | 903/960 | 936/960 |

候选通过所有原门槛，实际右侧为 97.5%，95% Wilson 区间为 96.31%–98.31%。相对参照 A 多通过 39 例、少通过 13 例，净增 26 例。相对参照 B 多通过 44 例、少通过 11 例，净增 33 例。仰卧与右侧分流分别命中 1,951/1,951 和 960/960，均无误选。 [独立评分与区间](analysis.json) · [阶段判定](decision.json) · [释放姿态复核](release-verification.json)

实际右侧中 882 例三路均通过，67 例结果分歧，11 例三路均失败。候选 24 例失败的末段均持续双脚着地、头腿接触且倾角超限。候选失败组最终倾角中位数为 34.29°。下一步用新的独立留出确认，恢复原四组请求姿态的比例，并扩大到 3,072 个环境。 [失败复盘](right-failure-review.json) · [独立留出草案](../../../../configs/experiments/getup_right_robustness_holdout_draft.json)

## 录像

三段运行原片与三段实际右侧回放各 11 秒、276 帧。实际右侧回放使用预先选定的场景 1，保存状态渲染过程中物理步数为零。关键帧对应释放、起身早段、起身截止及持稳终点。 [媒体核验](media-review.json) · [逐帧来源](actual-right-replay/manifest.json)

| 策略 | 运行原片 · 实际仰卧 | 保存状态回放 · 实际右侧 |
| --- | --- | --- |
| 参照 A | [原片](../../../evaluations/duck_getup_right-robustness_development_s1168_20261110T200128/evaluation-reference-a-right-side/clip-step-0.mp4) | [回放](actual-right-replay/reference-a.mp4) |
| 参照 B | [原片](../../../evaluations/duck_getup_right-robustness_development_s1168_20261110T200128/evaluation-reference-b-right-side/clip-step-0.mp4) | [回放](actual-right-replay/reference-b.mp4) |
| 右侧专用策略 | [原片](../../../evaluations/duck_getup_right-robustness_development_s1168_20261110T200128/evaluation-candidate-right-side/clip-step-0.mp4) | [回放](actual-right-replay/candidate.mp4) |

![右侧起身](actual-right-replay/right-side-keyframes.jpg)
