# 四姿态起身独立留出

扩大样本的开发评估通过原门槛，候选在 960 个实际右侧场景中通过 936 例。本轮预留一个新种子，恢复原四组请求比例。3,072 个场景中请求俯卧 288、仰卧 2,016、左侧 384、右侧 384。此前留出仍封存。 [开发评估](../development/README.md) · [冻结方案](../../../../configs/experiments/getup_right_robustness_holdout_s2065.json)

## 方法

三路共用跌落前段和释放快照。首个主动控制前按躯干重力方向核对实际姿态，要求实际右侧至少 128 例，其他三个实际姿态各至少 32 例。每路完整 11 秒，按原规则检查第 8 秒前开始连续持稳及末段持稳，指定姿态、实际姿态及总体均须达到 95%。实际右侧还须相对两路同权参照各净增至少 1 例。 [CPU 场景核验](freeze.json) · [运行观察](../../../getup-right-robustness-holdout-live.html)

首次释放时选取最小的实际右侧场景编号，用于从保存状态重绘完整动作。运行原片的镜头在跌落前固定，实际释放姿态以状态记录为准。

独立 CUDA 零步核对了 335 项状态字段。共同释放时实际俯卧 288、仰卧 2,412、左侧 189、右侧 183，全部满足覆盖条件。用保存关节状态复算，3,072 个标签逐一吻合。运行原片的场景 5 实际释放为仰卧，预先选定的实际右侧回放为场景 8。 [CUDA 零步](independent-zero/proof.json) · [释放记录](../../../evaluations/duck_getup_right-robustness_holdout_s2065_20261110T201715/release-coverage.json)

## 执行记录

三路共采样 4,454,400 条转移，记录 7,250 个批量物理子步和一次初始跌落重置。含录像和写盘用时 358.16 秒，约 12,437 条转移/秒。显存峰值 13,334 MiB，约占整卡 81.4%。Windows 端核验 30 次运行刷新，其中 29 次含真实帧。学习更新为零。 [采样日志](sample.log) · [一次性留出记录](consumption.json) · [Windows 观察核验](../../../evaluations/duck_getup_right-robustness_holdout_s2065_20261110T201715/windows-view-verification.json)

## 独立评分

| 分组 | 参照 A | 参照 B | 双姿态分流 |
| --- | ---: | ---: | ---: |
| 全部 | 2,987/3,072 | 2,988/3,072 | 2,983/3,072 |
| 指定俯卧 | 287/288 | 287/288 | 287/288 |
| 指定仰卧 | 1,945/2,016 | 1,946/2,016 | 1,934/2,016 |
| 指定左侧 | 382/384 | 384/384 | 384/384 |
| 指定右侧 | 373/384 | 371/384 | 378/384 |
| 实际俯卧 | 287/288 | 287/288 | 287/288 |
| 实际仰卧 | 2,336/2,412 | 2,338/2,412 | 2,328/2,412 |
| 实际左侧 | 189/189 | 189/189 | 189/189 |
| 实际右侧 | 175/183 | 174/183 | 179/183 |

候选通过全部原门槛。实际右侧为 97.81%，95% Wilson 区间为 94.52%–99.15%。相对参照 A 多通过 5 例、少通过 1 例，净增 4 例。相对参照 B 多通过 7 例、少通过 2 例，净增 5 例。候选总体少通过 4、5 例，实际仰卧少通过 8、10 例，但仍通过原各分组门槛。实际仰卧 2,412 例和实际右侧 183 例均分流正确。 [评分与区间](analysis.json) · [最终判定](decision.json) · [释放核验](release-verification.json)

起身仿真包包含共同回退、仰卧和右侧三份训练 ONNX 及对应保存点。各用 128 条真实开发观测核对保存点与 ONNX，最大动作差为 1.15×10⁻⁶ rad。官方原件与上游固定归档字节一致。独立留出封存为验收记录。 [仿真交付清单](../../../../artifacts/delivery/getup-simulation.json) · [交付预检](../delivery-preflight.json)

## 录像

三段运行原片与三段实际右侧回放均为 11 秒、276 帧。原片场景 5 在释放时实际仰卧。实际右侧回放使用在首个主动控制前选定的场景 8，从保存状态渲染，物理步数为零。 [媒体核验](media-review.json) · [逐帧来源](actual-right-replay/manifest.json)

| 策略 | 运行原片 · 实际仰卧 | 保存状态回放 · 实际右侧 |
| --- | --- | --- |
| 参照 A | [原片](../../../evaluations/duck_getup_right-robustness_holdout_s2065_20261110T201715/evaluation-reference-a-right-side/clip-step-0.mp4) | [回放](actual-right-replay/reference-a.mp4) |
| 参照 B | [原片](../../../evaluations/duck_getup_right-robustness_holdout_s2065_20261110T201715/evaluation-reference-b-right-side/clip-step-0.mp4) | [回放](actual-right-replay/reference-b.mp4) |
| 双姿态分流 | [原片](../../../evaluations/duck_getup_right-robustness_holdout_s2065_20261110T201715/evaluation-candidate-right-side/clip-step-0.mp4) | [回放](actual-right-replay/candidate.mp4) |

![右侧起身](actual-right-replay/right-side-keyframes.jpg)
