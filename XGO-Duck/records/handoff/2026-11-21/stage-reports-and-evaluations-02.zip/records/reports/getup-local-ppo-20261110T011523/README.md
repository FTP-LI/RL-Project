# 本机起身 PPO 对照

同一父检查点、继承的 actor 与 critic Adam 状态、自适应成功回放、四种初始姿态和原控制接口。先跑 3,072 环境，再跑 1,536 环境。两组均采样 1,253,376 条转移，计划各完成 3,072 个 400 步回合。小批量固定为 3,072 条转移，每次收集 24 步，训练五轮。两组分别做 17 和 34 次更新，最多各 2,040 次名义小批量更新。

每次更新从全体成功观测中重新选择偏差最大的状态和关节。沿用整体 RMS 0.05 rad、单关节 0.25 rad 上限以及 85% 整卡显存筛选线。记录真实环境平均奖励、策略和价值损失、优化耗时、累计净吞吐和原片。净吞吐包含采样、录像和记录开销，区分于固定策略采样短测。

[冻结方案](../../../configs/experiments/local_getup_ppo.json) · [在线入口复算](../getup-success-step-control/adaptive-ppo-entry-parity.json) · [协调记录](coordinator.json) · [运行观察](../../training-live.html)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
flock -n "$HOME/XGO-Duck/training.lock" "$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python" \
  -B scripts/validation/run_local_getup_ppo.py
```

每个冻结批次只有一次执行。任一组触发守卫、技术错误或预算上限时保留现场，不自动重跑。整组采集完成后再独立核验训练轨迹、检查点、导出一致性及动作门槛。

## 训练观察

3,072 环境已经完成 17 次更新，采集 1,253,376 条转移，用时 165.71 秒。其中优化更新计时 72.15 秒，整卡显存观测峰值 12,637 MiB。Windows 进程在训练期间读到 17 次有效页面更新，最后一次已附完整 8 秒原片。页面数据和原片文件已核验。 [逐次更新](../../experiments/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/observation.json) · [运行中核验](../../experiments/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/windows-view-verification.json) · [训练原片](../../experiments/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/clip-step-0.mp4)

| 环境数 | 完整更新 | 完整回合 | 全程耗时（秒） | PPO 耗时（秒） | 整卡显存峰值（MiB） |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1,536 | 34 | 3,072 | 172.33 | 57.35 | 7,357 |
| 3,072 | 17 | 3,072 | 165.71 | 72.15 | 12,637 |

两组实际采样都含 921,600 条策略参与样本和 153,600 条末段持稳样本。本次训练全程净吞吐分别为 7,273 和 7,564 转移/秒，较大规模高约 4%。两组优化更新边界与策略梯度步数略有差异，实测分别为 1,573 和 1,560 步。动作验收使用新种子和相同起身门槛。 [1,536 环境更新](../../experiments/duck_getup_adaptive-scale_control_s3063_20261110T011523/observation.json) · [1,536 环境原片](../../experiments/duck_getup_adaptive-scale_control_s3063_20261110T011523/clip-step-0.mp4)

本轮保存的候选权重可用于复现结果。 [1,536 环境 ONNX](../../../artifacts/duck_getup_adaptive-scale_control_s3063_20261110T011523/policy.onnx) · [检查点](../../experiments/duck_getup_adaptive-scale_control_s3063_20261110T011523/model-final.pt) · [3,072 环境 ONNX](../../../artifacts/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/policy.onnx) · [检查点](../../experiments/duck_getup_adaptive-scale_throughput_s3063_20261110T011523/model-final.pt)

## 动作复核

两组训练原片各 201 帧，和保存姿态逐帧对应。独立核验还检查了父权重、Adam 状态、真实更新数和导出的 224 组动作。新种子 1061 从同一跌倒状态依次运行固定父模型、1,536 和 3,072 环境产出的策略。沿用原及时起身、末段持稳和分姿态门槛。 [训练核验](training-verification.json) · [评价冻结方案](../../../configs/experiments/local_getup_ppo_evaluation.json) · [CPU 准入](evaluation-preflight.json) · [动作运行日志](evaluation-execution.log)

训练验收时从项目根目录执行以下只读核验。评价通过同一 WSL 锁运行，伪终端满足旧采集器的终端检测，指标和原片保存在评价批次目录。

```bash
source scripts/setup/project_environment.sh
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
"$PY" -B scripts/validation/verify_local_getup_ppo.py
"$PY" -B scripts/validation/evaluate_local_getup_ppo.py --freeze
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
  "$PY -B scripts/validation/evaluate_local_getup_ppo.py" /dev/null
"$PY" -B scripts/validation/evaluate_local_getup_ppo.py --verify
```

| 策略 | 综合成功 | 实际仰卧 | 指定仰卧 | 实际右侧 |
| --- | ---: | ---: | ---: | ---: |
| 固定父模型 | 312/320 | 176/180 | 31/32 | 45/49 |
| 1,536 环境训练 | 303/320 | 167/180 | 28/32 | 46/49 |
| 3,072 环境训练 | 306/320 | 166/180 | 26/32 | 49/49 |

三组共 464,000 条评价转移、7,250 个批量物理子步、零学习。三组释放状态逐项相同，12 段 11 秒原片已逐帧核对。两组新模型未通过分姿态门槛。3,072 环境模型在实际右侧达到 49/49，但实际和指定仰卧均低于门槛，整体也低于固定父模型。未使用最终留出，两组权重作为研究记录保留。 [独立评分与原片索引](evaluation-analysis.json)

同次释放复算定位到 8 个固定父模型成功、两组新模型均失败的实际仰卧场景。第 3 秒倾角中位数为固定父模型 2.76°、1,536 环境 33.68°、3,072 环境 33.25°。两组新模型均有 8/8 末段头腿接触，父模型为 0/8。3,072 环境模型另挽回了固定父模型失败的全部 4 个实际右侧场景。下一步比较第 2.3 到 3.0 秒的转正与支撑，按姿态分别查动作差异。 [保存轨迹复算](paired-regression-review.json)

对保存轨迹做姿态分流复算。释放时先归一化首个带噪声的重力观测；判为右侧时用 3,072 环境模型，其余使用固定父模型。49 个右侧样本均分流正确，组合为 316/320，及时起身与末段持稳均达到原分组门槛。规则由本批结果提出，必须在新场景中实际运行后再判断。 首次只读检查把带噪声的观测当作单位向量，触发断言。原配置为每轴加性噪声，改用归一化方向并保留原姿态阈值。 [轨迹分流复算](posthoc-pose-routing.json) · [原始中止日志](posthoc-pose-routing.log) · [修正后日志](posthoc-pose-routing-normalized.log)
