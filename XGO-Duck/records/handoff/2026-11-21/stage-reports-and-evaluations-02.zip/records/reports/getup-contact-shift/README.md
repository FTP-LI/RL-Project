# 接触后髋膝协同

开发种子 1055 共完成 89,984 条实际转移、7,030 个物理子步和三段完整 11 秒原片，学习更新为 0。两次官方对照和候选分别持稳 54/64、57/64、57/64。34 个环境的触发时点一致并收到候选修正。候选在触发后 0.50 秒的倾角中位收益为 −0.16°，低于 5° 门槛。两次官方均失败的样本中，候选恢复 3 个。两次官方均成功的样本中，候选退化 3 个。两次官方之间本身有 5 个判定分歧。该方案关闭，继续条件未通过。 [逐环境核验](analysis.json)

首次头腿接触涉及右脚、实际释放为仰卧时，候选在接触后第 3 至第 7 个控制步把右髋俯仰目标上调、右膝目标下调，各最多 0.08 rad。两条原始目标合法时才应用，再按原限位截断。其余目标、官方权重和原始动作历史保留。三个分支在最早触发前共用物理轨迹，分支起点的 345 项状态字段及首个策略输入、动作、目标和电机命令逐位一致。之后各分支独立演化。 [冻结协议](../../../configs/experiments/getup_contact_shift.json) · [CPU 零步](preflight.json) · [运行记录](coordinator.json)

## 原片

预设相机环境 0 在第 2.48 秒触发。两次官方均未达到持稳标准，候选从第 2.86 秒进入连续持稳，并通过最后三秒的持稳检查。每段 276 帧、25 fps，覆盖 0–11 秒，已核对解码和物理状态来源。 [标注关键帧](../../../docs/reports/assets/getup-contact-shift-frames.jpg) · [帧来源](frame-review.json)

- [官方一](../../evaluations/duck_getup_contact-shift_paired_s1055_20261109T192009/evaluation-reference-a/clip-step-0.mp4)
- [官方二](../../evaluations/duck_getup_contact-shift_paired_s1055_20261109T192009/evaluation-reference-b/clip-step-0.mp4)
- [髋膝候选](../../evaluations/duck_getup_contact-shift_paired_s1055_20261109T192009/evaluation-hip-knee-shift/clip-step-0.mp4)

## 操作记录

采集在原 VS Code 共享任务终端启动。置前工具短暂把窗口恢复到 1202×802，启动前回到原 1707×1019。运行和截图均在该尺寸下。一次性任务已归档。 [运行截图](../../../docs/reports/assets/getup-contact-shift-terminal.jpg)

```bash
cd ~/XGO-Duck/workspace/xgoduck_rl
XGO_PROJECT=/mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source "$XGO_PROJECT/scripts/setup/project_environment.sh"
# 仅作为原执行记录。已关闭的协议不重复采样。
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/getup_contact_shift.py" --freeze
bash "$XGO_PROJECT/scripts/training/training_workflow.sh" getup-contact-shift
# 从已保存的真实录像提取关键帧。
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/render_getup_contact_shift_frames.py"
```
