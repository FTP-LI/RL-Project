# 起身监控开销对照

两组均已完成并通过保存数据核验。按每组 1,253,376 条转移计算，训练过程总耗时由 172.19 秒降至 133.13 秒，对应吞吐提高 **29.3%**。这是间隔约三小时的单次顺序对照，系统负载和温度可能不同，不能单独证明稳定收益或动作改善。[对照数据](comparison.json) · [独立复算](independent-summary-readback.json) · [恢复前归档](../pause-archive-20261116-monitored/README.md) · [恢复准入](resume-preflight.json)

改动为：完整文件检查由独立线程执行，每轮检查后等待 0.1 秒，训练回调拒绝超过 0.5 秒未更新的结果；初始化和外层进程监督继续同步检查。此方案改变了检查时序，不再声称每次回调都重新读取全部文件。11 项 CPU 故障检查通过；本次候选实际运行的监控未报告故障，但尚需在不同负载下重复验证。[监控记录](training/throughput/authorization-monitor.json) · [实现与注释](../../../scripts/training/monitored_ppo_authorization.py)

两组共用父保存点、种子 3266、3,072 环境，每组 17 次更新、1,253,376 条转移，控制步 408、物理子步 2,040。奖励、学习率、模型和录像规则一致。单次内部 900 秒、外部 1,100 秒封顶，不自动重试或延长，协议原字节保留。诊断模型暂不晋级，后续动作评价与性能测量分开。

两组实际 CUDA 零步和保存点复核通过：12 组已保存初态数组、网络、优化器和随机状态一致，123 份冻结来源保持原字节。两组训练过程均可在 VS Code 本地观察；最终文件和完整 8 秒录像已保留。截图按原片采样，没有为拍摄增加物理步。

| 指标 | 同步检查组 | 监控候选组 |
| --- | ---: | ---: |
| 更新与转移 | 17 次、1,253,376 条 | 17 次、1,253,376 条 |
| 训练过程总耗时 | 172.19 秒 | 133.13 秒 |
| 训练过程吞吐 | 7,279 条/秒 | 9,415 条/秒 |
| 检查回调，均为 2,075 次 | 34.18 秒 | 0.93 秒 |
| 环境控制步，均为 408 次 | 57.83 秒 | 56.87 秒 |
| GPU 利用率中位数 | 35% | 45% |
| 显存峰值 | 12,577 MiB | 12,502 MiB |
| 训练末次完整回合持稳 | 96.16% | 96.48% |
| ONNX 最大绝对误差 | 1.01×10⁻⁶ | 1.19×10⁻⁶ |

总耗时包含初始化、导出与收尾，减少 39.06 秒；外层进程耗时分别为 232.19 和 203.20 秒，还包括启动与观察确认等待，不能混作训练吞吐。候选监控线程另进行了 1,018 次完整检查，累计墙钟 20.67 秒、线程 CPU 4.12 秒，与主线程并行；最长单次检查 0.067 秒，没有记录故障。环境控制步、检查回调及其他计时可能嵌套，不能直接相加，也不代表纯 CUDA 内核耗时。下一步应继续分析环境控制步和同步等待，不能只看显存占用率。

训练内持稳比例不是最终策略的独立成功率。前 32 个环境的首控制步前输入、原始动作和下发目标一致，但首步后位置最大差约 4.47×10⁻⁸、速度约 8.56×10⁻⁸；两份最终网络对同一组保存观测的动作输出最大差为 0.0601。未记录全部物理内部状态，不能将差异唯一归因于某一项。最新权重均只供诊断，不替换交付模型。[同步组核验](training/control/independent-verification.json) · [候选组核验](training/throughput/independent-verification.json) · [完整数值对照](comparison.json)

![起身训练关键帧](training-key-frames.jpg)

关键帧为两组训练时各自环境 0 的 0、2、4、6、8 秒，完整录像各解码 201 帧；不能据一个环境推断总体动作质量。[原片与截图来源](training-key-frames.json) · [同步组视频](../../experiments/duck_getup_auth-sync_e3072_s3266_20261116T095241/clip-step-0.mp4) · [候选组视频](../../experiments/duck_getup_auth-monitor_e3072_s3266_20261116T095241/clip-step-0.mp4)

[同步组曲线](training/control/final-view/native-curve.png) · [候选组曲线](training/throughput/final-view/native-curve.png) · [候选运行中截图](training/throughput/progress-mid-run.png) · [候选保存点](../../experiments/duck_getup_auth-monitor_e3072_s3266_20261116T095241/model-final.pt) · [候选 ONNX](../../../artifacts/duck_getup_auth-monitor_e3072_s3266_20261116T095241/policy.onnx)

本轮[资料快照](stage-snapshot.zip)保存协议、源码、指标、日志、截图和报告；大模型、轨迹与视频保留在原路径，由[外部文件清单](stage-external-assets.json)登记。快照须与工程目录一起保存；[归档校验](stage-verification.json)记录解压和哈希检查。

[训练草案](../../../configs/experiments/observed_getup_monitor_draft_20261116.json) · [零步方案](../../../configs/experiments/observed_getup_monitor_zero_20261116.json) · [CPU 检查与依据](../getup-runtime-review-20261116/README.md) · [入口与修改注释](../../../scripts/training/observed_getup_monitor_entry.py)

[实际零步复核](zero-verification.json) · [冻结训练协议](../../../configs/experiments/observed_getup_monitor_pair_20261116.json) · [最终同步组状态](training/control/final-view/native-status.txt) · [运行日志](training/control/execution.log)
