# 仰卧早期转正筛查

在第 2.44、2.50、2.56 秒比较倾角变化、质心和头部几何。仅使用种子 1084、1087 选择一个时间、量和阈值。筛查要求失败至少提前 60 毫秒被识别，且每批误触发率不超过 5%。 [冻结方案](../../../configs/experiments/getup_supine_early_geometry_screen.json) · [逐场景数据与规则比较](analysis.json)

保留的规则在仿真时钟第 2.44 秒读取最近 40 毫秒倾角变化。下降不足约 14.15°时触发。两批参考分别识别 4/5、6/7 个有足够提前量的失败。随后在开发种子 1102 原样应用，识别 5/6 个失败，触发 6/171 个原成功场景。质心相关候选和其余时点一并保存在复算输出中。

这些结果来自保存轨迹，物理步和学习更新均为零。触发之后能否改变起身结果须用新的动态配对验证。 [上游时序复算](../getup-supine-support-timing/README.md)

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- env PYTHONPATH=scripts/validation:scripts/training /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/screen_getup_supine_early_geometry.py
```
