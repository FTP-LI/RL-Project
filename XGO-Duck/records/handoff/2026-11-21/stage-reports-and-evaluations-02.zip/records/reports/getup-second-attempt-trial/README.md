# 同回合二次起身

从同一次仿真初始状态运行到第 160 步，再比较两路原策略与一路短程回撤。每路保留原 11 秒回合、四姿态覆盖、及时起身与终点持稳门槛。两路参照都复算触发时点，提供固定策略本身的波动范围。 [冻结方案](../../../configs/experiments/getup_supine_second_attempt_trial.json) · [原生零步](../getup-second-attempt-native/README.md) · [运行观察](../../getup-second-attempt-live.html)

候选一次回撤最多 40 个控制周期。颈部目标到原下限内侧 0.15 rad，其余关节趋近原起始目标，每步不超过 0.04 rad。原策略的观测和动作历史继续更新。回撤结束后按相同限速接回原策略。只有颈部实际退离达到 0.08 rad、最后五个控制点保持安静仰卧，且随后按原要求持稳，才计为有效二次起身。

## 实测结果

| 分支 | 总体及时且终点持稳 | 实际仰卧持稳 | 指定仰卧持稳 |
| --- | ---: | ---: | ---: |
| 原策略 A | 724/768 | 578/617 | 506/544 |
| 原策略 B | 724/768 | 578/617 | 506/544 |
| 短程回撤 | 723/768 | 577/617 | 505/544 |

38 个场景在三路同一时点触发，两路原策略均失败。短程回撤没有挽回这些场景，也没有触发其他姿态。回撤末端实际颈部退离的中位数和最大值为 0.0060、0.0113 rad，均低于 0.08 rad，安静仰卧确认和有效二次起身均为 0。候选关闭。 [独立评分](analysis.json)

复算发现，目标相对实测颈角至少向内 0.02 rad 的第一时点，中位数是回撤开始后的 0.62 秒。40 个周期中位数仅有 9 个满足这个条件，回撤末端的躯干倾角中位数为 34.6°。31/38 个场景在最后五个控制点持续头腿接触。随后 0.4 秒内，38 个场景的颈部位移曾达到 0.08 rad。 [目标、位移与接触复算](contact-readback.json)

在此 0.4 秒内，2/38 个场景连续五个控制点没有头腿接触，其中只有 1 个与实际颈部退离同时出现。直到原 8 秒截止，真实躯干姿态和策略观测均没有确认安静仰卧。接触来自原生布尔传感读数。该时序未达到延长回撤的准入条件，后续转向原始跌落初态课程。 [迟到运动协议](../../../configs/experiments/getup_supine_second_attempt_late_motion.json) · [逐场景复算](late-motion.json)

三路共 1,021,440 条转移，用时 163.10 秒，约 6,263 条转移/秒。显存峰值 4,552 MiB，GPU 利用率采样均值约 31%。Windows 独立读取 56 次运行中状态和真实画面。预选环境 0 的三段原片各为 11 秒、276 帧。另从保存状态回放共同失败场景 86。 [运行记录](../../evaluations/duck_getup_second-attempt_paired_s1157_20261110T163238/README.md) · [GPU 采样](../../evaluations/duck_getup_second-attempt_paired_s1157_20261110T163238/gpu-telemetry.json)

![场景 86 关键帧](matched-keyframes.jpg)

[场景 86 原策略 A 回放](replay-reference-a.mp4) · [原策略 B 回放](replay-reference-b.mp4) · [短程回撤回放](replay-neck-retreat.mp4) · [回放核验](replay.json)

[原片 A](../../evaluations/duck_getup_second-attempt_paired_s1157_20261110T163238/evaluation-reference-a-supine/clip-step-0.mp4) · [原片 B](../../evaluations/duck_getup_second-attempt_paired_s1157_20261110T163238/evaluation-reference-b-supine/clip-step-0.mp4) · [原片短程回撤](../../evaluations/duck_getup_second-attempt_paired_s1157_20261110T163238/evaluation-neck-retreat-supine/clip-step-0.mp4)

## 复现

使用工程 WSL 环境设置 `PYTHONPATH=scripts/training`。先调用 [采样入口](../../../scripts/validation/run_getup_second_attempt_trial.py) 的 `freeze`，启动 [Windows 观察核验](../../../scripts/validation/observe_getup_second_attempt_trial.py)，再调用 `sample`，另设 `MUJOCO_GL=egl`。完成后调用 [独立评分](../../../scripts/validation/verify_getup_second_attempt_trial.py)，并使用 `--replay` 从已有姿态渲染同一触发场景。
