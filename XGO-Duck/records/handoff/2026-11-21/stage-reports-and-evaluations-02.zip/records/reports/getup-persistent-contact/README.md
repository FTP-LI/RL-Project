# 起身持续接触

| 内容 | 入口 |
| --- | --- |
| 旧评估时长分布 | [960条轨迹](../getup-teacher-anchor-pair/contact-duration/analysis.json) |
| 计时和接口预检 | [CPU组件](component-preflight.json) · [共同价值协议](../../../configs/experiments/getup_persistent_value.json) |
| 固定策略价值采样 | [状态](value/progress.json) · [原核验失败](value/original-verification-failure.json) · [CPU复核](value/cpu-reciprocal-review/analysis.json) |
| 原片及关键帧 | [完整8秒](../../experiments/duck_getup_contact-duration-value_reference_s44_20261103T160850/clip-step-0.mp4) · [关键帧](../../../docs/reports/assets/getup-persistent-value-sequence.jpg) |
| 实际优化器克隆 | [CPU预检](ppo-preflight.json) |
| 新策略对照 | [协议](../../../configs/experiments/getup_persistent_contact_pair.json) · [冻结核对](pair/preflight.json) · [GPU零步](pair/zero-step/verification.json) · [关闭记录](pair/coordinator.json) |
| 独立结果 | [三组成绩](pair/analysis.json) · [保存轨迹复核](pair/saved-data-review.json) · [图表核验](pair/figure-review.json) |
| 中间点清理 | [清单](pair/unused-checkpoint-cleanup-plan.json) · [结果](pair/unused-checkpoint-cleanup-result.json) |

共同价值记录为固定策略的数据与critic拟合。新策略对照从该critic和官方actor出发，训练入口为原VS Code窗口的“XGO-Duck · 起身持续接触成对训练与评估”，内部由 `training_workflow.sh getup-persistent-contact-pair` 分发。任务使用共享终端并持有工程锁。GPU两组零步核对通过后，才允许进入固定预算学习。

准备阶段在已安装环境中运行以下命令。冻结命令只在协议尚未存在时使用，已经关闭的采集保留原记录。

```bash
XGO_ROOT=/mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
.venv/bin/python -B "$XGO_ROOT/scripts/validation/getup_persistent_contact_pair.py" --freeze
```

两组各50次训练，候选289/320，低于原奖励294/320和总体门槛304/320。后续查明释放状态差异。只读复算使用 `scripts/validation/review_getup_persistent_contact_pair.py`。
