# 姿态分流起身

释放后的首个策略观测提供带噪声的重力方向。归一化后按原 0.75 对齐阈值判断，右侧使用已核验的 3,072 环境 ONNX，其余姿态和无效重力向量使用固定父模型。每次恢复只判定一次，显式开启新回合时重新判断。动作历史、碰撞、时长及及时起身和末段持稳门槛沿用前一批。

每批 320 个场景，三组策略共用 100 步跌倒前缀和释放状态。每支策略跑至第 550 步，三支累计 464,000 条转移、7,250 个批量物理子步、零学习。分流需同时通过原总体及分组门槛，且综合成功数不低于任一纯策略，才继续第二个开发种子。最终留出单独保留。

CPU 复查复现旧批次 49 个右侧分流、验证观测改变后锁定保持、显式重置后重新判定。1062 和 1063 的场景快照均通过 CPU 零步。 [冻结方案](../../../configs/experiments/getup_pose_router.json) · [准入证据](preflight.json) · [运行观察页](../../getup-routing-live.html)

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
export MUJOCO_GL=egl GALLIUM_DRIVER=d3d12 MESA_D3D12_DEFAULT_ADAPTER_NAME=NVIDIA
PY="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command \
  "$PY -B scripts/validation/evaluate_getup_pose_router.py --sample 1062" /dev/null
"$PY" -B scripts/validation/evaluate_getup_pose_router.py --verify 1062
```

每个冻结批次只运行一次。1062 通过后，才用同样入口执行已冻结的 1063。

## 开发结果

1062 实际采集 464,000 条转移。固定父模型 305/320、右侧专用模型 306/320、分流 313/320。分流的实际仰卧为 161/168、指定仰卧 31/32、实际右侧 54/54、指定右侧 122/128，均通过原门槛。重力分流与物理实际右侧分类一致，保存的 144,000 条分流动作输入逐条复算通过。六段 11 秒原片均已核验。 [独立评分与原片](seed1062-analysis.json) · [运行中核验](../../evaluations/duck_getup_pose-route_paired_s1062_20261110T013820/windows-view-verification.json)

独立留出预留种子 2062。仅在 1062、1063 都通过后冻结并实际运行，门槛沿用本批，不以留出结果调参。

1063 的固定父模型为 313/320，右侧专用模型 310/320，分流 316/320。分流的实际仰卧 175/178、指定仰卧 31/32、实际右侧 57/57、指定右侧 127/128。两批实际右侧均完全通过，合计 111/111。两批均通过及时与末段持稳门槛，并分别复算 144,000 条分流动作。 [1063 评分与原片](seed1063-analysis.json) · [实际右侧原片](../../evaluations/duck_getup_pose-route_paired_s1063_20261110T013820/evaluation-pose-routed-right-side/clip-step-0.mp4)

## 独立留出

2062 只运行一次，采集 464,000 条转移并保存六段 11 秒原片。固定父模型 311/320、右侧专用模型 311/320、分流 314/320。55 个实际右侧均正确分流，持稳 54/55；实际仰卧 162/167，达到原门槛。指定仰卧为 30/32，及时起身和末段持稳均低于 31/32 的要求。组合因此未晋级。留出已使用，结果保留。 [留出协议](../../../configs/experiments/getup_pose_router_holdout.json) · [评分与原片](heldout/seed2062-analysis.json) · [执行日志](heldout/execution.log)

只用两份开发轨迹逐场景比较分流与所选纯策略。两批首个输入和动作各 320/320 完全一致，首步后的位姿仅 44/320 和 49/320 逐值相同。1062 有 1 例仅分流成功；1063 有 4 例仅分流成功、3 例仅纯策略成功。保留实际分流成绩。复算未使用留出，状态差异的来源尚待定位。 [开发轨迹一致性](development-fork-consistency.json)

两批开发的 346 个实际仰卧中，分流共有 10 个失败。4 个在三个分支均失败；5 个在纯右侧专用分支成功，2 个在纯父模型分支成功，后两项有 1 个重合。分支在相同首个控制后出现物理分歧，保留这些编号供后续核验。10 个分流失败在第 3 秒倾角中位约 33°，全部失去及时与末段持稳。下一批训练先检查第 2.3–3.0 秒转正与支撑。 [仰卧复算](development-supine-gap.json)
