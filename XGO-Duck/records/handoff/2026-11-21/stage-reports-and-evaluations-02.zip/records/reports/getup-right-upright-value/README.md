# 右侧起身价值覆盖检查

本批固定策略使用新种子采集 1,024 个完整 8 秒回合，共 409,600 条转移。对照和候选来自同一物理轨迹，候选奖励系数为 10。释放观测与物理判定一致，90 维价值输入的状态历史、回报和接触在保存数据上独立复算。

冻结分组得到 6 个训练触发场景和 8 个验证触发场景。训练覆盖低于预设的 8 个，因此在价值拟合前停止，价值和策略均为零更新。原样保留这批分组、全部回合和录像。GPU 显存峰值为 5,236 MiB。Windows 读到 17 次运行中原始画面。 [独立核验](analysis.json) · [方案](../../../configs/experiments/getup_right_upright_value.json) · [运行观察](../../getup-right-upright-value-live.html) · [8 秒原片](../../experiments/duck_getup_right-upright-value_development_s1099_20261110T061708/clip-step-0.mp4)

独立新种子扩展到 3,072 个场景，分别预留训练、验证和复算的触发样本。新批次已通过价值准入。 [扩展价值结果](../getup-right-upright-value-coverage/README.md)
