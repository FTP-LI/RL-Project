# 仰卧支撑伸膝诊断

| 内容 | 入口 |
| --- | --- |
| 设计与阈值 | [草案](../../../configs/experiments/getup_knee_support_draft.json) |
| 早期姿态与关节目标 | [两批开发轨迹](../getup-shared-release/fixed-terrain/supine-support-review.json) |
| 触发筛查 | [逐环境触发和限位](preflight.json) |
| CPU 目标通路 | [原始动作、膝目标和执行器](target-path.json) |
| 首次同状态筛查 | [冻结协议](../../../configs/experiments/getup_knee_support_screen.json) · [CPU 采集预检](screen/acquisition-preflight.json) · [实际 GPU 零步停止](screen/zero-step-stop.json) |
| 供电验证 | [CPU 读回](supply-cpu/readback.json) · [新协议](../../../configs/experiments/getup_knee_support_supply_recovery.json) |
| 三路结果 | [独立复算](supply-recovery/analysis.json) · [逐时点复算](supply-recovery/motion-review.json) · [关键帧](../../../docs/reports/assets/getup-knee-screen-trigger-frames.jpg) |
| 11 秒原片 | [官方一](../../evaluations/duck_getup_knee-support-supply_fixed_s1054_20261109T182915/evaluation-reference-a/clip-step-0.mp4) · [官方二](../../evaluations/duck_getup_knee-support-supply_fixed_s1054_20261109T182915/evaluation-reference-b/clip-step-0.mp4) · [候选](../../evaluations/duck_getup_knee-support-supply_fixed_s1054_20261109T182915/evaluation-knee-pulse/clip-step-0.mp4) |

两批共 1,039 次实际仰卧。失败 163 次，触发 151 次。成功 876 次，触发 4 次。其他释放姿态触发为 0。两组的原始动作、观察和权重使用共同接口。候选只在第 2 秒释放后的早期支撑阶段，对左右膝目标叠加一次逐步上升和撤回的偏移。目标已越出模型硬限位时保留原请求。

```bash
cd ~/XGO-Duck/workspace/xgoduck_rl
XGO_PROJECT=/mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source "$XGO_PROJECT/scripts/setup/project_environment.sh"
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/review_getup_supine_support.py"
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/check_getup_knee_support.py"
.venv/bin/python -B "$XGO_PROJECT/scripts/validation/check_getup_knee_target_path.py"
```

前两条命令读取已关闭试验的保存轨迹。第三条初始化 CPU 场景并复查动作管理器、关节目标和执行器写入，积分为 0。seed1054 同状态仿真已经完成。首次触发的两例中，膝电机收到指令，候选在 0.50 秒后仍有头腿接触。实际收到脉冲的七例均未持稳，候选未通过继续条件。三段原片来自未触发的相机环境 0。环境 31 的对照图来自保存状态，原成绩按全样本复算。可见执行命令见[过程记录](../../../docs/reports/development_history.md)。
