# 起身早期解困

本轮已关闭，零学习、640个首次episode、352000个评价转移。官方原样对照291/320，候选296/320；原及时持稳与末段持稳门槛均未通过，不追加。当前不部署真机。

| 文件 | 用途 |
| --- | --- |
| [冻结协议](../../../configs/experiments/getup_early_guard_study.json) | 新seed1017、唯一启用开关、预算、原评分与停止条件 |
| [CPU检查](preflight.json) | 83份来源、真实处理器、冻结与重置边界 |
| [对照复核](control-analysis.json) | 官方权重、完整11秒、320个首次episode |
| [候选复核](candidate-analysis.json) | 提前识别持续卡住并修正颈部目标 |
| [总结果](analysis.json) | 功能判定、实际预算与关闭结论 |
| [全样本复盘](mechanism-review.json) | 触发、末段接触、失败姿态与配对编号差异 |
| [触发个案选择](replay-selection.json) | 5秒前触发的最小环境编号，不按成功选择 |
| [完整状态回放](replay/verification.json) | 环境2，两段11秒、无插值、零新增物理步 |
| [事件关键帧](event-frame-review.json) | 2.88秒触发、2.96秒修正峰值；只解码已有录像 |
| [实际播放截图](replay/vscode-complete-playback.jpg) | 原VS Code完整播放到11秒，布局未变 |

代码开头说明了修改及原因：[识别与修正](../../../scripts/training/getup_early_guard.py)、[控制器](../../../scripts/training/getup_early_guard_controller.py)、[可见协调器](../../../scripts/validation/getup_early_guard_study.py)。触发只读取姿态、颈角/角速度、原目标和时钟，不读取仿真接触或高度。16个过去和当前观测点覆盖0.30秒，避免把短暂借力直接判成卡住。

[早期960次轨迹审计](../getup-early-support/analysis.json)和[保存观测筛查](../getup-early-support/guard-screen.json)属于开发诊断，不是新干预结果。实际候选触发29次，其中7次最终持稳、22次未持稳；候选全部24个失败均无末段头腿接触，倾角中位仍约31°。请求/修正、原始动作历史、两模型推理和完整录像已独立重建。

预选仰卧环境10的两段原片都没有触发规则；[普通起身时间轴](../../../docs/reports/assets/getup-early-guard-sequence.jpg)因此只展示原始完整过程。[触发个案回放](../../../docs/reports/assets/getup-early-guard-active-case.jpg)另行标注来源；[事件关键帧](../../../docs/reports/assets/getup-early-guard-events.jpg)补取实际修正时刻，避免3秒、4秒截图漏掉短暂动作。环境2对照失败、候选成功；冻结期首步已有数值分歧，个例不作逐场景因果证明。

已结束任务不能重复执行。只复核保存数据，可在既有VS Code的WSL终端运行：

```bash
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_early_guard_study.py --verify control
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_early_guard_study.py --verify candidate
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/review_getup_early_guard.py
```

完整环境、修改与结果见[主报告](../../../docs/reports/development_report.md)第7.7.12节。可靠起身、独立滚翻确认、连续技能与扰动仍须后续完成。
