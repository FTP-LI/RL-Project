# 起身纠正回放评估

1,024 个新场景使用同一释放快照。两路固定参照在实际仰卧时使用训练起点，训练对照和纠正候选分别使用各自导出模型。四路的其他姿态均使用同一回退模型。四路释放快照的 345 项状态一致，实际仰卧 812/812 进入相应分支，其他姿态零误选。首次零步后的额外实测发现独立模型导入会改写 CUDA 随机状态，因此只用带随机状态保护的入口采样。 [冻结方案](../../../../../configs/experiments/getup_latched_head_corrective_evaluation_s1164_rng.json) · [原生零步](independent-zero/proof.json) · [导入检查](../import-rng-proof.json)

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 实际右侧 | 原片 |
| --- | ---: | ---: | ---: | ---: | --- |
| 固定参照 A | 984/1,024 | 637/672 | 775/812 | 50/53 | [原片](../../../../evaluations/duck_getup_latched-corrective-ppo_development_s1164_rng_20261110T185806/evaluation-reference-a-supine/clip-step-0.mp4) |
| 固定参照 B | 984/1,024 | 640/672 | 776/812 | 49/53 | [原片](../../../../evaluations/duck_getup_latched-corrective-ppo_development_s1164_rng_20261110T185806/evaluation-reference-b-supine/clip-step-0.mp4) |
| 训练对照 | 1,001/1,024 | 655/672 | 793/812 | 49/53 | [原片](../../../../evaluations/duck_getup_latched-corrective-ppo_development_s1164_rng_20261110T185806/evaluation-control-supine/clip-step-0.mp4) |
| 纠正候选 | 988/1,024 | 640/672 | 779/812 | 50/53 | [原片](../../../../evaluations/duck_getup_latched-corrective-ppo_development_s1164_rng_20261110T185806/evaluation-candidate-supine/clip-step-0.mp4) |

纠正候选比固定参照多通过 4、3 个实际仰卧场景，比同预算训练对照少通过 14 个。候选对训练对照新增成功 12 例、丢失 26 例。四路实际右侧均低于 51/53，因此本轮没有晋级模型，关闭纠正标签方案。保留训练对照作为仰卧研究参照。两路固定参照有 32 个场景结果不同。最终留出继续封存。 [独立评分](analysis.json) · [晋级判定](decision.json)

采样完成 1,945,600 条转移、9,500 个批量物理子步。含压缩写盘 275.61 秒，约 7,059 条转移/秒。整卡显存峰值 5,408 MiB，GPU 利用率采样均值 29.7%。Windows 读到 39 次运行中刷新，其中 38 次包含真实画面。四段原片各 11 秒。 [运行观察](../../../../getup-latched-head-corrective-evaluation-rng-live.html) · [独立核验日志](verify.log)

关键帧对齐 2 秒释放与 11 秒持稳终点。 [固定参照 A](../../../stage-media/cards/N598.jpg) · [固定参照 B](../../../stage-media/cards/N599.jpg) · [训练对照](../../../stage-media/cards/N600.jpg) · [纠正候选](../../../stage-media/cards/N601.jpg) · [媒体核验](media-review.json)

三个开发种子的 156 个实际右侧场景使用同一份回退权重。初步按已核验的评分分组，三个种子分别有 1、1、3 个场景在所选同权分支均失败，另有 2、3、2 个场景结果分歧。后续回读双脚承重、头腿接触、倾角和关节跟踪时序。 [跨种子复盘范围](../../../../../configs/experiments/getup_right_fallback_cross_seed_review.json)
