# 起身纠正回放对照

对照与候选从同一有界末层检查点开始。两组回放输入、抽样、原有环境奖励、价值网络、优化器起点和动作边界一致。两组各自使用 900 条辅助回放，候选只替换其中 450 条的有界腿部目标，另外 450 条保持一致。独立的动作保持回放来自 128 个已成功起身的实际场景，每姿态 32 个，共 1,024 条真实观测。重新推理的标签与原轨迹动作最大差为 1.67×10⁻⁶ rad。 [纠正数据](../getup-teacher-head-evaluation/corrective-replay/analysis.json) · [四姿态保持回放](../getup-teacher-head-evaluation/corrective-replay/success-anchor.json)

两组各自启动 3,072 个原生 CUDA 环境。初态物理、观测、随机数、网络和优化器签名一致，前两次回放抽样索引一致，只有两组目标标签的哈希不同。两组整卡显存峰值均为 11,986 MiB，物理和学习均为零。正式预算为每组 17 次更新、每次 24 个控制周期，合计每组 1,253,376 条转移。显存上限 85%，两组各以 8,500 条转移/秒为训练后吞吐检查线。 [匹配初态协议](../../../configs/experiments/getup_latched_head_corrective_ppo_zero.json) · [实测初态](matched-zero/analysis.json) · [正式训练协议](../../../configs/experiments/getup_latched_head_corrective_ppo.json)

首次正式入口在对照组的初态签名比较处停止，退出码 1。已尝试和实际物理步、训练更新均为零，候选组未启动。Windows 观察端捕获了启动和停止，未取得正式曲线或录像。 [停止日志](control-execution.log) · [协调器](coordinator.json) · [观察记录](windows-observations.json)

独立 CUDA 启动复现唯一差异，价值优化器的参数编号在内存中是整数，在保存的 JSON 中是字符串。统一使用 JSON 表示后，全部原有签名字段逐项相同。修复单独冻结，用新运行名称保留原预算、种子、训练数据和筛选门槛。 [实际 CUDA 复核](signature-recovery/diagnosis.json) · [恢复协议](../../../configs/experiments/getup_latched_head_corrective_ppo_signature.json)

## 训练结果

两组各完成 17 次更新、1,253,376 条转移及 2,040 个批量物理子步。两组都执行 1,560 次演员 Adam 和 2,040 次价值 Adam。独立重载检查确认抽样哈希一致，只有演员末层的腿部权重和偏置变化，其余行和对应动量逐位保留。Windows 分别读到 16 次运行中曲线、17 次带真实帧的状态和 1 段完整原片。两份 ONNX 与原生检查点在导出观测上的最大动作误差均低于 1×10⁻⁶ rad。 [独立核验](signature-recovery/training-verification.json)

| 组别 | 耗时 | 每秒转移 | 峰值显存 | GPU 利用率均值 | 证据 |
| --- | ---: | ---: | ---: | ---: | --- |
| 对照 | 104.24 s | 12,024 | 12,432 MiB | 41.2% | [8 秒原片](../../experiments/duck_getup_latched-corrective-ppo-signature_control_s1165_20261110T184708/clip-step-0.mp4) · [ONNX](../../../artifacts/duck_getup_latched-corrective-ppo-signature_control_s1165_20261110T184708/policy.onnx) · [检查点](../../experiments/duck_getup_latched-corrective-ppo-signature_control_s1165_20261110T184708/model-final.pt) |
| 候选 | 98.41 s | 12,737 | 12,278 MiB | 41.9% | [8 秒原片](../../experiments/duck_getup_latched-corrective-ppo-signature_candidate_s1165_20261110T184708/clip-step-0.mp4) · [ONNX](../../../artifacts/duck_getup_latched-corrective-ppo-signature_candidate_s1165_20261110T184708/policy.onnx) · [检查点](../../experiments/duck_getup_latched-corrective-ppo-signature_candidate_s1165_20261110T184708/model-final.pt) |

两组的 PPO 更新分别用时 30.35、29.38 秒，采样期间的原片录制累计 12.61、11.93 秒。表中端到端速度包含初始化、采样、更新、录制、导出与写盘。两组均通过吞吐和显存门槛，进入新种子的四路同释放评估。训练曲线只反映本轮采样，起身功能按独立场景验收。 [评估草案](../../../configs/experiments/getup_latched_head_corrective_evaluation_draft.json)

两段训练原片各 201 帧。关键帧标出第 2 秒共同释放和第 8 秒重置前的终态，完整动作可通过上表播放。 [候选关键帧](../stage-media/cards/N596.jpg) · [对照关键帧](../stage-media/cards/N597.jpg) · [媒体核验](signature-recovery/media-review.json)

新场景独立评价中，实际仰卧训练对照通过 793/812，纠正候选通过 779/812。实际右侧为 49/53 和 50/53，两组均低于原门槛。纠正标签方案关闭，训练对照保留为仰卧研究参照。 [四路评分与原片](evaluation/rng-guarded/README.md)

## 复现入口

从 XGO-Duck 根目录打开观察页，可查看逐次更新、吞吐、显存、真实画面和完整原片。Windows 观察脚本在训练期间按角色和更新次数保存独立读回。该协议已经使用，新练习先复制配置并分配独立运行名称和开发种子。 [观察页](../../getup-latched-head-corrective-ppo-signature-live.html) · [协调器](signature-recovery/coordinator.json) · [Windows 观察](signature-recovery/windows-observations.json)

在已部署的 WSL 环境中，从项目根目录执行以下首次核验命令。原运行已生成核验文件，可直接打开结果。 [核验结果](signature-recovery/training-verification.json)

```bash
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 PYTHONPATH=scripts/training
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B -u \
  scripts/validation/recover_getup_latched_head_corrective_ppo.py --verify
```
