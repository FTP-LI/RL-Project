# 颈部归位顺序

三组评估已结束，无入选方案；均为固定官方模型，零学习。共同接口291/320，只归位288/320，归位后站立287/320。各320个完整11秒首次episode，共528000个控制转移。

- [冻结协议](../../../configs/experiments/getup_neck_home_order.json)：66份源码、模型与依赖哈希、预算、两项功能门槛。
- [CPU预检](preflight.json)、[独立结果](analysis.json)、[全部轨迹复盘](mechanism-review.json)、[阶段摘要](phase-summary.json)。
- [完整时间轴](../../../docs/reports/assets/getup-neck-home-order-sequence.jpg)、[起身成绩](../../../docs/reports/assets/getup-neck-home-order-recovery.png)、[末段持稳](../../../docs/reports/assets/getup-neck-home-order-end-hold.png)。
- [开始截图](vscode-task-start.jpg)、[俯卧成功末帧](vscode-prone-complete.jpg)、[只归位末帧](vscode-neck-home-complete.jpg)、[归位后站立末帧](vscode-ordered-stand-complete.jpg)。
- 原片见三个 `records/evaluations/duck_getup_neck-home-order_*_s1015_20261103T082238/videos/`，逐段图册N199–N210。每段25fps、276帧，含0与11秒状态。

归位消除了末段头腿接触，失败姿态仍趴低；站立切换未救回未就绪的33次失败。下一步转向全身恢复请求、目标可达性和价值估计审计。完整实施、命令、结果及播放入口见[全流程报告](../../../docs/reports/development_report.md)第7.7.9节。已关闭任务不重复运行或扩展。
