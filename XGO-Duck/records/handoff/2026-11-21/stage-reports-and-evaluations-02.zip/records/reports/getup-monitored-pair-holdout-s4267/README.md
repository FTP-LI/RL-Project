# 起身模型独立留出

**本次留出已中断，没有有效成绩。** 观察器读取状态文件时报告 `FileNotFoundError` 并退出；采样器在第 1,275／1,450 个控制步检查到观察器退出后停止。已保存 3,916,800 条环境转移、6,375 个物理子步及部分视频和轨迹；候选分支不完整，不能作为独立留出成绩，原种子不再用于挑选参数或自动重启。[停止记录](entry-result.json) · [观察器错误](observer.log) · [部分采样记录](../../evaluations/duck_getup_monitor-pair_holdout_e3072_s4267_20261116T144236/evaluation.json)

停止后状态文件再次存在；这与短暂文件更替期间读取失败的情况一致，但现有日志不能证明其原因。GPU 显存峰值为 13,914 MiB，未超过方案的 85% 上限，遥测未记录显存异常。后续先做无物理步的观察器故障复现与修复验证，再考虑新的独立留出方案，不沿本次部分轨迹继续采样。[GPU 记录](../../evaluations/duck_getup_monitor-pair_holdout_e3072_s4267_20261116T144236/gpu-telemetry.json)

无物理步诊断中，1,500 次文件替换和 4,700 次读取未复现文件缺失，因此根因仍未确定。新观察适配器只对本轮状态文件的短暂缺失重读，最长等待 0.5 秒；持续缺失、其他文件缺失和无效状态仍报错。真实观察进程测试中，故意使状态文件缺失 0.3 秒后恢复，进程继续；持续缺失时进程退出，原有健康门槛仍然检查子进程。该修复覆盖已观察到的错误类型，不能证明原问题的根因。[故障检查](native-io-diagnosis.json) · [实际进程检查](native-observer-lifecycle.json) · [适配器代码](../../../scripts/training/native_run_observer_bounded.py)

候选在开发评估中通过原四姿态门槛后，本轮使用新的预留种子和 3,072 个并行环境，再次比较共同父模型、同步组与监控候选组。三组共享一次跌落和释放状态；原起身、末段持稳和姿态覆盖门槛保持不变。留出结果不用于继续挑选训练参数，也不自动替换交付模型。[开发结果](../getup-monitored-pair-action-s3267/README.md) · [冻结方案](../../../configs/experiments/getup_monitored_pair_holdout_s4267.json) · [CPU 零步](preflight.json)

本轮没有学习更新。采样期间的 VS Code 状态、真实画面和速度记录已留档；候选分支录像不完整。[本机状态](native-view/native-status.txt) · [最后画面](native-view/native-latest.jpg) · [采样速度](native-view/native-curve.png) · [启动截图](current-view.png) · [运行截图](running-view.png) · [执行日志](supervisor.log)
