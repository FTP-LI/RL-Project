# 仰卧早期支撑训练

从同一个固定起身策略和已准入的共享价值网络开始。两组各 3,072 个环境、17 次 PPO 更新，每次采样 24 个控制步。对照与候选只在第 2.3–3.0 秒的早期支撑奖励开关上有差异。两组都保留姿态锁存、原动作限制、成功动作回放、显存上限和真实录像。

| 冻结条件 | 数值 |
| --- | --- |
| 每组训练转移 | 1,253,376 |
| 每组完整首回合 | 3,072 |
| 原片长度 | 8 秒 |
| 显存上限 | 85% |
| 成功动作输出保护 | RMS 不超过 0.05 rad，单关节绝对偏差不超过 0.25 rad |

首次启动因 Adam 状态的整数键与 JSON 字符串键比较而在零物理步停止。四份启动档案均逐数组字节一致。修复将两侧签名放在同一序列化格式下比较，继续用原门槛核对完整初态。首次停止记录与修复后的运行分别留档。

[冻结方案](../../../configs/experiments/getup_early_support_ppo_recovery.json) · [首次停止记录](../getup-early-support-ppo/coordinator.json) · [只读复算](preflight.json) · [运行观察](../../getup-early-support-ppo-recovery-live.html) · [协调状态](coordinator.json)

## 训练结果

| 记录 | 对照 | 候选 |
| --- | --- | --- |
| 完成 PPO 更新 | 17 | 4 |
| 返回完整控制步 | 408 | 114 |
| 实际物理子步 | 2,040 | 575 |
| 显存峰值 | 12,641 MiB | 12,639 MiB |
| 运行耗时 | 109.76 秒 | 31.63 秒 |
| 录像 | 完整 8 秒 | 截断在 2.28 秒 |

对照 ONNX 与重新加载的策略在保存输入上的最大误差为 1.07 × 10⁻⁶。候选在第 115 步完成物理推进后于奖励读回处退出，差值最大 3.73 × 10⁻⁹。两组预算未匹配，无法用它们判断奖励是否改善起身。Windows 分别记录 16、4 次带曲线的运行中更新。

[对照原片](../../experiments/duck_getup_early-support-ppo-readback_control_s1083_20261110T033435/clip-step-0.mp4) · [候选截断原片](../../experiments/duck_getup_early-support-ppo-readback_candidate_s1083_20261110T033435/clip-step-0.mp4) · [对照独立核验](control-early-readback.log) · [候选停止日志](candidate-execution.log) · [Windows 观察](windows-observations.json)

候选共完成 480 次价值网络小批量更新，策略网络未更新。两组零步签名一致，保存轨迹在奖励生效前已出现数值分歧。CUDA 复算 409,600 个保存样本，直接比较原奖励项时有 1,354 处舍入差异，按本机管理器的运算顺序复算后全部逐位一致。后续保持严格比较，先用新种子验证实际奖励与重置。 [停止复核](stop-analysis.json) · [复算日志](stop-native-arithmetic.log)
