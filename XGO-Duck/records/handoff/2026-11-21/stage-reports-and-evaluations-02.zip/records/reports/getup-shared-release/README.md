# 起身释放状态复现

| 内容 | 入口 |
| --- | --- |
| 已保存的前100步 | [三组复核](prefix-audit.json) |
| 首次诊断 | [冻结协议](../../../configs/experiments/getup_shared_release.json) · [CPU预检](preflight.json) · [零步停止](zero-step-stop.json) |
| 固定地形适配 | [独立协议](../../../configs/experiments/getup_shared_release_terrain.json) · [CPU预检](fixed-terrain/preflight.json) |
| 实际运行 | [协调器](fixed-terrain/coordinator.json) · [独立核验](fixed-terrain/analysis.json) · [终端截图](fixed-terrain/vscode-run.png) |
| 保存数据复算 | [末段漂移](fixed-terrain/motion-review.json) · [仰卧支撑](fixed-terrain/supine-support-review.json) |
| 姿态图 | [可缩放矢量图](../../../docs/reports/assets/getup-shared-release-drift.svg) |
| 录像 | [重复一](../../evaluations/duck_getup_shared-release-terrain_reference_s1052_20261109T154754/evaluation-repeat-a/clip-step-0.mp4) · [重复二](../../evaluations/duck_getup_shared-release-terrain_reference_s1052_20261109T154754/evaluation-repeat-b/clip-step-0.mp4) · [关键帧](../../../docs/reports/assets/getup-shared-release-frames.jpg) |

VS Code 任务为“XGO-Duck · 同一释放状态复现（地形适配）”，使用已有共享任务终端。开发种子1052，32个环境共享100步跌落，再运行两次固定官方策略，每次450步。两段录像覆盖完整11秒，前2秒来自同一次真实跌落。动作验收仍用原及时起身与最后3秒持稳规则，诊断预算用于比较起点和数值漂移。

物理状态复制到原 Warp 缓冲区，保留 CUDA 图的地址。同步恢复动作及观测延迟、控制器历史、传感器缓存和随机状态。地形射线的加速结构由下一次正常感知更新。零步准入必须先核对已改动的状态能逐位恢复。运行完成后用独立 CPU 程序复查首个控制、实际积分次数、评分和录像来源。

实际分支在第 2 秒的 345 个字段、首个策略输入、原始动作、下发目标及实际执行器控制一致。两次各 31/32 及时起身且末段持稳，32 对样本评分无分歧。第 11 秒最大躯干姿态差为 31.56°，主要是水平朝向。该诊断共 32,000 条实际转移、零学习，四姿态覆盖只用于复现检查。已关闭的任务仅供追溯，复算命令见[过程记录](../../../docs/reports/development_history.md)。
