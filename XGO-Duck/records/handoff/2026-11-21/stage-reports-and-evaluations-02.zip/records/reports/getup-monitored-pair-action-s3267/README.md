# 起身模型共同跌落评估

本轮检查同步组和监控候选组完成训练后的动作表现，与两组的共同父模型对照。三个模型从同一批 1,024 个环境的物理跌落状态释放；动作轨迹、状态和原片已独立复核。本次只做仿真评估，没有学习更新，也不自动替换交付权重。

原判据包括：释放后及时起身、指定的高度和姿态范围、末段连续持稳，以及按请求姿态和实际释放姿态分别检查覆盖率。每个模型各录制四段从跌落开始到 11 秒结束的完整视频；具体实际姿态以轨迹复算为准。[冻结方案](../../../configs/experiments/getup_monitored_pair_action_s3267.json) · [CPU 零步](preflight.json) · [训练记录](../getup-monitored-authorization-20261116/README.md)

在 VS Code 中打开[运行状态](native-view/native-status.txt)、[最后画面](native-view/native-latest.jpg)或[采样速度](native-view/native-curve.png)；这些文件在采样时定期更新，无需本机网页。画面复用视频采集已有的渲染帧，没有额外推进仿真。观察器只呈现文件；采样入口另外检查观察器健康、暂停标志和显存，异常时停止。[启动时的观察截图](current-view.png) · [运行中截图](running-view.png) · [执行日志](supervisor.log)

运行入口为 `scripts/validation/evaluate_monitored_getup_pair.py`，使用既有 WSL 环境和训练锁执行 `freeze`、`run`、`verify`。方案固定了模型哈希、代码、共同释放、计算预算和停止条件；重现实验需要另建新的运行记录，不能覆盖这一轮。

## 对照结果

| 指标 | 父模型 | 同步组 | 监控候选组 |
| --- | ---: | ---: | ---: |
| 及时起身且末段持稳 | 1,003／1,024 | 998／1,024 | 1,006／1,024 |
| 实际右侧释放 | 159／170 | 161／170 | 162／170 |
| 请求仰卧 | 91／96 | 93／96 | 94／96 |
| 原四姿态及总体门槛 | 未通过 | 未通过 | 通过 |

实际右侧门槛为 162／170，因此候选仅高到门槛线；父模型的请求仰卧和实际右侧未通过，同步组的实际右侧未通过。候选相对父模型有 15 个共同场景由失败变为成功、12 个由成功变为失败，净增 3；相对同步组为 15 个改善、7 个退化，净增 8。单个开发种子支持继续独立确认，不能证明增益稳定。两组训练的奖励、学习率和网络设置相同，变化是文件检查的执行时序；由于两份训练权重不同，不能仅凭本次结果把动作差异归因于监控方式。[逐姿态结果与配对样本](analysis.json) · [训练时序与权重](../getup-monitored-authorization-20261116/README.md)

后续新种子独立留出中，候选请求仰卧 244／264，低于 251／264 的门槛；因此候选没有通过完整留出，不替换现有交付模型。[留出结果与原片](../getup-monitored-pair-holdout-s4268/README.md)

采集 1,484,800 条环境转移、7,250 个物理子步，三组共用一次物理重置；采集及轨迹保存用时约 255 秒。249 个评估进程期间的 GPU 样本中，利用率中位数为 39%，显存占用峰值为 6,046 MiB；该区间包含初始化与保存，不等于纯仿真或训练效率。[GPU 记录](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/gpu-telemetry.json) · [独立核验日志](verification.log)

## 完整原片

下表按启动时**请求姿态**选取相机，视频覆盖 0–11 秒。请求左侧和右侧的这两个相机环境在 2 秒释放时实际均为仰卧；它们可用于观看完整过程，但不能作为实际侧卧的示例。真实释放类型以独立轨迹评分为准。

| 请求姿态 | 父模型 | 同步组 | 监控候选组 |
| --- | --- | --- | --- |
| 俯卧 | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-parent-prone/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-control-prone/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-candidate-prone/clip-step-0.mp4) |
| 仰卧 | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-parent-supine/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-control-supine/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-candidate-supine/clip-step-0.mp4) |
| 左侧 | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-parent-left-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-control-left-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-candidate-left-side/clip-step-0.mp4) |
| 右侧 | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-parent-right-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-control-right-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_action_e1024_s3267_20261116T143044/evaluation-candidate-right-side/clip-step-0.mp4) |

## 右侧案例

下图从实际右侧释放的共同场景中，分别选取候选相对两组均改善和均退化的最小场景编号：场景 57 中候选持稳而两组参照未持稳；场景 370 中候选未持稳而两组参照持稳。每列为 2、3.2、8、11 秒；倾角直接从对应保存状态计算。这两个相反案例用于理解差异，不能代表总体比例。

![实际右侧起身](actual-right-review/actual-right-keyframes.jpg)

图和以下完整片段由已保存的位置和速度重建，明确属于保存状态回放，没有插值或新增物理步；它们与上表的现场采样原片分开标记。[改善案例回放](actual-right-review/candidate-right-env57-replay.mp4) · [退化案例回放](actual-right-review/candidate-right-env370-replay.mp4) · [来源与帧核验](actual-right-review/manifest.json) · [配对复算](actual-right-review/paired-summary.json)
