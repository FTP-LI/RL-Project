# 起身价值起点

同一固定策略在 1,024 个新场景生成 400 步首回合。在原有 75 项价值输入后加入仰卧标志。训练目标是原奖励和候选奖励折扣回报的均值。拟合与归一化仅用 960 个场景，64 个开发验证场景按四类指定姿态均分。

| 核验对象 | 解释方差 | 归一化均方误差 |
| --- | --- | --- |
| 原奖励 | 0.85579 | 0.01874 |
| 候选奖励 | 0.85590 | 0.01897 |
| 验收 | 至少 0.50，且每种姿态至少 0 | 至多 0.25 |

409,600 条转移，50 次价值网络更新，策略网络零更新，未使用最终留出。显存峰值为 5,856/16,384 MiB。Windows 读到 17 个运行中状态，其中 16 个已附真实帧。原片为 8 秒、201 帧，保留释放与重置前状态。

原独立读回将零步字段读成 `physics_substeps`，实际文件记录为 `physical_substeps`。首次修复调用还遇到导入顺序错误。保留两份错误日志，通过只读字段映射运行原有全部断言，成功复算两套回报、价值模型和录像。未增加仿真步、价值更新或策略更新。

[冻结方案](../../../configs/experiments/getup_early_support_value.json) · [采样和拟合日志](sampling-and-fit.log) · [首轮读回](verification.log) · [修复调用](readback-recovery.log) · [复算日志](readback-verification.log) · [修复凭证](readback-recovery.json) · [独立核验](analysis.json)

[运行观察](../../getup-early-support-value-live.html) · [原片](../../experiments/duck_getup_early-support-value_development_s1082_20261110T031630/clip-step-0.mp4) · [Windows 核验](../../experiments/duck_getup_early-support-value_development_s1082_20261110T031630/windows-view-verification.json) · [同起点草案](../../../configs/experiments/getup_early_support_ppo_draft.json)

## 执行入口

在 Ubuntu 项目根目录加载既有环境。以下入口对应本次执行记录。独立复算可以直接查看已保存的日志。

```bash
source scripts/setup/project_environment.sh
py="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
"$py" -B scripts/validation/run_getup_early_support_value.py --freeze
"$py" -B scripts/validation/run_getup_early_support_value.py --run
"$py" -B scripts/validation/recover_getup_early_support_value_readback.py
```

[新标注卡片核对](media-review.json) · [全量图册](../../../docs/reports/stage-video-gallery.html)
