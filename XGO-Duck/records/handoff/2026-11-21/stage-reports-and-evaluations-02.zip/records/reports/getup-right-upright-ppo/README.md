# 右侧起身训练对照

两组各 3,072 个 CUDA 环境、17 次 PPO 更新、最多 1,253,376 条转移。策略、共享价值、环境、随机种子、四姿态回放和训练参数相同。候选增加右侧受阻后的有符号直立进展奖励，对照保留相同价值状态历史并将这项奖励贡献置零。实际动作偏差、晚段稳定性、接触容量和显存有独立停止线。 [冻结协议](../../../configs/experiments/getup_right_upright_ppo.json) · [CUDA 初态](../getup-right-upright-ppo-zero/README.md)

[运行观察页](../../getup-right-upright-ppo-live.html)显示真实进度、回报、损失、净吞吐和训练画面。完整起身原片覆盖 8 秒仿真时间。Windows 观察入口已核验。 [观察入口证明](windows-entry.json)

本机命令从工程根目录执行。

```powershell
wsl.exe -d Ubuntu-24.04 -u atlas -- bash scripts/validation/run_getup_right_upright_ppo.sh
```

配对运行仅执行一次。观察脚本 `scripts/validation/watch_getup_right_upright_ppo.py` 可从 Windows 独立读取运行数据。训练收尾后，`scripts/validation/verify_getup_right_upright_ppo.py` 复核两组日志、模型、优化器、ONNX、回放抽样和原片，动作成绩另在同一组新释放场景上判定。

两组均完成 17 次更新和 1,253,376 条转移。净吞吐以实际训练段计，墙钟含初始化、训练、录像与导出。

| 组别 | 墙钟 | PPO 更新 | 净转移/秒 | 显存峰值 | 原片 |
| --- | ---: | ---: | ---: | ---: | --- |
| 对照 | 108.83 秒 | 34.86 秒 | 12,418 | 12,272 MiB | [播放](../../experiments/duck_getup_right-upright-ppo_control_s1101_20261110T064100/clip-step-0.mp4) |
| 候选 | 104.08 秒 | 32.07 秒 | 12,941 | 12,265 MiB | [播放](../../experiments/duck_getup_right-upright-ppo_candidate_s1101_20261110T064100/clip-step-0.mp4) |

两组各有 28 个场景触发奖励时钟，实际对照贡献全零。第 400 个控制步两组各有 3,072 个场景重置，清除了奖励历史。Windows 为两组各保存 16 个运行中曲线状态并核对完整原片。 [配对执行与退出状态](coordinator.json) · [Windows 观察结果](windows-observations.json) · [对照日志](control-execution.log) · [候选日志](candidate-execution.log)

独立 CPU 核验确认两组抽取完全相同的回放样本，检查点和 Adam 状态能重载，ONNX 输出最大偏差分别为 1.19×10⁻⁶、1.01×10⁻⁶ rad。原片各 201 帧均与物理状态时钟对齐。两组实际策略小批量更新为 1,447 和 1,560 次，价值小批量更新各 2,040 次。策略更新次数取决于原 KL 限制，物理样本预算相同。 [独立核验结果](training-verification.json)

动作评价使用新开发种子 1102。三组共享同一份 320 场景的释放状态，父模型 311/320、对照 316/320、候选 308/320。候选的实际右侧和实际仰卧成绩低于对照，当前方案关闭。 [独立评分和 11 秒原片](evaluation/README.md) · [评价观察页](../../getup-right-upright-ppo-evaluation-live.html)
