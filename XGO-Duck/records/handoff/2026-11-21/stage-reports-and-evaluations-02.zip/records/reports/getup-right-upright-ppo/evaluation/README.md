# 右侧起身独立评价

新开发种子 1102，父模型、对照和候选各 320 个场景。三组共享同一次物理释放，共采集 464,000 条转移，零学习。每种姿态在释放后分别评分，同时检查及时起身和最后 3 秒持稳。 [冻结协议](../../../../configs/experiments/getup_right_upright_ppo_evaluation.json) · [独立评分与全部原片路径](analysis.json) · [运行记录](sample-execution.log) · [Windows 观察核验](windows-live-verification.json)

| 指标 | 父模型 | 对照 | 右侧奖励候选 |
| --- | ---: | ---: | ---: |
| 及时起身且末段持稳 | 311/320 | 316/320 | 308/320 |
| 实际右侧 | 48/50 | 49/50 | 48/50 |
| 实际仰卧 | 171/177 | 174/177 | 168/177 |
| 指定仰卧 | 29/32 | 30/32 | 28/32 |

右侧奖励候选未入选。实际右侧相对对照净少 1 次，实际仰卧净少 6 次。指定仰卧三组均低于 31/32。原定右侧净增 4 次在本批存在上限问题，对照已通过 49/50，理论上最多只能净增 1 次。原判据和结果均保留，后续先核对对照可挽回样本数，再冻结增益门槛。

三组均未通过的两个指定仰卧场景为 234、312。对照约在释放后 0.58 秒达到 30°以内，随后重新倾斜。末段双脚均触地且一直存在头腿接触，最小倾角分别为 33.9° 和 33.1°。两组训练权重留作开发证据。下一步在独立开发档案核对转正后的支撑和回倾时序，最终留出继续封存。 [保存轨迹复算](requested-supine-review.json) · [失败动作关键帧](requested-supine-keyframes.jpg)

| 片段 | 父模型 | 对照 | 候选 |
| --- | --- | --- | --- |
| 指定仰卧 | [播放](../../../evaluations/duck_getup_right-upright-ppo_paired_s1102_20261110T064715/evaluation-fixed-weighted-supine/clip-step-0.mp4) | [播放](../../../evaluations/duck_getup_right-upright-ppo_paired_s1102_20261110T064715/evaluation-control-supine/clip-step-0.mp4) | [播放](../../../evaluations/duck_getup_right-upright-ppo_paired_s1102_20261110T064715/evaluation-candidate-supine/clip-step-0.mp4) |
| 指定右侧 | [播放](../../../evaluations/duck_getup_right-upright-ppo_paired_s1102_20261110T064715/evaluation-fixed-weighted-right-side/clip-step-0.mp4) | [播放](../../../evaluations/duck_getup_right-upright-ppo_paired_s1102_20261110T064715/evaluation-control-right-side/clip-step-0.mp4) | [播放](../../../evaluations/duck_getup_right-upright-ppo_paired_s1102_20261110T064715/evaluation-candidate-right-side/clip-step-0.mp4) |

原片每段 11 秒、276 帧。镜头按指定姿态在运行前选定，释放时的实际姿态见独立评分和图册标注。
