# 起身训练路径开销对照

两组训练均已完成并通过保存点、导出和原片核验。固定路径组的训练过程总耗时由 209.16 秒降到 153.18 秒，对应吞吐提高 **36.5%**。当前已按用户要求暂停，旧预算关闭。[保存数据复核](../pause-archive-20261116/saved-evidence-readback.json) · [逐项结果](comparison.json)

## 修改内容

原方法每次运行检查都重新解析固定文件路径，在 WSL 读取 Windows 工程目录时产生重复开销。候选仅在进程初次绑定时解析固定路径；之后每次仍重新读取项目暂停标记、完整协议和源码哈希。暂停判断频率、协议内容检查、父进程保护与外层监督均保留。

实现见[固定路径检查](../../../scripts/training/canonical_ppo_authorization.py)和[本轮入口](../../../scripts/training/observed_getup_path_entry.py)，注释说明修改理由和计时范围。23 项 CPU 判断检查通过；只读测量由约 33 毫秒/次降到 14 毫秒/次，这一离线数字与实际训练收益分别记录。[CPU 检查](../getup-observed-throughput-20261116/performance-review/canonical-check.json)

## 对照条件

两组共用父保存点、种子 3265、3,072 个环境、24 控制步采样、24 个小批量、17 次 PPO 更新，每组 1,253,376 条转移。奖励、学习率、动作保持及 8 秒录像规则相同。原组先运行，候选随后；单次对照没有交换顺序复验。

两组 CUDA 零步时保存的 12 组初态数组及网络、优化器、随机状态一致，118 份冻结来源保持原字节。旧协议只作为复现证据保存，当前暂停状态禁止重新启动。[零步复核](zero-verification.json) · [冻结协议](../../../configs/experiments/observed_getup_path_pair_20261116.json)

## 测量结果

| 指标 | 原检查组 | 固定路径组 |
| --- | ---: | ---: |
| PPO 更新 | 17 | 17 |
| 训练转移 | 1,253,376 | 1,253,376 |
| 训练过程总时间 | 209.16 秒 | 153.18 秒 |
| 对应总吞吐 | 5,992 转移/秒 | 8,182 转移/秒 |
| 采样至末次指标发布 | 199.04 秒 | 143.45 秒 |
| 对应窗口吞吐 | 6,297 转移/秒 | 8,737 转移/秒 |
| PPO 更新段累计 | 130.91 秒 | 77.64 秒 |
| 检查回调次数 | 2,075 | 2,075 |
| 检查回调累计墙钟时间 | 80.20 秒 | 32.50 秒 |
| 录像采样累计 | 3.84 秒 | 3.71 秒 |
| GPU 峰值显存 | 12,983 MiB | 12,969 MiB |
| GPU 利用率中位数 | 33% | 33.5% |

总时间包含环境初始化、训练、导出和收尾，排除外层查看等待；不能称为纯 GPU 训练时间。采样窗口仍包含录像、检查和指标发布。回调时间与 PPO 更新段存在包含关系，不应相加。两组回调累计相差 47.70 秒，总耗时相差 55.98 秒；剩余差额不能全部归因于路径修改。

## 模型差异

保存初态一致不代表后续轨迹逐位一致。第一控制步的位置和速度已出现最大约 8.20×10⁻⁸、1.44×10⁻⁷ 的差异，早于首次 PPO 更新；差异原因尚未确定。最终 actor 参数最大绝对差为 0.00275，同一探针输入的动作最大差约 0.0491 rad。完整差异保存在结果 JSON 中。

训练末次完整 episode 的持稳比例为 96.84% 和 96.91%，它们来自训练数据，不能作为独立动作改善结论。本轮未开展最终策略的留出评价，两份模型只作性能诊断材料，未替换交付权重。GPU 利用率仍偏低，本次提速不表示本机算力已经用满。

## 过程记录

| 内容 | 原检查组 | 固定路径组 |
| --- | --- | --- |
| 最终状态 | [状态](training/control/final-view/native-status.txt) | [状态](training/throughput/final-view/native-status.txt) |
| 曲线 | [曲线](training/control/final-view/native-curve.png) | [曲线](training/throughput/final-view/native-curve.png) |
| 命令、退出与日志 | [命令](training/control/supervisor-result.json) · [日志](training/control/execution.log) | [命令](training/throughput/supervisor-result.json) · [日志](training/throughput/execution.log) |
| 保存点 | [模型](../../experiments/duck_getup_auth-original_e3072_s3265_20261116T021829/model-final.pt) | [模型](../../experiments/duck_getup_auth-canonical_e3072_s3265_20261116T021829/model-final.pt) |
| ONNX | [导出](../../../artifacts/duck_getup_auth-original_e3072_s3265_20261116T021829/policy.onnx) | [导出](../../../artifacts/duck_getup_auth-canonical_e3072_s3265_20261116T021829/policy.onnx) |
| 独立核验 | [记录](training/control/independent-verification.json) | [记录](training/throughput/independent-verification.json) |
| 完整原片 | [8 秒录像](../../experiments/duck_getup_auth-original_e3072_s3265_20261116T021829/clip-step-0.mp4) | [8 秒录像](../../experiments/duck_getup_auth-canonical_e3072_s3265_20261116T021829/clip-step-0.mp4) |

下面是固定路径组的完整训练原片，覆盖该次释放、起身和终态；它不是训练结束后的独立评估。两段原片均完整解码为 201 帧、25 fps，动作时间为 8 秒。

<video controls preload="none" src="../../experiments/duck_getup_auth-canonical_e3072_s3265_20261116T021829/clip-step-0.mp4"></video>

![训练曲线](training/throughput/final-view/native-curve.png)

![训练过程](training/throughput/progress-eleven-updates.png)

截图记录原 VS Code 中第 11 次更新的实际显示。运行时状态与曲线曾自动刷新；目前均为历史记录。用户窗口大小、位置和布局保持不变。

## 后续处理

当前仅归档。恢复后先检查第一步数值分歧和剩余 CPU、采样及写盘开销，再确定是否以新协议采用固定路径方案。独立动作评价通过前，不将本轮模型作为更好的起身策略。[全部目标](../../../docs/current_goal.md) · [本次暂停归档](../pause-archive-20261116/README.md)
