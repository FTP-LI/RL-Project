# 共同接口价值预检

[原协议](../../../configs/experiments/getup_interface_value.json)在1个控制步后因日志读取字段错误停止；1024个控制转移、行为及价值更新0，记录保持关闭。不是零步失败。

[单独读取修复](../../../configs/experiments/getup_interface_value_readback_recovery.json)新增只读别名，配置和实际动作数学不变。CPU身份、反例与配置检查后，重新采集完整首次episode；没有从残缺物理状态恢复。

[独立结果](readback-recovery/analysis.json)：新测量409600个转移、50次价值小批量更新、行为0且权重逐位不变。独立开发验证EV0.82861、归一化MSE0.02473，门槛通过；全部请求及处理目标各5734400项重建误差0。含失败开销共410624个转移。

[原错误截图](vscode-readback-failure.jpg)、[独立验证终端](readback-recovery/vscode-value-verified.jpg)、[完整播放末帧](readback-recovery/vscode-value-complete.jpg)。完整8秒原片见[实验记录](../../experiments/duck_getup_interface-value-readback_reference_s42_20261103T090629/clip-step-0.mp4)。70份冻结源码及新模型哈希见协议和独立结果；旧文件保留原字节。

价值准入只证明拟合通过。该起点随后用于[有界行为对照](../getup-late-feasibility/README.md)，其候选未晋级，不追加。完整环境、过程、图表及CPU复核命令见[主报告](../../../docs/reports/development_report.md)第7.7.10节。
