# 右侧起身扩展价值覆盖

首批 1,024 场景按原分组停止，保留训练 6 个、验证 8 个触发的原结果。本批使用独立种子 1100 和 3,072 个新场景。按预先固定的世界顺序，以触发条件分配稀少样本，分组时没有读取动作成败或回报。固定同一策略网络采集 400 步，候选回报加入系数 10 的右侧转正奖励。

| 用途 | 场景数 | 触发场景数 | 对照解释方差 | 候选解释方差 |
| --- | ---: | ---: | ---: | ---: |
| 价值拟合 | 960 | 62 | — | — |
| 验证 | 64 | 4 | 0.846 | 0.846 |
| 独立复算 | 2,048 | 4 | 0.866 | 0.866 |

共享价值网络完成 50 次更新，策略网络前后哈希一致。对照和候选在验证集上的归一化均方误差约为 0.0215，独立复算约为 0.0190。两组都通过原价值准入和四个姿态分项。独立复算中的四个触发场景，候选解释方差为 0.443、归一化均方误差为 0.0388。这是小样本诊断，需在后续独立动作评价检查触发后的恢复。 [独立评分](analysis.json)

本轮采集 1,228,800 条转移，整机显存峰值为 12,888 MiB，低于 85% 上限。Windows 读取 17 次运行中原始画面。保存的价值检查点及优化器已重新加载，8 秒原片逐帧核验。 [冻结方案](../../../configs/experiments/getup_right_upright_value_coverage.json) · [运行观察](../../getup-right-upright-value-coverage-live.html) · [8 秒原片](../../experiments/duck_getup_right-upright-value-coverage_development_s1100_20261110T062215/clip-step-0.mp4) · [价值检查点](../../experiments/duck_getup_right-upright-value-coverage_development_s1100_20261110T062215/critic-final.pt)

后续在 3,072 场景完成两组同初态 CUDA 零步与奖励接口核验，再做等样本 PPO。最终动作留出仍封存。 [配对训练草案](../../../configs/experiments/getup_right_upright_ppo_draft.json) · [两组 CPU 接口核验](../getup-right-upright-clock/ppo-bridge-cpu.json)
