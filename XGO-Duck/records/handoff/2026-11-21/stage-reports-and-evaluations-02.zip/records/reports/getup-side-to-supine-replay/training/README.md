# 起身回放覆盖训练

两个策略共享固定父模型、价值网络、早期支撑奖励及训练预算。两组在 CUDA 零步均用 3,072 个环境，显存峰值 11,922 MiB。候选将 180 条指定仰卧回放替换为侧倒转仰卧回放，其他 720 条保持逐位一致。

| 组别 | PPO 更新 | 转移 | 耗时 | 显存峰值 | ONNX 最大误差 |
| --- | --- | --- | --- | --- | --- |
| 对照 | 17 | 1,253,376 | 100.97 秒 | 12,642 MiB | 9.54e-07 |
| 候选 | 17 | 1,253,376 | 101.28 秒 | 12,649 MiB | 1.01e-06 |

Windows 分别读到 16 次带曲线的运行中更新和一段完整 8 秒原片。两组检查点和 ONNX 已独立读回。

[冻结方案](../../../../configs/experiments/getup_side_to_supine_ppo.json) · [运行观察](../../../getup-side-to-supine-ppo-live.html) · [训练核验](training-verification.json) · [Windows 观察](windows-observations.json)

[对照原片](../../../experiments/duck_getup_side-to-supine-ppo_control_s1086_20261110T041411/clip-step-0.mp4)
[候选原片](../../../experiments/duck_getup_side-to-supine-ppo_candidate_s1086_20261110T041411/clip-step-0.mp4)

两组共复算 2,040 个提交的回放批次，逐批索引哈希一致。每组重复抽取 391,680 条，候选其中 94,526 条属于侧倒转仰卧，对照为零。 [实际抽样复算](replay-draws.json) · [新场景评估协议](../../../../configs/experiments/getup_side_to_supine_ppo_evaluation.json)
