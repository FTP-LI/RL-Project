# 侧倒转仰卧回放

实际仰卧的 180 个新评估场景中有 148 个由侧倒形成。候选失去的 5 个父策略成功场景全部属于这一类。旧回放按实际右侧和指定仰卧取样，缺少这类成功数据。相同父策略输入上的早期动作偏差在失败组和共同成功组接近，因此将覆盖缺口作为下一对照变量。

从既有开发种子 1061、1062 准备两个 900 条、24 单元的回放池。候选在每个种子、每个采样时刻替换 15 条指定仰卧样本，改用已成功的侧倒转仰卧样本。180 条被替换，720 条输入和目标逐位一致。所有样本用同一固定父策略的 ONNX 复算。种子 1063 的 864 条历史输入仅用于独立读回。种子 1084 仅用于诊断。

[准备方案](../../../configs/experiments/getup_side_to_supine_replay_draft.json) · [覆盖复算](../getup-early-support-ppo-functional/parent-retention-review.json) · [回放核验](preflight.json) · [对照数据](control-replay.npz) · [候选数据](candidate-replay.npz)

[双组 CUDA 初态核验](zero-step/analysis.json) · [训练、曲线与原片](training/README.md)

[独立动作评分与 11 秒原片](evaluation/README.md)
