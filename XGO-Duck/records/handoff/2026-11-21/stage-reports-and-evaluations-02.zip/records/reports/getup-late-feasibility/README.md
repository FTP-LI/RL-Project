# 末段可达目标训练

本轮已经关闭：官方295/320，对照283/320，候选283/320；功能门槛及候选相对改进门槛均未通过，不追加。实际学习2457600个转移，独立评价528000个转移。真机操作后置。

| 文件 | 用途 |
| --- | --- |
| [冻结协议](../../../configs/experiments/getup_late_feasibility_pair.json) | 起点、唯一改动、预算、种子、录像和选择规则 |
| [CPU预检](preflight.json) | 物理场景一致、阶段边界、目标处理、模型接口和晋级上限 |
| [执行状态](coordinator.json) | 顺序执行及停止状态 |
| [对照训练复核](control/training-verification.json) | 实际更新、导出、原始历史及完整8秒录像 |
| [对照评价](control-analysis.json) | 320个完整11秒首次动作，保留原及时持稳和末段持稳 |
| [官方参照](original-analysis.json) | 同一组开发场景中的固定官方权重 |
| [选择记录](selection.json) | 按冻结规则决定候选和是否晋级 |
| [候选训练复核](candidate/training-verification.json) | 成对起点逐位一致及实际50次更新 |
| [候选评价](candidate-analysis.json) | 完整11秒独立复算 |
| [最终结果](analysis.json) | 原成绩、末段成绩和预算结算 |
| [目标与阶段复盘](mechanism-review.json) | 全样本越界幅度、失败姿态和训练曲线 |
| [完整动作录像核验](recording-verification.json) | 4段8秒训练、12段11秒评价及末帧检查 |

训练每组最多50次rollout更新，每次24步、1024环境。行为网络从官方权重开始，价值网络及其Adam从已准入的共同接口预检开始；行为Adam新建，归一化与探索标准差0.10固定。环境奖励相同，候选只在episode年龄不小于5秒时，对14个关节的均值目标到合法区间的平方距离求和，加入行为损失。冻结期和早期借力动作不加此项。

每项动态评价覆盖0–11秒，先冻结2秒，再检查8秒前开始连续3秒持稳，并额外检查整个8–11秒段。四种起始姿态和四种实际释放姿态分别验收，比例均要求95%，实际释放每类不少于32例。原样本、旧严格分数和失败保留。

起身训练原片为201帧、25fps，物理时间0–8秒；评估原片为276帧、25fps，0–11秒。首帧及结束帧均是真实状态，训练末帧在自动重置前捕获。录像不增加物理步，部分片段不得标成完整动作。

代码开头说明修改原因：[训练入口](../../../scripts/training/getup_late_feasibility.py)、[行为损失](../../../scripts/training/getup_feasibility_loss.py)、[协调器](../../../scripts/validation/getup_late_feasibility_pair.py)。完整说明和播放入口见[主报告](../../../docs/reports/development_report.md)。

运行已经使用当前冻结名称，不能再次启动同一训练。复查保存的数据可在既有VS Code的WSL终端执行以下命令，不增加仿真或学习：

```bash
cd /home/atlas/XGO-Duck/workspace/xgoduck_rl
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_late_feasibility_pair.py --verify-train control
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_late_feasibility_pair.py --verify-eval control
./.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/getup_late_feasibility_pair.py --verify-eval original
```

完整动作时间轴见[过程图](../../../docs/reports/assets/getup-late-feasibility-timeline.jpg)，原VS Code播放截图为[8秒训练](vscode-complete8s.jpg)和[11秒评价](vscode-complete11s.jpg)。所有新动作原片及时间范围进入[图册](../../../docs/reports/stage-video-gallery.html)。

候选完整失败原片已在原VS Code播放到11秒：[终态截图](vscode-candidate-complete11s.jpg)。窗口保持1214×818，位置保持(49,28)。
