# 起身接力证据

最新动态对照在 `fixed-evaluation/`：两组各320次、完整11秒，零学习；对照292/320、候选296/320，功能门槛均未通过，原协议关闭。

| 文件 | 用途 |
| --- | --- |
| [analysis.json](fixed-evaluation/analysis.json) | 独立功能分数、轨迹与8段完整原片核验 |
| [failure-review.json](fixed-evaluation/failure-review.json) | 全部失败分量、末段持稳、干预前分歧 |
| [neck-state-sensitivity.json](fixed-evaluation/neck-state-sensitivity.json) | 208条真实输入及单颈部观测条件推理，不是实际恢复 |
| [preflight.json](fixed-evaluation/preflight.json) | 新动态协议的CPU冻结检查 |
| [vscode-task-start.jpg](fixed-evaluation/vscode-task-start.jpg) | 原共享终端中的真实采样 |
| [vscode-candidate-playback.jpg](fixed-evaluation/vscode-candidate-playback.jpg) | 候选原片播放到11秒 |
| [analysis.json](analysis.json) | 前期观测噪声差异与首次站立请求审计 |
| [component-preflight.json](component-preflight.json) | 处理器、独立动作历史和部分重置的CPU核验 |
| [phase-summary.json](phase-summary.json) | 前期接口准备阶段的历史摘要 |

`initial-profile-mismatch.json`和`component-initial-check-failure.json`保留前期CPU检查失败；真实动态运行没有因这两项重新消费预算。完整说明见[主报告](../../../docs/reports/development_report.md)。

新颈部归位与接力顺序仍为草案；不重复运行已关闭试验，不将条件推理或`status=passed`误当成动作通过。
