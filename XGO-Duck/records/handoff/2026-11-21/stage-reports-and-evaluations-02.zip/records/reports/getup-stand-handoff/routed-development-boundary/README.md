# 起身接站立边界

从四姿态开发评估中读取候选的保存观测。仿真时间 10.98 秒前的连续半秒内，机身倾角不超过 15°、角速度不超过 1 rad/s 的场景共有 3,010/3,072 个。这批场景与原起身通过判定逐一吻合。此处用开发数据核对切换输入，留出数据继续单独验收。 [开发评估](../../getup-right-robustness/development/README.md) · [CPU 核验](analysis.json)

实际俯卧、仰卧、左侧、右侧各取 32 个样本，转换站立模型的关节零位，保持同一测量关节位置，并清零站立模型的原始动作历史和指令。用已交付站立策略计算首个目标。最大未限速请求差为 0.214 rad，按现有 2 rad/s 限速后，第一步目标变化最大为 0.040 rad。 [首步输入和输出](first-standing-requests.npz) · [站立模型](../../../../artifacts/delivery/walking-simulation.json)

该项为 CPU 条件推理。连续切换需在同一个物理回合里验证，记录首次切换、实际持稳和后续行走。 [执行记录](../routed-boundary-execution.log)
