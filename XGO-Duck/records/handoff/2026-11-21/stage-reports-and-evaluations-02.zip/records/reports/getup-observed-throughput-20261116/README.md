# 本机起身训练观察与吞吐

两组训练均已结束并通过独立读回。每组采集 1,253,376 条转移；3,072 环境组比 1,536 环境组的训练过程净吞吐高 **9.7%**，耗时少 **8.8%**，峰值显存多 **5.16 GiB**。本轮证明本地训练记录与导出流程可用，尚未证明动作改善，交付模型保持原选择。

网页不可访问时，直接在 VS Code 查看[训练记录入口](../../training-current.md)。本轮完整原片、曲线和日志均保存在工程内；不用启动网页服务。WSL 项目工作器已退出，训练锁空闲。[汇总数据](comparison.json) · [进程检查](process-check.json)

## 结果

| 指标 | 1,536 环境 | 3,072 环境 |
| --- | ---: | ---: |
| 完成的 PPO 更新 | 34 | 17 |
| 采样转移 | 1,253,376 | 1,253,376 |
| 控制步 / 物理子步 | 816 / 4,080 | 408 / 2,040 |
| 完整回合 | 3,072 | 3,072 |
| 训练过程总耗时 | 229.33 秒 | 209.13 秒 |
| 总过程净吞吐 | 5,465 转移/秒 | 5,993 转移/秒 |
| PPO 计时 | 125.87 秒 | 130.50 秒 |
| 录像采样计时 | 3.80 秒 | 3.95 秒 |
| 整机显存峰值 | 7,685 MiB | 12,969 MiB |
| GPU 利用率中位数 | 31% | 33% |
| 本轮策略 / 价值网络小批量更新 | 1,580 / 2,040 | 1,560 / 2,040 |
| 监督进程总时间 | 347.19 秒 | 278.76 秒 |

总过程吞吐采用转移数除以 `elapsed_seconds`，包含初始化、导出和收尾。另按采样开始至末次指标发布计算，两组为 221.50、199.05 秒，对应吞吐提高 11.3%。监督进程还包含查看确认等待和依赖导入，不能将全部差异归因于并行规模。PPO 计时包含同步后的主机和设备工作；扣除 PPO 后的余量不能当作纯物理仿真时间。本轮 GPU 采样覆盖整张显卡，没有逐进程 CPU 和内核时间线。[计时纠正与开销测量](performance-review/README.md)

两组从同一父保存点和相同种子 3264 开始，小批量均为 3,072 条样本，奖励和动作保持约束相同。并行规模改变了更新边界，策略小批量更新次数也有差异；每种规模仅运行一次。末个完整训练回合的持稳比例约为 95.77% 和 97.07%，属于训练数据，不能用来判定哪份模型更好。

## 观察与模型

| 内容 | 1,536 环境 | 3,072 环境 |
| --- | --- | --- |
| 最终状态 | [状态](json-publication/training/control/final-view/native-status.txt) | [状态](json-publication/training/throughput/final-view/native-status.txt) |
| 完整曲线 | [曲线](json-publication/training/control/final-view/native-curve.png) | [曲线](json-publication/training/throughput/final-view/native-curve.png) |
| 实际训练原片 | [8 秒起身](../../experiments/duck_getup_observed-json-e1536_s3264_20261116T013246/clip-step-0.mp4) | [8 秒起身](../../experiments/duck_getup_observed-json-e3072_s3264_20261116T013246/clip-step-0.mp4) |
| 完整命令输出 | [日志](json-publication/training/control/execution.log) | [日志](json-publication/training/throughput/execution.log) |
| 独立核验 | [结果](json-publication/training/control/independent-verification.json) | [结果](json-publication/training/throughput/independent-verification.json) |
| 最终保存点 | [model-final.pt](../../experiments/duck_getup_observed-json-e1536_s3264_20261116T013246/model-final.pt) | [model-final.pt](../../experiments/duck_getup_observed-json-e3072_s3264_20261116T013246/model-final.pt) |
| 推理模型 | [policy.onnx](../../../artifacts/duck_getup_observed-json-e1536_s3264_20261116T013246/policy.onnx) | [policy.onnx](../../../artifacts/duck_getup_observed-json-e3072_s3264_20261116T013246/policy.onnx) |

两段完整原片均为 201 帧、25 fps，覆盖 8 秒仿真动作，已逐帧解码核验。控制组另有预算结束时的 0.32 秒片段，首次失败留有 0.48 秒片段，均按不完整记录保存。训练中策略会更新，因此这些录像用于观察过程，后续动作验收须使用固定最终策略。

两份保存点的网络、Adam 步数和有限数值通过 CPU 读回；ONNX 对保存的 PyTorch 输出最大差分别为 8.94×10⁻⁷ 和 1.33×10⁻⁶。这不代表从原物理现场精确恢复已经验证。本轮父点来自早期仰卧加权起身训练，用于核验训练入口，不替代当前起身组合。

在原 VS Code 窗口实际查看了运行中进度、曲线和起身视频；窗口位置、尺寸保持原样。下图为实际播放中的记录。

![起身过程](json-publication/training/throughput/video-middle-view.png)

[查看证据](json-publication/training/throughput/viewing-verification.json) · [控制组运行进度](json-publication/training/control/progress-29-updates.png)

## 修改及原因

| 修改 | 原因 | 已核验效果 |
| --- | --- | --- |
| 训练工作器接入本地状态、曲线、完整动作原片与外层监督器 | 本机网页不可访问，训练过程仍需可查看和留档。 | 两组实际训练完成；运行前与运行中画面、最终指标和原片可追溯。 |
| 独立入口统一 JSON 表示 | 首次运行把 Python 元组与落盘后的列表直接比较，误报观察数据不一致。 | 真实失败复现；表示统一后通过，篡改数值、非有限值与过期数据仍拒绝。 |
| 按完整动作录像 | 3 秒片段无法观察起身的全过程。 | 两组均保留 8 秒完整原片；中断片段明确标记。 |
| 同父点、等转移比较并行规模 | 评估增加显存占用是否带来实际提速。 | 实测总过程吞吐提高 9.7%，未将其作为动作改善或算力已用满的结论。 |

冻结方案见[本轮协议](../../../configs/experiments/observed_getup_json_throughput_20261116.json)，独立适配入口见[源码](../../../scripts/training/observed_getup_json_entry.py)。原失败协议的 110 份来源和本轮 113 份来源均重新校验，字节未变。[实际 CUDA 零步](json-publication/zero-verification.json) · [序列化复现](publication-verification.json) · [两组核对脚本](../../../scripts/validation/review_observed_getup_pair.py)

观察文件末尾仍保留旧组件的“自身不能停止训练”提示：文件查看器只显示数据，停止由训练回调和外层监督器负责。首次真实错误已停止并保存部分点；进程丢失和停滞的故障注入目前仍是合成检查，不能据此宣称真实 GPU 卡死恢复已通过。

## 失败记录

首次 3,072 环境运行在 24 控制步、73,728 条转移后因序列化比较错误关闭；只发生 120 次价值网络更新，策略更新为 0，另一组未启动。CPU 读回确认策略权重未变、Adam 增量相符；未验证精确物理恢复。原日志、部分保存点和不完整原片保留。[失败日志](training/throughput/execution.log) · [部分点核验](partial-checkpoint-verification.json)

配置生成曾因 Windows 默认文本编码退出，指定 UTF-8 后完成；临时目录检查改为工程内隔离目录后通过；独立录像验证改用已安装的 FFmpeg 解码，无需新增 OpenCV。验证脚本随后修正了控制组两个完整回合的终态索引，首次成功使用的源码已[单独留存](verification-source-before-episode-index.zip)。文档快照首次按 Windows 反斜杠读取 ZIP 成员失败，统一成员路径后核验通过。这些文档和检查故障均没有新增物理或学习步。

计入首次失败，本阶段实际训练共 2,580,480 条转移、6,240 个批量物理子步、52 次完整 PPO 更新；策略与价值网络小批量更新合计分别为 3,140、4,200 次。两轮零步检查、后续核验和归档均没有新增仿真或学习。

## 后续与归档

先分析计时，再冻结下一次有界性能试验。现有数据中 PPO 占训练过程总时间约 55%–62%，3,072 环境组的 PPO 总时间没有降低；录像采样约占 2%。下一次需要区分 CPU 计算、同步等待、推理、物理采样、优化和写盘，才能决定调整小批量、线程或其他实现。现有数据没有证明 CPU 或 WSL 是瓶颈，也不足以认定原生 Ubuntu 必然更快。

本轮两份模型只作为诊断保存。任何后续动作训练仍需新协议、同父点对照、原动作门槛和独立评估；不自动延长已结束的运行。全阶段任务和真机后置要求见[当前目标](../../../docs/current_goal.md)。

精选文档、方案、源码、日志及截图在本目录归档；模型、完整原片和轨迹保留原路径，通过外部文件清单校验。快照不是脱离工程的完整备份，兼容目录联接不应当作重复数据删除。归档完成后见本目录的 `archive-manifest.json` 与 `archive-verification.json`。
