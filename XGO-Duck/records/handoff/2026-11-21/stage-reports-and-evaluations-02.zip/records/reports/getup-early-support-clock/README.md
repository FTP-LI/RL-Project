# 起身奖励时钟

用固定父策略检查仰卧早期支撑奖励如何接入真实仿真。仰卧标志来自释放后的首个策略重力观测。奖励仅在第 115–150 步生效，结合身体转正、脚底接触和头腿接触。动作和物理由同一固定策略驱动。

| 检查 | 结果 |
| --- | --- |
| 物理采样 | 128 个环境，70,400 条转移，2,750 次批量物理子步 |
| 奖励计算 | 3,739 个正值，独立复算最大误差 1.32 × 10⁻⁷ |
| 接触及重置 | 9 个原始接触核对点，2 个局部重置，126 个自然重置 |
| 价值目标 | 126 个完整首回合，每回合 400 步，折扣回报最大绝对差 0.478 |
| 学习与覆盖 | 策略和价值网络均未更新，使用开发场景 |
| 过程留档 | Windows 核验 20 个运行状态，其中 19 个附真实帧，完整原片为 8 秒、201 帧 |

[冻结方案](../../../configs/experiments/getup_early_support_clock.json) · [零步检查](preflight.json) · [运行日志](sampling.log) · [独立核验](verification.log) · [复算结果](analysis.json) · [运行观察](../../getup-early-support-clock-live.html)

[原片](../../experiments/duck_getup_early-support-clock_development_s1081_20261110T031240/clip-step-0.mp4) · [Windows 观察核验](../../experiments/duck_getup_early-support-clock_development_s1081_20261110T031240/windows-view-verification.json)

## 执行入口

在 Ubuntu 项目根目录加载既有环境。以下入口对应本次执行记录。独立复算可以直接查看已保存的日志。

```bash
source scripts/setup/project_environment.sh
py="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
"$py" -B scripts/validation/check_getup_early_support_clock.py --freeze
"$py" -B scripts/validation/check_getup_early_support_clock.py --sample
"$py" -B scripts/validation/verify_getup_early_support_clock.py
```
