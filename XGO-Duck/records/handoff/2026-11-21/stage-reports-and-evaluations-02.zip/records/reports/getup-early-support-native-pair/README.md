# 原生奖励起身对照

使用已通过完整 CUDA 回合核验的新种子，两组从同一物理初态、策略和共享价值起点开始。每组 3,072 个环境、17 次 PPO 更新、1,253,376 条训练转移。两组的功能差异只有早期仰卧支撑奖励开关。奖励读回按本机管理器的运算顺序逐位比较。训练完成后还需在新开发场景中按原四姿态门槛评分。

[冻结方案](../../../configs/experiments/getup_early_support_native_pair.json) · [前置检查](../getup-early-support-native-reward/README.md) · [运行观察](../../getup-early-support-native-pair-live.html) · [协调状态](coordinator.json)

## 训练结果

| 组别 | 转移 | 耗时 | 净吞吐 | 显存峰值 |
| --- | --- | --- | --- | --- |
| 对照 | 1,253,376 | 102.78 秒 | 12,195 转移/秒 | 12,643 MiB |
| 候选 | 1,253,376 | 104.73 秒 | 11,967 转移/秒 | 12,640 MiB |

两组均完成 17 次更新和一个完整首回合。Windows 每组读到 16 次带曲线的运行中更新和完整原片。训练记录用于核对过程，动作效果由新场景评分。

[对照原片](../../experiments/duck_getup_early-support-ppo-native_control_s1085_20261110T034608/clip-step-0.mp4) · [候选原片](../../experiments/duck_getup_early-support-ppo-native_candidate_s1085_20261110T034608/clip-step-0.mp4) · [Windows 观察](windows-observations.json)

[训练独立核验](training-verification.json) · [四姿态评分协议](../../../configs/experiments/getup_early_support_ppo_evaluation.json)

## 执行入口

本次命令从 Ubuntu 的项目根目录执行。学习前先通过两组实际初态及 Windows 观察检查。运行编号已用于本次留档。复现实验需为新种子和运行目录重新冻结，避免覆盖原记录。

```bash
source scripts/setup/project_environment.sh
py="$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python"
"$py" -B scripts/validation/run_getup_early_support_native_pair.py --freeze
flock -n "$HOME/XGO-Duck/training.lock" script --quiet --return --command "$py -B scripts/validation/run_getup_early_support_native_pair.py" /dev/null
CUDA_VISIBLE_DEVICES="" "$py" -B scripts/validation/run_getup_early_support_native_pair.py --verify
```

Windows 的观察入口和过程核验分别使用 `--windows-preflight`、`--windows-watch`。VS Code 可直接查看运行页、指标和原片。
