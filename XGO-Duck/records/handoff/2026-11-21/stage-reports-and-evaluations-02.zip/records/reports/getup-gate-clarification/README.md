# 起身门槛与模型用途核对

训练和仿真保持暂停。本次只读取既有冻结方案、轨迹、评分和权重，没有新增物理步、学习更新或真机操作。核对发现，部分汇总把起身候选的**总体差值**误当作原方案要求的**实际右侧净增**，因此错误写成“未达到晋级要求”。

## 起身留出

原方案要求各指定姿态、实际姿态及总体满足 95% 门槛，分流覆盖达标，并在实际右侧相对两组参照各净增至少 1 例。逐场景的及时持稳与末段持稳均计入评分。 [冻结方案](../../../configs/experiments/getup_right_robustness_holdout_s2065.json) · [原判定](../getup-right-robustness/holdout/decision.json)

| 范围 | 参照 A | 参照 B | 双姿态分流候选 |
| --- | ---: | ---: | ---: |
| 总体 | 2,987/3,072 | 2,988/3,072 | 2,983/3,072 |
| 实际右侧 | 175/183 | 174/183 | 179/183 |
| 实际仰卧 | 2,336/2,412 | 2,338/2,412 | 2,328/2,412 |

候选在实际右侧相对参照 A 多成功 5 例、少成功 1 例，净增 4 例；相对参照 B 多成功 7 例、少成功 2 例，净增 5 例。候选总体分别比两组参照少 4、5 例。**原留出的逐姿态、分流覆盖及右侧净增门槛均通过**；总体差值需要如实保留，但不是该方案规定的右侧净增门槛。这是一枚独立留出种子的结果，不能据此声称候选在所有条件下均优于参照，也不能视为整套动作或真机已通过。

本次从三份保存轨迹重新计算每个场景的连续持稳，与原逐场景评分逐项比对，并重新统计分流覆盖及成对胜负；三份轨迹的哈希均与原评分记录一致。核对没有重跑策略推理，也没有新增物理步。[轨迹复算](raw-recount.json) · [原评分与录像](../getup-right-robustness/holdout/README.md)

## 行走模型的适用范围

同一份 `walk-common-base.onnx` 在两种任务里的结论不同：

- 在七指令固定回合中，它是按指令分流的多个模型组件之一；前进使用官方参考，右转使用另一份自训模型，控制还包含反馈。该组合的独立留出七项均为 32/32。
- 在滚翻→站立→前进的同种子对照中，使用这份自训行走模型的路线为 111/128，官方行走模型为 119/128；该次路线门槛为 116/128，自训臂未通过。

因此，这份权重可以保留为七指令组合的仿真组件，但不能因为七指令通过就认定它通过了滚翻后前进路线。模型和冻结方案哈希已核对；该对照的运行目录协议副本与冻结配置的 JSON 内容相同，但字节哈希不同，核验原冻结协议应使用配置文件的哈希。本次没有重算这条路线的轨迹。[模型用途核对](model-scope-check.json) · [七指令清单](../../../artifacts/delivery/walking-simulation.json) · [路线对照](../router-self-trained-walk-compare-s1223/README.md)

## 汇总与保留

[阶段矩阵](matrix-corrected.json)保留其他阶段数据，明确区分总体差值、实际右侧差值与原留出门槛；其中更大范围的最终模型选择仍待后续评价。原[机器记录](../stage-acceptance-matrix/matrix.json)和本次[修改前汇总快照](prior-summaries.zip)均保留，[快照清单](prior-summaries.json)记录哈希。原模型、轨迹、冻结方案和历史判定均未修改。

[本次核对快照](completed-audit.zip)收录更正后的说明、阶段矩阵、复算结果和脚本；[快照清单](completed-audit-manifest.json)记录每份文件的哈希。模型、完整轨迹和环境仍在工程原位置，快照不能单独替代整个项目。

如需在已配置的 WSL 环境自行复算，可在项目根目录打开终端，替换最后的输出文件名，确保该名称尚不存在。命令只读保存轨迹并写入一份新的检查结果，约需读取 3 GiB 数据：

```powershell
wsl -d Ubuntu-24.04 -- /home/atlas/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/scripts/validation/audit_getup_holdout_gate.py /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck/records/reports/getup-gate-clarification/recount-personal.json
```
