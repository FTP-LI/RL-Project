# 起身模型独立留出

本轮在观察器读取修复通过无物理步检查后，使用新种子和 2,816 个并行环境，重新独立比较共同父模型、同步组和监控候选组。此前中断的留出数据保留，未续接或用于调参；三份模型、共同释放和原四姿态判据不变。[开发对照](../getup-monitored-pair-action-s3267/README.md) · [中断原因与检查](../getup-monitored-pair-holdout-s4267/README.md) · [冻结方案](../../../configs/experiments/getup_monitored_pair_holdout_bounded_s4268.json)

此前 3,072 环境的显存峰值距离 85% 上限约 12 MiB。本轮缩小一档，为其他进程保留空间；实际占用以本轮遥测为准，不把估计值当作实测。

本轮没有学习更新。VS Code 中可打开[本机状态](native-view/native-status.txt)、[最后画面](native-view/native-latest.jpg)和[采样速度](native-view/native-curve.png)；完整 11 秒原片及轨迹已独立复核。[观察入口截图](current-view.png) · [执行日志](supervisor.log) · [CPU 零步](preflight.json)

计划的 1,450 个控制步及 4,083,200 条环境转移已采集和保存；显存峰值为 12,850 MiB，观察器未报告错误。[采样进度截图](running-view.png) · [报告预览截图](report-view.png) · [独立复算](analysis.json) · [逐环境汇总](summary.json)

## 留出结果

| 指标 | 父模型 | 同步组 | 监控候选组 |
| --- | ---: | ---: | ---: |
| 及时起身且末段持稳 | 2,736／2,816 | 2,735／2,816 | 2,737／2,816 |
| 请求仰卧 | 247／264 | 249／264 | 244／264 |
| 实际右侧释放 | 463／498 | 480／498 | 481／498 |
| 实际仰卧释放 | 1,524／1,565 | 1,503／1,565 | 1,505／1,565 |
| 原四姿态及总体门槛 | 未通过 | 未通过 | 未通过 |

请求仰卧要求至少 251／264，三组均未通过；候选虽达到实际右侧要求的 474／498，但不能替代其他姿态门槛。候选较父模型总体有 48 个共同场景改善、47 个退化，净增 1；实际右侧净增 18，实际仰卧净减 19。留出未支持候选整体可靠改进，保留两份训练权重作为实验记录，不替换现有交付模型，也不用该留出继续挑参数。

采集及轨迹保存耗时 404.39 秒，约 10,097 条环境转移／秒；395 个 GPU 遥测样本的利用率中位数为 50%，显存峰值 12,850 MiB。开发评估的 1,024 环境同口径约 5,822 条／秒、显存峰值 6,046 MiB；这两次分别使用不同种子和环境规模，属于单次实测，不能据此认定稳定加速比例或等同于训练吞吐。[本轮遥测](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/gpu-telemetry.json) · [开发评估](../getup-monitored-pair-action-s3267/README.md)

## 完整原片

每段为采样时的原片，覆盖 0–11 秒。下列四个相机环境在释放时的实际姿态与请求姿态一致；12 段视频均已核验帧数与保存的状态对应。

| 姿态 | 父模型 | 同步组 | 监控候选组 |
| --- | --- | --- | --- |
| 俯卧 | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-parent-prone/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-control-prone/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-candidate-prone/clip-step-0.mp4) |
| 仰卧 | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-parent-supine/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-control-supine/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-candidate-supine/clip-step-0.mp4) |
| 左侧 | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-parent-left-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-control-left-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-candidate-left-side/clip-step-0.mp4) |
| 右侧 | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-parent-right-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-control-right-side/clip-step-0.mp4) | [原片](../../evaluations/duck_getup_monitor-pair_holdout-bounded_e2816_s4268_20261116T145425/evaluation-candidate-right-side/clip-step-0.mp4) |
