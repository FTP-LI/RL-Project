# 起身动作保持对照

两组从同一个仰卧加权检查点开始，保留实际仰卧首秒的加权和原成功动作约束。候选额外把父模型动作加入策略损失，系数为 0.01。回放来自实际右侧和指定仰卧的成功轨迹，共 900 条观测。每个小批次等额抽取两类各 96 条。 [数据复盘](../getup-supine-weighted-learning/recovery-retention-audit.json) · [回放检查](replay-preflight.json)

在保存批次的 16 个小批次中，0.01 对应保守梯度比约 7.4%。两次完整 CPU PPO 对照中，零系数的 actor、critic、Adam 和采样序列与原更新一致，正系数只改变 actor 更新。冻结的训练和评估种子分别为 46 和 1058，两组各限 50 次更新、每次 24 步 × 512 环境。 [CPU 优化器检查](optimizer-preflight.json) · [冻结协议](../../../configs/experiments/getup_recovery_retention.json) · [CPU 场景检查](preflight.json)

两组在原 VS Code 共享任务终端通过实际 GPU 零步检查，匹配物理初态、随机数、网络和 Adam。随后仅对照组采样，完成 32 次更新、768 个批量控制步、3,840 个物理子步、393,216 条训练转移。第 31 次的固定成功样本动作偏移 RMS 为 0.04904 rad，第 32 次为 0.05027 rad，超过 0.05 rad 上限，协调器保存后退出。候选更新和独立评估均为零。 [协调器](coordinator.json) · [CPU 独立复核](stop-verification.json) · [运行日志](execution.log)

| 动作偏移 RMS（rad） | 起点 | 第 25 次更新 | 停止点 |
| --- | ---: | ---: | ---: |
| 原成功样本 | 0.03777 | 0.04257 | 0.05027 |
| 实际右侧回放 | 0.02636 | 0.03304 | 0.03714 |
| 指定仰卧回放 | 0.02391 | 0.03242 | 0.03705 |

两类父模型回放偏移都增大。它们衡量固定观测上的动作变化，实际起身成功率仍沿用上一次完整评估。本轮只能确认常规续训触发了累计偏移停止线。 [偏移图](../../../docs/reports/assets/getup-recovery-retention-drift.png)

[完整 8 秒训练原片](../../experiments/duck_getup_recovery-retention_control_s46_20261109T214221/clip-step-0.mp4)来自对照组第一个 episode，共 201 帧。包含跌落、2 秒释放和重置前的终态。 [可见终端](../../../docs/reports/assets/getup-recovery-retention-terminal.jpg) · [窗口位置与大小](terminal-layout.json)

一次性 VS Code 任务已归档。以下保留原命令供复查，协议拒绝重复启动。独立复核读取原文件并重建偏移图。

```bash
bash scripts/training/training_workflow.sh getup-recovery-retention
source scripts/setup/project_environment.sh
~/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python -B scripts/validation/review_getup_recovery_retention_stop.py
```
