# 右侧起身初态核验

两组共用父策略、90 列价值输入和同一份四姿态回放。回放从两个已完成的开发批次抽取 150 个实际落地后成功起身的场景，按姿态和控制时刻划分 24 个采样单元。父 ONNX 对 900 条观测的动作最大复算误差为 1.91×10⁻⁶ rad。 [回放复算](../getup-right-upright-ppo-replay/analysis.json)

首次 CUDA 检查在控制组初始化阶段停止。物理、61 列策略观测和动作处理历史已核验，读取价值检查点时触发归一化系数的精确相等断言。物理步数为零，学习更新为零。此前一次 PowerShell 内联命令在调用 Python 前退出，未占用此次检查预算。 [首次协议](../../../configs/experiments/getup_right_upright_ppo_zero.json) · [初态](control/startup.json) · [错误日志](control.log) · [退出结果](analysis.json)

修复协议沿用同一价值检查点、优化器、种子、回放与原断言。检查点的精确系数与独立复算相差 1.78×10⁻¹⁵，符合既有容差。随后奖励夹具的上下文组合报错，仍在物理步 0。探针修正后先通过 CPU 正负奖励和选择性清零检查，再冻结配对 CUDA 检查。 [系数修复](readback/preflight.json) · [探针停止日志](readback/control.log) · [最终初态协议](../../../configs/experiments/getup_right_upright_ppo_zero_probe.json)

在已部署的 Windows 环境中执行配对初态检查：

```powershell
Set-Location -LiteralPath 'C:\Users\atlas-win\Desktop\RL-Project\XGO-Duck'
wsl.exe -d Ubuntu-24.04 -u atlas -- bash scripts/validation/run_getup_right_upright_ppo_zero.sh probe
```

修正后的两组各 3,072 个 CUDA 环境均通过。物理状态、策略和价值观测、优化器、随机状态、回放池与奖励时钟的签名一致。候选探针保留约 +2、−2 的加权贡献，对照贡献全为零，选择性清零通过。每组峰值 11,922 MiB，约占 16 GiB 的 73%，低于 85% 上限。该检查没有推进物理或学习。 [配对结果](probe/analysis.json) · [对照日志](probe/control.log) · [候选日志](probe/candidate.log)

独立动作评价保留原来四姿态的及时起身和末段持稳判据。右侧候选相对对照须净增加至少 4 个场景，其他三姿态须保住父模型和对照的成绩。
