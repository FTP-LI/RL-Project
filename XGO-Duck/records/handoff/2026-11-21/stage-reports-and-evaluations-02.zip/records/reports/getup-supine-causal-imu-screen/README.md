# 仰卧卡住信号筛查

指定仰卧的独立留出为 30/32，门槛为 31/32。此前 40 毫秒倾角规则在实际策略观测中未通过。保持第 2.44 秒决策，使用此前 120 毫秒的七帧陀螺仪与重力观测。六个统计量覆盖倾角、倾角趋势、回倾、重力横向量和俯仰角速度。逻辑回归按正负类等权，每次用一个完整种子拟合，在另一种子预测，统一阈值只使用这两批交叉预测。 [冻结方案](../../../configs/experiments/getup_supine_causal_imu_screen.json)

| 开发种子 | 至少提前 60 毫秒识别失败 | 成功场景误触发 |
| --- | ---: | ---: |
| 1084 | 3/5 | 5/175 |
| 1087 | 0/7 | 2/159 |

覆盖率低于 75% 门槛，关闭本规则。第三批未进入筛查，物理步和 PPO 更新均为零。后续回到同次释放的接触、关节目标和实际转正响应。 [逐项结果](analysis.json) · [运行日志](../getup-supine-early-signal-readback/causal-imu-screen.log)

在项目的 WSL 虚拟环境中读取结果。历史筛查入口使用执行时的项目阶段与独立记录目录，现有结果留存供复算。

```bash
PYTHONPATH=scripts/training python -B scripts/validation/screen_getup_supine_causal_imu.py
```
