# 双姿态起身最终留出

总体 993/1,024，实际右侧 69/73（94.52%）。右侧门槛要求至少 70/73，差 1 例。其余分组通过，四姿态起身未晋级。仰卧与右侧分流分别命中 792/792 和 73/73，均无误选。

## 分组评分

| 范围 | 姿态 | 参照 A | 参照 B | 双姿态分流 |
| --- | --- | ---: | ---: | ---: |
| 全部 | 全部 | 992/1,024 | 992/1,024 | 993/1,024 |
| 指定 | 俯卧 | 96/96 | 96/96 | 96/96 |
| 指定 | 仰卧 | 646/672 | 650/672 | 647/672 |
| 指定 | 左侧 | 128/128 | 126/128 | 127/128 |
| 指定 | 右侧 | 122/128 | 120/128 | 123/128 |
| 实际 | 俯卧 | 96/96 | 96/96 | 96/96 |
| 实际 | 仰卧 | 765/792 | 768/792 | 765/792 |
| 实际 | 左侧 | 63/63 | 62/63 | 63/63 |
| 实际 | 右侧 | 68/73 | 66/73 | 69/73 |

两路参照均使用仰卧专用策略和共同回退。候选额外在实际右侧使用右侧专用策略。候选相对参照 A 在实际右侧多通过 4 例、少通过 3 例，净增 1 例。相对参照 B 多通过 4 例、少通过 1 例，净增 3 例。同权参照的分歧在评分中单列。 [独立评分与区间](analysis.json) · [阶段判定](decision.json)

## 执行与原片

预留种子执行一次，三路共 1,484,800 条转移、7,250 个批量物理子步，学习更新为零。含写盘用时 201.07 秒，约 7,384 条转移/秒，整卡显存峰值 5,365 MiB，GPU 利用率采样均值 28.6%。Windows 核验 30 次运行刷新，其中 29 次含真实画面。 [冻结配置](../../../../configs/experiments/getup_dual_pose_route_holdout_s2064.json) · [一次性消费记录](consumption.json) · [运行观察](../../../getup-dual-pose-route-holdout-live.html) · [独立核验日志](verify.log)

三段原片各 11 秒、276 帧，覆盖跌落、起身和持稳终点。环境 1 的指定姿态为右侧，实际释放为仰卧。

| 策略 | 原片 | 关键帧 |
| --- | --- | --- |
| 参照 A | [原片](../../../evaluations/duck_getup_dual-pose-route_holdout_s2064_20261110T193315/evaluation-reference-a-right-side/clip-step-0.mp4) | [关键帧](../../stage-media/cards/N608.jpg) |
| 参照 B | [原片](../../../evaluations/duck_getup_dual-pose-route_holdout_s2064_20261110T193315/evaluation-reference-b-right-side/clip-step-0.mp4) | [关键帧](../../stage-media/cards/N609.jpg) |
| 双姿态分流 | [原片](../../../evaluations/duck_getup_dual-pose-route_holdout_s2064_20261110T193315/evaluation-candidate-right-side/clip-step-0.mp4) | [关键帧](../../stage-media/cards/N610.jpg) |

该留出已封存为验收记录。后续开发提高实际右侧覆盖，保留仰卧等分组及原门槛。 [媒体核验](media-review.json) · [新开发草案](../../../../configs/experiments/getup_right_robustness_development_draft.json)
