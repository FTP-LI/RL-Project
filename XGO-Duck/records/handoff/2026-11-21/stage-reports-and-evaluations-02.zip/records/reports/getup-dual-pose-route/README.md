# 双姿态起身分流

两路参照在实际观测识别为仰卧时使用已核验的 PPO 对照，其余使用共同回退。候选只在释放首帧识别为右侧时增加已归档的右侧专用策略。三路在同一份释放快照下评分。三批保存观测及独立 CUDA 零步核对了分流、非右侧动作逐位相同、选择在后续姿态变化时保持，以及模型导入随机状态的保护。 [冻结方案](../../../configs/experiments/getup_dual_pose_route_s1166.json) · [CPU 准入](freeze.json) · [CUDA 零步](independent-zero/proof.json)

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 实际右侧 | 原片 |
| --- | ---: | ---: | ---: | ---: | --- |
| 参照 A | 993/1,024 | 647/672 | 778/806 | 54/57 | [原片](../../evaluations/duck_getup_dual-pose-route_development_s1166_20261110T191628/evaluation-reference-a-right-side/clip-step-0.mp4) |
| 参照 B | 991/1,024 | 644/672 | 776/806 | 54/57 | [原片](../../evaluations/duck_getup_dual-pose-route_development_s1166_20261110T191628/evaluation-reference-b-right-side/clip-step-0.mp4) |
| 双姿态分流 | 999/1,024 | 649/672 | 781/806 | 57/57 | [原片](../../evaluations/duck_getup_dual-pose-route_development_s1166_20261110T191628/evaluation-candidate-right-side/clip-step-0.mp4) |

候选在新开发种子的原逐姿态及总体门槛全部通过。实际仰卧识别 806/806，实际右侧识别 57/57，均无误选。候选相对两路参照分别挽回同三个右侧场景，无右侧场景退步。进入独立开发复验。 [独立评分](analysis.json) · [阶段判定](decision.json)

三路共采样 1,484,800 条转移、7,250 个批量物理子步，含写盘 205.12 秒，约 7,239 条转移/秒。整卡显存峰值 5,365 MiB，GPU 利用率采样均值 29.1%。Windows 核验 30 次运行刷新，其中 29 次含真实画面。三段原片均为实际右侧释放，每段 11 秒、276 帧。 [运行观察](../../getup-dual-pose-route-live.html) · [独立核验日志](verify.log)

关键帧对齐第 2 秒释放与第 11 秒持稳终点。 [参照 A](../stage-media/cards/N602.jpg) · [参照 B](../stage-media/cards/N603.jpg) · [右侧专用策略](../stage-media/cards/N604.jpg) · [媒体核验](media-review.json)

独立复验只更换开发种子，实际右侧达到 58/59，相对两路参照分别净增 3、2 例。逐姿态和总体门槛再次通过。相同配置的一次性最终留出总体为 993/1,024，实际右侧 69/73，低于 70/73，候选未晋级。 [复验评分和原片](replication/README.md) · [最终留出与原片](holdout/README.md)
