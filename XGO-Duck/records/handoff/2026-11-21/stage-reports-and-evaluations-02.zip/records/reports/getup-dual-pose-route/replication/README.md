# 双姿态起身独立复验

只更换开发种子，三份模型、释放分流、仿真、相机规则、时限和 95% 门槛沿用首批。 [冻结协议](../../../../configs/experiments/getup_dual_pose_route_s1167.json) · [实际 CUDA 零步](independent-zero/proof.json)

| 策略 | 全部持稳 | 指定仰卧 | 实际仰卧 | 实际右侧 | 原片 |
| --- | ---: | ---: | ---: | ---: | --- |
| 参照 A | 994/1,024 | 646/672 | 780/806 | 55/59 | [原片](../../../evaluations/duck_getup_dual-pose-route_development_s1167_20261110T192551/evaluation-reference-a-right-side/clip-step-0.mp4) |
| 参照 B | 999/1,024 | 650/672 | 784/806 | 56/59 | [原片](../../../evaluations/duck_getup_dual-pose-route_development_s1167_20261110T192551/evaluation-reference-b-right-side/clip-step-0.mp4) |
| 双姿态分流 | 1,000/1,024 | 649/672 | 783/806 | 58/59 | [原片](../../../evaluations/duck_getup_dual-pose-route_development_s1167_20261110T192551/evaluation-candidate-right-side/clip-step-0.mp4) |

候选通过全部原门槛。相对参照 A 挽回 3 个实际右侧场景，相对参照 B 挽回 2 个，均无实际右侧退步。实际仰卧和右侧识别为 806/806 和 59/59，均无误选。候选和参照 B 的实际仰卧相差 1 例，两路使用相同仰卧策略，均通过该组门槛。 [独立评分](analysis.json) · [阶段判定](decision.json)

本机共执行 1,484,800 条转移、7,250 个批量物理子步。含写盘 203.62 秒，约 7,292 条转移/秒，显存峰值 5,365 MiB，GPU 利用率采样均值 29.2%。Windows 核验 30 次运行刷新，其中 29 次含真实画面。三段原片均为 11 秒、276 帧。预定镜头场景 4 指定右侧跌倒，实际释放为仰卧。 [运行观察](../../../getup-dual-pose-route-s1167-live.html) · [独立核验日志](verify.log)

关键帧对齐第 2 秒释放与第 11 秒持稳终点。 [参照 A](../../stage-media/cards/N605.jpg) · [参照 B](../../stage-media/cards/N606.jpg) · [双姿态分流](../../stage-media/cards/N607.jpg) · [媒体核验](media-review.json)
