# 起身定向回放

从同一仰卧加权父检查点复算 32 个保存批次。两组分别保留原父模型回放系数 0 和 0.01。原官方成功回放、物理数据、随机批次和回退方式保持一致。 [冻结方案](../../../configs/experiments/getup_targeted_replay.json) · [原停止定位](sequence-drift-localization.json)

| 比较项 | 额外回放代价 |
| --- | --- |
| 原方案 | 无 |
| 颈部 | 左右侧倒 2.5、3 秒。颈部俯仰绝对误差超过 0.15 rad 的部分，取最大的八项平方平均 |
| 髋膝 | 左右侧倒 4 秒至末段。双髋俯仰和双膝偏差平方和取平均 |
| 组合 | 两项同时开启 |

两项附加系数分别为原官方回放系数的 4 倍和 0.5 倍。原累计 RMS 上限 0.05 rad 和单关节绝对偏差上限 0.25 rad 保持。组合两组均须接受完整 32 次更新，每组减步幅不超过 8 次，结束时 RMS 余量至少 0.001 rad。分项用于解释差异。所有运算在保存的 CPU 输入上完成。

```bash
cd /mnt/c/Users/atlas-win/Desktop/RL-Project/XGO-Duck
source scripts/setup/project_environment.sh
"$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python" -B scripts/validation/screen_getup_targeted_replay.py
```

## 结果

| 回放 | 对照接受次数 | 候选接受次数 |
| --- | ---: | ---: |
| 原方案 | 13/32 | 15/32 |
| 颈部 | 14/32 | 22/32 |
| 髋膝 | 13/32 | 13/32 |
| 组合 | 21/32 | 29/32 |

组合的第 22 和第 30 次更新被拒绝，三档步幅均超过 0.25 rad。结束时两组 RMS 分别为 0.03431、0.02955 rad，仍低于 0.05 rad。组合筛查未通过，按协议关闭。零物理步，零权重输出。 [逐次结果](targeted-replay-screen.json)

组合失败时，原先的颈部俯仰已让位于其他极值。对照三档均为仰卧 4 秒的右髋偏航，候选三档均为右侧倒地 3 秒的头部偏航。下一项离线检查让回放按当前误差从全部 2,360 组成功观测选取极值。 [拒绝复算](targeted-replay-rejection.json)

## 自适应回放

每个 PPO 训练轮次从 2,360 组成功输入、14 个关节中重新找出最大的 64 项绝对偏差，对其中超过 0.12 rad 的部分增加平方代价。附加系数为原官方回放系数的 8 倍。重试也重新选择极值。比较原 32 个保存场景与随后不重叠的 32 个保存场景，每批的两组都要通过原 32 次更新准入。 [冻结方案](../../../configs/experiments/getup_adaptive_replay.json)

```bash
source scripts/setup/project_environment.sh
set -o pipefail
"$HOME/XGO-Duck/workspace/xgoduck_rl/.venv/bin/python" -B scripts/validation/screen_getup_adaptive_replay.py \
  2>&1 | tee records/reports/getup-success-step-control/adaptive-replay-execution.log
```

原检查在第二块输入时中止。该档案的动作覆盖 1,024 个环境，策略观测和位姿只保留了前 32 个。原 32 个场景的两组均通过。补充检查保留自适应损失的全部参数，使用两个相同接口、不同随机种子的完整档案，各取实际保存的 32 个场景。启动前已核验动作、回报、策略及价值输入、终止和位姿的维度。 [中止日志](adaptive-replay-execution.log) · [补充方案](../../../configs/experiments/getup_adaptive_replay_archives.json)

| 随机种子 | 组别 | 接受次数 | 最大 RMS（rad） | 最大单关节偏差（rad） |
| --- | --- | ---: | ---: | ---: |
| 43 | 对照 | 32/32 | 0.03862 | 0.21872 |
| 43 | 候选 | 32/32 | 0.03853 | 0.21902 |
| 42 | 对照 | 32/32 | 0.03792 | 0.22711 |
| 42 | 候选 | 32/32 | 0.03792 | 0.23540 |

四组均未减步幅。零新物理步、零权重输出、未使用留出。 [补充日志](adaptive-archive-execution.log) · [逐次结果](adaptive-replay-archives.json)
