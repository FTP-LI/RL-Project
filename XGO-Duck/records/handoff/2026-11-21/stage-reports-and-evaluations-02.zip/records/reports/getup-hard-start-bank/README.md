# 仰卧困难初态库

本库从五个开发种子的第零步记录提取原始跌落高度和朝向。每个困难初态配一个同种子、同为指定与实际仰卧的成功初态。按高度和机身坐标系中的重力方向匹配，成功初态互不复用。 [冻结规则](../../../configs/experiments/getup_supine_hard_start_bank.json) · [逐对来源](analysis.json)

共 45 对。主要种子 1157 提供 37 对，另四个开发种子提供 8 对。配对高度差均值约 0.149 mm，重力方向夹角均值约 0.126°。训练前需用新随机种子核对失败率差，并单列另外四个种子的配对方向。本库属于课程准备，正式独立评价仍使用原跌落分布与原四姿态标准。 [三组筛查草案](../../../configs/experiments/getup_supine_hard_start_screen_draft.json)

在工程根目录设置 `PYTHONPATH=scripts/training`，使用现有 WSL Python 运行 [提取入口](../../../scripts/validation/build_getup_hard_start_bank.py)。已生成的记录以只读方式复核。
