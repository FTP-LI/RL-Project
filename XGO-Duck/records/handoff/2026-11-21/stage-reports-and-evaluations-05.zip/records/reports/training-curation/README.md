# 训练产物保留索引

本页用于查找保留的权重、录像和训练证据。10 个交付权重已重新核对来源字节，包括 4 个官方参照和 6 个自训开发文件。当前任务与动作验收状态见[当前目标](../../../docs/current_goal.md)和[权重索引](../../../artifacts/delivery/iteration_record.md)。

以下模型选择和清理数据记录的是 2026-11-09 当时的状态；后续模型及最终留出结果以当前目标和权重索引为准。最新空间盘点见[训练资料存储盘点](../storage-review-20261114/README.md)。

盘点覆盖 Windows 工程记录、模型交付目录、官方参照与专属 WSL 训练日志，清理前共有 325 个权重和模型文件。已删除 36 份中间保存点，共回收 166.3 MiB 文件空间。其中 129.3 MiB 位于 WSL 文件系统，37.0 MiB 位于 Windows 工程。清理后逐个核对其余 289 个文件的 SHA-256，原始录像和轨迹数量一致。 [清理清单](plan.json) · [执行回执](result.json) · [核验结果](verification.json)

## 优先使用的模型

| 动作 | 模型入口 | 已核验的范围 |
| --- | --- | --- |
| 站立、前后走、左右转、左右移 | [官方权重与指令映射、转向反馈](../../../artifacts/simulation/duck_walk_command-gyro_reference_20261103/README.md) | 原行走环境七指令 672/672。共同接口独立留出后退 30/32，后续开发保留后退成绩，仍在核对右转启动。 [七指令结果](../seven-command/confirmation-summary.json) · [共同接口留出](../common-walk-actuator-yaw-feedback-heldout/README.md) |
| 跌倒后起身 | [仰卧加权训练候选](../../../artifacts/duck_getup_supine-weighted_candidate_s45_20261109T211329/policy.onnx) · [官方起身参照](../../../official_resources/xgoduck_runtime_arduino/python/xgoduck_getup.onnx) | 同批独立开发评估中，候选 310/320，父模型 303/320，等权续训 302/320。实际仰卧 180/186，指定仰卧 30/32、实际右侧 37/41 仍未达标。 [结果和完整原片](../getup-supine-weighted-learning/README.md) |
| 前滚翻 | [官方滚翻模型](../../../official_resources/xgoduck_runtime_arduino/python/xgoduck_roulade.onnx) | 对齐接触读数后，开发与独立留出各 117/128，通过单动作门槛。较早的 112/128 留出按原判据保留。 [独立确认](../roll-endpoint-confirmation/README.md) · [较早留出](../roll-common-confirmation/rng-recovery/analysis.json) |

## 值得保留的资料

- 仿真使用上表的模型入口。恢复学习使用带优化器和归一化状态的 `.pt`，例如 [5000 次更新的行走基线](../../../artifacts/recovery/baseline_continuation_20261101T101809_s42/model_4999.pt) 和[仰卧加权候选最终点](../../experiments/duck_getup_supine-weighted_candidate_s45_20261109T211329/model-final.pt)。完整模型索引记录原路径与 SHA-256。
- 早期并脚、头部补偿和奖励修改保留对照权重、评估指标、训练曲线和代表性录像，便于复核为何停止。 [训练复盘](../training-review/history-audit.json) · [全部录像总览](../../../docs/reports/assets/all-video-overview.jpg)
- 保留逐帧评估轨迹、场景状态、冻结协议和审计输入。起身的离线灵敏度检查在保存轨迹上将脚掌接触全部视为满足，仍只有 310/320；原评估分数与判据保留。 [灵敏度证据](../getup-contact-sensitivity/analysis.json)
- 历史文件名和媒体链接沿用原位置。按训练主题查找时优先使用[全流程报告](../../../docs/reports/development_report.md)和[运行目录索引](../../../configs/experiments/run_catalog.json)。

## 清理范围

| 来源 | 删除文件数 | 保留依据 |
| --- | ---: | --- |
| 行走基线续训 | 16 | 删除 WSL 中间副本。Windows 保留同哈希备份，供历史核验逐个读取。 |
| 基线追加 | 2 | 保留首个点及最近两个恢复点。 |
| 并脚修复对照 | 11 | 保留两组起点、最近恢复点、导出与评估资料。 |
| 头部指令对照 | 7 | 保留中断后实际续训的父点、两组最终点及对照资料。 |

已删点的原始检查记录仍可查看。清单为每个删除项登记绝对路径、哈希、后续保留点及历史引用。逐帧轨迹用于重新计算成绩和回放失败场景，集中在 `records/evaluations/`，继续按原路径保留。Windows 与 WSL 的空间统计分别记录。

该核验命令对应清理完成时的文件快照。新增交付权重后的核验入口见[训练记录归档](../../training-archive/README.md)。

```bash
python3 -B scripts/validation/curate_training_checkpoints.py verify
```

## 训练与评估目录核查

2026-11-09 统计两个目录内的普通文件。逻辑大小按 GiB 计，重复量以相同类型、字节长度和 SHA-256 分组，每组扣除一份。重复量用于定位可归档对象，实际取舍还需查路径依赖。

| 目录 | 文件数 | 总大小 | `.npz` 大小 | 主要内容 |
| --- | ---: | ---: | ---: | --- |
| `records/evaluations/` | 6,075 | 6.70 GiB | 6.47 GiB | 逐帧轨迹、场景状态、评分和录像 |
| `records/experiments/` | 3,524 | 1.33 GiB | 0.79 GiB | 训练样本、更新轨迹、保存点、日志和配置 |

- 日常看结果或运行模型，需要模型与配置、成绩摘要、报告引用的录像。继续训练还需保留起点、最终及实际使用的恢复点。复算成绩或回放失败时，才会逐帧读取 `.npz`。抽查滚翻开发种子 1025 的三份轨迹与接触文件，实际 SHA-256 均与核验记录一致。起身四份 `value-data.npz` 合计约 590 MiB，已用于训练或比较中的价值函数探针。 [滚翻核验入口](../../../scripts/validation/verify_roll_endpoint_readback.py) · [起身探针配置](../../../configs/experiments/getup_recovery_retention.json)
- 两目录共发现 5,095 份内容重复的额外副本，合计 148.9 MiB。其中 4,160 份 Python 源码快照只占 34.8 MiB，主要影响浏览。重复日志也有路径依赖，例如旧基线的 `training.log` 与 `training-prefix.log` 哈希相同，收尾核验仍按原路径比较两份文件。 [日志核验入口](../../../scripts/validation/complete_continuation_record.py)
- 已结束且无当前流程依赖的历史批次适合按批归档。逐项记录原路径、哈希和恢复方式，保留报告引用的原片和能复算关键结论的完整轨迹。需要节省较多空间时，先审查旧批次的大轨迹与样本。重复源码快照主要影响文件数。核查未移动或删除两个目录中的文件。
