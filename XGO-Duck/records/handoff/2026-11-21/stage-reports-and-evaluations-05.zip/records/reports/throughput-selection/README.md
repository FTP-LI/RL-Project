# 吞吐与可观察性选择

这份记录把本机 CUDA 并行规模、观察器驱动、状态采样、显存、CPU、主机内存、视频和逐轮日志放在同一个可复核入口。它只决定后续实验的运行配方，不决定模型优劣，也没有改变正式训练预算。

行走规模使用同一父 checkpoint、同一 seed、24 步 rollout、四个 PPO 小批量和同一锁定依赖，顺序为 1024→2048→4096→4096→2048→1024。热身后固定统计 20 次完整更新。1,024、2,048、4,096 环境的转移吞吐分别为 9.86–10.05k、16.08–16.30k、23.98–24.58k/s；4,096 相对 1,024 的几何均值比为 2.439。最高显存 4,630 MiB，占 16 GiB 的 28.3%，CPU 约 100%，最小可用主机内存约 29 GiB；六次运行均退出 0、有限值通过、checkpoint 和配置审计通过。后续官方行走短训采用 4,096 环境。

可观察性使用相同父点和 40 次诊断更新，两遍顺序比较默认 llvmpipe、D3D12 + 4 Hz、D3D12 + 15 Hz。D3D12 + 4 Hz 的两遍吞吐为 18.35–18.38k/s，实际状态采样为 2.25–2.29 Hz，显存约 5,393 MiB，每遍保存 200 帧视频、progress、telemetry、逐轮计时和命令日志。D3D12 相对默认 llvmpipe 的几何均值比为 1.530；15 Hz 没有通过更高观察频率门槛，因此以后观察训练过程使用 D3D12 + 4 Hz。验证记录说明这里测的是实际状态更新和原片写出，未把原生显示器刷新率当作训练吞吐。

独立查看入口：

- [吞吐选择 JSON](selection.json)
- [行走规模原始复核](../../benchmarks/scale_20261101T154057_s42/verification.json)
- [观察器原始复核](../../benchmarks/observer_20261101T201418_s42/verification.json)
- [行走吞吐曲线](../../benchmarks/scale_20261101T154057_s42/figures/throughput.png)
- [观察器性能曲线](../../benchmarks/observer_20261101T201418_s42/figures/observer-performance.png)
- [D3D12 + 4 Hz 第一遍进度](../../benchmarks/observer_20261101T201418_s42/trial-02-gpu4/progress.json)
- [D3D12 + 4 Hz 第一遍原片](../../benchmarks/observer_20261101T201418_s42/trial-02-gpu4/training-env0.mp4)
- [VS Code 可见任务截图](../../benchmarks/observer_20261101T201418_s42/vscode-visible-task.png)

已完成的批次仍保留其 `protocol.json`、`console.log`、`telemetry.jsonl`、`iteration-timing.jsonl`、progress、原片、checkpoint 哈希和 verifier 输出；没有删除中间证据。
